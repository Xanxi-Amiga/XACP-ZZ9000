Place your own legally obtained Mega-CD / Sega CD BIOS files in this drawer.
For recognized BIOS filenames and region selection, see README.md.
No BIOS files or game data are included.
