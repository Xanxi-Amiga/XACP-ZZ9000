#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later
#
# build_arm.sh - ZZHalfLife 1.0: Core1 images of Half-Life (Xash3D FWGS, HLSDK-portable
# game code, ref_gl on ZZGL/librixgpu) for the ZZ9000 RasterIX GPU, XACP 1.8 / XX19d-RIX.
#
#   XASH3D=/path/to/xash3d-fwgs  HLSDK=/path/to/hlsdk-portable \
#   ZZQUAKE_RELEASE=/path/to/ZZQuake640_Core1  sh build_arm.sh
#
# XASH3D          : FWGS/xash3d-fwgs at commit 27092af50d912432887faa43a1cccddfae569b2d
#                   (submodules: 3rdparty/mainui, library_suffix, miniz vendored, MultiEmulator)
# HLSDK           : FWGS/hlsdk-portable at commit 8a09758d2912d278423870391f6c25995de0000b
#                   (submodule: freevgui 73bfb4659f3d9eb28b79e5b26baea8c6b888d5eb)
# ZZQUAKE_RELEASE : the ZZQuake640 release Core1 tree (boot, MMU, shared protocol, services),
#                   compiled from where it is, unmodified, as ZZQuake2 does.
# ARMBIN          : folder of arm-none-eabi-gcc 13.2.1. Default: the MSYS install
#                   "C:/ArmGNUToolchain/13.2 Rel1/bin" when it exists, else the PATH.
# ZZHL_RES        : 640 (default), 320 or 800: size of the screen the blob draws for.
# TRIAGE=1        : do not stop at the first compile error (audit mode), list failures.
#
# Everything is relative to this folder (ZZGear / ZZQuake2 convention), no path conversion.
# Nothing outside this folder is modified. Offline. ASCII only.

set -e
export SOURCE_DATE_EPOCH=1
export LC_ALL=C
cd "$(dirname "$0")"

[ -n "$XASH3D" ] || XASH3D="../../../../xash3d-fwgs"
[ -n "$HLSDK" ]  || HLSDK="../../../../hlsdk-portable"
[ -n "$ZZQUAKE_RELEASE" ] || ZZQUAKE_RELEASE="../ZZQuake2/source/ZZQuake2_sources/ZZQuake640_Core1"
X="$XASH3D"; H="$HLSDK"
B="build"; OUT="out"
fail() { echo "ERROR: $*"; exit 1; }

case "${ZZHL_RES:-640}" in
    640) RESX=640; RESY=480; NAME="zzhl"; CORE="zzhl_core"; RESD="" ;;
    320) RESX=320; RESY=240; NAME="zzhl_320"; CORE="zzhl_core_320"; RESD="-DZZQ2_VID_W=320 -DZZQ2_VID_H=240 -DZZHL_BLOB_320=1" ;;
    # 800 x 600, the frames in two 800 x 601 buffers of the GPU window (Core1/zzhl_gpu.c,
    # ZZQ2_VID_W > 640: the layout ZZOpenLara's 800 build runs on the A4000, rix_set_geometry)
    800) RESX=800; RESY=600; NAME="zzhl_800"; CORE="zzhl_core_800"; RESD="-DZZQ2_VID_W=800 -DZZQ2_VID_H=600 -DZZHL_BLOB_800=1" ;;
    *)   fail "ZZHL_RES: '$ZZHL_RES' (640, 320 or 800)" ;;
esac

# ---- tools -------------------------------------------------------------
if [ -z "$ARMBIN" ] && [ -x "C:/ArmGNUToolchain/13.2 Rel1/bin/arm-none-eabi-gcc.exe" ]; then
    ARMBIN="C:/ArmGNUToolchain/13.2 Rel1/bin"
fi
if [ -n "$ARMBIN" ]; then
    E=""; [ -x "$ARMBIN/arm-none-eabi-gcc.exe" ] && E=".exe"
    AGCC="$ARMBIN/arm-none-eabi-gcc$E"; AGXX="$ARMBIN/arm-none-eabi-g++$E"
    ALD="$ARMBIN/arm-none-eabi-ld$E"; ANM="$ARMBIN/arm-none-eabi-nm$E"
    AOBJCOPY="$ARMBIN/arm-none-eabi-objcopy$E"; AOBJDUMP="$ARMBIN/arm-none-eabi-objdump$E"
    AREADELF="$ARMBIN/arm-none-eabi-readelf$E"; ASIZE="$ARMBIN/arm-none-eabi-size$E"
else
    AGCC=arm-none-eabi-gcc; AGXX=arm-none-eabi-g++; ALD=arm-none-eabi-ld; ANM=arm-none-eabi-nm
    AOBJCOPY=arm-none-eabi-objcopy; AOBJDUMP=arm-none-eabi-objdump
    AREADELF=arm-none-eabi-readelf; ASIZE=arm-none-eabi-size
fi
"$AGCC" --version >/dev/null 2>&1 || fail "arm-none-eabi-gcc not found (ARMBIN='$ARMBIN')"
if command -v python3 >/dev/null 2>&1; then PY=python3; else PY=python; fi
[ -d "$X/engine" ] || fail "XASH3D: no xash3d-fwgs tree at $X"
[ -d "$H/dlls" ]   || fail "HLSDK: no hlsdk-portable tree at $H"
[ -f "$X/3rdparty/library_suffix/include/buildenums.h" ] || fail "xash3d-fwgs: submodule 3rdparty/library_suffix missing"
[ -f "$H/freevgui/vgui.cpp" ] || fail "hlsdk-portable: submodule freevgui missing"

echo "== ZZHalfLife A0: $NAME (${RESX}x${RESY}, RasterIX) =="
echo "  xash3d-fwgs    : $X"
echo "  hlsdk-portable : $H"
echo "  release Core1  : $ZZQUAKE_RELEASE"
rm -rf "$B"; mkdir -p "$B/engine" "$B/fs" "$B/ref" "$B/sv" "$B/cl" "$B/vgui" "$B/menu" "$B/xacp" "$B/log" "$OUT"

# ---- flags -------------------------------------------------------------
# Same FPU / ABI as every ZZ blob: VFPv3-d16 hard float, no NEON, no unaligned access,
# no short enums (the release runtime objects are built so too).
ARCH="-mcpu=cortex-a9 -marm -mfpu=vfpv3-d16 -mfloat-abi=hard -mno-unaligned-access -fno-short-enums"
OPT="-O2 -fno-strict-aliasing -fwrapv -fno-tree-vectorize -ffunction-sections -fdata-sections \
-fno-unwind-tables -fno-asynchronous-unwind-tables"
PMAP="-ffile-prefix-map=$X=xash3d -ffile-prefix-map=$H=hlsdk -ffile-prefix-map=$B=build"
# Engine configuration (see docs/AUDIT.md): static game libraries, no network, no libdl,
# miniz as zlib, console build (no SDL), platform XACP from xacp/include/build.h.
# XASH_SOUND=4: the XACP backend (xacp/src/xacp_snd.c, the launcher's PCM ring / AHI); 0 = none.
# XASH_REF_GL_ENABLED=1 is what waf's configure defines for the engine (define_cond in wscript):
# without it R_CollectRendererNames() has an empty list and R_Init() dies with "Can't initialize
# any renderer" before even trying ref_gl (A0 build 2 hardware run).
XDEF="-DXASH_NO_NETWORK=1 -DXASH_STATIC_LIBS=1 -DXASH_NO_LIBDL=1 -DXASH_LOW_MEMORY=0 \
-DXASH_MINIZ=1 -DMINIZ_NO_ARCHIVE_APIS=1 -DXASH_BUILD_COMMIT=\"27092af\" -DXASH_BUILD_BRANCH=\"master\" -DXASH_BUILD_COMMIT_DATE=\"2026-10-26\" \
-DNDEBUG=1 -DXASH_VIDEO=5 -DXASH_INPUT=0 -DXASH_SOUND=4 -DXASH_TIMER=2 -DXASH_MESSAGEBOX=5 -DXASH_REF_GL_ENABLED=1 -DXASH_GAMEDIR=\"valve\" \
-DHAVE_STRNCASECMP=1 -DHAVE_STRCASECMP=1 -DHAVE_STRLCPY=1 -DHAVE_STRLCAT=1 -DHAVE_STRNLEN=1 \
-DALLOCA_H=<alloca.h>"
XINC="-Ixacp/include -I$X/engine -I$X/engine/common -I$X/engine/common/imagelib -I$X/engine/server \
-I$X/engine/client -I$X/engine/client/vgui -I$X/engine/common/soundlib -I$X/engine/platform \
-I$X/public -I$X/common -I$X/filesystem -I$X/pm_shared -I$X/3rdparty/library_suffix/include \
-I$X/3rdparty/miniz -I$X/3rdparty/MultiEmulator/include -I$X/3rdparty/MultiEmulator/src"
RINC="-Ixacp/include -I$X/ref/common -I$X/ref/gl -I$X/engine -I$X/engine/common -I$X/engine/common/imagelib \
-I$X/filesystem -I$X/public -I$X/common -I$X/pm_shared -I$X/3rdparty/library_suffix/include"
CWARN="-w"
ENGFLAGS="$ARCH $OPT $CWARN $XDEF -DENGINE_DLL=1 -include xacp/include/xacp_pre.h $XINC $PMAP"
REFFLAGS="$ARCH $OPT $CWARN $XDEF -DREF_DLL=1 $RINC $PMAP"
# HLSDK, as its own waf build does on non-Windows (hlsdk-portable/wscript + mod_options.txt)
HDEF="-DXACP_HLSDK=1 -DCLIENT_WEAPONS=1 -DCROWBAR_FIX_RAPID_CROWBAR=1 -DSPEAKABLE_TARGETS=1 -DHD_HUD_DEFAULT=1 \
-Dstricmp=strcasecmp -Dstrnicmp=strncasecmp -D_snprintf=snprintf -D_vsnprintf=vsnprintf -D_LINUX=1 -DLINUX=1 \
-DHAVE_STRLCPY=1 -DHAVE_STRLCAT=1 -DNDEBUG=1"
HINC="-include xacp/include/build.h -Ixacp/include -I$H/common -I$H/engine -I$H/public -I$H/pm_shared -I$H/game_shared -I$H/dlls -I$H/utils/vgui/include"
CXXOPT="-std=gnu++11 -fno-exceptions -Wno-invalid-offsetof"
SVFLAGS="$ARCH $OPT $CWARN $CXXOPT $HDEF $HINC $PMAP"
CLFLAGS="$ARCH $OPT $CWARN $CXXOPT $HDEF -DCLIENT_DLL=1 -DINTERNAL_VGUI_SUPPORT=1 $HINC -I$H/cl_dll -I$H/cl_dll/hl $PMAP"
# FWGS mainui (3rdparty/mainui, the menu: GPL v2 or later), as its wscript builds it for
# the consoles: stb_truetype fonts, its own font renderer, no RTTI.  newlib's int32_t is long int,
# which mainui's overloads (CNumStr, int& of GetCharABCWidths) do not expect: inside mainui only,
# int32_t/uint32_t are int/unsigned int (same size and calling convention on ARM; its exports are C
# functions and C structs); the 64-bit printf macros from xacp_pre.h as for the engine.
MN="$X/3rdparty/mainui"
MENUFLAGS="$ARCH $OPT $CWARN $CXXOPT -fno-rtti -DSTDINT_H=<cstdint> -DMAINUI_USE_CUSTOM_FONT_RENDER=1 -DMAINUI_USE_STB=1 -DNDEBUG=1 \
-U__INT32_TYPE__ -D__INT32_TYPE__=int -U__UINT32_TYPE__ -D__UINT32_TYPE__=unsigned \
-include xacp/include/xacp_pre.h -include xacp/include/build.h -Ixacp/include -I$MN -I$MN/miniutl -I$MN/font -I$MN/controls \
-I$MN/menus -I$MN/model -I$MN/sdk_includes/common -I$MN/sdk_includes/engine -I$MN/sdk_includes/public -I$MN/sdk_includes/pm_shared $PMAP"
VGFLAGS="$ARCH $OPT $CWARN $CXXOPT -DXACP_HLSDK=1 -DINTERNAL_VGUI_SUPPORT=1 -include xacp/include/build.h -Ixacp/include -I$H/freevgui -I$H/utils/vgui/include -I$H/engine -I$H/common -I$H/public $PMAP"

FAILED=""; NOBJ=0
cc1() {  # cc1 <compiler> <flags> <src> <obj>
    if "$1" $2 -c "$3" -o "$4" 2> "$B/log/$(basename "$4" .o).log"; then
        rm -f "$B/log/$(basename "$4" .o).log"; NOBJ=$((NOBJ + 1))
    else
        if [ "${TRIAGE:-0}" = 1 ]; then FAILED="$FAILED $3"; else cat "$B/log/$(basename "$4" .o).log"; fail "compile failed: $3"; fi
    fi
}
oname() { echo "$1" | sed "s#^$X/##; s#^$H/##; s#^xacp/src/##" | tr '/.' '__'; }

# ---- 0. static library tables (engine/platform/misc/lib_static.c, as waf's xshlib.py) ----
# The engine "loads" filesystem_stdio, ref_gl, client and server through name tables instead
# of dlopen (XASH_STATIC_LIBS). The tables themselves are generated after the partial links
# (step 7), this header only lists the libraries.
mkdir -p "$B/gen"
cat > "$B/gen/generated_library_tables.h" <<'GEOF'
/* generated by build_arm.sh: static library list for lib_static.c (ZZHalfLife) */
extern table_t lib_filesystem_stdio_exports[];
extern table_t lib_ref_gl_exports[];
extern table_t lib_menu_exports[];
/* build 103: client and server live in the game image (zzhl_game.bin, xacp/src/xacp_game.c),
   which hands its two tables over when it is loaded, before Host_Main */
struct { const char *name; void *func; } libs[] = {
{ "filesystem_stdio", &lib_filesystem_stdio_exports },
{ "ref_gl", &lib_ref_gl_exports },
{ "client", 0 },
{ "server", 0 },
{ "menu", &lib_menu_exports },
{ 0, 0 }
};
void zzhl_game_libs_set( void *client, void *server ) { libs[2].func = client; libs[3].func = server; }
GEOF
ENGFLAGS="$ENGFLAGS -I$B/gen"

# ---- 0b. con_utils.c: the console completion must not read the maps (build 63) ----
# Cmd_ListMaps() is called with silent = 1 by Cmd_GetMapList() <- Con_CompleteCommand(field, false)
# <- Con_InputCompletion(), which runs after EVERY key typed in the console.  Upstream opens each
# maps/*.bsp inside pak0.pak, validates its lumps, looks for a .ent file and reads and parses the
# whole entity lump to get a title that is thrown away when silent.  ~90 maps in pak0.pak = tens of
# MiB read per key pressed: on the A4000 the game froze for seconds and the log filled with
# "short READAT, retrying: valve/pak0.pak".  The upstream tree stays untouched:
# the patched copy is generated here, with the same count-and-check rule as quakegeneric.h below.
$PY - "$X/engine/common/con_utils.c" "$B/gen/con_utils.c" <<'PYCONEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
old = "\t\tif( Q_stricmp( ext, \"bsp\" )) continue;\n"
new = old + """\t\t/* ZZHalfLife build 63: when silent, NOTHING read from the map is used.  The caller wants
\t\t   only the number of maps and the name of the last one, so the file is not opened at all.
\t\t   Difference with upstream, stated plainly: a .bsp that fails Mod_TestBmodelLumps() is
\t\t   counted here and skipped there.  The printing path below is untouched. */
\t\tif( silent )
\t\t{
\t\t\tCOM_FileBase( t->filenames[i], mapname, sizeof( mapname ));
\t\t\tnummaps++;
\t\t\tcontinue;
\t\t}
"""
if g.count(old) != 1:
    raise SystemExit('con_utils.c: unexpected content (upstream moved?)')
g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYCONEOF
[ -s "$B/gen/con_utils.c" ] || fail "con_utils.c: the patched copy was not generated"

# ---- 0b2. host.c: userconfig.cfg must not depend on config.cfg (build 70) ----
# Upstream never execs userconfig.cfg from the startup path.  The ONLY thing that runs it is the
# last line the engine itself writes into config.cfg (con_utils.c:1442, FS_Printf "exec
# userconfig.cfg").  Three ways that silently loses the user's bindings, all seen on the A4000:
#     14/11: no "execing userconfig.cfg" in the log at all, F7/F8 back to the engine defaults);
#   - the config.cfg that ships inside pak0.pak, which has no such line (it is Xash's own, not
#     Valve's), so the first run after deleting PROGDIR:data/config.cfg would ignore userconfig.cfg;
#   - any future damage to that one file.
# We exec it here instead, beside the userconfig.d directory that upstream already execs, so the
# bindings depend on nothing but their own file.  Running it twice is harmless: bind, alias and
# cvar lines are idempotent.
$PY - "$X/engine/common/host.c" "$B/gen/host.c" <<'PYHOSTEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
old = """\t\t// exec all files from userconfig.d
\t\tCbuf_AddText( "userconfigd\\n" );
\t\tCbuf_Execute();
"""
new = old + """
\t\t/* Load the optional user configuration independently of the engine-generated config file. */
\t\tif( FS_FileExists( "userconfig.cfg", false ))
\t\t{
\t\t\tCbuf_AddText( "exec userconfig.cfg\\n" );
\t\t\tCbuf_Execute();
\t\t}
"""
if g.count(old) != 1:
    raise SystemExit('host.c: unexpected content (upstream moved?)')
g = g.replace(old, new)

# build 80: one call a frame so a change of MP3Volume reaches the 68k launcher, which owns the
# MP3 playback.  The poll itself is in cl_cmds.c, where s_musicvolume is in scope; here we only
# call it.  It costs one float compare per frame and writes the queue only on a real change.
old2 = """\tHost_ClientFrame (); // client frame
\tHTTP_Run();\t\t\t // both server and client
"""
new2 = """\tHost_ClientFrame (); // client frame
\t{   /* ZZHalfLife build 80: MP3Volume to the launcher (cl_cmds.c) */
\t\textern void zzhl_music_volume_poll( void );
\t\tzzhl_music_volume_poll();
\t}
\tHTTP_Run();\t\t\t // both server and client
"""
if g.count(old2) != 1:
    raise SystemExit('host.c: Host_Frame moved, the MP3 volume poll has no anchor')
g = g.replace(old2, new2)

# build 84: the engine's time before the 3D scene, split.  "engine" was one number (6 to 10 ms on
# the frames over 45 ms, docs/PERF.md 15.1) holding the server, the client and the sound mix
# together.  zzhl_host_mark (Core1/zzhl_gpu.c) reads the timer twice a frame.
old3 = """\tHost_ServerFrame (); // server frame
\tHost_ClientFrame (); // client frame
"""
new3 = """\t{   /* ZZHalfLife build 84: the server's time, then the client's up to the 3D scene */
\t\textern void zzhl_host_mark( unsigned what );
\t\tzzhl_host_mark( 0 );
\t\tHost_ServerFrame (); // server frame
\t\tzzhl_host_mark( 1 );
\t}
\tHost_ClientFrame (); // client frame
"""
if g.count(old3) != 1:
    raise SystemExit('host.c: Host_Frame moved, the server/client marks have no anchor')
g = g.replace(old3, new3)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYHOSTEOF
[ -s "$B/gen/host.c" ] || fail "host.c: the patched copy was not generated"

# ---- 0b3. cmd.c: a command line too long must say WHICH line (build 70) ----
# MAX_CMD_LINE is 2048.  A line longer than that is thrown away whole (line[0] = 0) behind a
# Con_DPrintf, i.e. invisible at the default developer level: the uplink log of 14/11 only says
# "command string owerflow" while execing config.cfg, with no way to know what the line was.
# Diagnostic only - the control flow is left exactly as upstream.
$PY - "$X/engine/common/cmd.c" "$B/gen/cmd.c" <<'PYCMDEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
old = """\t\tif( i >= ( MAX_CMD_LINE - 1 ))
\t\t{
\t\t\tCon_DPrintf( S_ERROR "%s: command string owerflow\\n", __func__ );
\t\t\tline[0] = 0;
\t\t}
"""
new = """\t\tif( i >= ( MAX_CMD_LINE - 1 ))
\t\t{
\t\t\t/* ZZHalfLife build 70: upstream drops the line behind a Con_DPrintf, so a damaged
\t\t\t   config leaves no trace of what was lost.  Same control flow, but the start of the
\t\t\t   offending line is printed.  Non-printable bytes are shown as dots. */
\t\t\tchar zzhl_head[65];
\t\t\tint zzhl_n;
\t\t\tfor( zzhl_n = 0; zzhl_n < 64; zzhl_n++ )
\t\t\t{
\t\t\t\tunsigned char zzhl_c = (unsigned char)text[zzhl_n];
\t\t\t\tzzhl_head[zzhl_n] = ( zzhl_c >= ' ' && zzhl_c < 127 ) ? (char)zzhl_c : '.';
\t\t\t}
\t\t\tzzhl_head[64] = 0;
\t\t\tCon_Printf( S_ERROR "%s: a command line of %i bytes is longer than the %i the engine accepts, it is DROPPED. It starts with: %s\\n",
\t\t\t\t__func__, i, MAX_CMD_LINE - 1, zzhl_head );
\t\t\tline[0] = 0;
\t\t}
"""
if g.count(old) != 1:
    raise SystemExit('cmd.c: unexpected content (upstream moved?)')
g = g.replace(old, new)

# build 81: the overflow message must say WHICH of the two sides is big.
# sessions (13/11, 14/11, 15/11) and me two wrong diagnoses, because the test it reports is
#     if(( buf->cursize + requested_len ) >= sizeof( buf->data ))   /* 32768 */
# and the message names neither number.  A big FILE and an already-full BUFFER produce the
# same words and need opposite fixes.  Print both, plus the file's own size, and the next run
# settles it instead of me guessing.  Measured, not deduced - the rule of this project.
old2 = """\tif( !inserted )
\t\tCon_Printf( S_ERROR "%s: command buffer overflow, %s is not executed\\n", __func__, filename );
"""
new2 = """\tif( !inserted )
\t\tCon_Printf( S_ERROR "%s: command buffer overflow, %s is not executed"
\t\t\t" (ZZHalfLife build 81: file %d bytes, buffer %d of %d used, so %d free)\\n",
\t\t\t__func__, filename, (int)len, (int)cmd_text.cursize, (int)sizeof( cmd_text.data ),
\t\t\t(int)( sizeof( cmd_text.data ) - cmd_text.cursize ));
"""
if g.count(old2) != 1:
    raise SystemExit('cmd.c: the overflow message moved, build 81 instrumentation has no anchor')
g = g.replace(old2, new2)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYCMDEOF
[ -s "$B/gen/cmd.c" ] || fail "cmd.c: the patched copy was not generated"

# ---- 0c. gl_rmain.c: where ref_gl's own time goes (build 63) ----
# Our report gives ref_gl as a residual (everything between GL calls): 11,8 ms on a heavy frame of
# c2a5f (A4000, 14/11) without saying which phase spends it.  Before optimising anything in ref_gl
# we measure it: zzhl_refphase() (Core1/zzhl_gpu.c) is called at each phase boundary of
# R_RenderScene.  The upstream tree stays untouched; the patched copy is generated here.
$PY - "$X/ref/gl/gl_rmain.c" "$B/gen/gl_rmain.c" <<'PYRMEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
D = "\textern void zzhl_refphase( unsigned slot );   /* ZZHalfLife build 63 */\n\textern void zzhl_world_done( void );           /* build 84: EARLY=1, xacp_glq.c */\n"
subs = (
    ("\ttr.dlightframecount = R_PushDlights( WORLDMODEL, tr.framecount );",
     D + "\tzzhl_refphase( 0 );\n\ttr.dlightframecount = R_PushDlights( WORLDMODEL, tr.framecount );"),
    ("\tR_DrawWorld();",            "\tzzhl_refphase( 1 );\n\tR_DrawWorld();\n\tzzhl_refphase( 4 );\n\tzzhl_world_done();"),
    ("\tR_DrawEntitiesOnList();",   "\tzzhl_refphase( 2 );\n\tzzhl_entphase( 6 );\n\tR_DrawEntitiesOnList();\n\tzzhl_entphase( 0 );\n\tzzhl_refphase( 4 );"),
    ("\tR_DrawWaterSurfaces();",    "\tzzhl_refphase( 3 );\n\tR_DrawWaterSurfaces();\n\tzzhl_refphase( 5 );"),
)
for old, new in subs:
    if g.count(old) != 1:
        raise SystemExit('gl_rmain.c: unexpected content (upstream moved?): ' + old.strip())
    g = g.replace(old, new)

# build 64: inside the entity loops.  Each call appears twice (solid list, then the
# transparent list); both are wrapped, which is what we want.
D2 = "extern void zzhl_entphase( unsigned slot );   /* ZZHalfLife build 64 */\n"
g = g.replace("\nstatic void R_DrawEntitiesOnList( void )", "\n" + D2 + "static void R_DrawEntitiesOnList( void )", 1)
for call, slot in (("R_DrawBrushModel( RI.currententity );",  "4"),
                   ("R_DrawSpriteModel( RI.currententity );", "5"),
                   ("R_DrawStudioModel( RI.currententity );", "9")):
    if g.count(call) != 2:
        raise SystemExit('gl_rmain.c: expected 2 of ' + call)
    g = g.replace(call, "{ zzhl_entphase( " + slot + " ); " + call + " zzhl_entphase( 6 ); }")
if g.count("gEngfuncs.CL_DrawEFX( tr.frametime, false );") != 1:
    raise SystemExit('gl_rmain.c: CL_DrawEFX moved')
g = g.replace("gEngfuncs.CL_DrawEFX( tr.frametime, false );",
              "{ zzhl_entphase( 7 ); gEngfuncs.CL_DrawEFX( tr.frametime, false ); zzhl_entphase( 6 ); }")

# build 84: what "dispatch" swallowed (docs/PERF.md 15.2).  Only the first CL_DrawEFX had markers:
# the second one (particles, beams, tracers), the client's own triangles and the view model were
# all charged to "dispatch", 9 to 23 ms on the frames over 45 ms and never opened.  The view model
# also raises a flag: its meshes go through the studio path, whose own markers would otherwise
# count them with the other models (zzhl_origin_now, Core1/zzhl_gpu.c).
D3 = "extern void zzhl_org_viewmodel( int on );      /* ZZHalfLife build 84 */\n"
g = g.replace("\n" + D2, "\n" + D2 + D3, 1)
for call, pre, post in (
        ("gEngfuncs.CL_DrawEFX( tr.frametime, true );",   "zzhl_entphase( 14 ); ", " zzhl_entphase( 6 );"),
        ("gEngfuncs.pfnDrawNormalTriangles();",           "zzhl_entphase( 15 ); ", " zzhl_entphase( 6 );"),
        ("gEngfuncs.pfnDrawTransparentTriangles ();",     "zzhl_entphase( 15 ); ", " zzhl_entphase( 6 );"),
        ("R_DrawViewModel();",                            "zzhl_org_viewmodel( 1 ); zzhl_entphase( 16 ); ", " zzhl_entphase( 6 ); zzhl_org_viewmodel( 0 );")):
    if g.count(call) != 1:
        raise SystemExit('gl_rmain.c: expected 1 of ' + call)
    g = g.replace(call, "{ " + pre + call + post + " }")
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYRMEOF
[ -s "$B/gen/gl_rmain.c" ] || fail "gl_rmain.c: the patched copy was not generated"

# ---- 0c2. gl_warp.c: the sky box says it is the sky (build 84) ----
# R_DrawSkyBox is called from inside R_DrawWorld, so its quads would be counted with the world's.
# The sky is the one thing that is always at the far end of the picture: its pixels and its six
# 256x256 binds are worth a line of their own in the load by origin (xacp/include/zzhl_fx.h).
$PY - "$X/ref/gl/gl_warp.c" "$B/gen/gl_warp.c" <<'PYWARPEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
subs = (
    ("void R_DrawSkyBox( void )\n{\n",
     "void R_DrawSkyBox( void )\n{\n\textern void zzhl_org_sky( int on );   /* ZZHalfLife build 84 */\n\tzzhl_org_sky( 1 );\n"),
    ("\tif( RI.fogEnabled )\n\t\tpglFogf( GL_FOG_DENSITY, RI.fogDensity );\n\n\tR_LoadIdentity();\n}\n",
     "\tif( RI.fogEnabled )\n\t\tpglFogf( GL_FOG_DENSITY, RI.fogDensity );\n\n\tR_LoadIdentity();\n\tzzhl_org_sky( 0 );\n}\n"),
)
for old, new in subs:
    if g.count(old) != 1:
        raise SystemExit('gl_warp.c: unexpected content (upstream moved?): ' + old.strip()[:60])
    g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYWARPEOF
[ -s "$B/gen/gl_warp.c" ] || fail "gl_warp.c: the patched copy was not generated"

# ---- 0d. gl_studio.c: inside the studio models (build 64) ----
# The build 63 run gave entities = 28 680 us of a 38 024 us heavy frame (75 %), world = 1 746.
# We now split the studio path itself: bones, vertex transform + light positions, the per-normal
# lighting and chrome pass, and the mesh emission.  Upstream tree untouched, copy generated here.
$PY - "$X/ref/gl/gl_studio.c" "$B/gen/gl_studio.c" <<'PYSTEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
subs_once = (
    ("static void R_StudioDrawPoints( void )",
     "extern void zzhl_entphase( unsigned slot );   /* ZZHalfLife build 64 */\nstatic void R_StudioDrawPoints( void )"),
    ("\t\tfor( int i = 0; i < numverts; i++ )\n\t\t\tMatrix3x4_VectorTransform( g_studio.bonestransform[pvertbone[i]], pstudioverts[i], g_studio.verts[i] );",
     "\t\tzzhl_entphase( 2 );\n\t\tfor( int i = 0; i < numverts; i++ )\n\t\t\tMatrix3x4_VectorTransform( g_studio.bonestransform[pvertbone[i]], pstudioverts[i], g_studio.verts[i] );"),
    ("\tint k = 0;\n\tfor( int j = 0; j < m_pSubModel->nummesh; j++ )",
     "\tzzhl_entphase( 8 );\n\tint k = 0;\n\tfor( int j = 0; j < m_pSubModel->nummesh; j++ )"),
    ("\tif( r_studio_sort_textures.value && need_sort )",
     "\tzzhl_entphase( 3 );\n\tif( r_studio_sort_textures.value && need_sort )"),
)
for old, new in subs_once:
    if g.count(old) != 1:
        raise SystemExit('gl_studio.c: unexpected content (upstream moved?): ' + old.strip()[:60])
    g = g.replace(old, new)
call = "R_StudioSetupBones( RI.currententity );"
if g.count(call) != 2:
    raise SystemExit('gl_studio.c: expected 2 of R_StudioSetupBones( RI.currententity );')
g = g.replace(call, "{ zzhl_entphase( 1 ); " + call + " zzhl_entphase( 9 ); }")
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYSTEOF
[ -s "$B/gen/gl_studio.c" ] || fail "gl_studio.c: the patched copy was not generated"

# ---- 0d2. gl_decals.c: a decal out of ref_gl's own frustum is not emitted (build 96, DECALFRUST) ----
# A4000, 17/11, save007 (c1a1b): 577 decal batches a frame, nine triangles in ten out of view.
# DECALCULL (build 94) drops them at their glEnd and saves their replay, 1.9 ms; their EMISSION
# stays: the brush phase, where they are emitted, is 6.5 ms a frame there against 0.2 ms in a map
# with 20 decals.  ref_gl culls a surface with its frustum (R_CullSurface) but then draws every
# decal of a surface that is in view, wherever on it they are.  With DECALFRUST=1 the decal's own
# polygon (the cached one, or the clipped one) is tested against RI.frustum - the planes ref_gl
# culls surfaces and models with - and a polygon wholly beyond ONE plane by more than one world
# unit is not emitted.  Only where the surface's space is the world's (R_StaticEntity: no origin,
# no angles), and never with r_nocull or r_lockfrustum.  DECALFRUST=2 emits everything and only
# marks, so that the GL queue can check each marked decal against its clip coordinates.
# Upstream tree untouched, copy generated here.
$PY - "$X/ref/gl/gl_decals.c" "$B/gen/gl_decals.c" <<'PYDCEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
old = """void DrawSingleDecal( decal_t *pDecal, msurface_t *fa )
{
	int numVerts;
	float *v = R_DecalSetupVerts( pDecal, fa, pDecal->texture, &numVerts );
	if( !numVerts ) return;

	GL_Bind( XASH_TEXTURE0, pDecal->texture );

	if( FBitSet( R_GetTexture( pDecal->texture )->flags, TF_PREMULTIPLIED ))
		pglBlendFunc( GL_ONE, GL_ONE_MINUS_SRC_ALPHA );
	else pglBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	pglBegin( GL_POLYGON );
"""
new = """/* ZZHalfLife build 96 (build_arm.sh 0d2): DECALFRUST */
extern int zzhl_decalfrust;
extern unsigned zzhl_decal_seen, zzhl_decal_culled, zzhl_decal_mark, zzhl_emit_decal;
static int zzhl_decal_outside( const float *v, int n )
{
	const gl_frustum_t *f = &RI.frustum;
	unsigned int cand = f->clipFlags & (( 1u << FRUSTUM_PLANES ) - 1u );

	if( n < 3 || r_nocull.value || r_lockfrustum.value )
		return 0;
	for( int i = 0; i < n && cand; i++, v += VERTEXSIZE )
	{
		for( int k = 0; k < FRUSTUM_PLANES; k++ )
		{
			/* still a candidate: every vertex so far is more than one unit behind plane k.
			   A NaN compares false: the plane is given up, the decal is drawn. */
			if(( cand & ( 1u << k )) && !( DotProduct( v, f->planes[k].normal ) - f->planes[k].dist < -1.0f ))
				cand &= ~( 1u << k );
		}
	}
	return cand != 0;
}

void DrawSingleDecal( decal_t *pDecal, msurface_t *fa )
{
	int numVerts = 0;
	float *v = NULL;
	int zz_out = 0;

	if( zzhl_decalfrust )
	{
		zzhl_decal_seen++;
		if( RI.currententity && R_StaticEntity( RI.currententity ))
		{
			if( pDecal->polys )
				zz_out = zzhl_decal_outside( pDecal->polys->verts[0], pDecal->polys->numverts );
			else
			{
				v = R_DecalSetupVerts( pDecal, fa, pDecal->texture, &numVerts );
				if( !numVerts ) return;
				zz_out = zzhl_decal_outside( v, numVerts );
			}
			if( zz_out ) zzhl_decal_culled++;
		}
	}
	if( !v && !( zz_out && zzhl_decalfrust == 1 ))
	{
		v = R_DecalSetupVerts( pDecal, fa, pDecal->texture, &numVerts );
		if( !numVerts ) return;
	}

	/* the state the decal sets is set whether it is drawn or not: what follows finds the same */
	GL_Bind( XASH_TEXTURE0, pDecal->texture );

	if( FBitSet( R_GetTexture( pDecal->texture )->flags, TF_PREMULTIPLIED ))
		pglBlendFunc( GL_ONE, GL_ONE_MINUS_SRC_ALPHA );
	else pglBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	if( zz_out )
	{
		if( zzhl_decalfrust == 1 ) return;      /* wholly out of the frustum: not emitted */
		zzhl_decal_mark = 1;                    /* DECALFRUST=2: emitted, and checked by the GL queue */
	}

	zzhl_emit_decal = 1;                        /* build 98: the queue counts this batch as a decal (and clears it) */
	pglBegin( GL_POLYGON );
"""
if g.count(old) != 1:
    raise SystemExit('gl_decals.c: unexpected content (upstream moved?): DrawSingleDecal')
g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYDCEOF
[ -s "$B/gen/gl_decals.c" ] || fail "gl_decals.c: the patched copy was not generated"

# ---- 0d3. gl_rsurf.c: the water polygons say they are water, and WATERCULL (build 98) ----
# A4000, 17/11 (docs/PERF.md 32.1): in save007, 482 blended and biased polygons a frame are emitted
# during the brush phase and thrown away out of view; they are not decals.  EmitWaterPolys draws
# every polygon of a water surface that is in view (a func_water is one large surface cut in
# pieces), each vertex through three table look-ups.  Two things here:
#  - zzhl_emit_water is set while EmitWaterPolys runs, so the GL queue can say what the biased
#    batches it drops are (water, decals, the rest);
#  - zzhl_emit_bmodel says whether R_DrawBrushModel is drawing an entity at rest (1) or moved (2);
#  - WATERCULL=1 (off by default): a polygon wholly beyond one plane of RI.frustum, by more than
#    one unit plus the highest wave, is not emitted.  Never with r_nocull or r_lockfrustum, never
#    for a rotated entity; an entity that is only moved has its origin taken off the planes'
#    distances (R_TranslateForEntity: the polygons' space is the world's moved by that origin).
#    WATERCULL=2 is a check: everything is emitted, the polygons the test would leave out are
#    marked and the GL queue compares with their clip coordinates (as DECALFRUST=2 did).
#  Build 99, after the A4000's answer (build 98, 17/11 11 h 52, "overlays by source"): the batches
#  thrown away out of view in save007 ARE water, 145 a frame over the run against 14 kept, and
#  they come as quads (SURF_DRAWTURB_QUADS: one glBegin(GL_QUADS) for the whole surface, 704
#  polygons a frame for 159 batches).  Build 98 left the quads variant alone: WATERCULL did
#  nothing there.  A polygon of that variant is one whole quad (numverts 4), so leaving it out
#  of the run is as sound as leaving out a GL_POLYGON; in the check mode every quad gets a
#  glBegin of its own, so that the mark stays per polygon.
#  Build 100, after the A4000's answer to build 99 (17/11 12 h 20): WATERCULL=1 left out NOTHING
#  ("717 looked at, 0 wholly out of ref_gl's frustum") while the queue still threw 147 batches a
#  frame away.  Why the test on RI.frustum's planes never said "out" is not known (a rotated
#  entity? a wave height that makes the margin huge?).  So the test no longer rests on
#  RI.frustum nor on what the entity is: it is made where the queue makes its own, in clip
#  coordinates, with the two matrices ref_gl gave to GL for this entity (projection x
#  modelview: translated, rotated or the world, all the same).  And the report now says what
#  draws the water (the world, an entity at rest, moved, rotated), how many polygons were
#  tested, and the highest wave.
#  Build 102, after the A4000's answers to build 101 (17/11 12 h 46 to 12 h 55):
#   - save007: the water is drawn by a ROTATED entity (36 300 surfaces, none of another kind);
#     that is why build 99's test never ran.  Check there: 628 320 polygons called out of view,
#     the clip test disagrees on 0.  WATERCULL=1: brush phase 7 480 -> 3 266 us, save007 live
#     20.4 -> 21.4 img/s, frozen 22.8 -> 23.9.
#   - the dam of c2a5 (the world's water): the clip test DISAGREES on 17 561 of 706 689.  Cause,
#     read in ref_gl: R_SetupGL gives RI.worldviewMatrix to GL at the start of a view without
#     copying it into RI.modelviewMatrix, and R_LoadIdentity returns at once when
#     tr.modelviewIdentity is still set from the frame before: for the world,
#     RI.modelviewMatrix can be the view of the PREVIOUS frame.  A one-frame-old matrix is wrong
#     as soon as the player turns.  The world's water is now tested with RI.worldviewMatrix
#     (what GL holds for the world); an entity's with RI.modelviewMatrix, which
#     R_RotateForEntity / R_TranslateForEntity have just written.
# Upstream tree untouched, copy generated here.
$PY - "$X/ref/gl/gl_rsurf.c" "$B/gen/gl_rsurf.c" <<'PYRSEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
subs = (
    ("""static void EmitWaterPolys( msurface_t *warp, qboolean reverse, qboolean ripples )
{
	float	waveHeight;
""",
     """/* ZZHalfLife build 98 (build_arm.sh 0d3) */
extern int zzhl_emit_water, zzhl_emit_bmodel, zzhl_watercull;
extern unsigned zzhl_water_seen, zzhl_water_culled, zzhl_decal_mark;
extern unsigned zzhl_water_kind[4], zzhl_water_tested, zzhl_water_hmax;
/* build 100: x, y and w of the clip coordinates of a point of the surface's own space - rows 0,
   1 and 3 of projection x modelview, the two matrices ref_gl gave to GL for this entity - and
   what one unit of wave (along the surface's own z) can add to x+w, w-x, y+w and w-y. */
static float zz_wm[3][4], zz_wk[4];
static matrix4x4 zz_wmv, zz_wpr;
static void zzhl_water_matrix( const matrix4x4 mv )
{
	matrix4x4 m;

	if( !memcmp( zz_wmv, mv, sizeof( matrix4x4 )) && !memcmp( zz_wpr, RI.projectionMatrix, sizeof( matrix4x4 )))
		return;
	memcpy( zz_wmv, mv, sizeof( matrix4x4 ));
	memcpy( zz_wpr, RI.projectionMatrix, sizeof( matrix4x4 ));
	Matrix4x4_Concat( m, RI.projectionMatrix, mv );
	for( int j = 0; j < 4; j++ )
	{
		zz_wm[0][j] = m[0][j];
		zz_wm[1][j] = m[1][j];
		zz_wm[2][j] = m[3][j];
	}
	zz_wk[0] = m[0][2] + m[3][2]; if( zz_wk[0] < 0.0f ) zz_wk[0] = -zz_wk[0];
	zz_wk[1] = m[3][2] - m[0][2]; if( zz_wk[1] < 0.0f ) zz_wk[1] = -zz_wk[1];
	zz_wk[2] = m[1][2] + m[3][2]; if( zz_wk[2] < 0.0f ) zz_wk[2] = -zz_wk[2];
	zz_wk[3] = m[3][2] - m[1][2]; if( zz_wk[3] < 0.0f ) zz_wk[3] = -zz_wk[3];
}
/* 1 when every vertex of the polygon, lifted or lowered by h at most, is beyond one and the same
   side of the view (x < -w, x > w, y < -w or y > w) by more than one unit plus w/64.  The GL
   queue's own test (DECALCULL) uses w/256: whatever is left out here, it would throw away. */
static int zzhl_poly_outside( const float *v, int n, float h )
{
	unsigned int cand = 15u;

	for( int i = 0; i < n && cand; i++, v += VERTEXSIZE )
	{
		const float x = zz_wm[0][0] * v[0] + zz_wm[0][1] * v[1] + zz_wm[0][2] * v[2] + zz_wm[0][3];
		const float y = zz_wm[1][0] * v[0] + zz_wm[1][1] * v[1] + zz_wm[1][2] * v[2] + zz_wm[1][3];
		const float w = zz_wm[2][0] * v[0] + zz_wm[2][1] * v[1] + zz_wm[2][2] * v[2] + zz_wm[2][3];
		const float m = 1.0f + ( w < 0.0f ? -w : w ) * ( 1.0f / 64.0f );

		/* a NaN compares false: the side is given up, the polygon is drawn */
		if( !( x + w + h * zz_wk[0] < -m )) cand &= ~1u;
		if( !( w - x + h * zz_wk[1] < -m )) cand &= ~2u;
		if( !( y + w + h * zz_wk[2] < -m )) cand &= ~4u;
		if( !( w - y + h * zz_wk[3] < -m )) cand &= ~8u;
	}
	return cand != 0;
}

static void EmitWaterPolys( msurface_t *warp, qboolean reverse, qboolean ripples )
{
	float	waveHeight;
	int	zz_cull = 0, zz_each = 0;
	float	zz_h = 0.0f;
"""),
    ("""	// reset fog color for nonlightmapped water
	GL_ResetFogColor();

	if( useQuads )
		pglBegin( GL_QUADS );

	for( glpoly2_t *p = warp->polys; p; p = p->next )
	{
		float *v;

		if( reverse )
			v = p->verts[0] + ( p->numverts - 1 ) * VERTEXSIZE;
		else v = p->verts[0];

		if( !useQuads )
			pglBegin( GL_POLYGON );
""",
     """	// reset fog color for nonlightmapped water
	GL_ResetFogColor();

	zzhl_emit_water = 1;
	{   /* the report says what draws the water: the world, an entity at rest, moved, rotated */
		const cl_entity_t *ze = RI.currententity;
		const float zh = waveHeight < 0.0f ? -waveHeight : waveHeight;

		zzhl_water_kind[( !ze || ze == CL_GetEntityByIndex( 0 )) ? 0 : !VectorIsNull( ze->angles ) ? 3 : !VectorIsNull( ze->origin ) ? 2 : 1]++;
		if( zh * 1000.0f > (float)zzhl_water_hmax ) zzhl_water_hmax = zh < 4000000.0f ? (unsigned)( zh * 1000.0f ) : 4000000000u;
		if( zzhl_watercull && !r_nocull.value && !r_lockfrustum.value )
		{
			/* the wave lifts a vertex by 28.8 times the height at most (two table values of 0..16 and 0..12.8) */
			/* build 102: the world's modelview is RI.worldviewMatrix (R_SetupGL); RI.modelviewMatrix
			   may still be the frame before's there.  An entity's was written just now. */
			zzhl_water_matrix(( !ze || ze == CL_GetEntityByIndex( 0 )) ? RI.worldviewMatrix : RI.modelviewMatrix );
			zz_cull = 1;
			zz_h = 30.0f * zh;
			zz_each = useQuads && zzhl_watercull == 2;  /* the check: a glBegin per quad, the mark is per polygon */
		}
	}

	if( useQuads && !zz_each )
		pglBegin( GL_QUADS );

	for( glpoly2_t *p = warp->polys; p; p = p->next )
	{
		float *v;

		zzhl_water_seen++;
		/* a polygon of the quads variant is left out only when it is one whole quad */
		if( zz_cull && p->numverts >= 3 && ( !useQuads || p->numverts == 4 ))
			zzhl_water_tested++;
		if( zz_cull && p->numverts >= 3 && ( !useQuads || p->numverts == 4 )
		 && zzhl_poly_outside( p->verts[0], p->numverts, zz_h ))
		{
			zzhl_water_culled++;
			if( zzhl_watercull == 1 ) continue;     /* not emitted */
			zzhl_decal_mark = 1;                    /* WATERCULL=2: emitted, and checked by the GL queue */
		}

		if( reverse )
			v = p->verts[0] + ( p->numverts - 1 ) * VERTEXSIZE;
		else v = p->verts[0];

		if( !useQuads )
			pglBegin( GL_POLYGON );
		else if( zz_each )
			pglBegin( GL_QUADS );
"""),
    ("""			if( reverse )
				v -= VERTEXSIZE;
			else v += VERTEXSIZE;
		}

		if( !useQuads )
			pglEnd();
	}

	if( useQuads )
		pglEnd();

	GL_SetupFogColorForSurfaces();
}

/*
================
EmitWaterLightPolys
""",
     """			if( reverse )
				v -= VERTEXSIZE;
			else v += VERTEXSIZE;
		}

		if( !useQuads || zz_each )
			pglEnd();
	}

	if( useQuads && !zz_each )
		pglEnd();

	zzhl_emit_water = 0;
	GL_SetupFogColorForSurfaces();
}

/*
================
EmitWaterLightPolys
"""),
    ("""	if( gl_polyoffset_bmodels.value )
		GL_PushPolygonOffset( -0.5f, -gl_polyoffset_bmodels.value );

	// draw sorted translucent surfaces
""",
     """	if( gl_polyoffset_bmodels.value )
		GL_PushPolygonOffset( -0.5f, -gl_polyoffset_bmodels.value );
	zzhl_emit_bmodel = R_StaticEntity( e ) ? 1 : 2;   /* build 98: a brush entity at rest (1) or moved (2) */

	// draw sorted translucent surfaces
"""),
    ("""	if( gl_polyoffset_bmodels.value )
		GL_PopPolygonOffset();

	R_DrawTriangleOutlines();
""",
     """	if( gl_polyoffset_bmodels.value )
		GL_PopPolygonOffset();
	zzhl_emit_bmodel = 0;

	R_DrawTriangleOutlines();
"""),
)
for old, new in subs:
    if g.count(old) != 1:
        raise SystemExit('gl_rsurf.c: unexpected content (upstream moved?): ' + old.strip()[:60])
    g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYRSEOF
[ -s "$B/gen/gl_rsurf.c" ] || fail "gl_rsurf.c: the patched copy was not generated"

# ---- 0e. pm_trace.c + gl_sprite.c: the halo traces (build 65) ----
# The 64 run gave sprite = 13 673 us on the frames above 45 ms, a quarter of the frame.
# R_SpriteGlowBlend() casts one ray from the eye to every kRenderGlow sprite, every frame, and
# PM_PlayerTraceExt runs a FULL hull trace against every visible entity with no cheap rejection
# in front of it.  We add one: a segment/box test that can only reject entities the segment
# provably cannot touch, so the trace result is identical bit for bit - no halo through a closed
# the halo path sets, so player movement keeps the upstream path untouched.
$PY - "$X/engine/common/pm_trace.c" "$B/gen/pm_trace.c" <<'PYPMEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
old = "\t\tif(( flags & PM_CUSTOM_IGNORE ) && pe->solid == SOLID_CUSTOM )\n\t\t\tcontinue;\n\n\t\thullcount = 1;\n"
new = """\t\t/* ZZHalfLife build 65: cheap rejection, armed only by the halo path (bit 8).
\t\t   pe->mins/maxs are model-local and pe->origin is the world position (cl_pmove.c
\t\t   fills them from state->mins / mod->mins), so the world box is origin + mins/maxs.
\t\t   A rotating brush entity is covered by its bounding radius instead.  The box is
\t\t   then inflated by 64 units, well past the largest player hull the real trace uses,
\t\t   so the test can only ever reject what the full trace would have missed. */
\t\tif(( flags & 0x00000100 ) && i != 0 )
\t\t{
\t\t\textern int zzhl_seg_box( const float *, const float *, const float *, const float * );
\t\t\textern unsigned zzhl_pm_ents, zzhl_pm_rejected;
\t\t\tvec3_t zb_min, zb_max;
\t\t\tint zb_j;
\t\t\tzzhl_pm_ents++;
\t\t\tif( !VectorIsNull( pe->angles ))
\t\t\t{
\t\t\t\tfloat zb_r = 0.0f;
\t\t\t\tfor( zb_j = 0; zb_j < 3; zb_j++ )
\t\t\t\t{
\t\t\t\t\tconst float a = pe->mins[zb_j] < 0.0f ? -pe->mins[zb_j] : pe->mins[zb_j];
\t\t\t\t\tconst float b = pe->maxs[zb_j] < 0.0f ? -pe->maxs[zb_j] : pe->maxs[zb_j];
\t\t\t\t\tif( a > zb_r ) zb_r = a;
\t\t\t\t\tif( b > zb_r ) zb_r = b;
\t\t\t\t}
\t\t\t\tVectorSet( zb_min, -zb_r, -zb_r, -zb_r );
\t\t\t\tVectorSet( zb_max,  zb_r,  zb_r,  zb_r );
\t\t\t}
\t\t\telse { VectorCopy( pe->mins, zb_min ); VectorCopy( pe->maxs, zb_max ); }
\t\t\tfor( zb_j = 0; zb_j < 3; zb_j++ )
\t\t\t{
\t\t\t\tzb_min[zb_j] += pe->origin[zb_j] - 64.0f;
\t\t\t\tzb_max[zb_j] += pe->origin[zb_j] + 64.0f;
\t\t\t}
\t\t\tif( !zzhl_seg_box( start, end, zb_min, zb_max )) { zzhl_pm_rejected++; continue; }
\t\t}

""" + old
if g.count(old) != 1:
    raise SystemExit('pm_trace.c: unexpected content (upstream moved?)')
g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYPMEOF
[ -s "$B/gen/pm_trace.c" ] || fail "pm_trace.c: the patched copy was not generated"

# gl_sprite.c: arm the flag, count the traces, and reuse the answer when neither the eye nor the
# halo has moved since the previous frame (then the ray is the same ray: identical by definition).
$PY - "$X/ref/gl/gl_sprite.c" "$B/gen/gl_sprite.c" <<'PYSPEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
old = "\t\tpmtrace_t *tr = gEngfuncs.EV_VisTraceLine( RI.rvp.vieworigin, origin, r_traceglow.value ? PM_GLASS_IGNORE : (PM_GLASS_IGNORE|PM_STUDIO_IGNORE));\n\n\t\tif(( 1.0f - tr->fraction ) * dist > 8.0f )\n\t\t\treturn 0.0f;\n"
new = """\t\t/* Perform glow visibility rejection only when the trace does not intersect its segment box. */
\t\textern unsigned zzhl_glow_traces, zzhl_glow_us;
\t\textern uint32_t rix_now( void );
\t\textern uint32_t rix_ticks_to_us( uint32_t );
\t\tfloat zg_fraction;
\t\t{
\t\t\tconst unsigned zg_t0 = rix_now();
\t\t\tpmtrace_t *tr = gEngfuncs.EV_VisTraceLine( RI.rvp.vieworigin, origin, ( r_traceglow.value ? PM_GLASS_IGNORE : (PM_GLASS_IGNORE|PM_STUDIO_IGNORE)) | 0x00000100 );
\t\t\tzzhl_glow_us += rix_ticks_to_us( (unsigned)( rix_now() - zg_t0 ));
\t\t\tzzhl_glow_traces++;
\t\t\tzg_fraction = tr->fraction;
\t\t}

\t\tif(( 1.0f - zg_fraction ) * dist > 8.0f )
\t\t\treturn 0.0f;
"""
if g.count(old) != 1:
    raise SystemExit('gl_sprite.c: unexpected content (upstream moved?)')
g = g.replace(old, new)

# build 66: split R_DrawSpriteModel itself.  sprite = 16 625 us on the frames above 45 ms with
# the halo traces at 14 us, so the cost is somewhere else in this function.  Measure, then act.
g = g.replace("void R_DrawSpriteModel( cl_entity_t *e )",
              "extern void zzhl_entphase( unsigned slot );   /* ZZHalfLife build 66 */\nvoid R_DrawSpriteModel( cl_entity_t *e )", 1)
for anchor, slot in (
        ("\tif( R_SpriteOccluded( e, origin, &scale ))",      "10"),
        ("\tr_stats.c_sprite_models_drawn++;",                "11"),
        ("\tmspriteframe_t *frame = NULL, *oldframe = NULL;", "12"),
        ("\tint type = psprite->type;",                       "13")):
    if g.count(anchor) != 1:
        raise SystemExit('gl_sprite.c: anchor moved: ' + anchor.strip())
    g = g.replace(anchor, "\tzzhl_entphase( " + slot + " );\n" + anchor)

# build 84: SPRTRIM.  The quad of a sprite is as large as its picture, empty margins included.
# zzhl_sprite_trim (xacp/src/xacp_gl.c) says which part of the bound texture can change the
# picture in the current state; the quad is then drawn over that part only, with the texture
# coordinates of that part.  When it answers 0 (always, unless SPRTRIM=1) the four corners and
# the four coordinates are computed from the same values by the same operations as upstream.
old_q = """\tpglBegin( GL_QUADS );
\t\tpglTexCoord2f( 0.0f, 1.0f );
\t\tVectorMA( org, frame->down * scale, v_up, point );
\t\tVectorMA( point, frame->left * scale, v_right, point );
\t\tpglVertex3fv( point );
\t\tpglTexCoord2f( 0.0f, 0.0f );
\t\tVectorMA( org, frame->up * scale, v_up, point );
\t\tVectorMA( point, frame->left * scale, v_right, point );
\t\tpglVertex3fv( point );
\t\tpglTexCoord2f( 1.0f, 0.0f );
\t\tVectorMA( org, frame->up * scale, v_up, point );
\t\tVectorMA( point, frame->right * scale, v_right, point );
\t\tpglVertex3fv( point );
\t\tpglTexCoord2f( 1.0f, 1.0f );
\t\tVectorMA( org, frame->down * scale, v_up, point );
\t\tVectorMA( point, frame->right * scale, v_right, point );
\t\tpglVertex3fv( point );
\tpglEnd();
"""
new_q = """\t/* ZZHalfLife build 84 (SPRTRIM): u runs from the left edge to the right one, v from the top
\t   edge (up) to the bottom one (down) */
\textern int zzhl_sprite_trim( float *u0, float *v0, float *u1, float *v1 );
\tfloat zq_left = frame->left, zq_right = frame->right, zq_up = frame->up, zq_down = frame->down;
\tfloat zq_u0 = 0.0f, zq_v0 = 0.0f, zq_u1 = 1.0f, zq_v1 = 1.0f;
\tif( zzhl_sprite_trim( &zq_u0, &zq_v0, &zq_u1, &zq_v1 ))
\t{
\t\tzq_left  = frame->left + ( frame->right - frame->left ) * zq_u0;
\t\tzq_right = frame->left + ( frame->right - frame->left ) * zq_u1;
\t\tzq_up    = frame->up + ( frame->down - frame->up ) * zq_v0;
\t\tzq_down  = frame->up + ( frame->down - frame->up ) * zq_v1;
\t}
\tpglBegin( GL_QUADS );
\t\tpglTexCoord2f( zq_u0, zq_v1 );
\t\tVectorMA( org, zq_down * scale, v_up, point );
\t\tVectorMA( point, zq_left * scale, v_right, point );
\t\tpglVertex3fv( point );
\t\tpglTexCoord2f( zq_u0, zq_v0 );
\t\tVectorMA( org, zq_up * scale, v_up, point );
\t\tVectorMA( point, zq_left * scale, v_right, point );
\t\tpglVertex3fv( point );
\t\tpglTexCoord2f( zq_u1, zq_v0 );
\t\tVectorMA( org, zq_up * scale, v_up, point );
\t\tVectorMA( point, zq_right * scale, v_right, point );
\t\tpglVertex3fv( point );
\t\tpglTexCoord2f( zq_u1, zq_v1 );
\t\tVectorMA( org, zq_down * scale, v_up, point );
\t\tVectorMA( point, zq_right * scale, v_right, point );
\t\tpglVertex3fv( point );
\tpglEnd();
"""
if g.count(old_q) != 1:
    raise SystemExit('gl_sprite.c: R_DrawSpriteQuad moved')
g = g.replace(old_q, new_q)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYSPEOF
[ -s "$B/gen/gl_sprite.c" ] || fail "gl_sprite.c: the patched copy was not generated"

# ---- 0f. cl_cmds.c: the music goes to the release queue, not to a decoder (build 67) ----
# Core1 decodes nothing, exactly as ZZQuake640 and ZZQuake2 do: it pushes the track number into
# the release music queue and the 68k launcher plays it with the backend MUSIC= chose - CD, MP3
# (XACP on Core0) or MHI.  Interception is at CL_CDAudio_PlayTrack, where the NUMBER is still
# known: the original Half-Life CD is a Red Book disc whose track 1 is data and 2..28 the music,
# and Xash's own playlist is "blank" then Half-Life01.mp3, so the engine number IS the CD track.
$PY - "$X/engine/client/cl_cmds.c" "$B/gen/cl_cmds.c" <<'PYCLEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
D = "extern void zzhl_music_play( int track, int looping );   /* ZZHalfLife build 67 */\nextern void zzhl_music_stop( void );\nextern void zzhl_music_pause( void );\nextern void zzhl_music_resume( void );\nextern void zzhl_music_volume( int vol );   /* build 80 */\n"
# build 80: MP3Volume has to REACH the 68k launcher, which is what actually plays the MP3s.
# Until now nothing carried it: ZZQ_MUS_VOLUME was a reserved number implemented on neither
# against the voices).  This file is where s_musicvolume is in scope (it already prints it,
# "Current MP3 Volume"), so the poll lives here and Host_Frame calls it once a frame.  One
# float compare per frame, and the queue is written only when the value really changed.
POLL = """
void zzhl_music_volume_poll( void )   /* ZZHalfLife build 80, called from Host_Frame */
{
\tstatic float zzhl_last_vol = -1.0f;
\tif( s_musicvolume.value == zzhl_last_vol ) return;
\tzzhl_last_vol = s_musicvolume.value;
\tzzhl_music_volume( (int)( zzhl_last_vol * 65536.0f + 0.5f ));   /* AHI 16.16, 0x10000 = full */
}
"""
subs = (
  ("static void CL_CDAudio_PlayTrack( int track, qboolean loop )", D + POLL + "static void CL_CDAudio_PlayTrack( int track, qboolean loop )"),
  ("\t\tif( !COM_StringEmpty( clgame.cdtracks[track-1] ))\n\t\t\tS_StartBackgroundTrack( clgame.cdtracks[track-1], clgame.cdtracks[track-1], 0, false );\n\t}\n\telse S_StartBackgroundTrack( clgame.cdtracks[track-1], NULL, 0, false );",
   "\t\tif( !COM_StringEmpty( clgame.cdtracks[track-1] ))\n\t\t\tzzhl_music_play( track, 1 );   /* build 67 */\n\t}\n\telse zzhl_music_play( track, 0 );   /* build 67 */"),
  ("static void CL_CDAudio_Stop( void )\n{\n\tS_StopBackgroundTrack();",
   "static void CL_CDAudio_Stop( void )\n{\n\tzzhl_music_stop();   /* build 67 */\n\tS_StopBackgroundTrack();"),
  ("\t\tS_StreamSetPause( true );\n\t\tcdaudio.paused = true;",
   "\t\tzzhl_music_pause();   /* build 67 */\n\t\tS_StreamSetPause( true );\n\t\tcdaudio.paused = true;"),
  ("\t\tS_StreamSetPause( false );\n\t\tcdaudio.paused = false;",
   "\t\tzzhl_music_resume();   /* build 67 */\n\t\tS_StreamSetPause( false );\n\t\tcdaudio.paused = false;"),
  # a file name instead of a number: find it back in the playlist so the CD backend keeps working
  ("static void CL_CDAudio_PlayFile( const char *name, qboolean loop )\n{\n\tS_StartBackgroundTrack( name, loop ? name : NULL, 0, true );",
   "static void CL_CDAudio_PlayFile( const char *name, qboolean loop )\n{\n\t{   /* build 67: back to a track number, so CD / MP3 / MHI all work from one index */\n\t\tint zm;\n\t\tfor( zm = 0; zm < MAX_CDTRACKS; zm++ )\n\t\t\tif( !COM_StringEmpty( clgame.cdtracks[zm] ) && !Q_stricmp( clgame.cdtracks[zm], name ))\n\t\t\t{ zzhl_music_play( zm + 1, loop ? 1 : 0 ); break; }\n\t\tif( zm == MAX_CDTRACKS )\n\t\t\tCon_Printf( \"ZZHalfLife: music \\\"%s\\\" is not in the playlist, not played\\n\", name );\n\t}\n\tS_StartBackgroundTrack( name, loop ? name : NULL, 0, true );"),
)
for old, new in subs:
    if g.count(old) != 1:
        raise SystemExit('cl_cmds.c: unexpected content (upstream moved?): ' + old.strip()[:60])
    g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYCLEOF
[ -s "$B/gen/cl_cmds.c" ] || fail "cl_cmds.c: the patched copy was not generated"






# ---- 1. engine (what engine/wscript builds for a client without SDL, minus ffmpeg/tls/codecs) ----
echo "== engine objects =="
for f in $X/engine/common/*.c $X/engine/common/imagelib/*.c $X/engine/common/soundlib/*.c \
         $X/engine/server/*.c $X/engine/common/http/*.c $X/engine/client/*.c \
         $X/engine/client/input/*.c $X/engine/client/dll_int/*.c $X/engine/client/parse/*.c \
         $X/engine/client/sound/*.c $X/engine/client/soundlib/*.c $X/engine/client/vgui/*.c \
         $X/engine/client/avi/*.c $X/engine/platform/misc/lib_static.c $X/engine/platform/stub/s_stub.c \
         $X/public/*.c $X/3rdparty/miniz/miniz.c $X/3rdparty/library_suffix/src/library_suffix.c \
         $X/3rdparty/MultiEmulator/src/*.c; do
    case "$f" in
        */avi_ffmpeg.c|*/net_http_tls.c|*/whereami.c|*/snd_mp3.c|*/snd_ogg_opus.c|*/snd_ogg_vorbis.c|*/ogg_filestream.c|*/voice.c|*/getopt.c) continue ;;
        */engine/common/con_utils.c) continue ;;   # build 63: the patched copy in $B/gen is built instead
        */engine/common/pm_trace.c) continue ;;    # build 65: idem
        */engine/client/cl_cmds.c) continue ;;     # build 67: idem
        */engine/common/host.c) continue ;;      # build 70: idem
        */engine/common/cmd.c) continue ;;       # build 70: idem
    esac
    cc1 "$AGCC" "$ENGFLAGS" "$f" "$B/engine/$(oname "$f").o"
done
cc1 "$AGCC" "$ENGFLAGS" "$B/gen/con_utils.c" "$B/engine/engine_common_con_utils_c.o"   # build 63
cc1 "$AGCC" "$ENGFLAGS" "$B/gen/pm_trace.c" "$B/engine/engine_common_pm_trace_c.o"   # build 65
cc1 "$AGCC" "$ENGFLAGS" "$B/gen/cl_cmds.c" "$B/engine/engine_client_cl_cmds_c.o"   # build 67
cc1 "$AGCC" "$ENGFLAGS" "$B/gen/host.c" "$B/engine/engine_common_host_c.o"   # build 70
cc1 "$AGCC" "$ENGFLAGS" "$B/gen/cmd.c" "$B/engine/engine_common_cmd_c.o"   # build 70
for f in xacp/src/*.c; do cc1 "$AGCC" "$ENGFLAGS $RESD -ICore1 -Izzgl -Ilibrixgpu" "$f" "$B/xacp/$(oname "$f").o"; done

# ---- 2. filesystem_stdio (filesystem/*.c + VFileSystem009.cpp, as filesystem/wscript) ----
# FS_LoadProgs (engine/common/filesystem_engine.c) resolves BOTH GetFSAPI and CreateInterface in
# the filesystem library and Sys_Error()s when one is missing: the C++ GoldSrc IFileSystem009
# shim (VFileSystem009.cpp) that exports CreateInterface is therefore mandatory, not optional
# (A0 first hardware run: "engine returned 1" before the first file access, see docs/SUIVI.md).
echo "== filesystem objects =="
for f in $X/filesystem/*.c; do cc1 "$AGCC" "$ENGFLAGS" "$f" "$B/fs/$(oname "$f").o"; done
FSXXFLAGS="$ARCH $OPT $CWARN $CXXOPT $XDEF -DENGINE_DLL=1 -include xacp/include/xacp_pre.h $XINC $PMAP"
cc1 "$AGXX" "$FSXXFLAGS" "$X/filesystem/VFileSystem009.cpp" "$B/fs/filesystem_VFileSystem009.o"

# ---- 3. ref_gl + ref_common ----
echo "== ref_gl objects =="
for f in $X/ref/common/*.c $X/ref/gl/*.c $X/ref/gl/gl2_shim/*.c; do
    case "$f" in */ref/gl/gl_rmain.c|*/ref/gl/gl_studio.c|*/ref/gl/gl_sprite.c|*/ref/gl/gl_warp.c|*/ref/gl/gl_decals.c|*/ref/gl/gl_rsurf.c) continue ;; esac   # builds 63/64/65/84/96/98: the patched copies in $B/gen are built instead
    cc1 "$AGCC" "$REFFLAGS" "$f" "$B/ref/$(oname "$f").o"
done
cc1 "$AGCC" "$REFFLAGS" "$B/gen/gl_rmain.c" "$B/ref/ref_gl_gl_rmain_c.o"   # build 63
cc1 "$AGCC" "$REFFLAGS" "$B/gen/gl_studio.c" "$B/ref/ref_gl_gl_studio_c.o"   # build 64
cc1 "$AGCC" "$REFFLAGS" "$B/gen/gl_sprite.c" "$B/ref/ref_gl_gl_sprite_c.o"   # build 65
cc1 "$AGCC" "$REFFLAGS" "$B/gen/gl_warp.c" "$B/ref/ref_gl_gl_warp_c.o"   # build 84
cc1 "$AGCC" "$REFFLAGS" "$B/gen/gl_decals.c" "$B/ref/ref_gl_gl_decals_c.o"   # build 96
cc1 "$AGCC" "$REFFLAGS" "$B/gen/gl_rsurf.c" "$B/ref/ref_gl_gl_rsurf_c.o"   # build 98

# ---- 4. HLSDK server (hlsdk-portable/dlls/wscript: all dlls/**/*.cpp minus mpstubb, stats, Wxdebug) ----
echo "== hlsdk server objects =="
for f in $H/dlls/*.cpp $H/dlls/wpn_shared/*.cpp $H/pm_shared/*.c $H/game_shared/voice_gamemgr.cpp $H/public/safe_snprintf.c; do
    [ -e "$f" ] || continue
    case "$f" in */mpstubb.cpp|*/stats.cpp|*/Wxdebug.cpp) continue ;; esac
    case "$f" in *.c) C="$AGCC"; FL="$ARCH $OPT $CWARN $HDEF $HINC $PMAP" ;; *) C="$AGXX"; FL="$SVFLAGS" ;; esac
    cc1 "$C" "$FL" "$f" "$B/sv/$(oname "$f").o"
done
# build 35: the server's export-table interposer (xacp/dll/zzhl_sv_pump.cpp, GPU pumps during the game logic)
cc1 "$AGXX" "$SVFLAGS" "xacp/dll/zzhl_sv_pump.cpp" "$B/sv/xacp_dll_zzhl_sv_pump.o"

# ---- 5. HLSDK client (cl_dll/wscript: cl_dll/**/*.cpp, game_shared, the 15 shared weapon files) ----
echo "== hlsdk client objects =="
for f in $H/cl_dll/*.cpp $H/cl_dll/hl/*.cpp $H/game_shared/*.cpp $H/pm_shared/*.c $H/public/safe_snprintf.c \
         $H/dlls/crossbow.cpp $H/dlls/crowbar.cpp $H/dlls/egon.cpp $H/dlls/gauss.cpp $H/dlls/glock.cpp \
         $H/dlls/handgrenade.cpp $H/dlls/hornetgun.cpp $H/dlls/mp5.cpp $H/dlls/python.cpp $H/dlls/rpg.cpp \
         $H/dlls/satchel.cpp $H/dlls/shotgun.cpp $H/dlls/squeakgrenade.cpp $H/dlls/tripmine.cpp; do
    [ -e "$f" ] || continue
    case "$f" in */GameStudioModelRenderer_Sample.cpp|*/game_shared/voice_vgui_tweakdlg.cpp|*/game_shared/voice_gamemgr.cpp|*/game_shared/voice_status.cpp) continue ;; esac
    case "$f" in *.c) C="$AGCC"; FL="$ARCH $OPT $CWARN $HDEF -DCLIENT_DLL=1 $HINC -I$H/cl_dll $PMAP" ;; *) C="$AGXX"; FL="$CLFLAGS" ;; esac
    cc1 "$C" "$FL" "$f" "$B/cl/$(oname "$f").o"
done
# build 35: the client's export-table interposer (xacp/dll/zzhl_cl_pump.cpp)
cc1 "$AGXX" "$CLFLAGS" "xacp/dll/zzhl_cl_pump.cpp" "$B/cl/xacp_dll_zzhl_cl_pump.o"

# ---- 6. FreeVGUI (linked into the client, as hlsdk-portable does on consoles) ----
echo "== freevgui objects =="
for f in $H/freevgui/*.cpp $H/freevgui/controls/*.cpp $H/freevgui/platform/common/*.cpp $H/freevgui/platform/posix/font.cpp $H/freevgui/platform/xash3d-fwgs/*.cpp xacp/src/xacp_vgui_app.cpp; do
    [ -e "$f" ] || continue
    cc1 "$AGXX" "$VGFLAGS" "$f" "$B/vgui/$(oname "$f").o"
done

# ---- 6b. build 50: the menu (FWGS mainui, mainui/wscript: *.cpp of the top, miniutl, font, menus,
# menus/dynamic, model, controls) ----
echo "== mainui objects =="
for f in $MN/*.cpp $MN/miniutl/*.cpp $MN/font/*.cpp $MN/menus/*.cpp $MN/menus/dynamic/*.cpp $MN/model/*.cpp $MN/controls/*.cpp; do
    [ -e "$f" ] || continue
    [ -e "xacp/menu/$(basename "$f")" ] && continue          # an adapted copy (xacp/menu/) instead
    cc1 "$AGXX" "$MENUFLAGS" "$f" "$B/menu/$(oname "$f").o"
done
for f in xacp/menu/*.cpp; do cc1 "$AGXX" "$MENUFLAGS -I$MN/menus" "$f" "$B/menu/xacp_menu_$(basename "$f" .cpp).o"; done
cc1 "$AGXX" "$MENUFLAGS" "xacp/dll/zzhl_menu_wrap.cpp" "$B/menu/xacp_dll_zzhl_menu_wrap.o"   # GetMenuAPI: save comments peeked

echo "  $NOBJ objects compiled"
if [ -n "$FAILED" ]; then
    echo "== TRIAGE: failed units =="; for f in $FAILED; do echo "  $f"; done
    echo "$FAILED" | tr ' ' '\n' | sed '/^$/d' > "$B/failed.txt"
    exit 2
fi
echo "== compile stage done (link stage: see build_arm.sh, part 2) =="

# ======================================================================
# Part 2: the four "libraries" as relocatable objects (waf's xshlib.py scheme), then the
# engine link.  Each library is partially linked (ld -r), gets its export table
# (lib_<name>_exports[], the names the engine asks COM_GetProcAddress for) and every other
# defined symbol is made local (objcopy --keep-global-symbol), so client and server, which
# both define UTIL_*, pm_shared, g_vecZero..., can live in one blob without collisions.
# ======================================================================
mklib() {   # mklib <name> <object dir(s)> <exports file> [overrides file: "export wrapper" lines]
    name="$1"; dirs="$2"; exports="$3"; ovr="${4:-/dev/null}"
    objs=""; for d in $dirs; do objs="$objs $(ls "$B"/$d/*.o)"; done
    # export table source (as xshlib.py write_export_list); build 35: an export listed in the
    # overrides file points at its wrapper (xacp/dll/*.cpp), which calls the real function
    tgt() { w=$(awk -v e="$1" '$1==e {print $2}' "$ovr"); [ -n "$w" ] && echo "$w" || echo "$1"; }
    {
        echo "/* generated by build_arm.sh: exports of $name */"
        echo "typedef struct { const char *name; void *pointer; } zzhl_table_t;"
        while read -r e; do [ -n "$e" ] && echo "extern void $(tgt "$e")(void);"; done < "$exports"
        echo "zzhl_table_t lib_${name}_exports[] = {"
        while read -r e; do [ -n "$e" ] && echo "{ \"$e\", (void *)&$(tgt "$e") },"; done < "$exports"
        echo "{ 0, 0 } };"
    } > "$B/gen/lib_${name}_exports.c"
    while read -r e w; do [ -n "$e" ] && { grep -qx "$e" "$exports" || fail "override $e: not an export of $name"; }; done < "$ovr"
    "$AGCC" $ARCH $OPT -w -c "$B/gen/lib_${name}_exports.c" -o "$B/gen/lib_${name}_exports.o"
    "$ALD" -r --force-group-allocation -o "$B/${name}.unstripped.o" $objs "$B/gen/lib_${name}_exports.o"
    "$AOBJCOPY" --keep-global-symbol="lib_${name}_exports" "$B/${name}.unstripped.o" "$B/${name}.o"
    echo "  $name: $(echo $objs | wc -w) objects, $(grep -c . "$exports") exports"
}
# C-linkage functions of a partially linked HLSDK library = its exports (entity classes,
# GiveFnptrsToDll, GetEntityAPI..., HUD_*, pm_shared): global defined T symbols that are not
# C++ mangled (_Z...) and not compiler internals (__...).
cexports() {   # cexports <object dir(s)> <out file>
    objs=""; for d in $1; do objs="$objs $(ls "$B"/$d/*.o)"; done
    "$ANM" --defined-only -g $objs | awk '$2=="T" && $3 !~ /^_Z/ && $3 !~ /^__/ && $3 !~ /^zzhl_/ {print $3}' | sort -u > "$2"
}
echo "== libraries (ld -r + export tables) =="
printf "GetFSAPI\nCreateInterface\n" > "$B/gen/filesystem_stdio.exports"
echo "GetRefAPI" > "$B/gen/ref_gl.exports"
cexports "sv" "$B/gen/server.exports"
cexports "cl vgui" "$B/gen/client.exports"
mklib filesystem_stdio "fs" "$B/gen/filesystem_stdio.exports"
mklib ref_gl "ref" "$B/gen/ref_gl.exports"
mklib server "sv" "$B/gen/server.exports" xacp/dll/sv_overrides.txt
mklib client "cl vgui" "$B/gen/client.exports" xacp/dll/cl_overrides.txt
printf "GetMenuAPI\nGetExtAPI\n" > "$B/gen/menu.exports"      # build 50: mainui/exports.txt
mklib menu "menu" "$B/gen/menu.exports" xacp/dll/menu_overrides.txt

# ---- 8. RasterIX side: librixgpu, ZZGL, the GPU adapter and the presentation (engine image) ----
# EXACTLY the engine's FPU and ABI (VFPv3-d16, hard float) as ZZQuake2RIX (RIXFLAGS), with ONE
# exception since build 59: librixgpu/rixdesc.c is compiled with -mfpu=neon (NEONFLAGS below).
# The ABI is unchanged (hard float, same registers for arguments); only that file may use the NEON
# unit, and it runs on the engine's own 16-byte aligned stack (Core1/zzhl_stack.S), not on the
# release's, so the misaligned ENTRY_SP of 14/10 does not apply to it.
RIXFLAGS="$ARCH -O2 -ffreestanding -fno-builtin -fno-tree-vectorize -fomit-frame-pointer \
-fno-unwind-tables -fno-asynchronous-unwind-tables -ffunction-sections -fdata-sections -w \
-Ilibrixgpu -Izzgl -ICore1 -Ixacp/include $PMAP"
echo "== librixgpu 1.4.2, ZZGL 0.8.10, GPU adapter, presentation =="
sha256sum -c --quiet docs/rix_vendored.sha256 || fail "librixgpu/ or zzgl/ differs from the vendored ZZQuake2RIX tree"
NEONFLAGS="$(printf '%s' "$RIXFLAGS" | sed 's/-mfpu=vfpv3-d16/-mfpu=neon/')"
case "$NEONFLAGS" in *-mfpu=neon*) ;; *) fail "NEONFLAGS did not get -mfpu=neon" ;; esac
for f in rixgpu rixframe rixtex; do
    cc1 "$AGCC" "$RIXFLAGS" "librixgpu/$f.c" "$B/xacp/rix_$f.o"
done
# builds 59-60: the NEON files.  Each one is checked against the words the scalar path produced on
# the PC - at build time by tests/test_rixdesc.c, and at startup on the Amiga by xacp_rixcheck.c.
cc1 "$AGCC" "$NEONFLAGS" "librixgpu/rixdesc.c" "$B/xacp/rix_rixdesc.o"
cc1 "$AGCC" "$NEONFLAGS" "librixgpu/rixclip.c" "$B/xacp/rix_rixclip.o"
cc1 "$AGCC" "$NEONFLAGS" "zzgl/zzgl.c" "$B/xacp/zzgl.o"   # build 60: the clamps of draw_triangle
cc1 "$AGCC" "$RIXFLAGS $RESD" "Core1/zzhl_gpu.c" "$B/xacp/zzhl_gpu.o"
cc1 "$AGCC" "$RIXFLAGS" "Core1/zzq2rix_mmu.c" "$B/xacp/zzq2rix_mmu.o"
cc1 "$AGCC" "$RIXFLAGS $RESD" "Core1/zzhl_present.c" "$B/xacp/zzhl_present.o"

# ---- 9. the engine image (stage 2): zzhl_core.bin ----
echo "== stage-2 link: $B/zzhl_core.elf =="
"$AGCC" $ARCH -nostartfiles -T Core1/zzhl2.ld -Wl,--gc-sections -Wl,-Map="$B/zzhl_core.map" \
    -Wl,--wrap=_svfprintf_r,--wrap=_vfprintf_r \
    -Wl,--undefined=zzhl_core_entry -Wl,--undefined=zzhl_core_hdr \
    "$B"/engine/*.o "$B"/xacp/*.o "$B/filesystem_stdio.o" "$B/ref_gl.o" "$B/menu.o" \
    -Wl,--start-group -lstdc++ -lm -lc -lgcc -Wl,--end-group -o "$B/zzhl_core.elf" 2> "$B/link2.log" || {
        cat "$B/link2.log"; fail "stage-2 link failed"; }
grep -v "variable-size enums\|wrap" "$B/link2.log" || true
"$ANM" -n "$B/zzhl_core.elf" > "$B/zzhl_core.nm"
"$AOBJCOPY" -O binary "$B/zzhl_core.elf" "$B/zzhl_core.raw"
$PY tools/mkcore.py "$B/zzhl_core.raw" "$B/zzhl_core.map" "$B/zzhl_core.nm" "$OUT/$CORE.bin"
"$ASIZE" "$B/zzhl_core.elf"

# ---- 9b. build 103: the game image zzhl_game.bin (the HLSDK server and client, FreeVGUI) ----
# Not in the engine image any more (licences: xacp/include/zzhl_game.h).  Its own newlib and
# libstdc++; the system calls and the heap go to the engine through a table
# (xacp/game/zzhl_game_rt.c, 0BSD): every allocator entry is wrapped, so one heap serves both.
echo "== game image link: $B/zzhl_game.elf =="
mkdir -p "$B/game"
cc1 "$AGCC" "$ARCH $OPT $CWARN -Ixacp/include $PMAP" xacp/game/zzhl_game_rt.c "$B/game/zzhl_game_rt.o"
GWRAP="-Wl,--wrap=_svfprintf_r,--wrap=_vfprintf_r,--wrap=malloc,--wrap=free,--wrap=calloc,--wrap=realloc,--wrap=memalign"
GWRAP="$GWRAP,--wrap=_malloc_r,--wrap=_free_r,--wrap=_calloc_r,--wrap=_realloc_r,--wrap=_memalign_r"
"$AGCC" $ARCH -nostartfiles -T Core1/zzhl_game.ld -Wl,--gc-sections -Wl,-Map="$B/zzhl_game.map" $GWRAP \
    -Wl,--undefined=zzhl_game_entry -Wl,--undefined=zzhl_game_hdr \
    "$B/game/zzhl_game_rt.o" "$B/client.o" "$B/server.o" \
    -Wl,--start-group -lstdc++ -lm -lc -lgcc -Wl,--end-group -o "$B/zzhl_game.elf" 2> "$B/link_game.log" || {
        cat "$B/link_game.log"; fail "game image link failed"; }
grep -v "variable-size enums\|wrap" "$B/link_game.log" || true
"$ANM" -n "$B/zzhl_game.elf" > "$B/zzhl_game.nm"
# newlib's own allocator must not be in the game image: one heap, the engine's
if grep -qE " [TtWw] (_malloc_r|_free_r|_realloc_r|malloc|free)$" "$B/zzhl_game.nm"; then
    grep -E " [TtWw] (_malloc_r|_free_r|_realloc_r|malloc|free)$" "$B/zzhl_game.nm"; fail "the game image has an allocator of its own"; fi
# nothing of the engine in it: none of the engine image's own functions
for sym in Host_Main COM_LoadLibrary zzglBegin glq_flush xacp_fs_set_verify zzhl_core_entry; do
    grep -q " $sym$" "$B/zzhl_game.nm" && fail "the game image holds engine code ($sym)"
done
"$AOBJCOPY" -O binary "$B/zzhl_game.elf" "$B/zzhl_game.raw"
$PY tools/mkcore.py "$B/zzhl_game.raw" "$B/zzhl_game.map" "$B/zzhl_game.nm" "$OUT/zzhl_game.bin" zzhl_game_entry
"$ASIZE" "$B/zzhl_game.elf"
# and nothing of the game in the engine image
for sym in GiveFnptrsToDll GetEntityAPI2 HUD_Init lib_client_exports lib_server_exports; do
    grep -q " $sym$" "$B/zzhl_core.nm" && fail "the engine image still holds game code ($sym)"
done
echo "PASS two images: no game code in zzhl_core.bin, no engine code in zzhl_game.bin"

# ---- 10. the Core1 blob (stage 1): the release runtime, unmodified, + the loader glue ----
Z=""
for c in "$ZZQUAKE_RELEASE/Core1_GPL/640/zz9000" "$ZZQUAKE_RELEASE/640/zz9000" "$ZZQUAKE_RELEASE"; do
    if [ -f "$c/zzquake_main.c" ]; then Z="$c"; break; fi
done
[ -n "$Z" ] || fail "zzquake_main.c not found under $ZZQUAKE_RELEASE"
echo "== stage 1: release Core1 ($Z) + loader =="
sed "s#^\([0-9a-f]*\)  #\1  $Z/#" Core1/release_core1.sha256 > "$B/check.sha"
sha256sum -c --quiet "$B/check.sha" || fail "a release Core1 file differs from the expected sources (ZZQuake2 list) - nothing built"
echo "PASS release"
# the release headers of the Quake I tree, as ZZQuake2 A0 prepares them (quakegeneric.h with its
# screen size made overridable); the generated header is checked against ZZQuake2's hash
QG=""
for c in "$Z/../../quakegeneric_source" "$Z/../quakegeneric_source" "$ZZQUAKE_RELEASE/Core1_GPL/quakegeneric_source"; do
    if [ -f "$c/quakegeneric.h" ]; then QG="$c"; break; fi
done
[ -n "$QG" ] || fail "quakegeneric.h (Quake I tree of the release) not found"
mkdir -p "$B/s1gen"
cp "$QG/quakekeys.h" "$B/s1gen/quakekeys.h"
$PY - "$QG/quakegeneric.h" "$B/s1gen/quakegeneric.h" <<'PYEOF2'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
for old, new in (
    ('#define QUAKEGENERIC_RES_X 320', '#ifndef QUAKEGENERIC_RES_X\n#define QUAKEGENERIC_RES_X 320\n#endif'),
    ('#define QUAKEGENERIC_RES_Y 240', '#ifndef QUAKEGENERIC_RES_Y\n#define QUAKEGENERIC_RES_Y 240\n#endif')):
    if g.count(old) != 1:
        raise SystemExit('quakegeneric.h: unexpected content')
    g = g.replace(old, new)
open(sys.argv[2], 'w', encoding='latin-1', newline='').write(g)
PYEOF2
echo "2912eeb9e08a7e3abad1569b4290924e4b49f8c4ad219f5c08532b658eb0f583  $B/s1gen/quakegeneric.h" \
    | sha256sum -c --quiet - || fail "generated quakegeneric.h is not the release-patched header"
RELFLAGS="$ARCH -O2 -ffreestanding -ffunction-sections -fdata-sections -w -I$B/s1gen -I$Z -DZZQ_PRODUCTION \
-DQUAKEGENERIC_RES_X=$RESX -DQUAKEGENERIC_RES_Y=$RESY"
mkdir -p "$B/s1"
echo "== safe_mem.c: -O0, no builtins, linked FIRST (release rule) =="
"$AGCC" $ARCH -O0 -ffreestanding -fno-builtin-memcpy -fno-builtin-memmove -fno-builtin-memset \
    -c "$Z/safe_mem.c" -o "$B/s1/safe_mem.o"
"$AGCC" $RELFLAGS -c "$Z/zzquake_entry.S" -o "$B/s1/zzquake_entry.o"
"$AGCC" $RELFLAGS -c "$Z/zzquake_abort.S" -o "$B/s1/zzquake_abort.o"
for f in zzquake_main zzquake_fs_mem zzquake_mmu zzquake_syscalls zzquake_a1_fstest; do
    "$AGCC" $RELFLAGS -c "$Z/$f.c" -o "$B/s1/$f.o"
done
"$AGCC" $RELFLAGS -DSys_SendKeyEvents=zzq1_Sys_SendKeyEvents_unused -DSys_Quit=zzq1_Sys_Quit_unused \
    -c "$Z/zzquake_platform.c" -o "$B/s1/zzquake_platform.o"
GLUEFLAGS="$ARCH -O2 -ffreestanding -ffunction-sections -fdata-sections -Wall -w -ICore1 -Ixacp/include -I$B/s1gen -I$Z $RESD"
"$AGCC" $GLUEFLAGS -c Core1/zzhl_glue.c -o "$B/s1/zzhl_glue.o"
"$AGCC" $GLUEFLAGS -c Core1/zzhl_fsat.c -o "$B/s1/zzhl_fsat.o"
"$AGCC" $ARCH -c Core1/zzhl_stack.S -o "$B/s1/zzhl_stack.o"
"$AGCC" $ARCH -c Core1/zzhl_mmufix.S -o "$B/s1/zzhl_mmufix.o"   # build 22: launch after a clean run (docs/SUIVI.md)
echo "== stage-1 link (release zzquake.ld, safe_mem.o first, ASSERT 2MB blob) =="
"$AGCC" $ARCH -nostartfiles -T "$Z/zzquake.ld" -Wl,--gc-sections -Wl,-Map="$B/zzhl.map" -Wl,--wrap=mmu_init_zzquake \
    "$B/s1/safe_mem.o" $(ls "$B"/s1/*.o | grep -v safe_mem) -lgcc -lc -lm -o "$B/zzhl.elf" 2> "$B/link1.log" || {
        cat "$B/link1.log"; fail "stage-1 link failed"; }
"$AOBJCOPY" -O binary "$B/zzhl.elf" "$OUT/$NAME.bin"
"$AOBJDUMP" -d "$B/zzhl.elf" > "$B/dis1.txt"
grep -q "^04900000 <zzq_entry>:" "$B/dis1.txt" || fail "zzq_entry is not at 0x04900000"
grep -q "bl.*<__wrap_mmu_init_zzquake>" "$B/dis1.txt" || fail "zzq_main does not call the mmu_init wrapper (build 22)"
grep -q "ZZHALFLIFE-A0" "$OUT/$NAME.bin" || fail "the blob identity string is missing from $NAME.bin (the 68k launcher checks it)"
if grep -qE "libc_a-(memcpy|memset|memmove)" "$B/zzhl.map"; then fail "newlib mem* linked in stage 1 - is safe_mem.o first?"; fi
echo "PASS entry, memstubs"
echo "== object checks: unaligned access, short enums, ASCII sources =="
FAILC=0
for o in "$B"/engine/*.o "$B"/xacp/*.o "$B"/fs/*.o "$B"/ref/*.o "$B"/sv/*.o "$B"/cl/*.o "$B"/vgui/*.o "$B"/game/*.o "$B"/s1/*.o; do
    if "$AREADELF" -A "$o" 2>/dev/null | grep -q "Tag_CPU_unaligned_access: v6"; then echo "ERROR: $o built WITHOUT -mno-unaligned-access"; FAILC=1; fi
    if "$AREADELF" -A "$o" 2>/dev/null | grep -q "Tag_ABI_enum_size: small"; then echo "ERROR: $o built with short enums"; FAILC=1; fi
done
for f in Core1/*.c Core1/*.h Core1/*.S Core1/*.ld xacp/src/* xacp/game/* xacp/include/*.h xacp/include/platform/*.h build_arm.sh tools/*.py launcher/*.c; do
    [ -e "$f" ] || continue
    if LC_ALL=C grep -q -P '[^\x00-\x7F]' "$f"; then echo "ERROR: non-ASCII byte in $f"; FAILC=1; fi
done
[ $FAILC = 0 ] && echo "PASS checks" || exit 1
echo "== output =="
ls -l "$OUT/$NAME.bin" "$OUT/$CORE.bin" "$OUT/zzhl_game.bin"
md5sum "$OUT/$NAME.bin" "$OUT/$CORE.bin" "$OUT/zzhl_game.bin"
sha256sum "$OUT/$NAME.bin" "$OUT/$CORE.bin" "$OUT/zzhl_game.bin"
echo "DONE: copy out/$NAME.bin next to the ZZHalfLife launcher on the Amiga and out/$CORE.bin"
echo "      and out/zzhl_game.bin into PROGDIR:data/ (with pak0.pak), then: ZZHalfLife [MAP=c0a0] (docs/TEST.md)"
