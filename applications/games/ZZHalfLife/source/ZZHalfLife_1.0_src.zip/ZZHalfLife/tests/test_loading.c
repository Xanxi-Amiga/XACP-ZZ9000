/* test_loading.c - ZZHalfLife host test of xacp/src/xacp_loading.c (build 22): the loading screen
 * drawn into a PC buffer and written as PPM pictures (build/host/loading_*.ppm), once on black
 * (start of the game) and once over a darkened picture (level change); checks the colour-code and
 * time-stamp cleaning of the console line.  sh tests/run_host_tests.sh.  ASCII only. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void xacp_loading_test_draw( unsigned short *out, const unsigned short *bg, unsigned bg_pitch, unsigned now_us, const char *raw );
typedef struct { int w, h; const unsigned char *rgba; void *handle; } xl_img_t;
extern int xacp_loading_test_picture( unsigned short *out, int (*img_load)( const char *, xl_img_t * ), void (*img_free)( xl_img_t * ), char *(*text_load)( const char * ), const char *raw, char *from, unsigned fromsz );

/* a fake Steam install - BackgroundLoadingLayout.txt at 800 x 600 and its 12 tiles, each
   tile a colour of its own with a lighter cross so that the scaling shows */
static int g_layout = 1;
static unsigned tile_rgb( int r, int c ) { return (unsigned)(( 40 + 60 * c ) << 16 | ( 40 + 80 * r ) << 8 | ( 200 - 40 * c )); }
static int fake_img( const char *name, xl_img_t *o )
{
	int r, c, w, h, x, y;
	unsigned char *p;
	if( sscanf( name, "resource/background/800_%d_%c_loading.tga", &r, (char *)&c ) != 2 ) return 0;
	c = (char)c - 'a';
	if( r < 1 || r > 3 || c < 0 || c > 3 ) return 0;
	w = c == 3 ? 32 : 256; h = r == 3 ? 88 : 256;
	p = (unsigned char *)malloc( (size_t)w * h * 4 );
	for( y = 0; y < h; y++ ) for( x = 0; x < w; x++ )
	{
		unsigned v = tile_rgb( r - 1, c );
		int cross = ( x == w / 2 || y == h / 2 );
		p[( y * w + x ) * 4 + 0] = cross ? 255 : (unsigned char)( v >> 16 );
		p[( y * w + x ) * 4 + 1] = cross ? 255 : (unsigned char)( v >> 8 );
		p[( y * w + x ) * 4 + 2] = cross ? 255 : (unsigned char)v;
		p[( y * w + x ) * 4 + 3] = 255;
	}
	o->w = w; o->h = h; o->rgba = p; o->handle = p;
	return 1;
}
static void fake_free( xl_img_t *o ) { free( o->handle ); }
static char *fake_text( const char *name )
{
	static const char lay[] = "resolution\t800\t600\n\n// tiles\n"
		"resource/background/800_1_a_loading\tscaled\t0\t0\n\"resource/background/800_1_b_loading\" scaled 256 0\n"
		"resource/background/800_1_c_loading\tscaled\t512\t0\nresource/background/800_1_d_loading\tscaled\t768\t0\n"
		"resource/background/800_2_a_loading\tscaled\t0\t256\nresource/background/800_2_b_loading\tscaled\t256\t256\n"
		"resource/background/800_2_c_loading\tscaled\t512\t256\nresource/background/800_2_d_loading\tscaled\t768\t256\n"
		"resource/background/800_3_a_loading\tscaled\t0\t512\nresource/background/800_3_b_loading\tscaled\t256\t512\n"
		"resource/background/800_3_c_loading\tscaled\t512\t512\nresource/background/800_3_d_loading\tscaled\t768\t512\n";
	char *t;
	if( !g_layout || strcmp( name, "resource/BackgroundLoadingLayout.txt" )) return NULL;
	t = (char *)malloc( sizeof( lay ));
	memcpy( t, lay, sizeof( lay ));
	return t;
}
extern int xacp_loading_test_tga( unsigned short *out, const unsigned char *b, int len, const char *raw );
extern int xacp_loading_test_logo( unsigned short *out, char *(*text_load)( const char * ), unsigned char *(*bin_load)( const char *, int * ), const char *raw, char *from, unsigned fromsz );
/* the title: a fake hud.txt / titles.txt and a fake additive sprite (grey ramp palette, a frame
   of bars) - the shapes are not Valve's, only the file formats */
static int g_black;
static char *fake_text2( const char *name )
{
	static const char hud[] = "4\n// fake\ntitle_half\t320\t320_logo\t0\t0\t60\t20\ntitle_life\t320\t320_logo\t60\t0\t50\t20\n"
		"title_half 640 640_logo 0 0 120 40\ntitle_life 640 640_logo 120 0 100 40\n";
	static const char tit[] = "// fake titles\r\n$position -1 0.3\r\n$color 100 100 100\r\nCR1\r\n{\r\nx\r\n}\r\n$color 240 110 0\r\n$color2 0 0 0\r\nGAMETITLE\r\n{\r\nHalf-Life\r\n}\r\n$color 1 2 3\r\n";
	const char *src = !strcmp( name, "sprites/hud.txt" ) ? hud : !strcmp( name, "titles.txt" ) ? tit : NULL;
	char *t;
	if( !src ) return NULL;
	t = (char *)malloc( strlen( src ) + 1 ); strcpy( t, src ); return t;
}
static unsigned char *fake_spr( const char *name, int *len )
{
	int w, h, i, x, y, off;
	unsigned char *b;
	if( !strcmp( name, "sprites/640_logo.spr" )) { w = 220; h = 40; } else if( !strcmp( name, "sprites/320_logo.spr" )) { w = 110; h = 20; } else return NULL;
	*len = 42 + 768 + 20 + w * h;
	b = (unsigned char *)calloc( 1, *len );
	memcpy( b, "IDSP", 4 ); b[4] = 2; b[12] = 1; b[28] = 1; b[40] = 0; b[41] = 1;   /* v2, additive, 1 frame, 256 colours */
	for( i = 0; i < 256; i++ ) b[42 + i * 3] = b[43 + i * 3] = b[44 + i * 3] = (unsigned char)i;
	off = 42 + 768; b[off + 12] = (unsigned char)w; b[off + 16] = (unsigned char)h; off += 20;
	for( y = 0; y < h; y++ ) for( x = 0; x < w; x++ ) b[off + y * w + x] = ( x % 12 < 6 && y > 2 && y < h - 3 ) ? 255 : 0;
	return b;
}
static int black_img( const char *name, xl_img_t *o )
{
	int r = fake_img( name, o ), i;
	if( r && g_black ) for( i = 0; i < o->w * o->h * 4; i += 4 ) { ((unsigned char *)o->rgba)[i] = ((unsigned char *)o->rgba)[i + 1] = ((unsigned char *)o->rgba)[i + 2] = 0; }
	return r;
}
static int near_rgb( unsigned short p, unsigned v )
{
	int r = ( p >> 11 ) << 3, g = (( p >> 5 ) & 63 ) << 2, b = ( p & 31 ) << 3;
	return abs( r - (int)( v >> 16 )) < 12 && abs( g - (int)(( v >> 8 ) & 255 )) < 12 && abs( b - (int)( v & 255 )) < 12;
}

static void ppm( const char *path, const unsigned short *p, int w, int h )
{
	FILE *f = fopen( path, "wb" );
	int i;
	if( !f ) return;
	fprintf( f, "P6\n%d %d\n255\n", w, h );
	for( i = 0; i < w * h; i++ )
	{
		unsigned v = p[i];
		unsigned char c[3] = { (unsigned char)((( v >> 11 ) & 31 ) * 255 / 31 ), (unsigned char)((( v >> 5 ) & 63 ) * 255 / 63 ), (unsigned char)(( v & 31 ) * 255 / 31 ) };
		fwrite( c, 1, 3, f );
	}
	fclose( f );
}
static int count( const unsigned short *p, int n, unsigned short c ) { int i, k = 0; for( i = 0; i < n; i++ ) if( p[i] == c ) k++; return k; }

/* zzhl_loadscreen.tga as tools/hl_loading.py writes it (tests/test_hl_loading.py leaves
   one made from a made-up tree; its path in ZZHL_LOADSCREEN): 8-bit grey, top line first */
static int made_img( const char *name, xl_img_t *o )
{
	const char *path = getenv( "ZZHL_LOADSCREEN" );
	unsigned char h[18], *p;
	int w, ht, i;
	FILE *f;
	if( strcmp( name, "zzhl_loadscreen.tga" ) || !path || !( f = fopen( path, "rb" ))) return 0;
	if( fread( h, 1, 18, f ) != 18 || h[2] != 3 || h[16] != 8 || !( h[17] & 0x20 )) { fclose( f ); return 0; }
	fseek( f, 18 + h[0], SEEK_SET );
	w = h[12] | h[13] << 8; ht = h[14] | h[15] << 8;
	p = (unsigned char *)malloc( (size_t)w * ht * 4 );
	for( i = 0; i < w * ht; i++ ) { int v = fgetc( f ); p[i * 4] = p[i * 4 + 1] = p[i * 4 + 2] = (unsigned char)( v < 0 ? 0 : v ); p[i * 4 + 3] = 255; }
	fclose( f );
	o->w = w; o->h = ht; o->rgba = p; o->handle = p;
	return 1;
}
static int made_or_fake( const char *name, xl_img_t *o ) { return made_img( name, o ) || fake_img( name, o ); }

int main( void )
{
	static unsigned short out[LW * LH], bg[LW * LH];
	int fails = 0, i;
	/* start of the game: black, a mirror line with colours and a stamp */
	xacp_loading_test_draw( out, NULL, 0, 123456u, "\x1b[0m[00:46:56] loading models/^3v_shotgun.mdl" );
	ppm( "build/host/loading_start.ppm", out, LW, LH );
	if( count( out, LW * LH, 0xFFFFu ) < 500 ) { printf( "FAIL: no LOADING title\n" ); fails++; } else printf( "ok: LOADING title drawn\n" );
	if( count( out, LW * LH, 0xFD00u ) < 20 ) { printf( "FAIL: no bar\n" ); fails++; } else printf( "ok: moving bar drawn\n" );
	if( count( out, LW * LH, 0x8410u ) < 100 ) { printf( "FAIL: no console line\n" ); fails++; } else printf( "ok: console line drawn\n" );
	/* level change: a bright picture behind, darkened to a quarter */
	for( i = 0; i < LW * LH; i++ ) bg[i] = (unsigned short)((( i % LW ) * 31 / LW ) << 11 | (( i / LW ) * 63 / LH ) << 5 | 0x10 );
	xacp_loading_test_draw( out, bg, LW * 2, 900000u, "Spawn Server: c1a0a" );
	ppm( "build/host/loading_change.ppm", out, LW, LH );
	if( out[LW * ( LH - 40 ) + LW - 20] != (unsigned short)(( bg[LW * ( LH - 40 ) + LW - 20] >> 2 ) & 0x39E7u )) { printf( "FAIL: background not darkened\n" ); fails++; }
	else printf( "ok: game picture behind, darkened\n" );
	{   /* Half-Life's loading picture from the layout file, then by the tile names */
		char from[64];
		int k;
		for( k = 0; k < 2; k++ )
		{
			int x1 = LW / 64, y1 = LH / 48, x2 = LW - 1 - LW / 128, y2 = LH * 3 / 4;   /* in tile 1_a; in tile 2_d */
			g_layout = !k;
			memset( out, 0, sizeof( out ));
			if( !xacp_loading_test_picture( out, fake_img, fake_free, fake_text, "loading maps/c1a0.bsp", from, sizeof( from ))) { printf( "FAIL: no picture (%s)\n", k ? "names" : "layout" ); fails++; continue; }
			printf( "   picture from %s\n", from );
			if( !near_rgb( out[y1 * LW + x1], tile_rgb( 0, 0 )) || !near_rgb( out[y2 * LW + x2], tile_rgb( 1, 3 ))) { printf( "FAIL: tiles not where the layout puts them (%04x %04x)\n", out[y1 * LW + x1], out[y2 * LW + x2] ); fails++; }
			else printf( "ok: tiles composed and scaled (%s)\n", k ? "by name" : "layout file" );
			if( !k ) ppm( "build/host/loading_picture.ppm", out, LW, LH );
		}
		g_layout = 1;
		/* Treat fully black loading tiles as an absent picture. */
		g_black = 1;
		if( xacp_loading_test_picture( out, black_img, fake_free, fake_text, "x", from, sizeof( from )) || !strstr( from, "black" )) { printf( "FAIL: black tiles taken as a picture (%s)\n", from ); fails++; }
		else printf( "ok: black tiles refused (%s)\n", from );
		g_black = 0;
	}
	if( getenv( "ZZHL_LOADSCREEN" ))
	{   /* the picture of tools/hl_loading.py comes before the Steam tiles; L O A D I N G,
	       the bar and the console line under the logo, whose letters end at 42 % of the height */
		char from[160];
		int s = LW >= 640 ? 2 : 1, logo_end = LH * 42 / 100, y, x, light_under = 0, light_over = 0, orange_under = 0, orange_over = 0, logo = 0;
		memset( out, 0, sizeof( out ));
		if( !xacp_loading_test_picture( out, made_or_fake, fake_free, fake_text, "\x1b[0m[00:46:56] loading maps/c1a0.bsp", from, sizeof( from )) || !strstr( from, "zzhl_loadscreen" ))
		{ printf( "FAIL: zzhl_loadscreen.tga not taken (%s)\n", from ); fails++; }
		else
		{
			for( y = 0; y < LH; y++ ) for( x = 0; x < LW; x++ )
			{
				unsigned short p = out[y * LW + x];
				if( p == 0xDEFBu ) { if( y > logo_end + 10 * s && y < logo_end + 24 * s ) light_under++; }
				if( p == 0xFD00u ) { if( y > logo_end + 24 * s ) orange_under++; else orange_over++; }
				if( y <= logo_end && y > logo_end - 20 * s && ( p >> 11 ) >= 28 ) logo++;
				if( y > logo_end + 24 * s && y < LH - 16 && p == 0xDEFBu ) light_over++;
			}
			printf( "   picture from %s: %d logo pixels, LOADING %d, bar %d\n", from, logo, light_under, orange_under );
			if( logo < 100 * s ) { printf( "FAIL: no logo above line %d\n", logo_end ); fails++; }
			else if( light_under < 60 * s * s || orange_under < 20 || orange_over || light_over ) { printf( "FAIL: LOADING / bar not under the logo (%d %d %d %d)\n", light_under, orange_under, orange_over, light_over ); fails++; }
			else printf( "ok: hl_loading.py picture, LOADING and bar under the logo\n" );
			ppm( "build/host/loading_made.ppm", out, LW, LH );
			{   /* the same file decoded without the engine (read before Host_Main), as
			       grey and as a bottom-up 24-bit copy: the same screen */
				static unsigned short o2[LW * LH], o3[LW * LH];
				static unsigned char b[600000], c[18 + 640 * 480 * 3];
				FILE *f = fopen( getenv( "ZZHL_LOADSCREEN" ), "rb" );
				int len = f ? (int)fread( b, 1, sizeof( b ), f ) : 0, w, h, y, x, ok2, ok3;
				if( f ) fclose( f );
				ok2 = xacp_loading_test_tga( o2, b, len, "\x1b[0m[00:46:56] loading maps/c1a0.bsp" );
				w = b[12] | b[13] << 8; h = b[14] | b[15] << 8;
				memset( c, 0, 18 ); c[2] = 2; c[12] = b[12]; c[13] = b[13]; c[14] = b[14]; c[15] = b[15]; c[16] = 24; c[17] = 0;
				for( y = 0; y < h; y++ ) for( x = 0; x < w; x++ )
				{
					unsigned char v = b[18 + b[0] + y * w + x];
					unsigned char *d = c + 18 + (( h - 1 - y ) * w + x ) * 3;
					d[0] = d[1] = d[2] = v;
				}
				ok3 = xacp_loading_test_tga( o3, c, 18 + w * h * 3, "\x1b[0m[00:46:56] loading maps/c1a0.bsp" );
				if( !ok2 || !ok3 || memcmp( o2, out, sizeof( o2 )) || memcmp( o3, out, sizeof( o3 ))) { printf( "FAIL: picture read without the engine differs (%d %d)\n", ok2, ok3 ); fails++; }
				else printf( "ok: picture read without the engine (grey, and 24-bit bottom-up): same screen\n" );
			}
		}
	}
	else printf( "   (no ZZHL_LOADSCREEN: hl_loading.py picture not tested)\n" );
	{   /* the HALF-LIFE title on black, coloured by GAMETITLE's $color, placed by its $position */
		char from[160];
		int i, lit = 0, right = 1, top;
		memset( out, 0, sizeof( out ));
		if( !xacp_loading_test_logo( out, fake_text2, fake_spr, "loading maps/c0a0.bsp", from, sizeof( from ))) { printf( "FAIL: no title\n" ); fails++; }
		else
		{
			top = (int)( 0.3f * LH );
			for( i = 0; i < LW * LH; i++ ) if( out[i] && i / LW < top + ( LW >= 640 ? 40 : 20 ) && i / LW >= top )
			{
				lit++;
				if( !near_rgb( out[i], 240u << 16 | 110u << 8 | 0u )) right = 0;
			}
			printf( "   %s, %d title pixels\n", from, lit );
			if( lit < 200 || !right ) { printf( "FAIL: title missing or not in GAMETITLE's colour\n" ); fails++; }
			else printf( "ok: title drawn additively in GAMETITLE's colour at its position\n" );
			ppm( "build/host/loading_title.ppm", out, LW, LH );
		}
	}
	printf( "%s\n", fails ? "LOADING SOME TESTS FAILED" : "LOADING ALL TESTS PASSED" );
	return fails ? 1 : 0;
}
