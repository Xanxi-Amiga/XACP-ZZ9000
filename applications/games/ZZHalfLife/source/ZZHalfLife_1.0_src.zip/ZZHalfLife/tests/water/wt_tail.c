static double rnd( void ) { return rand() / (double)RAND_MAX; }
static void clip( const matrix4x4 m, const float *v, float *x, float *y, float *w )
{
	*x = m[0][0]*v[0] + m[0][1]*v[1] + m[0][2]*v[2] + m[0][3];
	*y = m[1][0]*v[0] + m[1][1]*v[1] + m[1][2]*v[2] + m[1][3];
	*w = m[3][0]*v[0] + m[3][1]*v[1] + m[3][2]*v[2] + m[3][3];
}
int main( void )
{
	long tests = 0, culled = 0, truly = 0, wrong = 0; int it;
	srand( 12345 );
	for( it = 0; it < 4000; it++ )
	{
		/* a view: quake-style eye space (x right, y up, -z forward) from yaw, pitch, position; an entity: yaw, pitch, roll, origin */
		double yaw = rnd()*6.283, pitch = ( rnd() - 0.5 ) * 2.6, ey = rnd()*6.283, ep = ( rnd()-0.5 )*1.0, er = ( rnd()-0.5 )*1.0;
		float fwd[3] = { (float)(cos(pitch)*cos(yaw)), (float)(cos(pitch)*sin(yaw)), (float)sin(pitch) };
		float right[3] = { (float)sin(yaw), (float)-cos(yaw), 0 }, up[3];
		float eye[3] = { (float)(( rnd()-0.5 )*2000), (float)(( rnd()-0.5 )*2000), (float)(( rnd()-0.5 )*600) };
		matrix4x4 wv, obj, pm, mvp; int i, j, q;
		float zn = 4, zf = 4096, xm = zn * (float)tan( 90.0 * M_PI / 360.0 ), ym = xm * 0.75f;
		float waveh = it % 3 == 0 ? 0.0f : (float)( rnd() * ( it % 7 == 0 ? 4.0 : 0.6 ));
		up[0] = right[1]*fwd[2] - right[2]*fwd[1]; up[1] = right[2]*fwd[0] - right[0]*fwd[2]; up[2] = right[0]*fwd[1] - right[1]*fwd[0];
		memset( wv, 0, sizeof wv );
		for( j = 0; j < 3; j++ ) { wv[0][j] = right[j]; wv[1][j] = up[j]; wv[2][j] = -fwd[j]; }
		for( i = 0; i < 3; i++ ) wv[i][3] = -( wv[i][0]*eye[0] + wv[i][1]*eye[1] + wv[i][2]*eye[2] );
		wv[3][3] = 1;
		memset( obj, 0, sizeof obj ); obj[3][3] = 1;
		if( it % 4 == 0 ) { obj[0][0] = obj[1][1] = obj[2][2] = 1; }                      /* the world / at rest */
		else
		{
			double cy = cos(ey), sy = sin(ey), cp = cos(ep), sp = sin(ep), cr = cos(er), sr = sin(er);
			if( it % 4 == 1 ) { cy = 1; sy = 0; cp = 1; sp = 0; cr = 1; sr = 0; }          /* moved only */
			obj[0][0] = (float)(cp*cy); obj[0][1] = (float)(sr*sp*cy - cr*sy); obj[0][2] = (float)(cr*sp*cy + sr*sy);
			obj[1][0] = (float)(cp*sy); obj[1][1] = (float)(sr*sp*sy + cr*cy); obj[1][2] = (float)(cr*sp*sy - sr*cy);
			obj[2][0] = (float)-sp;     obj[2][1] = (float)(sr*cp);            obj[2][2] = (float)(cr*cp);
			obj[0][3] = (float)(( rnd()-0.5 )*800); obj[1][3] = (float)(( rnd()-0.5 )*800); obj[2][3] = (float)(( rnd()-0.5 )*300);
		}
		Matrix4x4_Concat( RI.modelviewMatrix, wv, obj );
		memset( pm, 0, sizeof pm );
		pm[0][0] = zn / xm; pm[1][1] = zn / ym; pm[2][2] = -( zf + zn ) / ( zf - zn ); pm[3][2] = -1; pm[2][3] = -( 2 * zf * zn ) / ( zf - zn );
		memcpy( RI.projectionMatrix, pm, sizeof pm );
		Matrix4x4_Concat( mvp, pm, RI.modelviewMatrix );
		zzhl_water_matrix( RI.modelviewMatrix );
		for( q = 0; q < 500; q++ )
		{
			float v[4][VERTEXSIZE]; float cx = (float)( eye[0] + ( rnd()-0.5 )*3000 ), cyy = (float)( eye[1] + ( rnd()-0.5 )*3000 ), cz = (float)( eye[2] + ( rnd()-0.5 )*500 );
			float sz = (float)( 16 + rnd()*112 ); int k, t, all[4] = { 1, 1, 1, 1 }, out;
			memset( v, 0, sizeof v );
			v[0][0] = cx; v[0][1] = cyy; v[1][0] = cx + sz; v[1][1] = cyy; v[2][0] = cx + sz; v[2][1] = cyy + sz; v[3][0] = cx; v[3][1] = cyy + sz;
			for( k = 0; k < 4; k++ ) v[k][2] = cz;
			out = zzhl_poly_outside( v[0], 4, 30.0f * waveh );
			tests++;
			/* the truth, with the waves ref_gl can add: each vertex lifted by 0..28.8 h, either sign of h, 8 draws */
			for( t = 0; t < 8; t++ )
			{
				int s[4] = { 1, 1, 1, 1 }; float sg = t & 1 ? -1.0f : 1.0f;
				for( k = 0; k < 4; k++ )
				{
					float p[3] = { v[k][0], v[k][1], v[k][2] + sg * waveh * (float)( t < 2 ? 28.8 : rnd() * 28.8 ) }, x, y, w;
					clip( mvp, p, &x, &y, &w );
					if( !( x < -w )) s[0] = 0;
					if( !( x > w )) s[1] = 0;
					if( !( y < -w )) s[2] = 0;
					if( !( y > w )) s[3] = 0;
				}
				for( k = 0; k < 4; k++ ) if( !s[k] ) all[k] = 0;
				if( out && !( s[0] || s[1] || s[2] || s[3] )) { wrong++; break; }
			}
			if( all[0] || all[1] || all[2] || all[3] ) truly++;
			if( out ) culled++;
		}
	}
	printf( "%ld quads, %ld truly out of view whatever the wave, %ld left out by the test, left out but in view: %ld\n", tests, truly, culled, wrong );
	return wrong != 0;
}
