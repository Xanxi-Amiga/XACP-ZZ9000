/* tests/water: the harness around the water test of build_arm.sh 0d3 (WATERCULL, build 100).
   run_water_check.sh puts ref_gl's Matrix4x4_Concat and the generated functions between this file
   and wt_tail.c.  ASCII only. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
typedef float vec_t; typedef vec_t matrix4x4[4][4];
#define VERTEXSIZE 7
static struct { matrix4x4 modelviewMatrix, projectionMatrix; } RI;
