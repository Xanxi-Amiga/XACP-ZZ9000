#!/bin/sh
# ZZHalfLife build 100: the water test of WATERCULL, as build_arm.sh generated it (build/gen/gl_rsurf.c),
# against brute force on the PC: random views, entities at rest, moved and rotated, random waves.
# A quad the test leaves out must have its four vertices beyond one and the same side of the view
# whatever the wave.  Run after build_arm.sh:   XASH3D=/path/xash3d-fwgs sh tests/water/run_water_check.sh
set -e
X="${XASH3D:-../../../../xash3d-fwgs}"
G="build/gen/gl_rsurf.c"
[ -s "$G" ] || { echo "run build_arm.sh first: $G is missing"; exit 1; }
mkdir -p build/host/water
python3 - "$G" "$X/ref/common/ref_math.c" tests/water build/host/water/wt.c <<'PYEOF'
import sys
g = open(sys.argv[1], encoding='latin-1').read()
r = open(sys.argv[2], encoding='latin-1').read()
fn = g[g.index('static float zz_wm[3][4], zz_wk[4];'):g.index('static void EmitWaterPolys( msurface_t *warp')]
cc = r[r.index('void Matrix4x4_Concat('):r.index('void Matrix4x4_CreateOrtho(')]
cc = cc[:cc.index('/*\n================\nMatrix4x4_CreateProjection')] if 'Matrix4x4_CreateProjection' in cc else cc
open(sys.argv[4], 'w').write(open(sys.argv[3] + '/wt_head.c').read() + cc + fn + open(sys.argv[3] + '/wt_tail.c').read())
PYEOF
${CC:-gcc} -O2 -Wall -o build/host/water/wt build/host/water/wt.c -lm
./build/host/water/wt
