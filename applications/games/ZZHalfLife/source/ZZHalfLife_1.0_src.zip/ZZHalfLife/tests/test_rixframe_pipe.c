/* tests/test_rixframe_pipe.c - the deferred queue of librixgpu/rixframe.c (the
 * vendored copy, unmodified for this test) against a behavioural GPU, deferred and pipelined.
 *
 * The model executes what is submitted, in order, at its own pace while Core1 waits or works:
 * DDR lists are read at EXECUTION time (a ring slot rewritten too early shows), FIFO packets as
 * copied; OP_RENDER_CONFIG sets registers, a memset whose scissor is one line high writes a fence
 * (the clear colour, rix_fence_color is the identity here) into the fence line of the colour buffer
 * the stream last selected (REG COLOR_ADDR).  Checked while it runs:
 *   rule 11   - no DDR list submitted while a bind is submitted and not executed (the FSC deadlock);
 *   ring      - a list's words unchanged between its submission and its execution;
 *   fences    - every frame fence appears in its own buffer, in order;
 *   binds     - rix_frame_bind_passed never says "passed" for a bind not executed, and says it
 *               once the GPU went past it (current and previous frame);
 *   errors    - no RIXE_* from the library.
 * Frames follow ZZHalfLife's flow (Core1/zzhl_gpu.c, rix_overlap 1): frame N+1 begins on the buffer
 * of N-1, the pending frame N-1 is waited for and shown at the end of N, before N closes.
 * SPDX-License-Identifier: 0BSD */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rixframe.h"
#include "rix_window.h"
#include "rix_diag.h"

/* ---- memory ---- */
#define COL_A   0x06600000u
#define COL_B   0x06696500u
#define COL_SZ  (640u * 481u * 2u)
#define RING    0x10000000u
#define RINGSZ  (32u * 16384u)   /* the ring keeps its size, the slots get smaller (g_slots/g_chunk) */
#define BINDB   0x10100000u
#define TEXB    0x20000000u
static unsigned char m_col[2][COL_SZ], m_ring[RINGSZ], m_bind[1024], m_tex[64 * 2048];
void *sim_ptr(u32 a)
{
    if (a >= COL_A && a < COL_A + COL_SZ) return m_col[0] + (a - COL_A);
    if (a >= COL_B && a < COL_B + COL_SZ) return m_col[1] + (a - COL_B);
    if (a >= RING && a < RING + RINGSZ) return m_ring + (a - RING);
    if (a >= BINDB && a < BINDB + sizeof m_bind) return m_bind + (a - BINDB);
    if (a >= TEXB && a < TEXB + sizeof m_tex) return m_tex + (a - TEXB);
    fprintf(stderr, "sim_ptr: bad address %08x\n", a); exit(2);
}
u32 sim_mmio_rd(u32 a) { (void)a; return 0; }
void sim_mmio_wr(u32 a, u32 v) { (void)a; (void)v; }
void sim_wfi(void) { }
u32 rix_geo_w = 640u, rix_geo_h_alloc = 481u, rix_geo_fence_off = 480u * 640u * 2u;
static u16 *fence_px(u32 color, u32 x) { return (u16 *)sim_ptr(color + rix_geo_fence_off + x * 2u); }

/* ---- the GPU ---- */
#define QMAX 4096
typedef struct { int fifo, bind; u32 base, n, hash, w[96]; } item;
static item g_q[QMAX];
static int g_qh, g_qn;
static double now_us, gpu_busy_until;
static u32 regs[32];
static int violations, errors;
static unsigned rng = 12345u;
static unsigned rnd(unsigned n) { rng = rng * 1103515245u + 12345u; return (rng >> 8) % n; }
static double gpu_word_us = 0.004, gpu_bind_us = 60.0;
/* the engine phase and the presentation, as the 640 combat run measured them (0 = the old model) */
static double g_engine_us, g_engine_pump_us, g_present_us, g_present_pump_us;
static int run_keep_stats;
static u32 executed_bind[65536];          /* seq -> 1 once the GPU executed that bind's fence */
static u32 hash_words(u32 base, u32 n) { u32 h = 2166136261u, i; for (i = 0; i < n; i++) { u32 v; memcpy(&v, sim_ptr(base + i * 4u), 4); h = (h ^ v) * 16777619u; } return h; }
static void bad(const char *what) { if (violations < 20) fprintf(stderr, "VIOLATION at %.1f us: %s\n", now_us, what); violations++; }
/* an item's effects (fence pixels) appear when the GPU has spent its time on it, not when it starts
   (the fence-based busy test of the idle measure needs a GPU that is busy until its fences show) */
static double exec_words(const u32 *w, u32 n, int is_bind, int dry)
{
    u32 i = 0;
    double t = 0.0;
    while (i < n) {
        u32 op = w[i] & 0xF0000000u;
        if (op == RIX_OP_NOP) { i++; t += gpu_word_us; continue; }
        if (op == RIX_OP_RENDER_CONFIG) { if (!dry) regs[w[i] & 31u] = (i + 1 < n) ? w[i + 1] : 0u; i += 2; t += 2 * gpu_word_us; continue; }
        if (op == RIX_OP_FRAMEBUFFER) {
            if (!dry) {
                u32 y1 = (regs[RIX_REG_SCISSOR_END] >> 16) & 0x7FFu, x0 = regs[RIX_REG_SCISSOR_START] & 0x7FFu, k;
                if (y1 == 1u && (w[i] & RIX_FB_COLOR_SELECT)) {
                    u32 color = regs[RIX_REG_COLOR_ADDR];
                    u16 v = (u16)regs[RIX_REG_CLEAR_COLOR];
                    if (color != COL_A && color != COL_B) bad("fence with no colour buffer selected");
                    else for (k = 0; k < 64u; k++) *fence_px(color, x0 + k) = v;
                    if (x0 == RIX_BIND_FENCE_X) executed_bind[v] = 1u;
                }
            }
            i++; t += 1.0; continue;
        }
        if (op == RIX_OP_TEXTURE) {
            u32 pages = w[i] & 0x7FFFFu;
            if (!is_bind && !dry) bad("OP_TEXTURE inside a frame chunk");
            i += 1 + pages; t += gpu_bind_us; continue;
        }
        if (op == RIX_OP_TRIANGLE) { i += 40; t += 2.0; continue; }
        i++;
    }
    return t;
}
static int g_inprog;                       /* the head item is being executed (its effects at gpu_busy_until) */
static double exec_item(item *it, int dry)
{
    if (it->fifo) return exec_words(it->w, it->n, it->bind, dry);
    else {
        static u32 tmp[4096];
        if (hash_words(it->base, it->n) != it->hash) bad("list rewritten between submission and the end of its execution (ring slot reused)");
        memcpy(tmp, sim_ptr(it->base), it->n * 4u);
        return exec_words(tmp, it->n, it->bind, dry);
    }
}
static void gpu_run(void)
{
    for (;;) {
        if (g_inprog) {
            if (gpu_busy_until > now_us) break;
            (void)exec_item(&g_q[g_qh], 0);
            g_qh = (g_qh + 1) % QMAX; g_qn--; g_inprog = 0;
        }
        if (!g_qn) break;
        if (gpu_busy_until < now_us) gpu_busy_until = now_us;   /* idle meanwhile */
        gpu_busy_until += exec_item(&g_q[g_qh], 1);
        g_inprog = 1;
    }
}
static void advance(double us) { now_us += us; gpu_run(); }
static int bind_in_gpu(void)
{
    int i;
    for (i = 0; i < g_qn; i++) if (g_q[(g_qh + i) % QMAX].bind) return 1;
    return 0;
}
static void push(item *it)
{
    if (g_qn == QMAX) { fprintf(stderr, "model queue full\n"); exit(2); }
    g_q[(g_qh + g_qn) % QMAX] = *it; g_qn++;
}

/* ---- rixgpu.c, as the model needs it ---- */
void sim_barrier(void) { advance(0.02); }
u32 rix_now(void) { advance(0.01); return (u32)(now_us * 333.0); }
u32 rix_ticks_to_us(u32 dt) { return dt / 333u; }
void rix_idle_us(u32 us) { advance((double)us); }
void rix_mem_clean(u32 addr, u32 bytes) { (void)addr; (void)bytes; }
static u32 g_sd[256];
volatile u32 *rix_sd(void) { return g_sd; }
u32 rix_caps(void) { return RIXCAP_TEX_DDR; }
int rix_alive(void) { return 0; }
u32 rix_fifo_vacancy(void) { return 512u; }
u32 rix_fifo_isr(void) { return 0u; }
u32 rix_fence_color(u32 value16) { return value16 & 0xFFFFu; }
void rix_dl_begin(rix_dl *dl, u32 base, u32 cap_words) { memset(dl, 0, sizeof *dl); dl->base = base; dl->cap_words = cap_words; }
void rix_dl_word(rix_dl *dl, u32 w) { if (dl->n >= dl->cap_words) { dl->overflow = 1; return; } memcpy(sim_ptr(dl->base + dl->n * 4u), &w, 4); dl->n++; }
void rix_dl_reg(rix_dl *dl, u32 reg, u32 val) { rix_dl_word(dl, RIX_REG(reg)); rix_dl_word(dl, val); if (reg == RIX_REG_FRAGMENT) dl->frag_shadow = val; }
void rix_dl_clear(rix_dl *dl, u32 pixels) { rix_dl_word(dl, RIX_FB_CMD(pixels, RIX_FB_COLOR_SELECT | RIX_FB_MEMSET)); }
void rix_dl_clear_depth(rix_dl *dl, u32 pixels) { rix_dl_word(dl, RIX_FB_CMD(pixels, RIX_FB_DEPTH_SELECT | RIX_FB_MEMSET)); }
void rix_dl_tri(rix_dl *dl, const u32 *d) { u32 i; rix_dl_word(dl, RIX_OP_TRIANGLE | 39u); for (i = 0; i < 39u; i++) rix_dl_word(dl, d[i]); }
void rix_dl_fence_at(rix_dl *dl, u32 v, u32 features, u32 x0)
{
    u32 i;
    for (i = 0; i < 4u; i++) rix_dl_word(dl, RIX_OP_NOP);
    rix_dl_reg(dl, RIX_REG_FEATURES, features | RIX_FEAT_SCISSOR);
    rix_dl_reg(dl, RIX_REG_FRAGMENT, RIX_FRAGMENT_A07B);
    rix_dl_reg(dl, RIX_REG_SCISSOR_START, RIX_XY(x0, 0u));
    rix_dl_reg(dl, RIX_REG_SCISSOR_END, RIX_XY(x0 + RIX_FENCE_PIXELS, 1u));
    rix_dl_reg(dl, RIX_REG_CLEAR_COLOR, rix_fence_color(v));
    rix_dl_clear(dl, RIX_FENCE_PIXELS);
    if (x0 == 0u) dl->fence_value = v;
}
void rix_dl_fence(rix_dl *dl, u32 v, u32 features) { rix_dl_fence_at(dl, v, features, 0u); }
u32 rix_dl_finish(rix_dl *dl) { while (dl->n & 15u) rix_dl_word(dl, RIX_OP_NOP); return dl->n; }
int rix_submit(rix_dl *dl)
{
    item it;
    memset(&it, 0, sizeof it);
    it.base = dl->base; it.n = dl->n; it.hash = hash_words(dl->base, dl->n);
    it.bind = (dl->base >= BINDB && dl->base < BINDB + sizeof m_bind);
    if (!it.bind && bind_in_gpu()) bad("rule 11: a DDR list submitted behind a bind not executed");
    push(&it);
    advance(0.2);
    return 0;
}
int rix_submit_words_fifo_nowait(const u32 *w, u32 n)
{
    item it;
    memset(&it, 0, sizeof it);
    if (n > 96u) { bad("FIFO packet too long"); n = 96u; }
    it.fifo = 1; it.bind = 1; it.n = n; memcpy(it.w, w, n * 4u);
    push(&it);
    advance(0.5);
    return 0;
}
int rix_fence_passed_at(u32 buf, u32 value16, u32 x0)
{
    u16 cur = *fence_px(buf, x0);
    if (cur == 0u) return 0;
    return ((u16)(cur - (u16)value16)) < 1024u;
}
int rix_fence_check(u32 buf, u32 value16) { return *fence_px(buf, 0) == (u16)value16 && *fence_px(buf, 63) == (u16)value16; }
int rix_fence_wait(u32 buf, u32 v, u32 timeout_us, volatile u32 *stop, u32 *polls)
{
    double t0 = now_us;
    (void)stop; if (polls) *polls = 0;
    while (!rix_fence_check(buf, v)) { if (now_us - t0 > timeout_us) return (int)RIXE_FENCE_TIMEOUT; advance(10.0); }
    return 0;
}

/* ---- the driver: ZZHalfLife's frame flow ---- */
#define CHK(rc, what) do { int _r = (rc); if (_r) { if (errors < 20) fprintf(stderr, "ERROR %04x in %s (frame %u)\n", (unsigned)_r & 0xFFFFu, what, k); errors++; } } while (0)
static rix_texture g_tex[8];
static u32 bind_seqs[512], bind_frames[512], n_binds;

static double g_record_us;                       /* > 0: a recording phase of that length opens each frame (SORT=1) */
/* the ring geometry under test, same 512 KiB (ZZHalfLife: 32x16K was the demos' choice) */
static u32 g_slots = 32u, g_chunk = 16384u;
static int run(int pipelined, int bind_list, unsigned frames, unsigned seed, double word_us, double bind_us, unsigned *starved_out)
{
    static const u32 bufs[2] = { COL_A, COL_B };
    rix_ring_cfg rc;
    rix_frame f;
    u32 k, fence_of[4096];
    int pend = 0; u32 pend_buf = 0, pend_fence = 0, starved = 0, bp_checks = 0;
    memset(m_col, 0, sizeof m_col); memset(m_ring, 0, sizeof m_ring);
    g_qh = g_qn = 0; g_inprog = 0; now_us = gpu_busy_until = 0.0; memset(regs, 0, sizeof regs); memset(executed_bind, 0, sizeof executed_bind);
    violations = errors = 0; rng = seed; gpu_word_us = word_us; gpu_bind_us = bind_us;
    memset(&rc, 0, sizeof rc);
    rc.ring_base = RING; rc.ring_slots = g_slots; rc.chunk_bytes = g_chunk; rc.fence_x = 64u;
    rc.color_bufs = bufs; rc.color_count = 2u; rc.bind_base = BINDB;
    k = 0;
    CHK(rix_ring_init(&rc), "ring init");
    CHK(rix_frame_set_bind_mode(bind_list ? RIX_BIND_LIST : RIX_BIND_FIFO), "bind mode");
    rix_frame_set_deferred(1);
    rix_frame_set_pipelined(pipelined);
    rix_frame_set_idle_watch(seed == 4u);               /* the measure on in the 640-shaped runs (stats reset) */
    if (rix_frame_pipelined() != pipelined) { fprintf(stderr, "pipelined not set\n"); errors++; }
    for (k = 0; k < 8; k++) { g_tex[k].base = TEXB + k * 8u * 2048u; g_tex[k].pages = 1u + k; g_tex[k].cfg = k; }
    memset(&f, 0, sizeof f);
    for (k = 0; k < frames; k++) {
        rix_frame_desc d;
        u32 cur = bufs[k & 1u], b, nb = 0;
        memset(&d, 0, sizeof d);
        d.color = cur; d.zbuf = 0x30000000u; d.features = 0u; d.fragment = RIX_FRAGMENT_A07B;
        CHK(rix_frame_begin(&f, &d), "begin");
        rix_frame_set_phase(RIX_PH_REF);
        n_binds = 0;
        CHK(rix_frame_clear(&f, 0, 0u, 1, 0xFFFFu, 0u, 0u, 0u, 0u), "depth clear");
        CHK(rix_frame_flush(&f), "flush after the clear");
        if (g_record_us > 0.0) {                         /* SORT=1: ref_gl's walk recorded by the GL queue, a pump per batch (glq) */
            double t_end = now_us + g_record_us * (0.8 + 0.4 * rnd(100) / 100.0);
            while (now_us < t_end) { advance(5.0 + rnd(30)); CHK(rix_frame_pump(0), "pump while recording"); }
        }
        for (b = 0; b < 60u + rnd(60); b++) {          /* batches: state words, a bind now and then, pumps */
            u32 r = rnd(10), j;
            if (r < 3 && nb < 40u) {
                CHK(rix_frame_texture(&f, &g_tex[rnd(8)]), "bind");
                if (n_binds < 512u) { bind_seqs[n_binds] = rix_frame_last_bind_seq(); bind_frames[n_binds] = k; n_binds++; }
                nb++;
            }
            for (j = 0; j < 20u + rnd(400); j++) CHK(rix_frame_reg(&f, RIX_REG_TMU0_ENV, j), "reg");
            if (rnd(3) == 0) CHK(rix_frame_pump(&f), "pump");
            if (rnd(50) == 0) CHK(rix_frame_flush(&f), "flush");
            advance(g_record_us > 0.0 ? (double)rnd(8) : (double)rnd(60));   /* Core1 between batches (the replay is quick) */
            if (n_binds && rnd(4) == 0) {               /* bind_passed: never early */
                u32 i = rnd(n_binds), s = bind_seqs[i];
                if (rix_frame_bind_passed(&f, s) && !executed_bind[s]) bad("bind_passed said passed for a bind not executed");
                bp_checks++;
            }
        }
        rix_frame_set_phase(RIX_PH_PRESENT);
        if (pend) {                                      /* end of frame k: the pending k-1 waited (pumped) and shown */
            CHK(rix_frame_wait_pumped(pend_buf, pend_fence, 2000000u), "pending frame wait");
            if (!rix_fence_check(pend_buf, pend_fence)) bad("pending frame fence not in its buffer");
            if (g_present_us > 0.0) {                    /* the copy, a pump every g_present_pump_us */
                double t_end = now_us + g_present_us;
                while (now_us < t_end) { advance(g_present_pump_us); CHK(rix_frame_pump(&f), "pump in present"); }
            } else {
                advance(pipelined ? 3000.0 : 3000.0);    /* presentation copy (ZZGL pumps every 16 lines: modelled by pumps below) */
                CHK(rix_frame_pump(&f), "pump in present");
            }
            pend = 0;
        }
        fence_of[k] = 1000u + k;
        CHK(rix_frame_end(&f, fence_of[k]), "end");
        if (!pipelined && rix_frame_pending()) bad("non-pipelined: queue not empty after rix_frame_end");
        pend = 1; pend_buf = cur; pend_fence = fence_of[k];
        rix_frame_set_phase(RIX_PH_ENGINE);
        /* between frames: game logic, then one pump (GL_SwapBuffers); with pumps from the game libraries */
        if (g_engine_us > 0.0) {
            double t_end = now_us + g_engine_us;
            if (g_engine_pump_us > 0.0) { while (now_us < t_end) { advance(g_engine_pump_us); CHK(rix_frame_pump(0), "pump in the game logic"); } }
            else advance(g_engine_us);
        } else advance((double)rnd(1500));
        CHK(rix_frame_pump(0), "pump between frames");
        /* binds of the frame just closed: once the GPU is past them, bind_passed must say so */
        starved += f.dq_starved;
    }
    if (pend) CHK(rix_frame_wait_pumped(pend_buf, pend_fence, 2000000u), "last wait");
    CHK(rix_frame_drain(0), "drain");
    {   /* liveness: everything executed now, every bind of the last frame passed */
        u32 i;
        for (i = 0; i < n_binds; i++) if (!rix_frame_bind_passed(&f, bind_seqs[i])) { bad("bind_passed: an executed bind of the last frame not seen"); break; }
    }
    if (g_qn) bad("GPU queue not empty at the end");
    if (starved_out) *starved_out = starved;
    {
        u32 it, isp;
        rix_frame_idle_take(&it, &isp);
        printf("   %s, %s binds, %u frames, GPU %.3f us/word %.0f us/bind: %.0f ms, %u bind checks, %d violations, %d errors",
               pipelined ? "pipelined" : "deferred ", bind_list ? "list" : "FIFO", frames, word_us, bind_us, now_us / 1000.0, bp_checks, violations, errors);
        if (seed == 4u) printf(", GPU idle seen %.1f ms a frame", it / 333.0 / 1000.0 / frames);
        printf("\n");
    }
    if (!run_keep_stats) rix_frame_set_idle_watch(0);   /* off resets nothing; the stats are read after */
    rix_frame_set_pipelined(0);
    return violations + errors;
}

int main(void)
{
    int fails = 0;
    double t_def, t_pipe;
    unsigned s;
    /* same streams both ways, GPU slower and faster than Core1 */
    for (s = 1; s <= 3; s++) {
        fails += run(0, 1, 120, s, 0.004, 60.0, 0); t_def = now_us;
        fails += run(1, 1, 120, s, 0.004, 60.0, 0); t_pipe = now_us;
        printf("   seed %u: pipelined %.0f ms against deferred %.0f ms\n", s, t_pipe / 1000.0, t_def / 1000.0);
    }
    /* like the 640 long run: ref_gl records ~9 ms (SORT=1), the replay feeds a GPU that needs ~12 ms
       (36 binds), the presentation takes 3 ms: serial ~27 ms, the pipeline must pay */
    g_record_us = 9000.0;
    fails += run(0, 1, 120, 4, 0.02, 300.0, 0); t_def = now_us;
    fails += run(1, 1, 120, 4, 0.02, 300.0, 0); t_pipe = now_us;
    g_record_us = 0.0;
    printf("   GPU-bound: pipelined %.1f ms a frame against deferred %.1f ms\n", t_pipe / 120000.0, t_def / 120000.0);
    if (!(t_pipe < 0.85 * t_def)) { printf("FAIL: pipelined not 15 %% faster on a GPU-bound stream\n"); fails++; }
    fails += run(1, 1, 200, 7, 0.001, 16.0, 0);         /* fast GPU: the queue starves */
    fails += run(1, 1, 200, 8, 0.02, 230.0, 0);         /* slow GPU: ring and queue full */
    fails += run(1, 0, 150, 9, 0.004, 60.0, 0);         /* FIFO binds */
    fails += run(0, 0, 150, 9, 0.004, 60.0, 0);
    {   /* build 35, 1: the c1a3 combat shape (record 9 ms, engine 4.4 ms).  A = no pump in the game
           logic, present 4.6 ms pumping every 150 us; B = pumps every 50 us in the game logic,
           present by the DMA (0.6 ms, pumped all along).  B must be faster. */
        double t_a, t_b;
        g_record_us = 9000.0; g_engine_us = 4400.0;
        g_engine_pump_us = 0.0; g_present_us = 4600.0; g_present_pump_us = 150.0;
        fails += run(1, 1, 120, 4, 0.02, 300.0, 0); t_a = now_us;
        g_engine_pump_us = 50.0; g_present_us = 600.0; g_present_pump_us = 2.0;
        fails += run(1, 1, 120, 4, 0.02, 300.0, 0); t_b = now_us;
        printf("   combat shape: A (build 34) %.1f ms a frame, B (build 35) %.1f ms\n", t_a / 120000.0, t_b / 120000.0);
        if (!(t_b < 0.92 * t_a)) { printf("FAIL: engine pumps + DMA presentation not 8 %% faster on the combat shape\n"); fails++; }
    }
    {   /* build 35, 2: the measure.  A GPU-bound stream (binds of 900 us, short recording) leaves binds queued at the
           end of each frame; without pumps in the 4.4 ms of game logic the GPU stops at the next one and the
           measure must find it WAITING in the engine phase; with pumps every 50 us that wait must mostly go,
           and the stream must be faster.  The idle time with nothing queued is reported apart. */
        u32 v[6], w_a, w_b, sv_a, sv_b;
        double t_a, t_b;
        g_record_us = 500.0; g_engine_us = 4400.0; run_keep_stats = 1;
        g_engine_pump_us = 0.0; g_present_us = 600.0; g_present_pump_us = 2.0;
        fails += run(1, 1, 120, 4, 0.02, 900.0, 0); t_a = now_us;
        rix_frame_phase_stats(RIX_PH_ENGINE, 120u, v); w_a = v[3]; sv_a = v[5];
        g_engine_pump_us = 50.0;
        fails += run(1, 1, 120, 4, 0.02, 900.0, 0); t_b = now_us;
        rix_frame_phase_stats(RIX_PH_ENGINE, 120u, v); w_b = v[3]; sv_b = v[5];
        run_keep_stats = 0; rix_frame_set_idle_watch(0);
        g_record_us = 0.0; g_engine_us = 0.0; g_present_us = 0.0;
        printf("   GPU-bound, engine phase: no pumps %.1f ms a frame, GPU waiting %u us, starved %u us;"
               " pumps every 50 us %.1f ms, waiting %u us, starved %u us\n", t_a / 120000.0, w_a, sv_a, t_b / 120000.0, w_b, sv_b);
        if (!(w_a > 2000u)) { printf("FAIL: the measure did not find the GPU waiting in the engine phase\n"); fails++; }
        if (!(w_b < w_a / 4u)) { printf("FAIL: the engine pumps did not remove most of that wait\n"); fails++; }
        if (!(t_b < t_a)) { printf("FAIL: the engine pumps did not make the GPU-bound stream faster\n"); fails++; }
    }
    {   /* the phase sums no longer wrap (build 35 summed 333 MHz ticks on 32 bits: 12.9 s at most) */
        u32 v[6];
        g_record_us = 500.0; g_engine_us = 100000.0; g_engine_pump_us = 0.0; g_present_us = 600.0; g_present_pump_us = 2.0; run_keep_stats = 1;
        fails += run(1, 1, 150, 4, 0.02, 300.0, 0);       /* 150 frames of 100 ms of game logic: 15 s in that phase */
        rix_frame_phase_stats(RIX_PH_ENGINE, 150u, v);
        run_keep_stats = 0; rix_frame_set_idle_watch(0);
        g_record_us = 0.0; g_engine_us = 0.0; g_present_us = 0.0;
        printf("   15 s in the engine phase: %u us a frame measured there\n", v[0]);
        if (!(v[0] > 95000u && v[0] < 110000u)) { printf("FAIL: the engine phase time wrapped or is wrong\n"); fails++; }
    }
    {   /* ZZHalfLife: the same 512 KiB ring as more, smaller slots.  On the A4000 a chunk
           closes at every bind and fills 14 to 21 % of a 16 KiB slot; Core1 waited 11,7 ms a frame
           for a free slot while the GPU starved.  The stream that fills the ring (slow GPU, seed 8)
           must stay correct and get no slower. */
        double t16, t8, t4;
        /* the A4000's shape: Core1 produces a burst, then leaves the GPU alone for the game logic
           and the presentation copy.  A deeper ring carries more work across that silence. */
        g_record_us = 9000.0; g_engine_us = 4200.0; g_engine_pump_us = 0.0;
        g_present_us = 1800.0; g_present_pump_us = 150.0;
        g_slots = 32u; g_chunk = 16384u;
        fails += run(1, 1, 200, 8, 0.02, 230.0, 0); t16 = now_us;
        g_slots = 64u; g_chunk = 8192u;
        fails += run(1, 1, 200, 8, 0.02, 230.0, 0); t8 = now_us;
        g_slots = 128u; g_chunk = 4096u;
        fails += run(1, 1, 200, 8, 0.02, 230.0, 0); t4 = now_us;
        g_slots = 32u; g_chunk = 16384u;
        g_record_us = 0.0; g_engine_us = 0.0; g_present_us = 0.0;
        printf("   ring of 512 KiB, bursty Core1: 32x16K %u ms, 64x8K %u ms, 128x4K %u ms (200 frames)\n",
               (unsigned)(t16 / 1000.0), (unsigned)(t8 / 1000.0), (unsigned)(t4 / 1000.0));
        if (!(t8 <= t16 * 1.02) || !(t4 <= t16 * 1.05))
            { printf("FAIL: smaller slots made the bursty stream slower\n"); fails++; }
    }
    printf(fails ? "RIXFRAME PIPE: FAILED (%d)\n" : "RIXFRAME PIPE: ALL TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
