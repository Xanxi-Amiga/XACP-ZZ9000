/* test_xacp_fs.c - ZZHalfLife host test of xacp/src/xacp_fs.c: the fd layer over a simulated
 * launcher (READAT on a local file, 512 KiB per request, release READ/WRITE/STAT on a local
 * directory). Builds and runs on the PC: sh tests/run_host_tests.sh. ASCII only.
 * the simulated launcher does what the real one does (ZZQuake2_A0.c): a READAT keeps
 * its file open until a READAT of another name, a WRITE goes to <name>.tmp then DeleteFile and
 * Rename - refused when the file is the one held open (AmigaDOS does not delete an open file).
 * Build 19/20 passed this test with a simulator that closed every file: on the A4000 every
 * rewrite of an existing file was refused (SOAK run of 06/11). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include "xacp_rt.h"
#include "dirent.h"

const zzhl_rt_t *zzhl_rt;
void zzhl_log( const char *s ) { puts( s ); }
void zzhl_present_keepalive( void ) { }
void xacp_loading_tick( void ) { }
extern int dup( int fd );
extern int _open( const char *path, int flags, int mode );
extern int _close( int fd );
extern int _read( int fd, void *buf, size_t n );
extern int _write( int fd, const void *buf, size_t n );
extern off_t _lseek( int fd, off_t off, int whence );
extern int _stat( const char *path, struct stat *st );
extern void zzhl_fs_stats( unsigned *req, unsigned *bytes, unsigned *hit, unsigned *miss, unsigned *direct, unsigned *svc, unsigned *neg, unsigned *writes );
extern void xacp_fs_test_new_session( void );
extern void zzhl_fs_save_stats( unsigned *written, unsigned *read, unsigned *bad );
extern void zzhl_fs_save_memory( unsigned *files, unsigned *bytes, unsigned *taken, unsigned *largest_sav );   /* build 49 */
extern unsigned zzhl_fs_scratch_size( const char *path );
extern void xacp_fs_disk_saves_only( const char *prefix );
extern void xacp_fs_save_peek( int on );   /* build 50 */
extern void zzhl_fs_peek_stats( unsigned *heads, unsigned *reads, unsigned *whole );
static unsigned g_test_time = 1800000000u;
unsigned zzhl_wall_time( void ) { return g_test_time; }
/* xacp_disk.c (every request timed) and the read-ahead of animation files */
static int g_in_play;
int xacp_loading_in_play( void ) { return g_in_play; }
const char *xacp_loading_mapname( void ) { return "testmap"; }
extern const zzhl_rt_t *xacp_disk_wrap( const zzhl_rt_t *rt );
extern void xacp_disk_frame( void );
extern void xacp_disk_report( void );
extern void zzhl_fs_io_totals( unsigned *n, unsigned *bytes, unsigned *us );
extern const char *xacp_disk_test_event( unsigned i, unsigned *kind, unsigned *bytes );
extern unsigned xacp_disk_test_loads( void );
extern void xacp_fs_survey_map_end( int ch, unsigned *items, unsigned *bytes );
extern int  xacp_fs_survey_write( int ch, const char *title, const char *maps, unsigned *items, unsigned *bytes );
extern void xacp_fs_survey_common( unsigned *items, unsigned *bytes );
extern void xacp_fs_test_drop_paks( void );
extern void xacp_fs_survey_add( const char *path );
extern void xacp_fs_survey_add_bsp_textures( const char *bsp );
extern void zzhl_fs_chapter_stats( unsigned *opened, unsigned *kib, unsigned *ms, int *on );
extern void zzhl_fs_prefetch_stats( unsigned *files, unsigned *kib, unsigned *ms, unsigned *missing );
extern const char *xacp_fs_pak_entry( const char *flat, unsigned off );
extern void zzhl_fs_voice_stats( unsigned *sets, unsigned *files, unsigned *kib, unsigned *ms, unsigned *skipped );
extern void xacp_fs_set_disk_saves( int on );
extern int rename( const char *o, const char *nw );
void zzhl_console_write( const char *p, size_t n ) { fwrite( p, 1, n, stdout ); }

static const char *g_dir = "tests/data";
static unsigned g_requests;
static char g_held[128];              /* the file the launcher's READAT keeps open, "" for none */
static char g_last_name[128];         /* the name of the last request (stale-name simulation) */
static int g_stale_next_write;        /* 1: the next WRITE is carried out under g_last_name (03/11) */
static unsigned g_sim_refused;        /* WRITEs the simulated launcher refused */
static int g_stale_reads;             /* that many whole-file READs are answered as the request before them */
static unsigned g_sim_reads;          /* whole-file READs the simulated launcher received */
static int g_garbage_reads;           /* that many whole-file READs are answered with the right size and binary bytes (A4000, 17/11) */
static int sim_exists( const char *base ) { char path[512]; FILE *f; snprintf( path, sizeof( path ), "%s/%s", g_dir, base ); f = fopen( path, "rb" ); if( f ) fclose( f ); return f != NULL; }
static int sim_read_at( const char *name, unsigned off, void *dst, unsigned len, unsigned *total )
{
	char path[512];
	FILE *f;
	unsigned done = 0;
	snprintf( path, sizeof( path ), "%s/%s", g_dir, name );
	snprintf( g_last_name, sizeof( g_last_name ), "%s", name );
	if( strchr( name, '/' )) return -1;      /* the launcher refuses separators */
	if( strcmp( g_held, name )) g_held[0] = 0;   /* another name: Close() the one held */
	f = fopen( path, "rb" );
	if( !f ) return -1;                      /* Open() failed: nothing held */
	snprintf( g_held, sizeof( g_held ), "%s", name );
	fseek( f, 0, SEEK_END );
	if( total ) *total = (unsigned)ftell( f );
	while( done < len )
	{
		unsigned want = len - done, got;
		if( want > 512u * 1024u ) want = 512u * 1024u;
		fseek( f, off + done, SEEK_SET );
		got = (unsigned)fread( (char *)dst + done, 1, want, f );
		g_requests++;
		done += got;
		if( got < want ) break;
	}
	fclose( f );
	{   /* one read of g_corrupt_name gives zeros over [g_corrupt_lo, g_corrupt_hi) once
		   (g_corrupt_once reads, it is a count) */
		extern char g_corrupt_name[]; extern unsigned g_corrupt_lo, g_corrupt_hi; extern int g_corrupt_once;
		if( g_corrupt_once && !strcmp( name, g_corrupt_name ) && off < g_corrupt_hi && off + done > g_corrupt_lo )
		{
			unsigned a = off > g_corrupt_lo ? off : g_corrupt_lo, b = off + done < g_corrupt_hi ? off + done : g_corrupt_hi;
			extern unsigned char g_corrupt_byte;
			memset( (char *)dst + ( a - off ), g_corrupt_byte, b - a );
			g_corrupt_once--;
		}
	}
	return (int)done;
}
char g_corrupt_name[64]; unsigned g_corrupt_lo, g_corrupt_hi; int g_corrupt_once;
unsigned char g_corrupt_byte;   /* the byte the injected stretch is made of (0 by default) */
/* release READ ("rb") and WRITE ("wb", collected, carried out at fclose like zzq_fclose) */
static struct { FILE *f; char name[128]; } g_wr[8];
static FILE *sim_fopen( const char *p, const char *m )
{
	char path[512];
	int i;
	if( strchr( p, '/' )) return NULL;
	if( !strchr( m, 'w' ))
	{
		g_sim_reads++;
		if( g_garbage_reads > 0 )
		{   /* the size of the file asked for, and bytes that are not its own - the same at every READ */
			FILE *src, *g; long sz, k;
			g_garbage_reads--;
			snprintf( g_last_name, sizeof( g_last_name ), "%s", p );
			snprintf( path, sizeof( path ), "%s/%s", g_dir, p );
			src = fopen( path, "rb" );
			if( !src ) return NULL;
			fseek( src, 0, SEEK_END ); sz = ftell( src ); fclose( src );
			g = fopen( "tests/data/_garbage.tmp", "wb+" );
			if( !g ) return NULL;
			for( k = 0; k < sz; k++ ) fputc( (int)(( k * 37 + 80 ) & 0xFF ), g );
			fflush( g ); fseek( g, 0, SEEK_SET );
			return g;
		}
		if( g_stale_reads > 0 )
		{   /* the launcher answers the PREVIOUS request (A4000, 16/11: the READ of pak0.chp
			   came back as the save read just before).  The request itself was not seen: g_last_name stays. */
			g_stale_reads--;
			if( !g_last_name[0] ) return NULL;
			snprintf( path, sizeof( path ), "%s/%s", g_dir, g_last_name );
			return fopen( path, m );
		}
		snprintf( g_last_name, sizeof( g_last_name ), "%s", p );
		snprintf( path, sizeof( path ), "%s/%s", g_dir, p );
		return fopen( path, m );
	}
	for( i = 0; i < 8; i++ ) if( !g_wr[i].f ) break;
	if( i == 8 ) return NULL;
	snprintf( path, sizeof( path ), "%s/%s.tmp", g_dir, p );
	g_wr[i].f = fopen( path, "wb" );
	snprintf( g_wr[i].name, sizeof( g_wr[i].name ), "%s", p );
	return g_wr[i].f;
}
static int sim_fclose( FILE *f )
{
	char tmp[512], path[512], eff[128];
	int i;
	for( i = 0; i < 8; i++ ) if( g_wr[i].f == f ) break;
	if( i == 8 ) return fclose( f );
	fclose( f );
	g_wr[i].f = NULL;
	snprintf( eff, sizeof( eff ), "%s", g_stale_next_write ? g_last_name : g_wr[i].name );
	if( g_stale_next_write )
	{   /* the 68k read the previous request's name: the data go to <that name>.tmp */
		char t0[512];
		snprintf( t0, sizeof( t0 ), "%s/%s.tmp", g_dir, g_wr[i].name );
		snprintf( tmp, sizeof( tmp ), "%s/%s.tmp", g_dir, eff );
		renameat( AT_FDCWD, t0, AT_FDCWD, tmp );
		g_stale_next_write = 0;
	}
	snprintf( g_last_name, sizeof( g_last_name ), "%s", eff );
	snprintf( tmp, sizeof( tmp ), "%s/%s.tmp", g_dir, eff );
	snprintf( path, sizeof( path ), "%s/%s", g_dir, eff );
	if( !strcmp( g_held, eff ) && sim_exists( eff )) { g_sim_refused++; return -1; }   /* DeleteFile fails, Rename fails */
	unlink( path );
	if( renameat( AT_FDCWD, tmp, AT_FDCWD, path )) return -1;
	return 0;
}
/* the test binary carries xacp_fs.c's own stat(): the simulator checks existence with fopen */
static int sim_file_time( const char *p ) { snprintf( g_last_name, sizeof( g_last_name ), "%s", p ); return sim_exists( p ) ? 1 : -1; }
static unsigned sim_us( void ) { static unsigned t; return t += 1000; }
static int sim_pump( void ) { return 0; }
unsigned long long zzhl_us64( void ) { static unsigned long long t; return t += 100000ull; }   /* the write guard's clock, 0.1 s a call */
static int sim_printf( const char *fmt, ... ) { (void)fmt; return 0; }
static void sim_fatal( unsigned c ) { fprintf( stderr, "fatal %u\n", c ); exit( 1 ); }
static void sim_cache( unsigned a, unsigned l ) { (void)a; (void)l; }

void zzhl_fs_bsp_stats( unsigned *checks, unsigned *bad, unsigned *fixed );
void zzhl_fs_mdl_stats( unsigned *checks, unsigned *bad, unsigned *fixed );
void zzhl_fs_crc_stats( unsigned *blocks, unsigned *bad, unsigned *fixed, unsigned *lost, int *state );
static void wl( unsigned char *p, unsigned v ) { p[0] = (unsigned char)v; p[1] = (unsigned char)( v >> 8 ); p[2] = (unsigned char)( v >> 16 ); p[3] = (unsigned char)( v >> 24 ); }
static unsigned t_crc32( const unsigned char *p, unsigned n )
{
	unsigned c = 0xFFFFFFFFu, i, k;
	for( i = 0; i < n; i++ ) { c ^= p[i]; for( k = 0; k < 8u; k++ ) c = ( c & 1u ) ? 0xEDB88320u ^ ( c >> 1 ) : c >> 1; }
	return c ^ 0xFFFFFFFFu;
}
static void write_crc_file( const char *path, const unsigned char *pak, unsigned size, unsigned claimed_size )
{
	unsigned n = ( size + 65535u ) / 65536u, i;
	unsigned char h[20];
	FILE *f = fopen( path, "wb" );
	memcpy( h, "ZZCRC1\0\0", 8 ); wl( h + 8, 65536u ); wl( h + 12, claimed_size ); wl( h + 16, n );
	fwrite( h, 1, 20, f );
	for( i = 0; i < n; i++ ) { unsigned char w[4]; unsigned l = ( i + 1u < n ) ? 65536u : size - i * 65536u; wl( w, t_crc32( pak + i * 65536u, l )); fwrite( w, 1, 4, f ); }
	fclose( f );
}
static int fails;
#define CHECK( c, msg ) do { if( !( c )) { printf( "FAIL: %s\n", msg ); fails++; } else printf( "ok: %s\n", msg ); } while( 0 )

/* options as the engine would read them (XCACHE: 8 MiB, the old cache, for the tests above) */
static const char *g_opt_xcache = "8", *g_opt_survey = NULL;
const char *zzhl_option( const char *k ) { return !strcmp( k, "XCACHE" ) ? g_opt_xcache : !strcmp( k, "SURVEY" ) ? g_opt_survey : NULL; }
void zzhl_fs_cache_reset( void );
void zzhl_fs_cache_stats( unsigned *mib, unsigned *direct_hits, unsigned *kept );
int main( void )
{
	static zzhl_rt_t rt;
	static unsigned char ref[3 * 1024 * 1024 + 12345];
	static unsigned char buf[3 * 1024 * 1024 + 12345];
	unsigned i, req, bytes, hit, miss, direct, svc, neg, writes;
	int fd, n, k;
	struct stat st;
	FILE *f;
	DIR *d;
	struct dirent *e;
	rt.magic = ZZHL_RT_MAGIC; rt.version = ZZHL_RT_VERSION; rt.size = sizeof( rt );
	rt.us_now = sim_us; rt.printf = sim_printf; rt.fatal = sim_fatal;
	rt.fopen = sim_fopen; rt.fclose = sim_fclose; rt.fread = fread; rt.fwrite = fwrite; rt.fseek = fseek; rt.ftell = ftell;
	rt.file_time = sim_file_time; rt.read_at = sim_read_at; rt.dcache_clean = sim_cache; rt.dcache_invalidate = sim_cache;
	rt.pump = sim_pump;
	zzhl_rt = xacp_disk_wrap( &rt );        /* every request through the timed calls, as on the ZZ9000 */

	/* a fake 3 MiB pak with a known pattern */
	for( i = 0; i < sizeof( ref ); i++ ) ref[i] = (unsigned char)( i * 2654435761u >> 24 );
	memcpy( ref, "PACK", 4 );
	mkdir( g_dir, 0777 );
	f = fopen( "tests/data/pak0.pak", "wb" ); fwrite( ref, 1, sizeof( ref ), f ); fclose( f );
	f = fopen( "tests/data/liblist.gam", "wb" ); fputs( "game \"Half-Life\"\n", f ); fclose( f );
	unlink( "tests/data/config.cfg" );   /* the libc one: xacp_fs.c replaces remove() */
	unlink( "tests/data/pak0.pak.tmp" );
	{   /* the disk saves of a previous run of this test */
		const char *olds[] = { "hlsave.idx", "hlsv_quick.sav", "hlsv_quick.s01", "hlsv_quick.s02", "hlsv_quick.s03", "hlsv_autosave.sav", "hlsv_s9.sav" };
		char p[128];
		for( i = 0; i < 7; i++ ) { snprintf( p, sizeof( p ), "tests/data/%s", olds[i] ); unlink( p ); }
	}

	CHECK( _stat( "valve", &st ) == 0 && S_ISDIR( st.st_mode ), "valve is a directory" );
	CHECK( _stat( "valve/pak0.pak", &st ) == 0 && S_ISREG( st.st_mode ), "valve/pak0.pak exists (STAT)" );
	CHECK( _stat( "valve/nothere.wad", &st ) != 0, "absent file" );
	CHECK( _stat( "valve/nothere.wad", &st ) != 0, "absent file again (negative cache)" );
	zzhl_fs_stats( &req, &bytes, &hit, &miss, &direct, &svc, &neg, &writes );
	CHECK( neg == 1 && svc == 2, "one STAT for the absent name, one for the pak" );

	fd = _open( "valve/pak0.pak", O_RDONLY, 0 );
	CHECK( fd >= 3, "open pak" );
	CHECK( _lseek( fd, 0, SEEK_END ) == (off_t)sizeof( ref ), "size by lseek" );
	_lseek( fd, 0, SEEK_SET );
	n = _read( fd, buf, 4 );
	CHECK( n == 4 && !memcmp( buf, "PACK", 4 ), "small read at 0 (cache)" );
	_lseek( fd, 100000, SEEK_SET );
	n = _read( fd, buf, 2000 );
	CHECK( n == 2000 && !memcmp( buf, ref + 100000, 2000 ), "small read inside a block" );
	_lseek( fd, 65000, SEEK_SET );
	n = _read( fd, buf, 2000 );
	CHECK( n == 2000 && !memcmp( buf, ref + 65000, 2000 ), "small read across a block boundary" );
	_lseek( fd, 0, SEEK_SET );
	memset( buf, 0, sizeof( buf ));
	n = _read( fd, buf, sizeof( buf ));
	CHECK( n == (int)sizeof( ref ) && !memcmp( buf, ref, sizeof( ref )), "whole-file read (direct path + tail)" );
	_lseek( fd, sizeof( ref ) - 10, SEEK_SET );
	n = _read( fd, buf, 100 );
	CHECK( n == 10, "read at the end is short" );
	_lseek( fd, 70000, SEEK_SET );
	n = _read( fd, buf, 1000000 );
	CHECK( n == 1000000 && !memcmp( buf, ref + 70000, 1000000 ), "1 MB unaligned read (cache then direct)" );
	k = dup( fd );
	CHECK( k > fd && _lseek( k, 5, SEEK_SET ) == 5 && _read( k, buf, 3 ) == 3 && !memcmp( buf, ref + 5, 3 ), "dup has its own offset" );
	_close( k );
	_close( fd );
	zzhl_fs_stats( &req, &bytes, &hit, &miss, &direct, &svc, &neg, &writes );
	printf( "   readat requests %u (%u KiB), cache hits %u misses %u direct %u\n", req, bytes / 1024, hit, miss, direct );

	fd = _open( "valve/liblist.gam", O_RDONLY, 0 );
	n = _read( fd, buf, 100 );
	CHECK( fd >= 3 && n == 17, "loose file through the service READ" );
	_close( fd );
	fd = _open( "valve/config.cfg", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
	CHECK( fd >= 3 && _write( fd, "bind a +left\n", 13 ) == 13, "create and write config.cfg" );
	_close( fd );
	f = fopen( "tests/data/config.cfg", "rb" );
	CHECK( f && fread( buf, 1, 100, f ) == 13, "config.cfg written back at close" );
	if( f ) fclose( f );

	/* a file already on the disk, held open by the 68k (the last READAT read it, as
	   build 19's same-name probe did): its rewrite must go through */
	{
		unsigned char b1[4]; unsigned t = 0, rf, gu;
		extern void zzhl_fs_write_stats( unsigned *refused, unsigned *given_up );
		sim_read_at( "config.cfg", 0, b1, 1, &t );
		CHECK( !strcmp( g_held, "config.cfg" ), "simulator: the 68k holds config.cfg" );
		fd = _open( "valve/config.cfg", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, "bind b +right\nbind c +jump\n", 28 ); _close( fd );
		f = fopen( "tests/data/config.cfg", "rb" ); n = 0; if( f ) { n = (int)fread( buf, 1, 100, f ); fclose( f ); }
		CHECK( n == 28 && !memcmp( buf, "bind b +right", 13 ) && g_sim_refused == 0, "rewrite of a file the 68k held open goes through" );
		CHECK( !strcmp( g_held, "pak0.pak" ), "after a write the 68k holds pak0.pak" );
		/* the 03/11 case: the WRITE carried out under the previous request's name */
		g_stale_next_write = 1;
		fd = _open( "valve/config.cfg", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, "bind d +duck\n", 13 ); _close( fd );
		f = fopen( "tests/data/pak0.pak", "rb" ); n = 0; if( f ) { n = (int)fread( buf, 1, 4, f ); fseek( f, 0, SEEK_END ); k = (int)ftell( f ); fclose( f ); } else k = -1;
		CHECK( n == 4 && !memcmp( buf, "PACK", 4 ) && k == (int)sizeof( ref ), "stale-name write refused: pak0.pak intact" );
		f = fopen( "tests/data/config.cfg", "rb" ); n = 0; if( f ) { n = (int)fread( buf, 1, 100, f ); fclose( f ); }
		zzhl_fs_write_stats( &rf, &gu );
		CHECK( n == 13 && !memcmp( buf, "bind d +duck", 12 ) && rf == 1 && gu == 0 && g_sim_refused == 1, "stale-name write: second try written, one refusal counted" );
		/* put back the 13-byte config.cfg the rest of the test expects in the listing */
	}

	{   /* a loose file the engine looks for by name must be in the listing */
		int seen = 0;
		f = fopen( "tests/data/zzhl_loadscreen.tga", "wb" ); fputs( "x", f ); fclose( f );
		f = fopen( "tests/data/userconfig.cfg", "wb" ); fputs( "bind x +use\n", f ); fclose( f );   /* build 31 */
		d = opendir( "valve" );
		n = 0;
		while( d && ( e = readdir( d ))) { printf( "   valve/%s\n", e->d_name ); n++; if( !strcmp( e->d_name, "zzhl_loadscreen.tga" )) seen |= 1; if( !strcmp( e->d_name, "userconfig.cfg" )) seen |= 2; }
		closedir( d );
		unlink( "tests/data/zzhl_loadscreen.tga" );
		unlink( "tests/data/userconfig.cfg" );
		CHECK( n == 5 && seen == 3, "listing valve: pak0.pak, zzhl_loadscreen.tga, config.cfg, userconfig.cfg, liblist.gam" );
	}

	{   /* Host_FinalizeConfig's sequence (con_utils.c) reaches the disk under the final name */
		unlink( "tests/data/video.cfg" ); unlink( "tests/data/video.cfg.new" ); unlink( "tests/data/video.cfg.bak" );
		fd = _open( "valve/video.cfg.new", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, "width 640\n", 10 ); _close( fd );
		CHECK( !sim_exists( "video.cfg.new" ), "config: video.cfg.new stays in memory" );
		_unlink( "valve/video.cfg.bak" );
		CHECK( rename( "valve/video.cfg", "valve/video.cfg.bak" ) != 0, "config: first run, no video.cfg to back up" );
		CHECK( rename( "valve/video.cfg.new", "valve/video.cfg" ) == 0, "config: video.cfg.new -> video.cfg" );
		f = fopen( "tests/data/video.cfg", "rb" ); n = 0; if( f ) { n = (int)fread( buf, 1, 100, f ); fclose( f ); }
		CHECK( n == 10 && !memcmp( buf, "width 640\n", 10 ), "config: video.cfg on the disk after the rename" );
		fd = _open( "valve/video.cfg.new", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, "width 320\n", 10 ); _close( fd );
		_unlink( "valve/video.cfg.bak" );
		k = rename( "valve/video.cfg", "valve/video.cfg.bak" );
		CHECK( k == 0 && rename( "valve/video.cfg.new", "valve/video.cfg" ) == 0, "config: second run, backup then rename" );
		f = fopen( "tests/data/video.cfg", "rb" ); n = 0; if( f ) { n = (int)fread( buf, 1, 100, f ); fclose( f ); }
		CHECK( n == 10 && !memcmp( buf, "width 320\n", 10 ), "config: video.cfg replaced on the disk" );
		CHECK( !sim_exists( "video.cfg.new" ) && !sim_exists( "video.cfg.bak" ), "config: no .new nor .bak on the disk" );
		fd = _open( "valve/video.cfg", O_RDONLY, 0 ); n = fd >= 0 ? _read( fd, buf, 100 ) : -1; if( fd >= 0 ) _close( fd );
		CHECK( n == 10 && !memcmp( buf, "width 320\n", 10 ), "config: the engine reads the new video.cfg" );
		unlink( "tests/data/video.cfg" );
	}

	{   /* a map read whole is checked and read again when wrong (xacp_fs.c, bsp_check) */
		static unsigned char pk[260000], rd[200000], ok[200000];
		unsigned bc, bb, bf, j;
		float nz[3] = { 0.0f, 0.0f, 1.0f };
		memset( pk, 0xAB, sizeof( pk ));
		{   /* a BSP v30 of 200000 bytes at offset 1000 of pak1.pak: planes (0,0,1) at 1024, 4000 of them */
			unsigned char *b = pk + 1000;
			memset( b, 0, 200000 );
			b[0] = 30;
			b[4 + 8] = 0x00; b[5 + 8] = 0x04;                     /* lump 1 offset 1024 */
			b[8 + 8] = (unsigned char)( 80000 & 255 ); b[9 + 8] = (unsigned char)(( 80000 >> 8 ) & 255 ); b[10 + 8] = (unsigned char)( 80000 >> 16 );
			for( j = 0; j < 4000; j++ ) memcpy( b + 1024 + j * 20, nz, 12 );
			memcpy( ok, b, 200000 );
		}
		f = fopen( "tests/data/maptest.pak", "wb" ); fwrite( pk, 1, sizeof( pk ), f ); fclose( f );
		fd = _open( "valve/maptest.pak", O_RDONLY, 0 );
		_lseek( fd, 1000, SEEK_SET );
		n = _read( fd, rd, 200000 );
		zzhl_fs_bsp_stats( &bc, &bb, &bf );
		CHECK( n == 200000 && !memcmp( rd, ok, 200000 ) && bc == 1 && bb == 0, "map read check: a good map passes, checked once" );
		snprintf( g_corrupt_name, sizeof( g_corrupt_name ), "maptest.pak" );
		g_corrupt_lo = 1000 + 1024 + 20 * 1700; g_corrupt_hi = g_corrupt_lo + 32768; g_corrupt_once = 1;
		_lseek( fd, 1000, SEEK_SET );
		n = _read( fd, rd, 200000 );
		zzhl_fs_bsp_stats( &bc, &bb, &bf );
		CHECK( n == 200000 && !memcmp( rd, ok, 200000 ) && bc == 2 && bb == 1 && bf == 1, "map read check: 32 KiB of zeros found and fixed by a new read" );
		_lseek( fd, 1000 + 1024 + 20 * 1800, SEEK_SET );
		n = _read( fd, rd, 4000 );
		CHECK( n == 4000 && !memcmp( rd, ok + 1024 + 20 * 1800, 4000 ), "map read check: the cache does not keep the wrong bytes" );
		_close( fd );
		unlink( "tests/data/maptest.pak" );
	}

	{   /* a studio model read whole is checked and read again when its tables are wrong */
		static unsigned char pk[300000], rd[200000], ok[200000];
		const unsigned N = 200000u;
		unsigned bc, bb, bf;
		unsigned char *m = pk + 3000;
		memset( pk, 0xCD, sizeof( pk ));
		memset( m, 0, N );
		/* header: IDST v10, length; 1 bone at 1000, 1 controller at 1200, 1 hitbox at 1300, 2 sequences at 1400,
		   1 sequence group at 1800, 1 texture at 2000 (16x16 pixels at 3000), skins 1x1 at 2100, 1 body part at 2200,
		   1 attachment at 2400; the body part's model at 2500: 1 mesh at 2700 (tri commands at 2800), 10 vertices at
		   4000 (bone bytes at 4200), 10 normals at 4400 (bytes at 4600); events of sequence 0 at 5000 */
		m[0] = 'I'; m[1] = 'D'; m[2] = 'S'; m[3] = 'T'; wl( m + 4, 10 ); wl( m + 72, N );
		/* the tables from T = 70000 on: past the first 64 KiB block of the pak, so that a second read of the model
		   goes to the launcher again (the block cache keeps only the unaligned head) */
#define T 70000u
		wl( m + 140, 1 ); wl( m + 144, T + 1000 ); wl( m + 148, 1 ); wl( m + 152, T + 1200 ); wl( m + 156, 1 ); wl( m + 160, T + 1300 );
		wl( m + 164, 2 ); wl( m + 168, T + 1400 ); wl( m + 172, 1 ); wl( m + 176, T + 1800 );
		wl( m + 180, 1 ); wl( m + 184, T + 2000 ); wl( m + 188, T + 3000 ); wl( m + 192, 1 ); wl( m + 196, 1 ); wl( m + 200, T + 2100 );
		wl( m + 204, 1 ); wl( m + 208, T + 2200 ); wl( m + 212, 1 ); wl( m + 216, T + 2400 );
		wl( m + T + 1400 + 48, 2 ); wl( m + T + 1400 + 52, T + 5000 ); wl( m + T + 1400 + 124, T + 6000 );   /* seq 0: 2 events, animation */
		wl( m + T + 1576 + 156, 1 ); wl( m + T + 1576 + 124, 900000 );                                       /* seq 1: in group 1 (another file) */
		wl( m + T + 2000 + 68, 16 ); wl( m + T + 2000 + 72, 16 ); wl( m + T + 2000 + 76, T + 3000 );
		wl( m + T + 2200 + 64, 1 ); wl( m + T + 2200 + 72, T + 2500 );
		wl( m + T + 2500 + 72, 1 ); wl( m + T + 2500 + 76, T + 2700 ); wl( m + T + 2500 + 80, 10 ); wl( m + T + 2500 + 84, T + 4200 ); wl( m + T + 2500 + 88, T + 4000 );
		wl( m + T + 2500 + 92, 10 ); wl( m + T + 2500 + 96, T + 4600 ); wl( m + T + 2500 + 100, T + 4400 );
		wl( m + T + 2700 + 4, T + 2800 );
		memcpy( ok, m, N );
		f = fopen( "tests/data/mdltest.pak", "wb" ); fwrite( pk, 1, sizeof( pk ), f ); fclose( f );
		fd = _open( "valve/mdltest.pak", O_RDONLY, 0 );
		_lseek( fd, 3000, SEEK_SET );
		n = _read( fd, rd, N );
		zzhl_fs_mdl_stats( &bc, &bb, &bf );
		CHECK( n == (int)N && !memcmp( rd, ok, N ) && bc == 1 && bb == 0, "model read check: a good model passes, checked once" );
		snprintf( g_corrupt_name, sizeof( g_corrupt_name ), "mdltest.pak" );
		g_corrupt_byte = 0xFF;                       /* the body part entry overwritten: its model count and index absurd */
		g_corrupt_lo = 3000 + T + 2200 + 64; g_corrupt_hi = g_corrupt_lo + 12; g_corrupt_once = 1;
		_lseek( fd, 3000, SEEK_SET );
		n = _read( fd, rd, N );
		zzhl_fs_mdl_stats( &bc, &bb, &bf );
		CHECK( n == (int)N && !memcmp( rd, ok, N ) && bc == 2 && bb == 1 && bf == 1, "model read check: a wrong body part found and fixed by a new read" );
		g_corrupt_lo = 3000 + T + 2500 + 64; g_corrupt_hi = g_corrupt_lo + 40; g_corrupt_once = 1;   /* the model's mesh/vertex tables */
		_lseek( fd, 3000, SEEK_SET );
		n = _read( fd, rd, N );
		zzhl_fs_mdl_stats( &bc, &bb, &bf );
		CHECK( n == (int)N && !memcmp( rd, ok, N ) && bc == 3 && bb == 2 && bf == 2, "model read check: wrong mesh and vertex tables found and fixed" );
		g_corrupt_lo = 3000 + T + 1400 + 40; g_corrupt_hi = g_corrupt_lo + 16; g_corrupt_once = 1;   /* sequence 0's events */
		_lseek( fd, 3000, SEEK_SET );
		n = _read( fd, rd, N );
		zzhl_fs_mdl_stats( &bc, &bb, &bf );
		CHECK( n == (int)N && !memcmp( rd, ok, N ) && bc == 4 && bb == 3 && bf == 3, "model read check: a wrong event table found and fixed" );
		g_corrupt_byte = 0;
		_lseek( fd, 3000, SEEK_SET );
		n = _read( fd, rd, 1000 );
		zzhl_fs_mdl_stats( &bc, &bb, &bf );
		CHECK( n == 1000 && bc == 4, "model read check: a partial read (the header alone) is not checked" );
		_lseek( fd, 3000 + T + 2000, SEEK_SET );
		n = _read( fd, rd, 1000 );
		CHECK( n == 1000 && !memcmp( rd, ok + T + 2000, 1000 ), "model read check: the cache does not keep the wrong bytes" );
#undef T
		_close( fd );
		unlink( "tests/data/mdltest.pak" );
	}

	{   /* every block of a pak read is checked against <pak>.crc, read again when wrong */
		static unsigned char pk[300000], rd[300000];
		unsigned cb, cw, cf, cl, i, x = 7u;
		int cs;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		f = fopen( "tests/data/crctest.pak", "wb" ); fwrite( pk, 1, sizeof( pk ), f ); fclose( f );
		write_crc_file( "tests/data/crctest.crc", pk, sizeof( pk ), sizeof( pk ));
		fd = _open( "valve/crctest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 200000 );                 /* blocks 0..2 direct, block 3 through the cache */
		zzhl_fs_crc_stats( &cb, &cw, &cf, &cl, &cs );
		CHECK( n == 200000 && !memcmp( rd, pk, 200000 ) && cb == 4 && cw == 0 && cs == 1, "pak CRC: a good read passes, its 4 blocks checked" );
		snprintf( g_corrupt_name, sizeof( g_corrupt_name ), "crctest.pak" );
		g_corrupt_byte = 0x5A; g_corrupt_lo = 70000; g_corrupt_hi = 70016; g_corrupt_once = 1;   /* 16 bytes of block 1 */
		_lseek( fd, 0, SEEK_SET );
		n = _read( fd, rd, 200000 );
		zzhl_fs_crc_stats( &cb, &cw, &cf, &cl, &cs );
		CHECK( n == 200000 && !memcmp( rd, pk, 200000 ) && cw == 1 && cf == 1 && cl == 0, "pak CRC: 16 wrong bytes of a direct read found and fixed by a new read" );
		g_corrupt_lo = 262144 + 5000; g_corrupt_hi = g_corrupt_lo + 1; g_corrupt_once = 1;       /* one byte of block 4, a cache fill */
		_lseek( fd, 262144 + 4000, SEEK_SET );
		n = _read( fd, rd, 2000 );
		zzhl_fs_crc_stats( &cb, &cw, &cf, &cl, &cs );
		CHECK( n == 2000 && !memcmp( rd, pk + 262144 + 4000, 2000 ) && cw == 2 && cf == 2, "pak CRC: one wrong byte of a cached block found and fixed" );
		g_corrupt_byte = 0;
		_close( fd );
		/* a .crc made for another pak (other size): nothing checked, said once */
		f = fopen( "tests/data/crcother.pak", "wb" ); fwrite( pk, 1, 100000, f ); fclose( f );
		write_crc_file( "tests/data/crcother.crc", pk, 100000, 99999 );
		fd = _open( "valve/crcother.pak", O_RDONLY, 0 );
		i = cb;
		n = _read( fd, rd, 100000 );
		zzhl_fs_crc_stats( &cb, &cw, &cf, &cl, &cs );
		CHECK( n == 100000 && !memcmp( rd, pk, 100000 ) && cb == i && cs == -2, "pak CRC: a .crc of another pak is refused, nothing checked" );
		_close( fd );
		unlink( "tests/data/crctest.pak" ); unlink( "tests/data/crctest.crc" ); unlink( "tests/data/crcother.pak" ); unlink( "tests/data/crcother.crc" );
	}

	/* ---- saves on the disk ---- */
	{
		static unsigned char sv[1300000], rd[1300000];
		const char *olds[] = { "hlsave.idx", "hlsv_quick.sav", "hlsv_quick.s01", "hlsv_quick.s02", "hlsv_quick.s03", "hlsv_autosave.sav" };
		long sz0, sz1, sz2;
		char idx[256];
		for( i = 0; i < 6; i++ ) { char p[128]; snprintf( p, sizeof( p ), "tests/data/%s", olds[i] ); unlink( p ); }
		for( i = 0; i < sizeof( sv ); i++ ) sv[i] = (unsigned char)( i * 7u + ( i >> 9 ));
		fd = _open( "valve/save/quick.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		CHECK( fd >= 3 && _write( fd, sv, sizeof( sv )) == (int)sizeof( sv ), "write a 1.3 MB save" );
		_close( fd );
		f = fopen( "tests/data/hlsv_quick.sav", "rb" ); sz0 = -1; if( f ) { fseek( f, 0, SEEK_END ); sz0 = ftell( f ); fclose( f ); }
		f = fopen( "tests/data/hlsv_quick.s01", "rb" ); sz1 = -1; if( f ) { fseek( f, 0, SEEK_END ); sz1 = ftell( f ); fclose( f ); }
		f = fopen( "tests/data/hlsv_quick.s02", "rb" ); sz2 = -1; if( f ) { fseek( f, 0, SEEK_END ); sz2 = ftell( f ); fclose( f ); }
		/* the saves are DEFLATED, so the disk files follow the payload and not the
		   save's size.  sv[] is synthetic and compresses hard, so one file is expected; what
		   matters is that the payload is smaller than the save, that nothing is written past
		   it, and that st_size and the read-back below still speak in UNCOMPRESSED bytes. */
		CHECK( sz0 > 32 && sz0 < (long)sizeof( sv ) && sz1 == -1 && sz2 == -1,
		       "deflated: one disk file, smaller than the save" );
		CHECK( !sim_exists( "hlsv_quick.s01" ) && !sim_exists( "hlsv_quick.s02" ) && !sim_exists( "hlsv_quick.s03" ),
		       "no file past the payload" );
		fd = _open( "valve/save/autosave.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, sv, 10000 ); _close( fd );
		f = fopen( "tests/data/hlsave.idx", "rb" ); n = 0; if( f ) { n = (int)fread( idx, 1, sizeof( idx ) - 1, f ); fclose( f ); } idx[n > 0 ? n : 0] = 0;
		CHECK( !strcmp( idx, "quick\nautosave\n" ), "index lists quick and autosave" );
		fd = _open( "valve/save/c1a0.HL1", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv, 100 ); _close( fd );
		CHECK( !sim_exists( "hlsv_c1a0.sav" ) && !sim_exists( "c1a0.HL1" ), "level state files stay in memory" );

		xacp_fs_test_new_session();
		CHECK( _stat( "valve/save", &st ) == 0 && S_ISDIR( st.st_mode ), "new session: valve/save is a directory again" );
		d = opendir( "valve/save" ); n = 0;
		{
			int nsav = 0, nbmp = 0;
			while( d && ( e = readdir( d )))
			{
				size_t el = strlen( e->d_name );
				printf( "   valve/save/%s\n", e->d_name ); n++;
				if( el > 4 && !strcasecmp( e->d_name + el - 4, ".sav" )) nsav++;
				if( el > 4 && !strcasecmp( e->d_name + el - 4, ".bmp" )) nbmp++;
			}
			closedir( d );
			/* each save is listed with its screenshot.  mainui tests
			   FileExists( "save/<name>.bmp" ) before loading the picture, and that test walks
			   this listing (dir.c, FS_FixFileCase with createpath=false), so a .bmp missing
			   from here is a thumbnail the menu never even asks for. */
			CHECK( n == 4 && nsav == 2 && nbmp == 2,
			       "new session: the two saves are listed, each with its screenshot" );
		}
		CHECK( _stat( "valve/save/quick.sav", &st ) == 0 && st.st_size == (off_t)sizeof( sv ), "new session: quick.sav found with its size" );
		fd = _open( "valve/save/quick.sav", O_RDONLY, 0 );
		memset( rd, 0, sizeof( rd ));
		n = fd >= 3 ? _read( fd, rd, sizeof( rd )) : -1;
		CHECK( n == (int)sizeof( sv ) && !memcmp( rd, sv, sizeof( sv )), "new session: quick.sav read back identical" );
		_close( fd );
		CHECK( _open( "valve/save/nothere.sav", O_RDONLY, 0 ) < 0, "unknown save: not found" );

		/* Backward compatibility: version-1 saves must remain loadable. */
		{
			static unsigned char v1[70000], back[70000];
			unsigned char h[32];
			unsigned c, b, t;
			static unsigned tab[256];
			FILE *g;
			for( c = 0; c < 256u; c++ ) { t = c; for( b = 0; b < 8u; b++ ) t = ( t & 1u ) ? ( t >> 1 ) ^ 0xEDB88320u : t >> 1; tab[c] = t; }
			for( c = 0; c < sizeof( v1 ); c++ ) v1[c] = (unsigned char)( c * 11u + 3u );
			t = 0xFFFFFFFFu;
			for( c = 0; c < sizeof( v1 ); c++ ) t = tab[( t ^ v1[c] ) & 0xFFu] ^ ( t >> 8 );
			t ^= 0xFFFFFFFFu;
			memset( h, 0, sizeof( h ));
			h[0] = 'Z'; h[1] = 'H'; h[2] = 'S'; h[3] = 'V';
			h[4] = 1;                                                   /* version 1 */
			h[8]  = (unsigned char)sizeof( v1 );       h[9]  = (unsigned char)( sizeof( v1 ) >> 8 );
			h[10] = (unsigned char)( sizeof( v1 ) >> 16 ); h[11] = (unsigned char)( sizeof( v1 ) >> 24 );
			h[12] = 1;                                                  /* one part */
			h[16] = (unsigned char)t; h[17] = (unsigned char)( t >> 8 ); h[18] = (unsigned char)( t >> 16 ); h[19] = (unsigned char)( t >> 24 );
			g = fopen( "tests/data/hlsv_old.sav", "wb" );
			CHECK( g != NULL, "version 1: the forged file is created" );
			if( g ) { fwrite( h, 1, sizeof( h ), g ); fwrite( v1, 1, sizeof( v1 ), g ); fclose( g ); }
			g = fopen( "tests/data/hlsave.idx", "ab" );
			if( g ) { fputs( "old\n", g ); fclose( g ); }
			xacp_fs_test_new_session();
			CHECK( _stat( "valve/save/old.sav", &st ) == 0 && st.st_size == (off_t)sizeof( v1 ),
			       "version 1: found with its size, uncompressed" );
			fd = _open( "valve/save/old.sav", O_RDONLY, 0 );
			memset( back, 0, sizeof( back ));
			n = fd >= 3 ? _read( fd, back, sizeof( back )) : -1;
			CHECK( n == (int)sizeof( v1 ) && !memcmp( back, v1, sizeof( v1 )),
			       "version 1: read back identical - the old saves keep loading" );
			if( fd >= 3 ) _close( fd );
			unlink( "tests/data/hlsv_old.sav" );
		}

		/* the engine's rotation: quick.sav -> quick01.sav in memory, a new quick.sav to the disk */
		CHECK( rename( "valve/save/quick.sav", "valve/save/quick01.sav" ) == 0, "rotation: rename in memory" );
		fd = _open( "valve/save/quick.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv + 5, 4000 ); _close( fd );
		f = fopen( "tests/data/hlsv_quick.sav", "rb" ); sz0 = -1; if( f ) { fseek( f, 0, SEEK_END ); sz0 = ftell( f ); fclose( f ); }
		CHECK( sz0 == 4032 && !sim_exists( "hlsv_quick01.sav" ), "rotation: the new quick.sav on the disk, quick01 in memory only" );

		/* a damaged disk file: refused, never half loaded */
		xacp_fs_test_new_session();
		fd = _open( "valve/save/autosave.sav", O_RDONLY, 0 );
		CHECK( fd >= 3, "new session: autosave read" ); if( fd >= 3 ) _close( fd );
		f = fopen( "tests/data/hlsv_autosave.sav", "r+b" ); if( f ) { fseek( f, 5000, SEEK_SET ); fputc( 0x55, f ); fclose( f ); }
		xacp_fs_test_new_session();
		CHECK( _open( "valve/save/autosave.sav", O_RDONLY, 0 ) < 0, "damaged save refused (CRC)" );

		/* SAVES=0: memory only */
		xacp_fs_set_disk_saves( 0 );
		fd = _open( "valve/save/s9.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv, 100 ); _close( fd );
		CHECK( !sim_exists( "hlsv_s9.sav" ), "SAVES=0: nothing on the disk" );
		xacp_fs_set_disk_saves( 1 );
		zzhl_fs_stats( &req, &bytes, &hit, &miss, &direct, &svc, &neg, &writes );
		printf( "   service writes %u\n", writes );

		{   /* what the saves take from the heap, trimmed at close; TRAVERSE's trav* only to the disk */
			unsigned sf, sb, stk, sl, sf0, sb0, st0, sl0, k;
			unlink( "tests/data/hlsv_trav.sav" ); unlink( "tests/data/hlsv_autosave.sav" );
			zzhl_fs_save_memory( &sf0, &sb0, &st0, &sl0 );
			fd = _open( "valve/save/c2a5.HL1", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
			for( k = 0; k < 75u; k++ ) _write( fd, sv + k * 4096u, 4096 );   /* 300 KiB grown by doubling: 512 KiB taken */
			_close( fd );
			zzhl_fs_save_memory( &sf, &sb, &stk, &sl );
			CHECK( sf == sf0 + 1 && sb - sb0 == 75u * 4096u && stk - st0 <= 75u * 4096u + 1u, "saves' memory: a closed level state takes its size, not its 512 KiB of growth" );
			xacp_fs_disk_saves_only( "trav" );
			fd = _open( "valve/save/autosave.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv, 7000 ); _close( fd );
			fd = _open( "valve/save/trav.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv, 9000 ); _close( fd );
			CHECK( !sim_exists( "hlsv_autosave.sav" ) && sim_exists( "hlsv_trav.sav" ), "TRAVERSE: trav.sav reaches the disk, a map's own autosave stays in memory" );
			CHECK( zzhl_fs_scratch_size( "valve/save/trav.sav" ) == 9000u, "TRAVERSE: the save's size known" );
			zzhl_fs_save_memory( &sf, &sb, &stk, &sl );
			CHECK( sl >= 9000u, "saves' memory: the largest save" );
			xacp_fs_disk_saves_only( "" );
			unlink( "tests/data/hlsv_trav.sav" );
		}
	}
	{   /* a 64 MiB cache keeps the whole blocks of direct reads: read again, nothing asked to the launcher */
		static unsigned char pk[3u * 1048576u + 5000u], rd[3u * 1048576u + 5000u];
		unsigned req0, req1, bytes, hit, miss, direct, svc, neg, writes, mib, dh, dh0, kept, i, x = 99u;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		f = fopen( "tests/data/bigtest.pak", "wb" ); fwrite( pk, 1, sizeof( pk ), f ); fclose( f );
		zzhl_fs_cache_reset(); g_opt_xcache = "64";
		fd = _open( "valve/bigtest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, sizeof( pk ));
		zzhl_fs_cache_stats( &mib, &dh0, &kept );
		zzhl_fs_stats( &req0, &bytes, &hit, &miss, &direct, &svc, &neg, &writes );
		CHECK( n == (int)sizeof( pk ) && !memcmp( rd, pk, sizeof( pk )) && mib == 64 && kept == 48, "big cache: 3 MiB read directly, 48 whole blocks kept" );
		memset( rd, 0, sizeof( rd ));
		_lseek( fd, 0, SEEK_SET );
		n = _read( fd, rd, sizeof( pk ));
		zzhl_fs_cache_stats( &mib, &dh, &kept );
		zzhl_fs_stats( &req1, &bytes, &hit, &miss, &direct, &svc, &neg, &writes );
		CHECK( n == (int)sizeof( pk ) && !memcmp( rd, pk, sizeof( pk )) && dh - dh0 == 48 && req1 == req0, "big cache: read again from the cache (48 blocks), no request" );
		_lseek( fd, 65536u * 7u + 100u, SEEK_SET );   /* an unaligned read across kept blocks */
		n = _read( fd, rd, 200000 );
		CHECK( n == 200000 && !memcmp( rd, pk + 65536u * 7u + 100u, 200000 ), "big cache: an unaligned read over kept blocks is right" );
		_close( fd );
		unlink( "tests/data/bigtest.pak" );
	}

	{   /* a model read whole brings its animation file ("sequence group") into the cache */
		static unsigned char pk[400000], rd[300000];
		unsigned mdl_at = 12u, mdl_n = 244u + 208u, grp_at = 70000u, grp_n = 200000u, dir_at = 280000u, i, x = 5u;
		unsigned r0, r1, pf, pkib, pms, pmiss, n0, b0, u0, n1, b1, u1, kind, evb;
		const char *e;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, 3u * 64u );
		/* models/foo.mdl: a studio header with no table but its 2 sequence groups */
		memset( pk + mdl_at, 0, mdl_n );
		memcpy( pk + mdl_at, "IDST", 4 ); wl( pk + mdl_at + 4, 10u ); wl( pk + mdl_at + 72, mdl_n );
		wl( pk + mdl_at + 172, 2u ); wl( pk + mdl_at + 176, 244u );
		strcpy( (char *)pk + mdl_at + 244, "default" ); strcpy( (char *)pk + mdl_at + 244 + 32, "" );
		strcpy( (char *)pk + mdl_at + 244 + 104, "seq01" ); strcpy( (char *)pk + mdl_at + 244 + 104 + 32, "models\\FOO01.mdl" );
		memcpy( pk + grp_at, "IDSQ", 4 );
		memset( pk + dir_at, 0, 3u * 64u );
		strcpy( (char *)pk + dir_at, "models/foo.mdl" ); wl( pk + dir_at + 56, mdl_at ); wl( pk + dir_at + 60, mdl_n );
		strcpy( (char *)pk + dir_at + 64, "models/foo01.mdl" ); wl( pk + dir_at + 64 + 56, grp_at ); wl( pk + dir_at + 64 + 60, grp_n );
		strcpy( (char *)pk + dir_at + 128, "sound/x.wav" ); wl( pk + dir_at + 128 + 56, 272000u ); wl( pk + dir_at + 128 + 60, 1000u );
		f = fopen( "tests/data/pftest.pak", "wb" ); fwrite( pk, 1, dir_at + 3u * 64u, f ); fclose( f );
		fd = _open( "valve/pftest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );                                   /* the engine reads the header first */
		CHECK( n == 12 && xacp_fs_pak_entry( "pftest.pak", grp_at + 5000u ) && !strcmp( xacp_fs_pak_entry( "pftest.pak", grp_at + 5000u ), "models/foo01.mdl" ), "read-ahead: the pak's directory names the file at an offset" );
		_lseek( fd, mdl_at, SEEK_SET );
		n = _read( fd, rd, mdl_n );                                /* the level's load reads the model whole */
		zzhl_fs_prefetch_stats( &pf, &pkib, &pms, &pmiss );
		CHECK( n == (int)mdl_n && pf == 1 && pkib == grp_n / 1024u && pmiss == 0, "read-ahead: the model's animation file read with it (name in another case, '\\\\')" );
		r0 = g_requests;
		_lseek( fd, grp_at, SEEK_SET );
		n = _read( fd, rd, grp_n );                                /* the game asks for it later: from memory */
		r1 = g_requests;
		CHECK( n == (int)grp_n && !memcmp( rd, pk + grp_at, grp_n ) && r1 == r0, "read-ahead: the animation file read later comes from the cache, no request" );
		_lseek( fd, mdl_at, SEEK_SET );
		n = _read( fd, rd, mdl_n );
		zzhl_fs_prefetch_stats( &pf, &pkib, &pms, &pmiss );
		CHECK( pf == 1, "read-ahead: the model read again, its animations not read twice" );

		/* xacp_disk.c: the game's requests named, the loads counted */
		zzhl_fs_io_totals( &n0, &b0, &u0 );
		g_in_play = 1; xacp_disk_frame();                          /* the game shows: a load ends */
		f = fopen( "tests/data/loose.txt", "wb" ); fputs( "hello", f ); fclose( f );
		CHECK( _stat( "valve/loose.txt", &st ) == 0, "disk: a STAT during the game" );
		_lseek( fd, 272000u, SEEK_SET );
		zzhl_fs_cache_reset();                                     /* the sound's block not in the cache: a READAT */
		n = _read( fd, rd, 1000 );
		zzhl_fs_io_totals( &n1, &b1, &u1 );
		e = xacp_disk_test_event( 0, &kind, &evb );
		CHECK( e && !strcmp( e, "loose.txt" ) && kind == 2, "disk: the game's first request kept, a STAT of loose.txt" );
		e = xacp_disk_test_event( 1, &kind, &evb );
		CHECK( e && !strcmp( e, "pftest.pak sound/x.wav" ) && kind == 3 && evb > 0, "disk: the game's READAT named by the file inside the pak" );
		CHECK( n1 - n0 == 2 && xacp_disk_test_loads() == 1, "disk: two requests during the game, one load ended" );
		g_in_play = 0; xacp_disk_frame();
		xacp_disk_report();
		_close( fd );
		unlink( "tests/data/pftest.pak" ); unlink( "tests/data/loose.txt" );
	}
	{   /* a save renamed away is not read back from the disk (the rotation before each autosave) */
		static unsigned char sv[5000];
		unsigned w0, r0, r1, bad, q0, q1;
		for( i = 0; i < sizeof( sv ); i++ ) sv[i] = (unsigned char)( i * 7u );
		fd = _open( "valve/save/autosave.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, sv, sizeof( sv )); _close( fd );
		xacp_fs_test_new_session();
		zzhl_fs_save_stats( &w0, &r0, &bad );
		CHECK( _stat( "valve/save/autosave.sav", &st ) == 0, "rotation: the disk's autosave found (read once)" );
		CHECK( rename( "valve/save/autosave.sav", "valve/save/autosave01.sav" ) == 0, "rotation: autosave -> autosave01 in memory" );
		q0 = g_requests;
		CHECK( _stat( "valve/save/autosave.sav", &st ) != 0 && _open( "valve/save/autosave.sav", O_RDONLY, 0 ) < 0, "rotation: autosave is gone under its old name" );
		zzhl_fs_save_stats( &w0, &r1, &bad );
		q1 = g_requests;
		CHECK( r1 == r0 + 1 && q1 == q0, "rotation: the disk's copy not read back (one read in all, no request)" );
		fd = _open( "valve/save/autosave.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, sv + 1, 4000 ); _close( fd );
		CHECK( _stat( "valve/save/autosave.sav", &st ) == 0 && st.st_size == 4000, "rotation: the new autosave written and found" );
		CHECK( _stat( "valve/save/autosave01.sav", &st ) == 0 && st.st_size == (off_t)sizeof( sv ), "rotation: autosave01 holds the previous one" );
	}

	{   /* a loose file found once is not asked to the 68k again (the STATs of every listing of valve/) */
		unsigned n0, b0, u0, n1, b1, u1;
		f = fopen( "tests/data/loose2.txt", "wb" ); fputs( "x", f ); fclose( f );
		zzhl_fs_io_totals( &n0, &b0, &u0 );
		CHECK( _stat( "valve/loose2.txt", &st ) == 0 && _stat( "valve/loose2.txt", &st ) == 0 && _stat( "valve/LOOSE2.TXT", &st ) == 0, "stat cache: the loose file found three times" );
		zzhl_fs_io_totals( &n1, &b1, &u1 );
		CHECK( n1 - n0 == 1, "stat cache: one STAT asked to the 68k for three looks" );
		unlink( "tests/data/loose2.txt" );
	}
	{   /* the HEV voice / HUD / decals at the first model, a character's voice with its model */
		static unsigned char pk[700000], rd[100000];
		struct { const char *nm; unsigned at, len; } ent[] = {
			{ "models/scientist.mdl", 12u, 244u },
			{ "sound/scientist/a.wav", 70000u, 30000u }, { "sound/scientist/b.wav", 100000u, 90000u },
			{ "sound/fvox/x.wav", 200000u, 50000u }, { "sprites/640hud1.spr", 260000u, 20000u },
			{ "sprites/hud.txt", 290000u, 3000u }, { "decals.wad", 300000u, 100000u },
			{ "sound/barney/z.wav", 470000u, 150000u } };
		unsigned ne = 8u, dir_at = 650000u, i, x = 9u, vs, vf, vk, vm, vx, r0, r1;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, ne * 64u );
		memset( pk + 12, 0, 244 ); memcpy( pk + 12, "IDST", 4 ); wl( pk + 16, 10u ); wl( pk + 12 + 72, 244u );
		memset( pk + dir_at, 0, ne * 64u );
		for( i = 0; i < ne; i++ ) { strcpy( (char *)pk + dir_at + i * 64u, ent[i].nm ); wl( pk + dir_at + i * 64u + 56, ent[i].at ); wl( pk + dir_at + i * 64u + 60, ent[i].len ); }
		f = fopen( "tests/data/vctest.pak", "wb" ); fwrite( pk, 1, dir_at + ne * 64u, f ); fclose( f );
		xacp_fs_test_new_session();
		fd = _open( "valve/vctest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );
		_lseek( fd, 12, SEEK_SET );
		n = _read( fd, rd, 244 );                                   /* models/scientist.mdl read whole */
		zzhl_fs_voice_stats( &vs, &vf, &vk, &vm, &vx );
		CHECK( n == 244 && vs == 2 && vx == 0 && vf == 6, "read ahead: the first set (fvox, HUD sprites and lists, decals) and the scientist's voice, 6 files" );
		r0 = g_requests;
		_lseek( fd, 100000, SEEK_SET ); n = _read( fd, rd, 90000 );
		_lseek( fd, 290000, SEEK_SET ); n += _read( fd, rd + 90000 - 90000, 3000 );
		r1 = g_requests;
		CHECK( n == 93000 && r1 == r0, "read ahead: a sentence's word and the HUD list come from the cache, no request" );
		_lseek( fd, 540000, SEEK_SET ); n = _read( fd, rd, 1000 );
		CHECK( g_requests > r1, "read ahead: the barney voice not read (no barney model)" );
		_close( fd );
		unlink( "tests/data/vctest.pak" );
	}

	{   /* SURVEY=1 notes the pak's files and the .wad's textures each map opens, cache or not */
		static unsigned char pk[200000], rd[100000], wad[12 + 6000 + 3 * 32];
		static char txt[4096];
		const char *ln[] = { "maps/c1a3.bsp", "halflife.wad", "models/a.mdl", "sound/x.wav" };
		unsigned at[4] = { 12u, 40000u, 60000u, 90000u }, len[4] = { 20000u, 0u, 15000u, 5000u };
		unsigned dir_at = 150000u, i, x = 3u, it, by;
		const char *lumps[3] = { "crate1", "floor", "unused" };
		unsigned lsz[3] = { 1000u, 2000u, 3000u }, lp = 12u;
		FILE *g;
		size_t tl;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		memcpy( wad, "WAD3", 4 ); wl( wad + 4, 3u ); wl( wad + 8, 12u + 6000u );
		for( i = 0; i < 3; i++ )
		{
			unsigned char *e = wad + 12u + 6000u + i * 32u;
			memset( e, 0, 32 ); wl( e, lp ); wl( e + 4, lsz[i] ); wl( e + 8, lsz[i] ); strcpy( (char *)e + 16, lumps[i] );
			lp += lsz[i];
		}
		len[1] = sizeof( wad ); memcpy( pk + at[1], wad, sizeof( wad ));
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, 4u * 64u );
		memset( pk + dir_at, 0, 4u * 64u );
		for( i = 0; i < 4; i++ ) { strcpy( (char *)pk + dir_at + i * 64u, ln[i] ); wl( pk + dir_at + i * 64u + 56, at[i] ); wl( pk + dir_at + i * 64u + 60, len[i] ); }
		f = fopen( "tests/data/svtest.pak", "wb" ); fwrite( pk, 1, dir_at + 4u * 64u, f ); fclose( f );
		g_opt_survey = "1";
		xacp_fs_test_new_session();
		xacp_fs_test_drop_paks();
		fd = _open( "valve/svtest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );
		_lseek( fd, at[0], SEEK_SET ); n = _read( fd, rd, len[0] );             /* the map */
		_lseek( fd, at[1], SEEK_SET ); n = _read( fd, rd, 12 );                 /* the wad's header */
		_lseek( fd, at[1] + 12u + 6000u, SEEK_SET ); n = _read( fd, rd, 96 );   /* its directory */
		_lseek( fd, at[1] + 12u, SEEK_SET ); n = _read( fd, rd, 1000 );         /* the texture crate1 */
		_lseek( fd, at[2], SEEK_SET ); n = _read( fd, rd, len[2] );             /* a model */
		_lseek( fd, at[2], SEEK_SET ); n = _read( fd, rd, len[2] );             /* again, from the cache */
		xacp_fs_survey_map_end( 5, &it, &by );
		CHECK( it == 3 && by == len[0] + len[2] + 1000u, "survey: map 1 opened the map, a model and one texture of the wad" );
		_lseek( fd, at[3], SEEK_SET ); n = _read( fd, rd, len[3] );             /* map 2: a sound */
		_lseek( fd, at[1] + 12u + 1000u, SEEK_SET ); n = _read( fd, rd, 2000 ); /* and the texture floor */
		_lseek( fd, at[2], SEEK_SET ); n = _read( fd, rd, 100 );                /* and part of the model */
		xacp_fs_survey_map_end( 5, &it, &by );
		CHECK( it == 3, "survey: map 2 opened a sound, a texture and the model (cached or not)" );
		unlink( "tests/data/zzhl_ch05.lst" );
		CHECK( xacp_fs_survey_write( 5, "We've Got Hostiles", "c1a3 c1a3a", &it, &by ) == 1 && it == 6, "survey: the chapter's list written, 6 lines (4 files... less the wad, its directory, 2 textures)" );
		g = fopen( "tests/data/zzhl_ch05.lst", "rb" );
		tl = g ? fread( txt, 1, sizeof( txt ) - 1, g ) : 0; if( g ) fclose( g ); txt[tl] = 0;
		CHECK( strstr( txt, "f maps/c1a3.bsp 20000\n" ) && strstr( txt, "f models/a.mdl 15000\n" ) && strstr( txt, "f sound/x.wav 5000\n" )
			&& strstr( txt, "d halflife.wad 108\n" ) && strstr( txt, "w halflife.wad crate1 1000\n" ) && strstr( txt, "w halflife.wad floor 2000\n" )
			&& !strstr( txt, "unused" ) && !strstr( txt, "f halflife.wad" ), "survey: the list names the files, the wad's directory and the 2 textures, not the third" );
		xacp_fs_survey_common( &it, &by );
		CHECK( it == 5, "survey: one chapter, all its files and textures common" );
		_close( fd );
		g_opt_survey = NULL; xacp_fs_test_new_session();
		unlink( "tests/data/svtest.pak" ); unlink( "tests/data/zzhl_ch05.lst" );
	}

	{   /* what the map needs without opening it again - the server's precaches, the .bsp's textures */
		static unsigned char pk[120000], rd[16];
		static unsigned char bsp[124 + 4 + 8 + 80];
		static unsigned char wad[12 + 3000 + 2 * 32];
		const char *ln[] = { "maps/x.bsp", "halflife.wad", "models/b.mdl", "models/bt.mdl", "models/b01.mdl", "models/b02.mdl", "sound/y.wav" };
		unsigned at[7] = { 12u, 2000u, 20000u, 30000u, 40000u, 50000u, 60000u }, len[7] = { 0u, 0u, 5000u, 4000u, 3000u, 2000u, 1000u };
		unsigned dir_at = 100000u, i, it, by, lo = 124u;
		memset( bsp, 0, sizeof( bsp ));
		wl( bsp, 30u ); wl( bsp + 4u + 16u, lo ); wl( bsp + 8u + 16u, 4u + 8u + 80u );    /* lump 2 */
		wl( bsp + lo, 2u ); wl( bsp + lo + 4u, 12u ); wl( bsp + lo + 8u, 52u );
		strcpy( (char *)bsp + lo + 12u, "FLOOR" );                                 /* external: offsets[0] = 0 */
		strcpy( (char *)bsp + lo + 52u, "inbsp" ); wl( bsp + lo + 52u + 24u, 40u );  /* in the .bsp */
		memset( wad, 0, sizeof( wad ));
		memcpy( wad, "WAD3", 4 ); wl( wad + 4, 2u ); wl( wad + 8, 12u + 3000u );
		wl( wad + 3012u, 12u ); wl( wad + 3012u + 4u, 1000u ); strcpy( (char *)wad + 3012u + 16u, "floor" );
		wl( wad + 3044u, 1012u ); wl( wad + 3044u + 4u, 2000u ); strcpy( (char *)wad + 3044u + 16u, "inbsp" );
		len[0] = sizeof( bsp ); len[1] = sizeof( wad );
		memset( pk, 0, sizeof( pk ));
		memcpy( pk + at[0], bsp, sizeof( bsp )); memcpy( pk + at[1], wad, sizeof( wad ));
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, 7u * 64u );
		for( i = 0; i < 7; i++ ) { strcpy( (char *)pk + dir_at + i * 64u, ln[i] ); wl( pk + dir_at + i * 64u + 56, at[i] ); wl( pk + dir_at + i * 64u + 60, len[i] ); }
		f = fopen( "tests/data/sv2.pak", "wb" ); fwrite( pk, 1, dir_at + 7u * 64u, f ); fclose( f );
		g_opt_survey = "1";
		xacp_fs_test_new_session();
		xacp_fs_test_drop_paks();
		fd = _open( "valve/sv2.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );
		xacp_fs_survey_add( "models/b.mdl" );
		xacp_fs_survey_add( "sound/y.wav" );
		xacp_fs_survey_add( "*3" );
		xacp_fs_survey_add_bsp_textures( "maps/x.bsp" );
		xacp_fs_survey_map_end( 7, &it, &by );
		CHECK( it == 6 && by == 5000u + 4000u + 3000u + 2000u + 1000u + 1000u, "survey 44: a model brings its texture model and its 2 animation files, a sound, the texture, no inline model" );
		xacp_fs_survey_add_bsp_textures( "maps/x.bsp" );
		xacp_fs_survey_map_end( 7, &it, &by );
		CHECK( it == 1 && by == 1000u, "survey 44: the .bsp's external texture (FLOOR in any case) found in the wad, not the one inside the .bsp" );
		_close( fd );
		g_opt_survey = NULL; xacp_fs_test_new_session(); xacp_fs_test_drop_paks();
		unlink( "tests/data/sv2.pak" );
	}

	{   /* a map of another chapter makes its ranges of pak0.chp read first; the chapter then comes from memory */
		static unsigned char pk[1200000], rd[300000], chp[16 + 12 + 16 + 12 + 8];
		const char *ln[] = { "maps/c1a3.bsp", "maps/c1a3a.bsp", "models/a.mdl", "sound/b.wav" };
		unsigned at[4] = { 12u, 70000u, 400000u, 900000u }, len[4] = { 50000u, 50000u, 300000u, 100000u };
		unsigned dir_at = 1100000u, i, x = 11u, r0, r1, co, ck, cm, psize = dir_at + 4u * 64u;
		int con;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, 4u * 64u );
		memset( pk + dir_at, 0, 4u * 64u );
		for( i = 0; i < 4; i++ ) { strcpy( (char *)pk + dir_at + i * 64u, ln[i] ); wl( pk + dir_at + i * 64u + 56, at[i] ); wl( pk + dir_at + i * 64u + 60, len[i] ); }
		f = fopen( "tests/data/chtest.pak", "wb" ); fwrite( pk, 1, psize, f ); fclose( f );
		memcpy( chp, "ZZCHP1\0\0", 8 ); wl( chp + 8, psize ); wl( chp + 12, 2u );
		wl( chp + 16, 5u ); wl( chp + 20, 2u ); wl( chp + 24, 120000u );         /* chapter 05: the second map and the model */
		wl( chp + 28, at[1] ); wl( chp + 32, len[1] );
		wl( chp + 36, at[2] ); wl( chp + 40, len[2] );
		wl( chp + 44, 255u ); wl( chp + 48, 1u ); wl( chp + 52, len[3] );        /* the common part: the sound */
		wl( chp + 56, at[3] ); wl( chp + 60, len[3] );
		f = fopen( "tests/data/chtest.chp", "wb" ); fwrite( chp, 1, sizeof( chp ), f ); fclose( f );
		xacp_fs_test_new_session();
		xacp_fs_test_drop_paks();
		zzhl_fs_cache_reset(); g_opt_xcache = "64";
		fd = _open( "valve/chtest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );                                     /* the header: the pak's names */
		_lseek( fd, at[0], SEEK_SET ); n = _read( fd, rd, 124 );     /* c1a3's header: chapter 05 opens */
		zzhl_fs_chapter_stats( &co, &ck, &cm, &con );
		CHECK( con && co == 2 && ck >= ( len[1] + len[2] + len[3] ) / 1024u, "chapter: c1a3 opens chapter 05, the common part then its ranges read (chtest.chp)" );
		r0 = g_requests;
		_lseek( fd, at[1], SEEK_SET ); n = _read( fd, rd, len[1] );  /* the chapter's next map */
		_lseek( fd, at[2], SEEK_SET ); n += _read( fd, rd, len[2] ); /* and its model */
		r1 = g_requests;
		CHECK( n == (int)( len[1] + len[2] ) && !memcmp( rd, pk + at[2], len[2] ) && r1 == r0, "chapter: its other map and its model from memory, no request" );
		_lseek( fd, at[1], SEEK_SET ); n = _read( fd, rd, 124 );
		zzhl_fs_chapter_stats( &co, &ck, &cm, &con );
		CHECK( co == 2, "chapter: another map of the same chapter reads nothing more" );
		r0 = g_requests;
		_lseek( fd, at[3], SEEK_SET ); n = _read( fd, rd, len[3] );
		CHECK( g_requests == r0, "chapter: the common part from memory" );
		_close( fd );
		xacp_fs_test_new_session(); xacp_fs_test_drop_paks();
		unlink( "tests/data/chtest.pak" ); unlink( "tests/data/chtest.chp" );
	}

	{   /* a whole-file READ answered as the request before it (A4000, 16/11, 23 h 36: the READ of
		   pak0.chp came back as the 83 KiB of the save just read, and no chapter was read whole) */
		static unsigned char pk[1200000], rd[300000], chp[16 + 12 + 16 + 12 + 8];
		const char *ln[] = { "maps/c1a3.bsp", "maps/c1a3a.bsp", "models/a.mdl", "sound/b.wav" };
		unsigned at[4] = { 12u, 70000u, 400000u, 900000u }, len[4] = { 50000u, 50000u, 300000u, 100000u };
		unsigned dir_at = 1100000u, i, x = 13u, co, ck, cm, co0, psize = dir_at + 4u * 64u, ra0, ra1, un, rd0;
		extern unsigned zzhl_fs_read_again( unsigned *unsure );
		int con;
		for( i = 0; i < sizeof( pk ); i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, 4u * 64u );
		memset( pk + dir_at, 0, 4u * 64u );
		for( i = 0; i < 4; i++ ) { strcpy( (char *)pk + dir_at + i * 64u, ln[i] ); wl( pk + dir_at + i * 64u + 56, at[i] ); wl( pk + dir_at + i * 64u + 60, len[i] ); }
		f = fopen( "tests/data/chst.pak", "wb" ); fwrite( pk, 1, psize, f ); fclose( f );
		memcpy( chp, "ZZCHP1\0\0", 8 ); wl( chp + 8, psize ); wl( chp + 12, 2u );
		wl( chp + 16, 5u ); wl( chp + 20, 2u ); wl( chp + 24, 120000u );
		wl( chp + 28, at[1] ); wl( chp + 32, len[1] );
		wl( chp + 36, at[2] ); wl( chp + 40, len[2] );
		wl( chp + 44, 255u ); wl( chp + 48, 1u ); wl( chp + 52, len[3] );
		wl( chp + 56, at[3] ); wl( chp + 60, len[3] );
		f = fopen( "tests/data/chst.chp", "wb" ); fwrite( chp, 1, sizeof( chp ), f ); fclose( f );
		xacp_fs_test_new_session();
		xacp_fs_test_drop_paks();
		zzhl_fs_cache_reset(); g_opt_xcache = "64";
		fd = _open( "valve/chst.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );                                     /* the launcher's last request: chst.pak */
		ra0 = zzhl_fs_read_again( &un ); rd0 = g_sim_reads;
		zzhl_fs_chapter_stats( &co0, &ck, &cm, &con );               /* the count of chapters opened is the run's */
		g_stale_reads = 1;                                           /* the READ of chst.chp is answered with chst.pak */
		_lseek( fd, at[0], SEEK_SET ); n = _read( fd, rd, 124 );
		zzhl_fs_chapter_stats( &co, &ck, &cm, &con );
		ra1 = zzhl_fs_read_again( &un );
		CHECK( con && co == co0 + 2u, "stale READ: the chapter file answered as the pak once is asked again, the chapters are read whole" );
		CHECK( ra1 == ra0 + 1u && un == 0u && g_sim_reads == rd0 + 3u && g_stale_reads == 0, "stale READ: one disagreement counted, three requests (wrong, right, right)" );
		_close( fd );
		xacp_fs_test_new_session(); xacp_fs_test_drop_paks();
		unlink( "tests/data/chst.pak" ); unlink( "tests/data/chst.chp" );

		/* the same on a .cfg: the user's keys.  Before build 91 the first answer was served - or, larger
		   than the engine's command buffer, refused and the keys of the pak's config.cfg used instead */
		f = fopen( "tests/data/big.cfg", "wb" ); for( i = 0; i < 3000u; i++ ) fputs( "bind z +forward\n", f ); fclose( f );   /* 48 000 bytes */
		f = fopen( "tests/data/keys.cfg", "wb" ); fputs( "bind x +use\n", f ); fclose( f );
		fd = _open( "valve/big.cfg", O_RDONLY, 0 );                  /* too big: refused, and the launcher's last request */
		CHECK( fd < 0, "stale READ: a .cfg of 48 000 bytes is refused (build 79), and is the launcher's last request" );
		ra0 = zzhl_fs_read_again( &un ); rd0 = g_sim_reads;
		g_stale_reads = 1;
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		n = fd >= 0 ? _read( fd, rd, 100 ) : -1;
		CHECK( fd >= 3 && n == 12 && !memcmp( rd, "bind x +use\n", 12 ), "stale READ: keys.cfg answered as the big file once is served as itself, not refused" );
		CHECK( zzhl_fs_read_again( &un ) == ra0 + 1u && g_sim_reads == rd0 + 3u, "stale READ: one disagreement, three requests" );
		if( fd >= 0 ) _close( fd );
		/* answered ABSENT once (the request before it was for a file that does not exist) */
		xacp_fs_test_new_session();
		fd = _open( "valve/nothere.cfg", O_RDONLY, 0 );
		rd0 = g_sim_reads;
		CHECK( fd < 0, "stale READ: a file that is not there is absent" );
		fd = _open( "valve/nothere2.cfg", O_RDONLY, 0 );
		CHECK( fd < 0 && g_sim_reads == rd0 + 2u, "stale READ: absent costs two requests (two answers that agree)" );
		ra0 = zzhl_fs_read_again( &un );
		g_stale_reads = 1;
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		n = fd >= 0 ? _read( fd, rd, 100 ) : -1;
		CHECK( fd >= 3 && n == 12 && !memcmp( rd, "bind x +use\n", 12 ) && zzhl_fs_read_again( &un ) == ra0 + 1u, "stale READ: keys.cfg answered absent once is found all the same" );
		if( fd >= 0 ) _close( fd );
		xacp_fs_test_new_session();
		unlink( "tests/data/big.cfg" ); unlink( "tests/data/keys.cfg" );
	}

	{   /* a .cfg answered with the right SIZE and binary bytes, the same at both READs
		   (A4000, 17/11 10 h 05: config.cfg executed as garbage, the keys lost and written back) */
		extern void zzhl_fs_cfg_stats( unsigned v[4] );
		static const char keys[] = "unbindall\nbind w +forward\nbind s +back\nbind MOUSE1 +attack\nsensitivity 3\n";
		const int kl = (int)sizeof( keys ) - 1;
		unsigned v0[4], v[4];
		char rd[200];
		int fd, n;
		FILE *f;
		xacp_fs_test_new_session();
		f = fopen( "tests/data/keys.cfg", "wb" ); fputs( keys, f ); fclose( f );
		/* 1. both READs binary, the READAT road right */
		zzhl_fs_cfg_stats( v0 );
		g_garbage_reads = 2;
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		n = fd >= 0 ? _read( fd, rd, 200 ) : -1;
		zzhl_fs_cfg_stats( v );
		CHECK( fd >= 3 && n == kl && !memcmp( rd, keys, (size_t)kl ), "binary .cfg: two READs agree on binary bytes, the file is served as itself (by READAT)" );
		CHECK( v[0] == v0[0] + 1u && v[1] == v0[1] + 1u && v[2] == v0[2] && g_garbage_reads == 0, "binary .cfg: one binary answer counted, one file read right at last, none refused" );
		CHECK( !strcmp( g_held, "pak0.pak" ), "binary .cfg: after the READAT road the 68k holds pak0.pak" );
		if( fd >= 0 ) _close( fd );
		/* 2. the READs binary, the READAT road binary once too (zeros), the READs right after that */
		xacp_fs_test_new_session();
		zzhl_fs_cfg_stats( v0 );
		g_garbage_reads = 2;
		strcpy( g_corrupt_name, "keys.cfg" ); g_corrupt_lo = 0; g_corrupt_hi = 1000; g_corrupt_byte = 0; g_corrupt_once = 1;
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		n = fd >= 0 ? _read( fd, rd, 200 ) : -1;
		zzhl_fs_cfg_stats( v );
		CHECK( fd >= 3 && n == kl && !memcmp( rd, keys, (size_t)kl ) && v[1] == v0[1] + 1u && v[2] == v0[2], "binary .cfg: READAT binary as well, the READ asked once more is right and served" );
		if( fd >= 0 ) _close( fd );
		/* 3. binary every time: refused, and what the engine writes on leaving does not reach the disk */
		xacp_fs_test_new_session();
		zzhl_fs_cfg_stats( v0 );
		g_garbage_reads = 100; g_corrupt_once = 100;
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		zzhl_fs_cfg_stats( v );
		CHECK( fd < 0 && v[0] == v0[0] + 1u && v[1] == v0[1] && v[2] == v0[2] + 1u, "binary .cfg: binary every time, the file is refused (the engine goes to the pak's own)" );
		g_garbage_reads = 0; g_corrupt_once = 0;
		fd = _open( "valve/keys.cfg", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, "bind UPARROW +forward\n", 22 ); _close( fd );
		f = fopen( "tests/data/keys.cfg", "rb" ); n = 0; if( f ) { n = (int)fread( rd, 1, 200, f ); fclose( f ); }
		zzhl_fs_cfg_stats( v );
		CHECK( n == kl && !memcmp( rd, keys, (size_t)kl ) && v[3] == v0[3] + 1u, "binary .cfg: the refused file is NOT written back, the disk keeps the user's keys" );
		/* the next session reads it as it is, and writes it again */
		xacp_fs_test_new_session();
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		n = fd >= 0 ? _read( fd, rd, 200 ) : -1;
		CHECK( fd >= 3 && n == kl && !memcmp( rd, keys, (size_t)kl ), "binary .cfg: the next session reads the user's file" );
		if( fd >= 0 ) _close( fd );
		fd = _open( "valve/keys.cfg", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		_write( fd, "bind UPARROW +forward\n", 22 ); _close( fd );
		f = fopen( "tests/data/keys.cfg", "rb" ); n = 0; if( f ) { n = (int)fread( rd, 1, 200, f ); fclose( f ); }
		CHECK( n == 22 && !memcmp( rd, "bind UPARROW", 12 ), "binary .cfg: and a config read right is written back as before" );
		/* 4. text is text: accents, tabs, CR LF and one stray Ctrl-Z pass */
		xacp_fs_test_new_session();
		f = fopen( "tests/data/keys.cfg", "wb" ); fputs( "// r\xe9glages\r\n\tbind \"e\" \"+use\"\r\nname \"TestPlayer\"\r\n", f ); for( n = 0; n < 20; n++ ) fputs( "bind x +use\r\n", f ); fputc( 0x1A, f ); fclose( f );
		zzhl_fs_cfg_stats( v0 );
		fd = _open( "valve/keys.cfg", O_RDONLY, 0 );
		zzhl_fs_cfg_stats( v );
		CHECK( fd >= 3 && v[0] == v0[0], "binary .cfg: a real config with accents, tabs, CR LF and a Ctrl-Z is text" );
		if( fd >= 0 ) _close( fd );
		xacp_fs_test_new_session();
		unlink( "tests/data/keys.cfg" ); unlink( "tests/data/_garbage.tmp" );
	}

	{   /* two chapters that do not fit with the common part in the cache: the common part stays */
		static unsigned char pk[23u << 20], rd[4u << 20], chp[16 + 3 * 20];
		const char *ln[] = { "maps/c1a3.bsp", "maps/c1a4.bsp", "models/a.mdl", "models/b.mdl", "sound/c.wav" };
		unsigned at[5] = { 12u, 100000u, 1u << 20, 19u << 19, 18u << 20 }, len[5] = { 50000u, 50000u, 8u << 20, 8u << 20, 4u << 20 };
		unsigned dir_at = 22u << 20, i, x = 7u, r0, co, ck, cm, co0, ck0, psize = dir_at + 5u * 64u, p;
		int con;
		for( i = 0; i < psize; i++ ) { x = x * 1103515245u + 12345u; pk[i] = (unsigned char)( x >> 16 ); }
		memcpy( pk, "PACK", 4 ); wl( pk + 4, dir_at ); wl( pk + 8, 5u * 64u );
		memset( pk + dir_at, 0, 5u * 64u );
		for( i = 0; i < 5; i++ ) { strcpy( (char *)pk + dir_at + i * 64u, ln[i] ); wl( pk + dir_at + i * 64u + 56, at[i] ); wl( pk + dir_at + i * 64u + 60, len[i] ); }
		f = fopen( "tests/data/chtest.pak", "wb" ); fwrite( pk, 1, psize, f ); fclose( f );
		memcpy( chp, "ZZCHP1\0\0", 8 ); wl( chp + 8, psize ); wl( chp + 12, 3u ); p = 16;
		wl( chp + p, 5u ); wl( chp + p + 4, 1u ); wl( chp + p + 8, len[2] ); wl( chp + p + 12, at[2] ); wl( chp + p + 16, len[2] ); p += 20;   /* 05: a.mdl */
		wl( chp + p, 6u ); wl( chp + p + 4, 1u ); wl( chp + p + 8, len[3] ); wl( chp + p + 12, at[3] ); wl( chp + p + 16, len[3] ); p += 20;   /* 06: b.mdl */
		wl( chp + p, 255u ); wl( chp + p + 4, 1u ); wl( chp + p + 8, len[4] ); wl( chp + p + 12, at[4] ); wl( chp + p + 16, len[4] );        /* common: c.wav */
		f = fopen( "tests/data/chtest.chp", "wb" ); fwrite( chp, 1, sizeof( chp ), f ); fclose( f );
		xacp_fs_test_new_session(); xacp_fs_test_drop_paks();
		zzhl_fs_cache_reset(); g_opt_xcache = "16";                 /* 256 blocks: common 4 + chapter 8 fit, + the next 8 not */
		fd = _open( "valve/chtest.pak", O_RDONLY, 0 );
		n = _read( fd, rd, 12 );
		zzhl_fs_chapter_stats( &co0, &ck0, &cm, &con );
		_lseek( fd, at[0], SEEK_SET ); n = _read( fd, rd, 124 );     /* c1a3: chapter 05, with the common part */
		_lseek( fd, at[1], SEEK_SET ); n = _read( fd, rd, 124 );     /* c1a4: chapter 06 */
		zzhl_fs_chapter_stats( &co, &ck, &cm, &con );
		co -= co0; ck -= ck0;
		CHECK( con && co == 4 && ck >= ( 4u + 8u + 8u ) * 1024u && ck < ( 4u + 8u + 8u + 1u ) * 1024u, "chapter change: the common part read again first, from the cache (20 MiB not read twice)" );
		r0 = g_requests;
		_lseek( fd, at[4], SEEK_SET ); n = _read( fd, rd, len[4] );
		CHECK( n == (int)len[4] && !memcmp( rd, pk + at[4], len[4] ) && g_requests == r0, "chapter change: the common part still in the cache after a chapter too big for both (no request)" );
		r0 = g_requests;
		_lseek( fd, at[3], SEEK_SET ); n = _read( fd, rd, 1u << 20 );
		CHECK( g_requests == r0, "chapter change: the new chapter in the cache" );
		r0 = g_requests;
		_lseek( fd, at[2], SEEK_SET ); n = _read( fd, rd, 1u << 20 );
		CHECK( g_requests > r0, "chapter change: the previous chapter is what left the cache" );
		_close( fd );
		xacp_fs_test_new_session(); xacp_fs_test_drop_paks(); zzhl_fs_cache_reset(); g_opt_xcache = "8";
		unlink( "tests/data/chtest.pak" ); unlink( "tests/data/chtest.chp" );
	}
	{   /* the menu's list of saves: header only for stat, first bytes by READAT for the comment */
		static unsigned char sv[700000], rd[700000];
		unsigned w0, r0, bad, w1, r1, h0, pr0, wh0, h1, pr1, wh1, sf, sb, stk, sl, sf0, sb0, stk0, sl0;
		const char *olds[] = { "hlsave.idx", "hlsv_m1.sav", "hlsv_m1.s01", "hlsv_m2.sav" };
		for( i = 0; i < 4; i++ ) { char p[128]; snprintf( p, sizeof( p ), "tests/data/%s", olds[i] ); unlink( p ); }
		xacp_fs_test_new_session();
		for( i = 0; i < sizeof( sv ); i++ ) sv[i] = (unsigned char)( i * 13u + ( i >> 7 ));
		g_test_time = 1800000123u;
		fd = _open( "valve/save/m1.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv, sizeof( sv )); _close( fd );   /* two files */
		g_test_time = 1800000456u;
		fd = _open( "valve/save/m2.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 ); _write( fd, sv + 3, 9000 ); _close( fd );
		CHECK( _stat( "valve/save/m2.sav", &st ) == 0 && st.st_mtime == (time_t)1800000456, "save times: a save just written has its time" );
		xacp_fs_test_new_session();
		zzhl_fs_save_stats( &w0, &r0, &bad ); zzhl_fs_peek_stats( &h0, &pr0, &wh0 ); zzhl_fs_save_memory( &sf0, &sb0, &stk0, &sl0 );
		CHECK( _stat( "valve/save/m1.sav", &st ) == 0 && st.st_size == (off_t)sizeof( sv ) && st.st_mtime == (time_t)1800000123
		       && _stat( "valve/save/m2.sav", &st ) == 0 && st.st_mtime == (time_t)1800000456, "new session: stat gives size and time from the header" );
		zzhl_fs_save_stats( &w1, &r1, &bad ); zzhl_fs_peek_stats( &h1, &pr1, &wh1 ); zzhl_fs_save_memory( &sf, &sb, &stk, &sl );
		CHECK( r1 == r0 && sf == sf0 && h1 == h0 + 2, "stat of a save on the disk reads its header only, nothing in memory" );
		xacp_fs_save_peek( 1 );
		fd = _open( "valve/save/m1.sav", O_RDONLY, 0 );
		n = fd >= 3 ? _read( fd, rd, 4 ) : -1;
		n += fd >= 3 ? _read( fd, rd + 4, 20000 ) : -1;
		_close( fd );
		xacp_fs_save_peek( 0 );
		zzhl_fs_save_stats( &w1, &r1, &bad ); zzhl_fs_peek_stats( &h1, &pr1, &wh1 ); zzhl_fs_save_memory( &sf, &sb, &stk, &sl );
		CHECK( n == 20004 && !memcmp( rd, sv, 20004 ) && r1 == r0 && sf == sf0 && pr1 == pr0 + 2, "comment: the first bytes served from the disk, the save not read into memory" );
		xacp_fs_save_peek( 1 );
		fd = _open( "valve/save/m1.sav", O_RDONLY, 0 );
		memset( rd, 0, sizeof( rd ));
		n = fd >= 3 ? _read( fd, rd, 100 ) : -1;
		n += fd >= 3 ? _read( fd, rd + 100, sizeof( rd ) - 100 ) : -1;
		_close( fd );
		xacp_fs_save_peek( 0 );
		zzhl_fs_save_stats( &w1, &r1, &bad ); zzhl_fs_peek_stats( &h1, &pr1, &wh1 );
		CHECK( n == (int)sizeof( sv ) && !memcmp( rd, sv, sizeof( sv )) && r1 == r0 + 1 && wh1 == wh0 + 1, "comment reading beyond the first file: the whole save, checked" );
		xacp_fs_test_new_session();
		zzhl_fs_save_stats( &w0, &r0, &bad );
		fd = _open( "valve/save/m2.sav", O_RDONLY, 0 );
		n = fd >= 3 ? _read( fd, rd, 9000 ) : -1;
		_close( fd );
		zzhl_fs_save_stats( &w1, &r1, &bad );
		CHECK( n == 9000 && !memcmp( rd, sv + 3, 9000 ) && r1 == r0 + 1, "loading a save (not the menu's comment): whole and checked as before" );
		{   /* on 15/11 the header of two saves came back wrong once and they were "not on the
			   disk" for the whole run (xacp_fs.c, save_peek).  One wrong answer must not hide a save. */
			extern void zzhl_fs_peek_retry_stats( unsigned *retries, unsigned *recovered, unsigned *lost );
			extern char g_corrupt_name[]; extern unsigned g_corrupt_lo, g_corrupt_hi; extern int g_corrupt_once;
			unsigned t0, c0, l0, t1, c1, l1;
			int k, seen;
			xacp_fs_test_new_session();
			zzhl_fs_peek_retry_stats( &t0, &c0, &l0 );
			strcpy( g_corrupt_name, "hlsv_m1.sav" ); g_corrupt_lo = 0; g_corrupt_hi = 32; g_corrupt_once = 1;
			seen = _stat( "valve/save/m1.sav", &st ) == 0 && st.st_size == (off_t)sizeof( sv ) && st.st_mtime == (time_t)1800000123;
			zzhl_fs_peek_retry_stats( &t1, &c1, &l1 );
			CHECK( seen && !g_corrupt_once && t1 == t0 + 1 && c1 == c0 + 1 && l1 == l0, "a save header that reads wrong once is asked again: the save is there" );
			/* a header that never reads: not listed, asked again at each look, given up after four looks */
			xacp_fs_test_new_session();
			zzhl_fs_peek_retry_stats( &t0, &c0, &l0 );
			seen = 0;
			g_corrupt_once = 1000;                       /* every request for its header comes back wrong */
			for( k = 0; k < 4; k++ ) if( _stat( "valve/save/m1.sav", &st ) == 0 ) seen++;
			zzhl_fs_peek_retry_stats( &t1, &c1, &l1 );
			CHECK( !seen && l1 == l0 + 1 && t1 == t0 + 12 && g_corrupt_once == 1000 - 12, "a save header that never reads: four looks of three requests, then given up for the session" );
			g_corrupt_once = 0;
			CHECK( _stat( "valve/save/m1.sav", &st ) != 0, "given up: not asked again in this session" );
			zzhl_fs_peek_retry_stats( &t1, &c1, &l1 );
			CHECK( t1 == t0 + 12, "given up: no more requests for it" );
			/* three bad looks, then the disk answers: the save comes back in the same session */
			xacp_fs_test_new_session();
			g_corrupt_once = 9;                          /* three looks of three requests fail, the fourth look reads */
			seen = 0;
			for( k = 0; k < 3; k++ ) if( _stat( "valve/save/m1.sav", &st ) == 0 ) seen++;
			CHECK( !seen && g_corrupt_once == 0, "three looks at a header that does not read: the save is not there yet" );
			CHECK( _stat( "valve/save/m1.sav", &st ) == 0 && st.st_size == (off_t)sizeof( sv ), "a save whose header failed three looks comes back when the disk answers" );
			g_corrupt_name[0] = 0;
			xacp_fs_test_new_session();
		}
		for( i = 0; i < 4; i++ ) { char p[128]; snprintf( p, sizeof( p ), "tests/data/%s", olds[i] ); unlink( p ); }
		xacp_fs_test_new_session();
	}
	{   /* a .cfg over the engine's command buffer must be REFUSED, not served.
	       Cmd_ExecScript() hands the whole file to Cbuf_InsertTextLen(); past MAX_CMD_BUFFER
	       (32768) that call fails and the file is not executed AT ALL - every bind of
	       config.cfg gone at once, while the small userconfig.cfg exec'd next still works.
	       That is the "keyboard gone but the cheats answer" of 13/11, 14/11 and 15/11. */
		static char big[40960];
		int seen;
		memset( big, 'x', sizeof( big ));
		memcpy( big, "bind w +forward\n", 16 );
		f = fopen( "tests/data/config.cfg", "wb" ); fwrite( big, 1, sizeof( big ), f ); fclose( f );
		xacp_fs_test_new_session();
		fd = _open( "valve/config.cfg", O_RDONLY, 0 );
		CHECK( fd < 0, "a 40 KiB config.cfg is refused, not served to the engine" );
		if( fd >= 3 ) _close( fd );
		CHECK( _stat( "valve/config.cfg", &st ) != 0,
		       "the refused config is absent from stat, so the engine falls through to pak0" );
		seen = 0;
		d = opendir( "valve" );
		while( d && ( e = readdir( d ))) if( !strcmp( e->d_name, "config.cfg" )) seen = 1;
		if( d ) closedir( d );
		CHECK( !seen, "the refused config leaves the directory listing (FS_FixFileCase)" );
		/* the refusal must never become permanent: the engine's next write replaces it */
		fd = _open( "valve/config.cfg", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		CHECK( fd >= 3 && _write( fd, "bind a +left\n", 13 ) == 13, "a good config can still be written over the refused one" );
		if( fd >= 3 ) _close( fd );
		CHECK( _stat( "valve/config.cfg", &st ) == 0 && st.st_size == 13, "the good config is served again at once" );
		/* the boundary: just under the cap is still served, or we would break real configs */
		f = fopen( "tests/data/config.cfg", "wb" ); fwrite( big, 1, 24u * 1024u - 1u, f ); fclose( f );
		xacp_fs_test_new_session();
		fd = _open( "valve/config.cfg", O_RDONLY, 0 );
		CHECK( fd >= 3, "a config just under the cap is still served" );
		if( fd >= 3 ) _close( fd );
		f = fopen( "tests/data/config.cfg", "wb" ); fputs( "bind a +left\n", f ); fclose( f );
		xacp_fs_test_new_session();
	}
	{   /* the save thumbnails are deflated, like the saves since build 75.
	       VID_MINISHOT writes a 267x200 BMP in 32 bits (cl_scrn.c:438) = 209 KiB uncompressed,
	       and at the 479 KiB/s measured on the A4000 that blocks the frame 350-385 ms each time.
	       Two things must hold: the disk file is SMALLER than the picture, and what comes back
	       is the picture BYTE FOR BYTE - a thumbnail served wrong is worse than no thumbnail. */
		static unsigned char shot[209000], back[209000];
		unsigned u;
		long disk;
		for( u = 0; u < sizeof( shot ); u++ )          /* BMP-like: long runs, some noise */
			shot[u] = (unsigned char)(( u / 97u ) ^ ( u & 3u ));
		/* the save first, as the engine does: shot_get only serves the picture of a save that is
		   in the index (idx_find), which is what keeps a stray .bmp from being handed out. */
		fd = _open( "valve/save/quick.sav", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		if( fd >= 3 ) { _write( fd, shot, 3000 ); _close( fd ); }
		fd = _open( "valve/save/quick.bmp", O_WRONLY | O_CREAT | O_TRUNC, 0666 );
		CHECK( fd >= 3 && _write( fd, shot, sizeof( shot )) == (int)sizeof( shot ), "thumbnail written" );
		if( fd >= 3 ) _close( fd );
		f = fopen( "tests/data/hlsv_quick.bmp", "rb" );
		disk = -1; if( f ) { fseek( f, 0, SEEK_END ); disk = ftell( f ); fclose( f ); }
		printf( "   thumbnail: %d bytes -> %ld on the disk\n", (int)sizeof( shot ), disk );
		CHECK( disk > 0 && disk < (long)sizeof( shot ), "thumbnail deflated: the disk file is smaller than the picture" );
		xacp_fs_test_new_session();
		fd = _open( "valve/save/quick.bmp", O_RDONLY, 0 );
		memset( back, 0, sizeof( back ));
		n = fd >= 3 ? _read( fd, back, sizeof( back )) : -1;
		if( fd >= 3 ) _close( fd );
		CHECK( n == (int)sizeof( shot ) && !memcmp( back, shot, sizeof( shot )),
		       "thumbnail inflated: read back byte for byte" );
		/* a .bmp written before build 83 has no header and must still be served as it is */
		f = fopen( "tests/data/hlsv_quick.bmp", "wb" ); fwrite( shot, 1, 4096, f ); fclose( f );
		xacp_fs_test_new_session();
		fd = _open( "valve/save/quick.bmp", O_RDONLY, 0 );
		memset( back, 0, sizeof( back ));
		n = fd >= 3 ? _read( fd, back, sizeof( back )) : -1;
		if( fd >= 3 ) _close( fd );
		CHECK( n == 4096 && !memcmp( back, shot, 4096 ),
		       "an old uncompressed thumbnail is still served unchanged" );
		unlink( "tests/data/hlsv_quick.bmp" );
		xacp_fs_test_new_session();
	}
	printf( "%s\n", fails ? "SOME TESTS FAILED" : "ALL TESTS PASSED" );
	return fails ? 1 : 0;
}
