/* test_rixwalk.c - the model of the rasteriser's edge walker
 * (librixgpu/rix_walk_model.h) against what the A4000 measured.
 *
 * The price list of build 86 (15/11, 22 h, GPU.log) timed eight batches of triangles: 2000 of 8 px
 * a side, 2000 of 32 px, and six shapes of the same surface (1024 px), 500 of each.  Here the very
 * same triangles are drawn through the real ZZGL and the real descriptor builder, compiled for the
 * PC; the descriptors that would go to the GPU are handed to the model, which counts the walker's
 * clocks.  If the model is the rasteriser, ONE clock period and ONE fixed cost per triangle must
 * turn its counts into the eight measured times.  They are fitted by least squares and every case
 * must then fall within 12 % of its measurement.
 * (The six shapes and their order are those of Core1/zzhl_gpu.c, gb_shape; if they change there,
 * change them here and measure again.)
 * Build and run: tests/run_host_tests.sh
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "rixgpu.h"
#include "rixframe.h"
#include "rixtex.h"
#include "zzgl.h"
#include "rix_walk_model.h"

static int fails;
static void ok(int cond, const char *what) { if (cond) printf("ok   %s\n", what); else { printf("FAIL %s\n", what); fails++; } }

/* ---- the frame library, reduced to "what triangle was sent" ---- */
static u32 f_now;
static unsigned char f_mem[1 << 20];
static rix_walk_t f_sum;
static u32 f_tris;
u32 rix_geo_w = 640u, rix_geo_h_alloc = 481u;
int zzgl_test_force_busy;
void *sim_ptr(u32 a) { return f_mem + (a & 0xFFFFFu); }
void sim_barrier(void) { }
u32 rix_now(void) { return ++f_now; }
u32 rix_ticks_to_us(u32 dt) { return dt; }
void rix_mem_clean(u32 a, u32 b) { (void)a; (void)b; }
int rix_frame_begin(rix_frame *f, const rix_frame_desc *d) { (void)f; (void)d; return 0; }
int rix_frame_tri(rix_frame *f, const u32 *d)
{
    rix_walk_t w;
    (void)f;
    rix_walk(d, 640u, 481u, &w);
    f_sum.clocks += w.clocks; f_sum.pixels += w.pixels; f_sum.lines += w.lines; f_sum.empty += w.empty; f_sum.far_clocks += w.far_clocks;
    f_tris++;
    return 0;
}
int rix_frame_clear(rix_frame *f, int color, u32 rgba, int depth, u32 d16, u32 x0, u32 y0, u32 x1, u32 y1)
{ (void)f; (void)color; (void)rgba; (void)depth; (void)d16; (void)x0; (void)y0; (void)x1; (void)y1; return 0; }
int rix_frame_reg(rix_frame *f, u32 r, u32 v) { (void)f; (void)r; (void)v; return 0; }
int rix_frame_features(rix_frame *f, u32 v) { (void)f; (void)v; return 0; }
int rix_frame_fragment(rix_frame *f, u32 v) { (void)f; (void)v; return 0; }
int rix_frame_scissor(rix_frame *f, u32 a, u32 b, u32 c, u32 d) { (void)f; (void)a; (void)b; (void)c; (void)d; return 0; }
int rix_frame_texture(rix_frame *f, const rix_texture *t) { (void)f; (void)t; return 0; }
void rix_frame_texture_invalidate(u32 b) { (void)b; }
int rix_frame_end(rix_frame *f, u32 v) { (void)f; (void)v; return 0; }
void rix_frame_set_deferred(int on) { (void)on; }
int rix_frame_deferred(void) { return 0; }
int rix_frame_pump(rix_frame *f) { (void)f; return 0; }
u32 rix_frame_last_bind_seq(void) { return 0u; }
int rix_frame_flush(rix_frame *f) { (void)f; return 0; }
int rix_frame_bind_passed(rix_frame *f, u32 s) { (void)f; (void)s; return 1; }
int rix_frame_drain(rix_frame *f) { (void)f; return 0; }
void rix_frame_set_pipelined(int on) { (void)on; }
int rix_frame_pipelined(void) { return 0; }
int rix_frame_pending(void) { return 0; }
void rix_frame_set_phase(u32 ph) { (void)ph; }
u32 rix_fragment(u32 df, int dw, u32 af, u32 ar, u32 bs, u32 bd) { return (df & 7u) | (dw ? 8u : 0u) | (af << 4) | (ar << 8) | (bs << 16) | (bd << 20) | 0x80000000u; }
int rix_texpool_init(u32 b, u32 p, int c) { (void)b; (void)p; (void)c; return 0; }
u32 rix_texpool_largest_free(void) { return 1000u; }
int rix_tex_alloc(rix_texture *t, u32 w, u32 h, int l) { (void)t; (void)w; (void)h; (void)l; return -1; }
void rix_tex_free(rix_texture *t) { (void)t; }
void rix_tex_write_rgb565(const rix_texture *t, const u16 *s, int b) { (void)t; (void)s; (void)b; }
void rix_tex_write_rect_rgb565(const rix_texture *t, u32 x, u32 y, u32 w, u32 h, const u16 *s, int b) { (void)t; (void)x; (void)y; (void)w; (void)h; (void)s; (void)b; }

/* ---- the triangles of the price list, as Core1/zzhl_gpu.c draws them ---- */
static void gb_tris(u32 n, u32 side)
{
    u32 i, cols = 640u / (side + 2u), open = 0u;
    for (i = 0; i < n; i++) {
        float x = (float)((i % cols) * (side + 2u)), y = (float)(((i / cols) % (480u / (side + 2u))) * (side + 2u));
        if (!open) { zzglBegin(ZGL_TRIANGLES); open = 1u; }
        zzglVertex3f(x, y, 0.0f); zzglVertex3f(x + (float)side, y, 0.0f); zzglVertex3f(x, y + (float)side, 0.0f);
        if ((i % 20u) == 19u) { zzglEnd(); open = 0u; }
    }
    if (open) zzglEnd();
}
static const float gb_shape[6][6] = {
    {   0.0f, 0.0f,  32.0f, 0.0f,   0.0f,  64.0f },
    {   0.0f, 0.0f,  32.0f, 0.0f,  32.0f,  64.0f },
    {   0.0f, 0.0f, 256.0f, 0.0f,   0.0f,   8.0f },
    {   0.0f, 0.0f,   8.0f, 0.0f,   0.0f, 256.0f },
    {   0.0f, 0.0f,   8.0f, 0.0f, 264.0f, 256.0f },
    { 256.0f, 0.0f, 264.0f, 0.0f,   0.0f, 256.0f } };
static const u32 gb_shape_box[6][2] = { { 32u, 64u }, { 32u, 64u }, { 256u, 8u }, { 8u, 256u }, { 264u, 256u }, { 264u, 256u } };
static void gb_shapes(u32 s)
{
    const float *o = gb_shape[s];
    u32 i, bw = gb_shape_box[s][0] + 2u, bh = gb_shape_box[s][1] + 2u, cols = 640u / bw, rows = 480u / bh, open = 0u;
    if (!cols) cols = 1u;
    if (!rows) rows = 1u;
    for (i = 0; i < 500u; i++) {
        float x = (float)((i % cols) * bw), y = (float)(((i / cols) % rows) * bh);
        if (!open) { zzglBegin(ZGL_TRIANGLES); open = 1u; }
        zzglVertex3f(x + o[0], y + o[1], 0.0f); zzglVertex3f(x + o[2], y + o[3], 0.0f); zzglVertex3f(x + o[4], y + o[5], 0.0f);
        if ((i % 20u) == 19u) { zzglEnd(); open = 0u; }
    }
    if (open) zzglEnd();
}
static void quads(u32 layers)
{
    u32 k;
    for (k = 0; k < layers; k++) {
        zzglBegin(ZGL_QUADS);
        zzglVertex3f(0.0f, 0.0f, 0.0f); zzglVertex3f(640.0f, 0.0f, 0.0f); zzglVertex3f(640.0f, 480.0f, 0.0f); zzglVertex3f(0.0f, 480.0f, 0.0f);
        zzglEnd();
    }
}

/* what the A4000 measured (build 86, GPU.log of 15/11): us for the whole batch, clears taken off */
typedef struct { const char *name; u32 n; double us; rix_walk_t w; u32 tris; } mcase;
static mcase g_case[] = {
    { "r 2000 triangles of 8 px a side          ", 2000u, 10841.0 - 6247.0, { 0 }, 0u },
    { "s 2000 triangles of 32 px a side         ", 2000u, 23498.0 - 6247.0, { 0 }, 0u },
    { "v 500 right-angled 32x64, left           ",  500u, 14275.0 - 6247.0, { 0 }, 0u },
    { "w 500 right-angled 32x64, right          ",  500u, 15319.0 - 6247.0, { 0 }, 0u },
    { "x 500 flat 256x8                         ",  500u, 14963.0 - 6247.0, { 0 }, 0u },
    { "y 500 standing 8x256                     ",  500u, 18694.0 - 6247.0, { 0 }, 0u },
    { "z 500 diagonal sliver, box 264x256       ",  500u, 29605.0 - 6247.0, { 0 }, 0u },
    { "A 500 the same, leaning back             ",  500u, 97779.0 - 6247.0, { 0 }, 0u },
    { "d 4 full-screen layers (8 triangles)     ",    8u, 18964.0 - 6247.0, { 0 }, 0u } };
#define NCASE (sizeof g_case / sizeof g_case[0])

/* ---- rix_box_fit (librixgpu/rixdesc.c).  The box is cut to the lines that hold a pixel:
   the GPU must draw EXACTLY the same pixels, in fewer clocks.  40 000 random triangles of every
   kind - compact, slivers, a pixel wide, between two lines - each built in the three modes and
   walked by the model; the set of pixels drawn is compared through its signature. */
#include "rixdesc.h"
static u32 rs = 2463534242u;
static u32 rnd(void) { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return rs; }
static float rf(float lo, float hi) { return lo + (hi - lo) * (float)(rnd() & 0xFFFFFFu) / 16777215.0f; }
static void rvert(rix_vertex *v, float x, float y)
{
    if (x < 0.0f) x = 0.0f; if (x > 639.0f) x = 639.0f;
    if (y < 0.0f) y = 0.0f; if (y > 479.0f) y = 479.0f;
    v->sx = x; v->sy = y; v->z = rf(0.0f, 1.0f); v->invw = rf(0.01f, 1.0f); v->u = rf(0.0f, 4.0f); v->v = rf(0.0f, 4.0f);
    v->r = rf(0.0f, 1.0f); v->g = rf(0.0f, 1.0f); v->b = rf(0.0f, 1.0f); v->a = rf(0.0f, 1.0f);
}
static float fbits_f(u32 u) { union { float f; u32 u; } v; v.u = u; return v.f; }
static void boxfit_tests(void)
{
    u32 n, sent0 = 0u, same1 = 0u, same2 = 0u, bits1 = 0u, dropped_ok = 0u, dropped = 0u, plane_ok = 0u, plane_n = 0u, fewer1 = 0u, fewer2 = 0u, bad = 0u, plane_close = 0u;
    unsigned long long c0 = 0ull, c1 = 0ull, c2 = 0ull;
    for (n = 0; n < 40000u; n++) {
        rix_vertex a, b, c;
        u32 d0[RIX_TRI_DESC_WORDS], d1[RIX_TRI_DESC_WORDS], d2[RIX_TRI_DESC_WORDS];
        rix_walk_t w0, w1, w2;
        unsigned long long s0 = 0ull, s1 = 0ull, s2 = 0ull;
        const u32 kind = n % 5u;
        const float x = rf(0.0f, 639.0f), y = rf(0.0f, 479.0f);
        int r0, r1, r2;
        if (kind == 0u) { rvert(&a, rf(0, 639), rf(0, 479)); rvert(&b, rf(0, 639), rf(0, 479)); rvert(&c, rf(0, 639), rf(0, 479)); }            /* anything */
        else if (kind == 1u) { rvert(&a, x, y); rvert(&b, x + rf(-60, 60), y + rf(-60, 60)); rvert(&c, x + rf(-60, 60), y + rf(-60, 60)); }           /* compact */
        else if (kind == 2u) { const float dx = rf(-300, 300), dy = rf(-300, 300); rvert(&a, x, y); rvert(&b, x + dx, y + dy); rvert(&c, x + dx + rf(-6, 6), y + dy + rf(-6, 6)); }   /* a sliver */
        else if (kind == 3u) { rvert(&a, x, y); rvert(&b, x + rf(-2, 2), y + rf(-2, 2)); rvert(&c, x + rf(-2, 2), y + rf(-2, 2)); }                    /* a pixel or less */
        else { const float yy = (float)(int)y + rf(0.05f, 0.45f); rvert(&a, x, yy); rvert(&b, x + rf(-200, 200), yy + rf(0.0f, 0.4f)); rvert(&c, x + rf(-200, 200), yy + rf(0.0f, 0.4f)); }   /* between two lines */
        rix_box_fit = 0; r0 = rix_tri_desc(&a, &b, &c, d0);
        if (!r0) continue;
        sent0++;
        rix_walk_sig(d0, 640u, 481u, &w0, &s0); c0 += w0.clocks;
        rix_box_fit = 1; r1 = rix_tri_desc(&a, &b, &c, d1);
        rix_box_fit = 2; r2 = rix_tri_desc(&a, &b, &c, d2);
        if (!r1 || !r2) {                              /* not sent: it must have drawn nothing, and both modes must agree */
            dropped++;
            if (!r1 && !r2 && w0.pixels == 0u) dropped_ok++; else bad++;
            continue;
        }
        rix_walk_sig(d1, 640u, 481u, &w1, &s1); c1 += w1.clocks;
        rix_walk_sig(d2, 640u, 481u, &w2, &s2); c2 += w2.clocks;
        if (w1.pixels == w0.pixels && s1 == s0) same1++; else bad++;
        if (w2.pixels == w0.pixels && s2 == s0) same2++; else bad++;
        if (w1.clocks <= w0.clocks) fewer1++;
        if (w2.clocks <= w1.clocks) fewer2++;
        if (d1[1] == d0[1] && !memcmp(d1 + 3, d0 + 3, (RIX_TRI_DESC_WORDS - 3u) * sizeof(u32)) && (d1[2] & 0xFFFFu) == (d0[2] & 0xFFFFu) && (d1[2] >> 16) <= (d0[2] >> 16)) bits1++;
        {   /* mode 2: every plane at the new start = the mode 0 plane moved up by the lines taken off */
            const s32 up = (s32)(d2[1] >> 16) - (s32)(d0[1] >> 16);
            static const u32 base[9] = { 12u, 13u, 14u, 15u, 24u, 25u, 30u, 31u, 32u }, step[9] = { 8u, 8u, 8u, 8u, 4u, 4u, 6u, 6u, 6u };
            u32 q, good = 1u, close = 1u;
            for (q = 0; q < 9u; q++) {
                const double v0 = (double)fbits_f(d0[base[q]]), vy = (double)fbits_f(d0[base[q] + step[q]]), want = v0 + (double)up * vy, got = (double)fbits_f(d2[base[q]]);
                /* both starts are sums of three products by weights that grow as the triangle thins: on a
                   sliver the float rounding of either reaches 1e-4 of the value's range (0..1 for a colour
                   or a depth), which is the size of the difference allowed here; on the others, 1e-4 of
                   the value */
                const double tol = 1e-4 * (fabs(v0) + fabs((double)up * vy) + fabs(want)) + 1e-6;
                if (fabs(got - want) > tol) { close = 0u; if (getenv("RIXWALK_V")) printf("     tri %u plane %u: mode 0 start %g + %d lines x %g = %g, mode 2 start %g; box %ux%u\n", n, q, v0, up, vy, want, got,
                    (d0[2] & 0xFFFFu) - (d0[1] & 0xFFFFu), (d0[2] >> 16) - (d0[1] >> 16)); }
                if (fabs(got - want) > 1e-3 * (1.0 + fabs(want))) good = 0u;
                if (d2[base[q] + step[q]] != d0[base[q] + step[q]] || d2[base[q] + step[q] / 2u] != d0[base[q] + step[q] / 2u]) good = 0u;     /* the gradients do not move */
            }
            plane_n++; if (good) plane_ok++; if (close) plane_close++;
        }
    }
    rix_box_fit = 0;
    printf("     %u triangles sent in mode 0; mode 1 and 2 drop %u that draw nothing; clocks %llu -> %llu (mode 1) -> %llu (mode 2)\n", sent0, dropped, c0, c1, c2);
    ok(sent0 > 30000u && dropped > 500u, "the random triangles cover the cases (sent, and some that draw nothing)");
    ok(bad == 0u && same1 == sent0 - dropped && same2 == sent0 - dropped, "BOXFIT 1 and 2: exactly the same pixels drawn as without, for every triangle");
    ok(dropped_ok == dropped, "a triangle that is not sent any more drew no pixel, and both modes drop the same ones");
    ok(bits1 == sent0 - dropped, "BOXFIT=1: only the end line of the box changes - same start, same edge values, same planes, bit for bit");
    ok(plane_ok == plane_n && plane_close * 1000u >= plane_n * 999u,
       "BOXFIT=2: colour, depth and texture at the new start are the old planes moved up by the lines taken off (to float rounding: 1e-4 of the value for 999 in 1000, 1e-3 for all); the gradients are the same bits");
    if (plane_ok != plane_n || plane_close != plane_n) printf("     within 1e-3: %u of %u, within 1e-4: %u\n", plane_ok, plane_n, plane_close);
    ok(fewer1 == sent0 - dropped && fewer2 == sent0 - dropped && c2 < c1 && c1 < c0, "and never more clocks: mode 1 <= mode 0, mode 2 <= mode 1, for every triangle");
}

int main(void)
{
    zzgl_config gc;
    u32 i;
    double sxx = 0.0, sxy = 0.0, sxz = 0.0, syy = 0.0, syz = 0.0, det, tclk, tfix, worst = 0.0;
    memset(&gc, 0, sizeof gc);
    gc.pool_base = 0x30400000u; gc.pool_pages = 64u; gc.zbuf = 0x30C80000u; gc.width = 640u; gc.height = 480u;
    ok(zzgl_init(&gc) == 0, "ZZGL starts");
    { zzgl_target t; t.color = 0x30000000u; t.fence = 1u; zzgl_set_target(&t); }
    zzglViewport(0, 0, 640, 480);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglDisable(ZGL_CULL_FACE); zzglDisable(ZGL_DEPTH_TEST); zzglDepthMask(0u);
    for (i = 0; i < NCASE; i++) {
        memset(&f_sum, 0, sizeof f_sum); f_tris = 0u;
        if (i == 0u) gb_tris(2000u, 8u);
        else if (i == 1u) gb_tris(2000u, 32u);
        else if (i < 8u) gb_shapes(i - 2u);
        else quads(4u);
        g_case[i].w = f_sum; g_case[i].tris = f_tris;
    }
    /* a triangle that touches the screen's edge is cut by ZZGL's screen clip into two: more descriptors than triangles, the same pixels */
    ok(g_case[0].tris >= 2000u && g_case[2].tris >= 500u && g_case[7].tris >= 500u && g_case[8].tris >= 8u, "every triangle of the price list reaches the model");
    /* the rasteriser keeps a pixel when its three edge values are >= 0, the edges included: a shape
       draws its surface give or take its outline (a thin sliver up to 12 % more or less) */
    for (i = 2; i < 8u; i++) if (!(g_case[i].w.pixels > 500u * 900u && g_case[i].w.pixels < 500u * 1150u)) break;
    ok(i == 8u, "the model draws about the 1024 pixels of each of the six shapes");
    if (i != 8u) printf("     case %u: %u pixels for 500 triangles\n", i, g_case[i].w.pixels);
    ok(g_case[8].w.pixels == 4u * 640u * 480u, "and exactly 640 x 480 pixels for a full-screen layer");
    /* us = tclk * clocks + tfix * triangles, least squares over the eight batches of triangles (the
       full-screen layers are kept out of the fit and predicted from it) */
    for (i = 0; i + 1u < NCASE; i++) {
        double x = (double)g_case[i].w.clocks, y = (double)g_case[i].tris, z = g_case[i].us;
        sxx += x * x; sxy += x * y; sxz += x * z; syy += y * y; syz += y * z;
    }
    det = sxx * syy - sxy * sxy;
    tclk = (sxz * syy - syz * sxy) / det; tfix = (sxx * syz - sxy * sxz) / det;
    printf("     fitted: %.2f ns a clock (%.1f MHz), %.0f ns fixed per triangle\n", tclk * 1000.0, 1000.0 / (tclk * 1000.0), tfix * 1000.0);
    printf("     case                                        clocks/tri  pixels  lines  empty  far clocks | model us/tri  A4000 us/tri   diff\n");
    for (i = 0; i < NCASE; i++) {
        const mcase *c = &g_case[i];
        double n = (double)c->tris, model = (tclk * (double)c->w.clocks + tfix * n) / n, meas = c->us / n, diff = (model - meas) / meas * 100.0;
        printf("     %s %9.0f %7.0f %6.1f %6.1f %10.0f | %12.2f %13.2f %+6.1f %%\n", c->name, (double)c->w.clocks / n, (double)c->w.pixels / n,
               (double)c->w.lines / n, (double)c->w.empty / n, (double)c->w.far_clocks / n, model, meas, diff);
        if (fabs(diff) > worst) worst = fabs(diff);
    }
    ok(tclk * 1000.0 > 9.0 && tclk * 1000.0 < 11.5, "one clock of the walker comes out between 9 and 11.5 ns");
    ok(worst < 12.0, "every measured case within 12 % of the model");
    ok(g_case[7].w.far_clocks > 20u * g_case[6].w.far_clocks / 10u && g_case[7].w.far_clocks > g_case[7].w.clocks / 2u,
       "the sliver that leans back spends most of its clocks running to the end of its box and back");
    {   /* what the model expects of the price list with the boxes fitted: to be set against the A4000's
           price list run with BOXFIT=1 and BOXFIT=2 (the same cases, the same order) */
        int mode;
        printf("     the price list by the model with BOXFIT (us per descriptor of mode 0; descriptors sent):\n");
        printf("     case                                        BOXFIT=0      BOXFIT=1               BOXFIT=2\n");
        for (i = 0; i < NCASE; i++) {
            const mcase *c = &g_case[i];
            double n = (double)c->tris, us[3]; u32 sent[3];
            us[0] = (tclk * (double)c->w.clocks + tfix * n) / n; sent[0] = c->tris;
            for (mode = 1; mode <= 2; mode++) {
                rix_box_fit = mode; memset(&f_sum, 0, sizeof f_sum); f_tris = 0u;
                if (i == 0u) gb_tris(2000u, 8u);
                else if (i == 1u) gb_tris(2000u, 32u);
                else if (i < 8u) gb_shapes(i - 2u);
                else quads(4u);
                us[mode] = (tclk * (double)f_sum.clocks + tfix * (double)f_tris) / n; sent[mode] = f_tris;
                if (f_sum.pixels != c->w.pixels) { printf("FAIL case %u mode %d: %u pixels, %u without BOXFIT\n", i, mode, f_sum.pixels, c->w.pixels); fails++; }
            }
            rix_box_fit = 0;
            printf("     %s %8.2f  %8.2f (%+5.1f %%, %5u)  %8.2f (%+5.1f %%, %5u)\n", c->name, us[0], us[1], (us[1] - us[0]) / us[0] * 100.0, sent[1], us[2], (us[2] - us[0]) / us[0] * 100.0, sent[2]);
        }
        ok(1, "the price list drawn with BOXFIT=1 and 2: the same pixels in every case");
    }
    boxfit_tests();
    printf(fails ? "RIXWALK TESTS FAILED (%d)\n" : "RIXWALK ALL TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
