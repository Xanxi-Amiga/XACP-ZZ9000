#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# test_zzhl_ref.py - ZZHalfLife: tools/zzhl_data.py's check of an install against the reference
# (tools/zzhl_ref.py, made by tools/make_zzhl_ref.py).  Run by tests/run_host_tests.sh.
# ASCII only.
import hashlib, os, struct, sys, tempfile, types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'tools'))
import zzhl_data, hl_paklist

fails = 0
def check(what, ok, detail=''):
    global fails
    if ok: print('ok   ' + what)
    else: print('FAIL ' + what + (': ' + str(detail) if detail else '')); fails += 1

def md5(b): return hashlib.md5(b).hexdigest()

def write_pak(path, files):
    with open(path, 'wb') as o:
        o.write(b'PACK' + b'\0' * 8); pos = 12; d = []
        for name, data in files:
            o.write(data); d.append((name, pos, len(data))); pos += len(data)
        for name, ofs, size in d: o.write(name.encode('latin-1').ljust(56, b'\0') + struct.pack('<II', ofs, size))
        o.seek(4); o.write(struct.pack('<II', pos, len(d) * 64))

# 1. what kind of file
for name, want in (('config.cfg', 'personal'), ('CONFIG.CFG', 'personal'), ('tempdecal.wad', 'personal'),
                   ('custom.hpk', 'personal'), ('voice_ban.dt', 'personal'), ('autoexec.cfg', 'personal'),
                   ('models/player/remapped.bmp', 'personal'), ('Maps/Graphs/hldemo1.NRP', 'personal'),
                   ('mapcycle.txt', 'personal'), ('server.cfg', 'personal'), ('listenserver.cfg', 'personal'),
                   ('user.scr', 'personal'), ('settings.scr', 'personal'), ('steam_autocloud.vdf', 'personal'),
                   ('spserver.cfg', 'game'), ('steam.inf', 'game'),
                   ('maps/graphs/c1a0.nod', 'graph'), ('maps/graphs/hldemo2.nod', 'graph'),
                   ('maps/c1a0.bsp', 'game'), ('default.cfg', 'game'), ('skill.cfg', 'game'),
                   ('models/player/gman/gman.bmp', 'game'), ('gfx/vgui/fonts/1024_Briefing Text.tga', 'game'),
                   ('halflife.wad', 'game'), ('maps/hldemo1_load.cfg', 'game')):
    check('kind of %s: %s' % (name, want), zzhl_data.kind_of(name) == want, zzhl_data.kind_of(name))

# 2. compare
ref = {'a.txt': ('a.txt', 3, md5(b'aaa')), 'maps/b.bsp': ('maps/b.bsp', 4, md5(b'bbbb')),
       'gone.wav': ('gone.wav', 1, md5(b'g')), 'maps/graphs/b.nod': ('maps/graphs/b.nod', 2, md5(b'nn')),
       'maps/graphs/c.nod': ('maps/graphs/c.nod', 2, md5(b'cc')), 'sound/x y.wav': ('sound/x y.wav', 2, md5(b'xy'))}
members = [('A.TXT', 3, md5(b'aaa')), ('maps/b.bsp', 4, md5(b'bbbX')), ('mine.bsp', 5, md5(b'mmmmm')),
           ('config.cfg', 9, md5(b'whatever!')), ('maps/graphs/b.nod', 2, md5(b'NN')),
           ('maps/graphs/mine.nod', 1, md5(b'm')), ('sound/x y.wav', 2, md5(b'xy'))]
r = zzhl_data.compare(members, ref)
check('compare: the same whatever the case of the name, a name with a space', sorted(r['game']['same']) == ['A.TXT', 'sound/x y.wav'], r['game']['same'])
check('compare: same size, other content: different', [d[0] for d in r['game']['different']] == ['maps/b.bsp'], r['game']['different'])
check('compare: of the reference, not here: missing', [d[0] for d in r['game']['missing']] == ['gone.wav'], r['game']['missing'])
check('compare: here, not in the reference: extra', [d[0] for d in r['game']['extra']] == ['mine.bsp'], r['game']['extra'])
check('compare: personal files counted, never compared', r['personal'] == ['config.cfg'], r['personal'])
check('compare: node graphs apart', ([d[0] for d in r['graph']['different']], [d[0] for d in r['graph']['missing']], [d[0] for d in r['graph']['extra']])
      == (['maps/graphs/b.nod'], ['maps/graphs/c.nod'], ['maps/graphs/mine.nod']), r['graph'])

# 3. the reference of the repository
mod, real = zzhl_data.load_reference()
check('tools/zzhl_ref.py loads', mod is not None and real is not None)
if real:
    check('its count is the number of its lines', mod.REF_COUNT == len(real), (mod.REF_COUNT, len(real)))
    check('no personal file in it', not [n for n in real if zzhl_data.kind_of(n) == 'personal'])
    check('every entry: a 32 character fingerprint and a size', all(len(v[2]) == 32 and v[1] >= 0 for v in real.values()))
    check('the campaign and Uplink maps are in it', all('maps/%s.bsp' % m in real for m in ('c0a0', 'c1a0', 'c5a1', 'hldemo1')))
    check('the other files: pak1.pak, the loading screen, 27 tracks',
          'pak1.pak' in mod.REF_FILES and 'zzhl_loadscreen.tga' in mod.REF_FILES and len([k for k in mod.REF_FILES if k.startswith('music/track')]) == 27, sorted(mod.REF_FILES)[:4])
    whole = [(v[0], v[1], v[2]) for v in real.values()]
    rr = zzhl_data.compare(whole, real)
    check('the reference against itself: all the same', not rr['game']['different'] and not rr['game']['missing'] and not rr['game']['extra']
          and len(rr['game']['same']) + len(rr['graph']['same']) == len(real))

# 3b. 17/11, the first report from another PC: mapcycle.txt, server.cfg and user.scr differed, Steam's
#     cloud marker was absent - 3 873 game files and 95 graphs the same.  That install is the same game.
if real:
    theirs = [(v[0], v[1], v[2]) for v in real.values()] + [('mapcycle.txt', 85, md5(b'm')), ('server.cfg', 582, md5(b's')), ('user.scr', 1054, md5(b'u'))]
    rr = zzhl_data.compare(theirs, real)
    check('the tester\'s install: its server files and options are personal, the game files are the same',
          not rr['game']['different'] and not rr['game']['missing'] and not rr['game']['extra'] and sorted(rr['personal']) == ['mapcycle.txt', 'server.cfg', 'user.scr']
          and 'steam_autocloud.vdf' not in real and 'mapcycle.txt' not in real, (rr['game']['different'][:3], rr['game']['missing'][:3], rr['personal']))

# 3c. 17/11: the tool on C:, Half-Life in a Steam library on F: - os.path.commonpath raises there
import ntpath, posixpath
W = ntpath
check('two drives: the output folder is not inside Half-Life, and nothing is raised',
      zzhl_data.inside('C:\\Users\\steve\\Desktop\\ZZHalfLife\\ZZHalfLife_data', 'F:\\SteamLibrary\\steamapps\\common\\Half-Life\\valve', W) is False)
check('same drive, inside (whatever the case of the letters): refused',
      zzhl_data.inside('f:\\steamlibrary\\steamapps\\common\\half-life\\VALVE\\out', 'F:\\SteamLibrary\\steamapps\\common\\Half-Life\\valve', W) is True)
check('same drive, the folder itself: refused', zzhl_data.inside('F:\\HL\\valve', 'F:\\HL\\valve', W) is True)
check('same drive, next to it: accepted', zzhl_data.inside('F:\\HL\\valve2\\out', 'F:\\HL\\valve', W) is False and zzhl_data.inside('F:\\HL', 'F:\\HL\\valve', W) is False)
check('a network path against a drive: accepted, nothing raised', zzhl_data.inside('\\\\nas\\share\\out', 'C:\\HL\\valve', W) is False)
check('POSIX paths (macOS, Linux)', zzhl_data.inside('/home/a/hl/valve/out', '/home/a/hl/valve', posixpath) is True and zzhl_data.inside('/home/a/out', '/home/a/hl/valve', posixpath) is False)

# 4. the whole check on a small pak0.pak, with a small reference in place of the real one
tmp = tempfile.mkdtemp(prefix='zzhl_ref_')
data = os.path.join(tmp, 'data'); valve = os.path.join(tmp, 'valve')
os.makedirs(os.path.join(data, 'music')); os.makedirs(valve)
with open(os.path.join(valve, 'steam.inf'), 'w') as f: f.write('PatchVersion=1.2.3.4\r\nProductName=valve\r\n')
files = [('liblist.gam', b'game'), ('maps/hldemo1.bsp', b'BSP1'), ('maps/c1a0.bsp', b'BSP2'), ('maps/graphs/c1a0.nod', b'nod'),
         ('config.cfg', b'bind w +forward'), ('tempdecal.wad', b'spray')]
write_pak(os.path.join(data, 'pak0.pak'), files)
with open(os.path.join(data, 'pak1.pak'), 'wb') as f: f.write(b'menu')
with open(os.path.join(data, 'music', 'track02.mp3'), 'wb') as f: f.write(b'mp3')
check('hl_paklist.members: name, size, md5, by name', hl_paklist.members(os.path.join(data, 'pak0.pak'))[0] == ('config.cfg', 15, md5(b'bind w +forward')))
def fake(game):
    m = types.SimpleNamespace(REF_DATE='2026-01-01', REF_NOTE='test', REF_COUNT=len(game),
                              REF_FILES={'pak1.pak': (md5(b'menu'), 4), 'music/track02.mp3': (md5(b'other'), 5)})
    return m, {n.lower(): (n, len(d), md5(d)) for n, d in game}
said = []
zzhl_data.say = lambda msg='': said.append(msg)
same = [f for f in files if zzhl_data.kind_of(f[0]) != 'personal']
zzhl_data.load_reference = lambda: fake(same)
rep = zzhl_data.check_reference(valve, data, tmp)
txt = open(rep).read()
check('the same game files: the verdict says so', 'VERDICT: SAME GAME FILES as the reference.' in txt and any('SAME GAME FILES' in s for s in said), txt[:300])
check('the report: steam.inf, the counts, the personal files by name only',
      'Your steam.inf: PatchVersion=1.2.3.4 ProductName=valve' in txt and 'game files      : 3 the same, 0 different, 0 missing, 0 of yours' in txt
      and 'personal files  : 2' in txt and md5(b'bind w +forward') not in txt and md5(b'spray') not in txt, txt)
check('other music files do not change the verdict', '1 of 1 files differ' in txt)
check('Uplink without its node graph: the note', 'NOTE: no node graph for the Uplink map(s) hldemo1.' in txt, txt)
check('the report does not hold the path of the install', tmp not in txt)
zzhl_data.load_reference = lambda: fake([('liblist.gam', b'GAME'), ('maps/hldemo1.bsp', b'BSP1'), ('maps/c1a0.bsp', b'BSP2'),
                                         ('maps/graphs/c1a0.nod', b'NOD'), ('sound/gone.wav', b'w')])
txt = open(zzhl_data.check_reference(valve, data, tmp)).read()
check('another install: DIFFERENT, with the counts', 'VERDICT: DIFFERENT from the reference (1 different, 1 missing).' in txt, txt[:400])
check('a node graph of one\'s own is not a difference of the game', 'node graphs     : 0 the same, 1 different' in txt and 'game files      : 2 the same, 1 different, 1 missing' in txt, txt)
check('the lists: what differs, what is missing', '  liblist.gam  4 %s  /  4 %s' % (md5(b'game'), md5(b'GAME')) in txt and '  sound/gone.wav  1' in txt, txt)
zzhl_data.load_reference = lambda: (None, None)
check('without a reference: nothing compared, no report', zzhl_data.check_reference(valve, data, tmp) is None)

print('ALL TESTS PASSED' if not fails else '%d TEST(S) FAILED' % fails)
sys.exit(1 if fails else 0)
