#!/usr/bin/env python3
# test_hl_loading.py - ZZHalfLife host test of tools/hl_loading.py (build 25), on a made-up Steam
# tree: nothing of Valve is in it, only the file formats and the names of the 25th anniversary
# update (resource/background/21_9_<row>_<col>_loading.tga, 15 x 7 tiles, the last row 64 high;
# Steam's black 800_ set and its layout file; resource/logo.tga with the shape in the alpha, here
# in a pak0.pak to go through the pak reader). Each column of tiles has its own grey, so that the
# 4:3 crop and the scaling show. Leaves build/host/zzhl_loadscreen.tga for tests/test_loading.c.
#   python3 tests/test_hl_loading.py   (from run_host_tests.sh)
# ASCII only.
import os, shutil, struct, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL = os.path.join(HERE, '..', 'tools', 'hl_loading.py')
OUT = os.path.join(HERE, '..', 'build', 'host')
COLS = 'abcdefghijklmno'

def grey_of(ci, ri):
    return 20 + 10 * ci + 2 * ri

def tga(w, h, n, rows_top_first, desc=0, it=2):
    """uncompressed TGA, bottom line first unless desc has 0x20"""
    hdr = struct.pack('<BBBHHBHHHHBB', 0, 0, it, 0, 0, 0, 0, 0, w, h, 8 * n, desc)
    rows = rows_top_first if desc & 0x20 else rows_top_first[::-1]
    return hdr + b''.join(rows)

def make_tree(top, tiles=True, logo=True, hd_layout=True, hd_res='3840\t1600'):
    if os.path.isdir(top):
        shutil.rmtree(top)
    bg = os.path.join(top, 'valve', 'resource', 'background')
    os.makedirs(bg)
    if tiles:
        lay = ['// made up', 'resolution\t' + hd_res, '']
        for ri in range(7):
            h = 64 if ri == 6 else 256
            for ci, c in enumerate(COLS):
                v = grey_of(ci, ri)
                rows = [bytes((v, v, v)) * 256 for y in range(h)]
                open(os.path.join(bg, '21_9_%d_%c_loading.tga' % (ri + 1, c)), 'wb').write(tga(256, h, 3, rows))
                name = 'resource/background/21_9_%d_%c_loading' % (ri + 1, c)
                lay.append(('"%s" scaled %d %d' if ci % 2 else '%s\t\tfit\t\t%d\t%d') % (name, ci * 256, ri * 256))
        if hd_layout:
            open(os.path.join(top, 'valve', 'resource', 'HD_BackgroundLoadingLayout.txt'), 'w').write('\r\n'.join(lay) + '\r\n')
    lay = ['resolution\t800\t600']        # Steam's 800 set: black to the last pixel
    for r, h in ((1, 256), (2, 256), (3, 88)):
        for i, c in enumerate('abcd'):
            w = 32 if c == 'd' else 256
            open(os.path.join(bg, '800_%d_%c_loading.tga' % (r, c)), 'wb').write(tga(w, h, 3, [bytes(w * 3)] * h))
            lay.append('resource/background/800_%d_%c_loading.tga\t\tfit\t\t%d\t%d' % (r, c, i * 256, (r - 1) * 256))
    open(os.path.join(top, 'valve', 'resource', 'BackgroundLoadingLayout.txt'), 'w').write('\n'.join(lay) + '\n')
    if logo:   # 800 x 86, white, nine bars as letters on lines 19..65, in a pak0.pak
        rows = []
        for y in range(86):
            r = bytearray()
            for x in range(800):
                a = 255 if 19 <= y <= 65 and 13 <= x < 788 and (x - 13) % 90 < 30 else 0
                r += bytes((255, 255, 255, a))
            rows.append(bytes(r))
        data = tga(800, 86, 4, rows, desc=0x08)
        name = b'resource/logo.tga'
        d = struct.pack('<56sII', name, 12, len(data))
        open(os.path.join(top, 'valve', 'pak0.pak'), 'wb').write(b'PACK' + struct.pack('<II', 12 + len(data), 64) + data + d)

def run(*args):
    p = subprocess.run([sys.executable, '-I', TOOL] + list(args), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return p.returncode, p.stdout.decode('latin-1')

def read_out(path):
    d = open(path, 'rb').read()
    idl, it, w, h, bpp, desc = d[0], d[2], *struct.unpack('<HH', d[12:16]), d[16], d[17]
    return d, idl, it, w, h, bpp, desc, d[18 + idl:]

def main():
    fails = 0
    def check(ok, what):
        nonlocal fails
        print(('ok: ' if ok else 'FAIL: ') + what)
        if not ok: fails += 1
    os.makedirs(OUT, exist_ok=True)
    top = os.path.join(OUT, 'fake_hl25')
    tga_out = os.path.join(OUT, 'zzhl_loadscreen.tga')
    bmp_out = os.path.join(OUT, 'zzhl_loadscreen_preview.bmp')
    make_tree(top)
    rc, log = run('-p', bmp_out, top, tga_out)       # the Half-Life folder: valve/ is found
    print('   ' + log.strip().replace('\n', '\n   '))
    check(rc == 0, 'hl_loading.py ran')
    check('hd_backgroundloadinglayout.txt: 105 tiles, middle 2133 x 1600' in log, 'HD layout file used, middle 4:3 part')
    d, idl, it, w, h, bpp, desc, px = read_out(tga_out)
    check((it, w, h, bpp, desc & 0x20) == (3, 640, 480, 8, 0x20) and len(px) == 640 * 480, 'grey TGA 640 x 480, top line first')
    check(len(d) < 512 * 1024, 'under the 512 KiB of the file service (%d bytes)' % len(d))
    check(b'42%' in d[18:18 + idl], 'the logo line (42 %) in the TGA comment')
    # x 0 is source x 853..856 (column d), x 639 is 2983..2986 (column l); line 400 is source 1333..1336 (row 6)
    check(abs(px[400 * 640] - grey_of(3, 5)) <= 1 and abs(px[400 * 640 + 639] - grey_of(11, 5)) <= 1,
          'crop and scale: left %d (%d), right %d (%d)' % (px[400 * 640], grey_of(3, 5), px[400 * 640 + 639], grey_of(11, 5)))
    # the 64-high last row: lines 461..479 come from source 1536..1599
    check(abs(px[475 * 640 + 320] - grey_of(7, 6)) <= 1, 'the 64-high last row in place (%d, %d)' % (px[475 * 640 + 320], grey_of(7, 6)))
    rows = [y for y in range(480) if max(px[y * 640:(y + 1) * 640]) >= 230]
    check(rows and rows[-1] == 480 * 42 // 100, 'logo letters end on line %d (%s)' % (480 * 42 // 100, rows[-1] if rows else None))
    check(rows and rows[0] > 480 * 42 // 100 - 40, 'logo 33 lines high (%s..%s)' % (rows[0] if rows else None, rows[-1] if rows else None))
    lit = [x for x in range(640) if px[190 * 640 + x] >= 230]
    check(lit and abs((lit[0] + lit[-1]) / 2 - 319.5) <= 2, 'logo centred (%s..%s)' % (lit[0] if lit else None, lit[-1] if lit else None))
    check(all(px[240 * 640 + x] < 140 for x in range(640)), 'nothing of the logo or glow 38 lines under it')
    check(px[205 * 640 + 60] > grey_of(4, 3) + 5, 'glow under the letters (%d)' % px[205 * 640 + 60])
    b = open(bmp_out, 'rb').read()
    check(b[:2] == b'BM' and struct.unpack('<ii', b[18:26]) == (640, 480) and b[54 + 3 * (479 * 640)] == px[0], 'preview BMP, same picture')
    # --gain doubles the background
    rc, log = run('--gain', '2', os.path.join(top, 'valve'), os.path.join(OUT, 'g2.tga'))
    px2 = read_out(os.path.join(OUT, 'g2.tga'))[7]
    check(rc == 0 and abs(px2[400 * 640] - 2 * grey_of(3, 5)) <= 2, '--gain 2 (%d)' % px2[400 * 640])
    # without the HD layout file: the 21_9 set by name, the same picture
    t2 = os.path.join(OUT, 'fake_hl25_names')
    make_tree(t2, hd_layout=False)
    rc, log = run(t2, os.path.join(OUT, 'n.tga'))
    pxn = read_out(os.path.join(OUT, 'n.tga'))[7]
    check(rc == 0 and '21_9_*_loading.tga: 105 tiles' in log and pxn == px, 'tiles found by name, same picture')
    check('resource/backgroundloadinglayout.txt: 12 tiles, 800 x 600, black - skipped' in log, 'black 800 set skipped')
    # an HD layout whose resolution does not match its tiles: the canvas grows to them, same picture
    make_tree(t2, hd_res='1920 800')
    rc, log = run(t2, os.path.join(OUT, 'r.tga'))
    pxr = read_out(os.path.join(OUT, 'r.tga'))[7]
    check(rc == 0 and 'past the 1920 x 800 given: 3840 x 1600 used' in log and pxr == px, 'layout resolution too small: canvas grown, same picture')
    # no tiles: the logo on black
    make_tree(t2, tiles=False)
    rc, log = run(t2, os.path.join(OUT, 'l.tga'))
    pxl = read_out(os.path.join(OUT, 'l.tga'))[7]
    check(rc == 0 and 'logo on black' in log and pxl[400 * 640] == 0 and max(pxl) >= 230, 'no tiles: logo on black')
    # neither: nothing written, said why
    make_tree(t2, tiles=False, logo=False)
    if os.path.exists(os.path.join(OUT, 'x.tga')): os.remove(os.path.join(OUT, 'x.tga'))
    rc, log = run(t2, os.path.join(OUT, 'x.tga'))
    check(rc == 1 and not os.path.exists(os.path.join(OUT, 'x.tga')) and 'nothing to make' in log, 'nothing in the install: nothing written')
    shutil.rmtree(t2)
    print('HL_LOADING %s' % ('SOME TESTS FAILED' if fails else 'ALL TESTS PASSED'))
    return 1 if fails else 0

if __name__ == '__main__':
    sys.exit(main())
