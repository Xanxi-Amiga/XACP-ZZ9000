/* SPDX-License-Identifier: GPL-3.0-or-later */
/* test_dropstat.c - Core1/zzhl_dropstat.h, the frames dropped at the
   presentation counted by the engine's pace.  Run by tests/run_host_tests.sh. */
#include <stdio.h>
#include <string.h>
#include "../Core1/zzhl_dropstat.h"

static int fails;
#define CHECK( c, msg ) do { if( !( c )) { printf( "FAIL: %s\n", msg ); fails++; } else printf( "ok: %s\n", msg ); } while( 0 )

static unsigned run( zzhl_dropstat_t *d, unsigned *t, unsigned iv, int n )
{
	unsigned m = 0;
	while( n-- > 0 ) { *t += iv; m = zzhl_dropstat_call( d, *t ); }
	return m;
}

int main( void )
{
	zzhl_dropstat_t d;
	unsigned t = 5000u, m;

	memset( &d, 0, sizeof( d ));
	m = zzhl_dropstat_call( &d, t );
	CHECK( m == 0u && zzhl_dropstat_class( m ) == 4u, "the first call: no pace yet, class 'not known'" );
	zzhl_dropstat_drop( &d, m );
	CHECK( d.dropped == 1u && d.by[4] == 1u, "a frame dropped then is counted as 'not known'" );

	m = run( &d, &t, 13889u, 20 );
	CHECK( m == 13889u && zzhl_dropstat_class( m ) == 0u, "72 frames a second: faster than the screen (class 0)" );
	zzhl_dropstat_drop( &d, m );
	CHECK( d.by[0] == 1u, "a frame dropped at that pace: the screen had no room for it" );

	m = run( &d, &t, 18000u, 8 );
	CHECK( m == 18000u && zzhl_dropstat_class( m ) == 1u, "eight frames at 18 ms: 50 to 60 a second (class 1), the older intervals have left the mean" );
	m = run( &d, &t, 22000u, 8 );
	CHECK( zzhl_dropstat_class( m ) == 2u, "22 ms: 40 to 50 a second (class 2)" );
	m = run( &d, &t, 33000u, 8 );
	CHECK( zzhl_dropstat_class( m ) == 3u, "33 ms: under 40 a second (class 3)" );

	{   /* the case the counter is there for: two presentations 10 ms apart, then 30 ms, and so on -
		   50 a second on average, yet one of each pair can find no buffer */
		int i;
		for( i = 0; i < 8; i++ ) { t += ( i & 1 ) ? 30000u : 10000u; m = zzhl_dropstat_call( &d, t ); }
		CHECK( m == 20000u && zzhl_dropstat_class( m ) == 2u, "10 ms then 30 ms in turn: the pace is 50 a second, not 100" );
		zzhl_dropstat_drop( &d, m );
		CHECK( d.by[2] == 1u, "a frame dropped there is one the screen had room for (class 2)" );
	}

	t += 5000000u; m = zzhl_dropstat_call( &d, t );
	CHECK( m == 0u, "five seconds without a frame (a load): the mean is emptied" );
	m = run( &d, &t, 16000u, 3 );
	CHECK( m == 16000u, "and built again from the frames that follow" );

	{   /* the microsecond counter wraps after 71 minutes */
		zzhl_dropstat_t w;
		unsigned tw = 0xFFFFFF00u;
		memset( &w, 0, sizeof( w ));
		zzhl_dropstat_call( &w, tw );
		tw += 20000u;                                   /* past zero */
		m = zzhl_dropstat_call( &w, tw );
		CHECK( tw < 0x1000u * 16u && m == 20000u, "the clock passing zero: the interval is still 20 ms" );
	}
	CHECK( d.calls == 1u + 20u + 8u + 8u + 8u + 8u + 1u + 3u && d.dropped == 3u, "calls and drops counted" );

	printf( fails ? "SOME TESTS FAILED\n" : "ALL TESTS PASSED\n" );
	return fails ? 1 : 0;
}
