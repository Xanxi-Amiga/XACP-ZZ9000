/* test_rixdesc.c - ZZHalfLife host test: the scalar rix_tri_desc still produces exactly the words
 * in xacp/include/rixdesc_golden.h.  That table is what the A4000 compares its NEON descriptors
 * against at startup (xacp/src/xacp_rixcheck.c), so if the table and the scalar path ever drift
 * apart the hardware check would be measuring nothing.  Regenerate with tests/gen_rixdesc_golden.c
 * ONLY when the descriptor format itself changes, and say so in docs/RIX_CHANGES.md. */
#include <stdio.h>
#include "rixdesc.h"
#include "rixclip.h"
#include "rixdesc_golden.h"
u32 rix_geo_w = 640u, rix_geo_h_alloc = 481u;
int main(void)
{
    unsigned i, j, bad = 0, refused = 0;
    for (i = 0; i < RIXDESC_GOLDEN_TRIS; i++) {
        rix_vertex v[3];
        u32 d[RIX_TRI_DESC_WORDS];
        for (j = 0; j < 3u; j++) {
            const float *s = rixdesc_golden_v[i][j];
            v[j].sx = s[0]; v[j].sy = s[1]; v[j].z = s[2]; v[j].invw = s[3];
            v[j].u  = s[4]; v[j].v  = s[5];
            v[j].r  = s[6]; v[j].g  = s[7]; v[j].b  = s[8]; v[j].a = s[9];
        }
        if (!rix_tri_desc(&v[0], &v[1], &v[2], d)) { refused++; continue; }
        for (j = 0; j < RIX_TRI_DESC_WORDS; j++)
            if (d[j] != rixdesc_golden_w[i][j]) {
                if (bad < 8u) printf("FAIL triangle %u word %u: %08x, expected %08x\n", i, j, d[j], rixdesc_golden_w[i][j]);
                bad++;
            }
    }
    if (refused) { printf("FAIL: %u of %u triangles refused\n", refused, (unsigned)RIXDESC_GOLDEN_TRIS); bad++; }
    else printf("ok   %u triangles, %u words each, all identical to the golden table\n",
                (unsigned)RIXDESC_GOLDEN_TRIS, (unsigned)RIX_TRI_DESC_WORDS);
    {   /* rix_project against the same table */
        rix_viewport vp; rix_clipvert cv[RIXPROJ_GOLDEN_N]; rix_vertex pv[RIXPROJ_GOLDEN_N];
        unsigned w, badp = 0;
        vp.scale_x = rixproj_golden_vp[0]; vp.trans_x = rixproj_golden_vp[1];
        vp.scale_y = rixproj_golden_vp[2]; vp.trans_y = rixproj_golden_vp[3];
        vp.scale_z = rixproj_golden_vp[4]; vp.trans_z = rixproj_golden_vp[5];
        for (i = 0; i < RIXPROJ_GOLDEN_N; i++) {
            const float *s = rixproj_golden_in[i];
            cv[i].x = s[0]; cv[i].y = s[1]; cv[i].z = s[2]; cv[i].w = s[3];
            cv[i].u = s[4]; cv[i].v = s[5];
            cv[i].r = s[6]; cv[i].g = s[7]; cv[i].b = s[8]; cv[i].a = s[9];
        }
        rix_project(cv, (u32)RIXPROJ_GOLDEN_N, &vp, pv);
        for (i = 0; i < RIXPROJ_GOLDEN_N; i++) {
            const u32 *q = (const u32 *)&pv[i];
            for (w = 0; w < 10u; w++)
                if (q[w] != rixproj_golden_out[i][w]) {
                    if (badp < 6u) printf("FAIL rix_project vertex %u word %u: %08x, expected %08x\n", i, w, q[w], rixproj_golden_out[i][w]);
                    badp++;
                }
        }
        if (!badp) printf("ok   rix_project: %u vertices, 10 words each, identical to the golden table\n", (unsigned)RIXPROJ_GOLDEN_N);
        bad += badp;
    }
    {   /* the two startup checks of xacp_rixcheck.c as the Amiga runs them, with BOXFIT asked for */
        extern unsigned zzhl_rixdesc_check(unsigned *refused);
        extern unsigned zzhl_rixfit_check(unsigned *vs_table, unsigned *cut);
        unsigned refused = 9u, vst = 9u, cut = 0u, b1, b2;
        rix_box_fit = 2; rix_box_fit_lines = 1234u; rix_box_fit_dropped = 56u;
        b1 = zzhl_rixdesc_check(&refused);
        if (b1 || refused || rix_box_fit != 2) { printf("FAIL startup table check with BOXFIT=2 asked: %u words, %u refused, box fit left at %d\n", b1, refused, rix_box_fit); bad++; }
        else printf("ok   startup table check: BOXFIT=2 asked for does not disturb it (it runs with the boxes whole) and is put back\n");
        b2 = zzhl_rixfit_check(&vst, &cut);
        if (b2 || vst || !cut || rix_box_fit != 2 || rix_box_fit_lines != 1234u || rix_box_fit_dropped != 56u) {
            printf("FAIL startup BOXFIT check: %u words between the two paths, %u against the table, %u boxes cut, state %d %u %u\n", b2, vst, cut, rix_box_fit, rix_box_fit_lines, rix_box_fit_dropped); bad++;
        } else printf("ok   startup BOXFIT check: mode 1 changes nothing but the end of the box on the table's triangles, mode 2 makes %u boxes smaller, the frame's counters are put back\n", cut);
        rix_box_fit = 0; rix_box_fit_lines = rix_box_fit_dropped = 0u;
    }
    printf(bad ? "RIXDESC TESTS FAILED (%u)\n" : "RIXDESC ALL TESTS PASSED\n", bad);
    return bad ? 1 : 0;
}
