/* test_menufont.cpp - ZZHalfLife (build 52): host test of the menu's font atlas (xacp/menu/BaseFontBackend.cpp,
 * the adapted copy of FWGS mainui's) with mainui's stb_truetype backend (font/StbFont.cpp) and the
 * menu font of tools/menu (FiraSans).  The seven fonts mainui makes at 640x480 (FontManager VidInit,
 * scale 480/768) with the character ranges of xacp/menu/FontManager.cpp:
 *   - every page is a 256x256 texture (the RasterIX texture unit takes no more);
 *   - every glyph lies inside its page and overlaps no other glyph of that page;
 *   - drawn through DrawCharacter (PIC_Set + PIC_DrawTrans with the glyph rectangle, as the engine's
 *     PIC_DrawGeneric turns it into texture coordinates), each character shows the pixels stb_truetype
 *     gives for THAT character: compared with a page holding that character alone;
 *   - the destructor frees every page.
 * Writes build/host/menufont_<n>.tga (the pages of the 16 px font, for a look) and a line per font.
 * Code by the ZZHalfLife port, GPL-3.0-or-later (it links mainui code).  ASCII only. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <vector>
#include <string>
#include "FontManager.h"
#include "StbFont.h"
#include "Utils.h"
#undef Con_Printf    /* enginecallback_menu.h: macros over the engine table, set below */
#undef Con_DPrintf

ui_enginefuncs_t EngFuncs::engfuncs;
CFontManager *g_FontMgr;
static const char *g_ttf;

struct pic_t { std::string name; int w, h; std::vector<unsigned char> rgba; bool freed; };  /* rgba top-down, as the engine's BMP loader */
static std::vector<pic_t> g_pics;
static int g_set = -1, g_fail;
struct draw_t { int pic; int x, y, w, h; wrect_t r; };
static std::vector<draw_t> g_draws;

#define CHECK( c, ... ) do { if( !( c )) { printf( "FAIL: " __VA_ARGS__ ); printf( "\n" ); g_fail++; } } while( 0 )

static HIMAGE stub_PIC_Load( const char *name, const byte *buf, int size, int flags )
{
	(void)flags;
	if( !buf || size < 54 ) return 0;
	unsigned off, w; int h; unsigned short bpp;
	memcpy( &off, buf + 10, 4 ); memcpy( &w, buf + 18, 4 ); memcpy( &h, buf + 22, 4 ); memcpy( &bpp, buf + 28, 2 );
	CHECK( bpp == 32, "%s: %u bpp", name, bpp );
	pic_t p; p.name = name; p.w = (int)w; p.h = h; p.freed = false; p.rgba.resize( w * h * 4 );
	for( int row = 0; row < h; row++ )             /* bottom-up rows, BGRA (engine img_bmp.c, case 32) */
	{
		const byte *s = buf + off + ( h - 1 - row ) * w * 4;
		unsigned char *d = &p.rgba[row * w * 4];
		for( unsigned x = 0; x < w; x++, s += 4, d += 4 ) { d[0] = s[2]; d[1] = s[1]; d[2] = s[0]; d[3] = s[3]; }
	}
	g_pics.push_back( p );
	return (HIMAGE)g_pics.size();
}
static void stub_PIC_Free( const char *name )
{
	for( size_t i = 0; i < g_pics.size(); i++ ) if( g_pics[i].name == name && !g_pics[i].freed ) { g_pics[i].freed = true; return; }
	CHECK( 0, "PIC_Free( %s ): no such picture", name );
}
static void stub_PIC_Set( HIMAGE h, int r, int g, int b, int a ) { (void)r; (void)g; (void)b; (void)a; g_set = h - 1; }
static void stub_PIC_DrawTrans( int x, int y, int w, int h, const wrect_t *prc ) { draw_t d = { g_set, x, y, w, h, *prc }; g_draws.push_back( d ); }
static void stub_Con_Printf( const char *fmt, ... ) { va_list a; va_start( a, fmt ); vprintf( fmt, a ); va_end( a ); }

void EngFuncs::PIC_Set( HIMAGE hPic, int r, int g, int b, int a ) { engfuncs.pfnPIC_Set( hPic, r, g, b, a ); }
void UI_DrawRectangleExt( int, int, int, int, unsigned int, int, int ) { }
bool CFontManager::FindFontDataFile( const char *name, int tall, int weight, int flags, char *dataFile, size_t dataFileChars )
{
	(void)name; (void)tall; (void)weight; (void)flags;
	snprintf( dataFile, dataFileChars, "%s", g_ttf ); return true;
}
byte *CFontManager::LoadFontDataFile( const char *virtualpath, int *length )
{
	FILE *f = fopen( virtualpath, "rb" ); if( !f ) return NULL;
	fseek( f, 0, SEEK_END ); long n = ftell( f ); fseek( f, 0, SEEK_SET );
	byte *b = (byte *)malloc( n ); if( fread( b, 1, n, f ) != (size_t)n ) { fclose( f ); free( b ); return NULL; }
	fclose( f ); if( length ) *length = (int)n; return b;
}

/* the ranges of xacp/menu/FontManager.cpp */
static const uint32_t zzhl_signs[] = { 0x0152, 0x0153, 0x2013, 0x2014, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2026, 0x20AC, 0x2122 };
static charRange_t g_range[] =
{
	{ 0x0021, 0x007E, NULL, 0 }, { 0x00A1, 0x00BF, NULL, 0 }, { 0x00C0, 0x00FF, NULL, 0 }, { 0, 0, zzhl_signs, 12 },
};

/* the pixels a DrawCharacter call shows for ch, as the texture lookup gives them (nearest texel) */
static std::vector<unsigned char> drawn( CStbFont &f, int ch, int *pw, int *ph )
{
	g_draws.clear();
	f.DrawCharacter( ch, Point( 0, 0 ), 0, 0xFFFFFFFF, false );
	std::vector<unsigned char> out;
	*pw = *ph = 0;
	if( g_draws.size() != 1 ) return out;
	const draw_t &d = g_draws[0];
	const pic_t &p = g_pics[d.pic];
	int w = d.r.right - d.r.left, h = d.r.bottom - d.r.top;
	out.resize( w * h );
	for( int y = 0; y < h; y++ )
		for( int x = 0; x < w; x++ )
		{
			float s = ( d.r.left + x + 0.5f ) / p.w, t = ( d.r.top + y + 0.5f ) / p.h;   /* PIC_DrawGeneric: rect / source size */
			int tx = (int)( s * p.w ), ty = (int)( t * p.h );
			out[y * w + x] = ( tx < p.w && ty < p.h ) ? p.rgba[( ty * p.w + tx ) * 4 + 3] : 0;
		}
	*pw = w; *ph = h;
	return out;
}

struct spec_t { const char *what; int tall, weight, blur; float brighten; int outline; };

int main( int argc, char **argv )
{
	g_ttf = argc > 1 ? argv[1] : "tools/menu/gfx/fonts/FiraSans-Regular.ttf";
	const char *outdir = argc > 2 ? argv[2] : "build/host";
	EngFuncs::engfuncs.pfnPIC_Load = stub_PIC_Load;
	EngFuncs::engfuncs.pfnPIC_Free = stub_PIC_Free;
	EngFuncs::engfuncs.pfnPIC_Set = stub_PIC_Set;
	EngFuncs::engfuncs.pfnPIC_DrawTrans = stub_PIC_DrawTrans;
	EngFuncs::engfuncs.Con_Printf = stub_Con_Printf;
	EngFuncs::engfuncs.Con_DPrintf = stub_Con_Printf;
	g_FontMgr = (CFontManager *)calloc( 1, sizeof( CFontManager ));   /* only its two file functions (above) are called */

	const float sc = 480.0f / 768.0f;   /* uiStatic.scaleY at 640x480 */
	const spec_t specs[] =
	{
		{ "default", (int)( 26 * sc ), 500, 0, 0, 0 }, { "small", (int)( 20 * sc ), 500, 0, 0, 0 },
		{ "big", (int)( 40 * sc ), 500, 0, 0, 0 }, { "bold", (int)( 26 * sc ), 1000, 0, 0, 0 },
		{ "light blur", (int)( 26 * sc ), 500, (int)( 2 * sc ), 1.25f, 0 }, { "heavy blur", (int)( 26 * sc ), 500, (int)( 8 * sc ), 2.0f, 0 },
		{ "console", (int)( 18 * sc ), 500, 0, 0, 1 },
	};
	const char *probe = "New game Hazard course Configuration Load game Quit 0123456789 eacute\xe9 c\xe7 oe\x9c";
	int total_pages = 0;

	for( size_t k = 0; k < sizeof( specs ) / sizeof( specs[0] ); k++ )
	{
		const spec_t &sp = specs[k];
		size_t first = g_pics.size();
		{
			CStbFont f;
			CHECK( f.Create( "Trebuchet MS", sp.tall, sp.weight, sp.blur, sp.brighten, sp.outline, 0, 0, 0 ), "%s: Create", sp.what );
			f.UploadGlyphsForRanges( g_range, sizeof( g_range ) / sizeof( g_range[0] ));
			size_t pages = g_pics.size() - first;
			total_pages += (int)pages;
			for( size_t i = first; i < g_pics.size(); i++ )
			{
				CHECK( g_pics[i].w <= 256 && g_pics[i].h <= 256, "%s: page %s is %dx%d", sp.what, g_pics[i].name.c_str(), g_pics[i].w, g_pics[i].h );
				for( size_t j = first; j < i; j++ )   /* the engine would hand back the first one for the same name */
					CHECK( g_pics[i].name != g_pics[j].name, "%s: two pages named %s", sp.what, g_pics[i].name.c_str());
			}

			/* every glyph inside its page, no two overlapping */
			std::vector<draw_t> all;
			for( int r = 0; r < 4; r++ )
				for( size_t i = 0; i < g_range[r].Length(); i++ )
				{
					int ch = g_range[r].Character( i ), w, h;
					g_draws.clear();
					f.DrawCharacter( ch, Point( 0, 0 ), 0, 0xFFFFFFFF, false );
					if( g_draws.empty()) continue;           /* a glyph the font lacks */
					const draw_t d = g_draws[0];
					CHECK( d.pic >= (int)first && d.pic < (int)g_pics.size(), "%s: U+%04X drawn with picture %d", sp.what, ch, d.pic );
					const pic_t &p = g_pics[d.pic];
					CHECK( d.r.left >= 0 && d.r.top >= 0 && d.r.right <= p.w && d.r.bottom <= p.h, "%s: U+%04X rect %d,%d-%d,%d outside %dx%d",
						sp.what, ch, d.r.left, d.r.top, d.r.right, d.r.bottom, p.w, p.h );
					for( size_t j = 0; j < all.size(); j++ )
						if( all[j].pic == d.pic && d.r.left < all[j].r.right && all[j].r.left < d.r.right && d.r.top < all[j].r.bottom && all[j].r.top < d.r.bottom && d.r.right > d.r.left && all[j].r.right > all[j].r.left )
							CHECK( 0, "%s: U+%04X overlaps another glyph", sp.what, ch );
					all.push_back( d );
					(void)w; (void)h;
				}

			/* each character of the probe shows its own pixels: a font holding that character alone */
			for( const char *c = probe; *c; c++ )
			{
				int ch = (unsigned char)*c;
				if( ch == ' ' ) continue;
				if( ch == 0x9c ) ch = 0x153;   /* cp1252 oe */
				int w1, h1, w2, h2;
				std::vector<unsigned char> a = drawn( f, ch, &w1, &h1 );
				CStbFont one;
				one.Create( "Trebuchet MS", sp.tall, sp.weight, sp.blur, sp.brighten, sp.outline, 0, 0, 0 );
				charRange_t r1 = { (uint32_t)ch, (uint32_t)ch, NULL, 0 };
				one.UploadGlyphsForRanges( &r1, 1 );
				std::vector<unsigned char> b = drawn( one, ch, &w2, &h2 );
				CHECK( w1 > 0 && w1 == w2 && h1 == h2 && a == b, "%s: '%c' (U+%04X) does not show its own glyph (%dx%d vs %dx%d)", sp.what, *c, ch, w1, h1, w2, h2 );
			}

			if( k == 0 )   /* the pages of the default font, for a look */
				for( size_t i = first; i < first + pages; i++ )
				{
					char path[512]; snprintf( path, sizeof( path ), "%s/menufont_%d.tga", outdir, (int)( i - first ));
					FILE *o = fopen( path, "wb" );
					if( !o ) continue;
					unsigned char th[18] = { 0, 0, 2 }; th[12] = g_pics[i].w & 255; th[13] = g_pics[i].w >> 8; th[14] = g_pics[i].h & 255; th[15] = g_pics[i].h >> 8; th[16] = 24; th[17] = 0x20;
					fwrite( th, 1, 18, o );
					for( int px = 0; px < g_pics[i].w * g_pics[i].h; px++ ) { unsigned char a = g_pics[i].rgba[px * 4 + 3], v[3] = { a, a, a }; fwrite( v, 1, 3, o ); }
					fclose( o );
				}
			printf( "font %-10s %2d px: %d page(s) of 256x256, %d glyphs\n", sp.what, sp.tall, (int)pages, (int)all.size());
		}
		/* the destructor freed its pages (the probe fonts too) */
		for( size_t i = first; i < g_pics.size(); i++ )
			CHECK( g_pics[i].freed, "%s: page %s not freed", sp.what, g_pics[i].name.c_str());
	}
	printf( "menu fonts: %d pages of 256x256 in all (RGBA4444 in ZZGL: %d KiB)\n", total_pages, total_pages * 128 );
	printf( g_fail ? "MENUFONT TESTS FAILED (%d)\n" : "MENUFONT ALL TESTS PASSED\n", g_fail );
	return g_fail ? 1 : 0;
}
