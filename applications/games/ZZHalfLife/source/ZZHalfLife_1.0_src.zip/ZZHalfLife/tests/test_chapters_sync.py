#!/usr/bin/env python3
# test_chapters_sync.py - ZZHalfLife build 78.
#
# The chapters live in TWO tables that must say exactly the same thing:
#   - xacp/src/xacp_chapters.c, g_ch[]  : read on Core1, decides what is preloaded into RAM
#   - tools/hl_chapters.py,     CHAPTERS: read on the PC, decides how pak0.pak is laid out
# Nothing checked they agreed until Uplink was added on 15/11 and the change had to be made in
# five places at once.  A chapter in one table and not the other is silent: the pak is laid out
# for one map order while Core1 preloads another, and the only symptom is a slow level.
#
# Also checked: GAME_ORDER of tools/hl_chlayout.py names every chapter, because
# "chs = [c for c in GAME_ORDER if c in lists]" drops without a word any it does not.
# And SV_CH of xacp/src/xacp_fs.c, which must be the chapter count PLUS ONE (the slot for the
# maps of no chapter).
#
# Standard library only. ASCII only.
import os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "tools"))

fails = []


def check(ok, what):
    print(("PASS  " if ok else "FAIL  ") + what)
    if not ok:
        fails.append(what)


def c_table():
    """g_ch[] of xacp_chapters.c, as [(title, [maps])]"""
    src = open(os.path.join(ROOT, "xacp/src/xacp_chapters.c"), encoding="latin-1").read()
    body = src[src.index("g_ch[] = {") + len("g_ch[] = {"):]
    body = body[:body.index("\n};")]
    body = re.sub(r"/\*.*?\*/", "", body, flags=re.S)        # the comments, which hold no entry
    out = []
    for m in re.finditer(r'\{\s*"((?:[^"\\]|\\.)*)"\s*,\s*"([^"]*)"\s*\}', body):
        out.append((m.group(1).replace("\\'", "'"), m.group(2).split()))
    return out


def py_table():
    import hl_chapters as hc
    return [(t, m.split()) for t, m in hc.CHAPTERS]


ct, pt = c_table(), py_table()
check(len(ct) > 0, "the C table is read (%d chapters)" % len(ct))
check(len(ct) == len(pt), "same number of chapters: C %d, Python %d" % (len(ct), len(pt)))

for i in range(min(len(ct), len(pt))):
    (c_title, c_maps), (p_title, p_maps) = ct[i], pt[i]
    check(c_title == p_title, "chapter %d: same title (%r / %r)" % (i, c_title, p_title))
    check(c_maps == p_maps,
          "chapter %d %r: same maps, in the same order" % (i, c_title))

# every map belongs to exactly one chapter
seen = {}
dup = []
for i, (title, maps) in enumerate(ct):
    for m in maps:
        if m in seen:
            dup.append("%s is in %r and %r" % (m, seen[m], title))
        seen[m] = title
check(not dup, "no map in two chapters" + (" -- " + "; ".join(dup) if dup else ""))

# GAME_ORDER must name them all, or the layout silently drops one
import hl_chlayout as L
missing = [i for i in range(len(ct)) if i not in L.GAME_ORDER]
check(not missing,
      "GAME_ORDER names every chapter" +
      (" -- missing: " + ", ".join("%d (%s)" % (i, ct[i][0]) for i in missing) if missing else ""))
check(sorted(L.GAME_ORDER) == list(range(len(ct))),
      "GAME_ORDER holds each chapter exactly once")

# SV_CH = chapters + 1 (the slot for the maps of no chapter)
fs = open(os.path.join(ROOT, "xacp/src/xacp_fs.c"), encoding="latin-1").read()
m = re.search(r"#define\s+SV_CH\s+(\d+)", fs)
check(m is not None, "SV_CH is found in xacp_fs.c")
if m:
    check(int(m.group(1)) == len(ct) + 1,
          "SV_CH is %d = %d chapters + the slot for the maps of none" % (len(ct) + 1, len(ct)))

# Uplink, added on 15/11: it must be there, and last, so its place in the pak moves no other
check(any(t == "Uplink" for t, _ in ct), "Uplink is a chapter")
if ct and ct[-1][0] == "Uplink":
    check(ct[-1][1] == ["hldemo1", "hldemo2", "hldemo3"], "Uplink holds its three maps")
else:
    check(False, "Uplink is the LAST chapter (it must move no other)")

print()
if fails:
    print("%d FAILED" % len(fails))
    sys.exit(1)
print("ALL TESTS PASSED")
