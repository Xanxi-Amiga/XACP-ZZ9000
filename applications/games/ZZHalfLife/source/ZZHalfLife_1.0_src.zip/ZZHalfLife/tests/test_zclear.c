/* test_zclear.c - the rule of ZCLEAR=1 (xacp/include/zzhl_zclear.h) on the PC.
 *
 * The header decides which depth buffer is clean, when the PL330 may be started over one and when a
 * frame must wait.  A mistake there is a picture with holes or with walls seen through walls, on
 * the A4000 only.  So the rule is driven here by a model of what it stands for - two depth buffers
 * with a real content (FAR everywhere, or WRITTEN), frames that write them while they are in the
 * GPU, a copy that takes time - through a few fixed sequences and through a million random ones,
 * and four things are checked at every step:
 *   A. a frame told "clean" really finds FAR everywhere in its buffer;
 *   B. the PL330 never runs over a buffer a frame still uses (open, or its fence not waited);
 *   C. no frame ever opens on a buffer the PL330 is still copying over;
 *   D. never two copies at once.
 * And that the rule earns its keep: in the steady state every frame of the game is clean, with one
 * copy a frame and no wait when the copy is shorter than the frame.
 * Build and run: tests/run_host_tests.sh
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <stdio.h>
#include <stdlib.h>
#include "zzhl_zclear.h"

static int fails;
static void ok( int cond, const char *what ) { if( cond ) printf( "ok   %s\n", what ); else { printf( "FAIL %s\n", what ); fails++; } }

/* ---- what the rule stands for ---- */
enum { FAR_ALL = 0, WRITTEN };
static int content[2];        /* what buffer i holds */
static int users[2];          /* frames on buffer i that are open or not yet fenced */
static int copying = -1;      /* the buffer the PL330 is on */
static int copy_left;         /* steps before that copy ends */
static int copy_time = 1;     /* steps a copy takes */
static int copy_fails;        /* the next start is refused */
static unsigned n_clean, n_frames, n_copies, n_late, n_waits, viol;
static zclear_t z;

static void violation( const char *w ) { if( viol < 5u ) printf( "     violation: %s\n", w ); viol++; }
static void pl330_step( void )
{
	if( copying < 0 ) return;
	if( users[copying] ) violation( "B: the PL330 runs over a buffer a frame uses" );
	if( copy_left > 0 ) copy_left--;
}
static int pl330_done( void ) { return copying >= 0 && copy_left == 0; }
/* what Core1/zzhl_gpu.c does: zc_poll */
static void poll( void )
{
	if( z.run < 0 ) return;
	if( pl330_done()) { content[copying] = FAR_ALL; copying = -1; zclear_done( &z ); }
}
static void finish( void ) { while( z.run >= 0 && !pl330_done()) pl330_step(); poll(); }
static int start( unsigned i )
{
	if( copy_fails ) { copy_fails = 0; zclear_fail( &z ); return 0; }
	if( copying >= 0 ) { violation( "D: a copy started while another runs" ); return 0; }
	if( users[i] ) violation( "B: a copy started over a buffer a frame uses" );
	copying = (int)i; copy_left = copy_time; n_copies++;
	zclear_started( &z, i );
	return 1;
}
/* a frame opens on the current target, as zc_frame_opens: 1 = told clean */
static int frame_open( void )
{
	int a, clean, waited = 0;
	unsigned i;
	poll();
	while(( a = zclear_open_need( &z )) != ZCA_NONE )
	{
		waited = 1;
		if( a == ZCA_WAIT ) finish();
		else { n_late++; (void)start( z.cur ); }
	}
	if( waited ) n_waits++;
	i = z.cur;
	clean = zclear_open( &z );
	if( copying == (int)i ) violation( "C: a frame opens on a buffer the PL330 is copying over" );
	if( clean && content[i] != FAR_ALL ) violation( "A: a frame was told clean and its buffer is not FAR everywhere" );
	users[i]++;
	content[i] = WRITTEN;                 /* it draws */
	n_frames++; if( clean ) n_clean++;
	return clean;
}
/* every frame on buffer i has been fenced (and shown): as zc_release_buf */
static void frames_done( unsigned i )
{
	users[i] = 0;
	poll();
	if( zclear_release( &z, i )) (void)start( i );
}
static void reset( int on )
{
	zclear_init( &z );
	content[0] = content[1] = WRITTEN; users[0] = users[1] = 0; copying = -1; copy_left = 0; copy_time = 1; copy_fails = 0;
	n_clean = n_frames = n_copies = n_late = n_waits = viol = 0u;
	if( on ) { content[1] = FAR_ALL; zclear_enable( &z, 1 ); }
}
static unsigned rnd_s = 12345u;
static unsigned rnd( unsigned n ) { rnd_s = rnd_s * 1664525u + 1013904223u; return ( rnd_s >> 8 ) % n; }

int main( void )
{
	unsigned k, cur = 0u;

	/* off: nothing ever clean, nothing ever started */
	reset( 0 );
	for( k = 0; k < 20u; k++ ) { zclear_target( &z, cur, 1 ); (void)frame_open(); frames_done( cur ); cur ^= 1u; pl330_step(); }
	ok( n_clean == 0u && n_copies == 0u && viol == 0u, "ZCLEAR off: no frame is told clean, the PL330 is never started" );

	/* the game without the overlap: a frame is fenced and shown before the next one opens */
	reset( 1 ); cur = 0u;
	for( k = 0; k < 100u; k++ ) { zclear_target( &z, cur, 1 ); (void)frame_open(); pl330_step(); frames_done( cur ); cur ^= 1u; pl330_step(); pl330_step(); }
	ok( viol == 0u && n_clean == 100u, "no overlap: every frame clean, no rule broken" );
	ok( n_copies == 101u && n_late == 1u, "no overlap: one copy a frame as it is shown; the only late one is the first frame's (its buffer had never been cleared)" );

	/* the overlap: frame N stays in the GPU while N+1 is built; N is fenced at the end of N+1 */
	reset( 1 ); cur = 0u;
	{
		int pend = -1;
		for( k = 0; k < 100u; k++ )
		{
			zclear_target( &z, cur, 1 ); (void)frame_open(); pl330_step(); pl330_step();
			if( pend >= 0 ) frames_done( (unsigned)pend );          /* end of this frame: the pending one is fenced, shown */
			pend = (int)cur; cur ^= 1u;
			pl330_step(); pl330_step();                              /* the engine, between two frames */
		}
		ok( viol == 0u && n_clean == 100u, "overlap: every frame clean, no rule broken" );
		ok( n_copies == 100u && n_late == 1u && n_waits == 1u, "overlap: one copy a frame, started as the frame before is shown; no wait but the first frame's late clear" );
	}
	/* a copy longer than a frame: the frame waits, and is still clean */
	reset( 1 ); cur = 0u; copy_time = 50;
	{
		int pend = -1;
		for( k = 0; k < 50u; k++ )
		{
			zclear_target( &z, cur, 1 ); (void)frame_open(); pl330_step();
			if( pend >= 0 ) frames_done( (unsigned)pend );
			pend = (int)cur; cur ^= 1u;
		}
		ok( viol == 0u && n_clean == 50u && n_waits >= 48u, "a copy longer than a frame: the frames wait for it and stay clean" );
	}
	/* hidden frames (tests, price list) never count on a clean buffer, and cost the game one GPU clear */
	reset( 1 ); cur = 0u;
	for( k = 0; k < 6u; k++ ) { zclear_target( &z, cur, 0 ); ok( frame_open() == 0, "a hidden frame is never told clean" ); users[cur] = 0; cur ^= 1u; }   /* fenced, never shown: nobody reports it */
	{
		int c1, c2, c3;
		zclear_target( &z, cur, 1 ); c1 = frame_open(); frames_done( cur ); cur ^= 1u; pl330_step();
		zclear_target( &z, cur, 1 ); c2 = frame_open(); frames_done( cur ); cur ^= 1u; pl330_step();
		zclear_target( &z, cur, 1 ); c3 = frame_open(); frames_done( cur ); cur ^= 1u; pl330_step();
		ok( c1 == 0 && c2 == 0 && c3 == 1 && viol == 0u, "after hidden frames: one frame of the game on each buffer is cleared by the GPU, then clean again" );
	}
	/* a stray frame: a second frame opens on the target of a frame still in the GPU */
	reset( 1 ); cur = 1u;
	zclear_target( &z, cur, 1 ); ok( frame_open() == 1, "the frame on the buffer the self-test left clean is clean" );
	ok( frame_open() == 0 && viol == 0u, "a second frame on the same target is not clean and starts nothing" );
	frames_done( cur );
	ok( z.run == (int)cur && viol == 0u, "both fenced: the copy starts over their buffer" );
	/* the PL330 refuses: everything by the GPU from there on */
	reset( 1 ); cur = 0u;
	for( k = 0; k < 10u; k++ ) { zclear_target( &z, cur, 1 ); (void)frame_open(); frames_done( cur ); cur ^= 1u; pl330_step(); }
	copy_fails = 1;
	{
		unsigned c0 = n_copies, clean_after = 0u;
		for( k = 0; k < 10u; k++ ) { zclear_target( &z, cur, 1 ); (void)frame_open(); frames_done( cur ); cur ^= 1u; pl330_step(); }
		for( k = 0; k < 10u; k++ ) { zclear_target( &z, cur, 1 ); clean_after += (unsigned)frame_open(); frames_done( cur ); cur ^= 1u; pl330_step(); }
		ok( !z.on && clean_after == 0u && n_copies <= c0 + 1u && viol == 0u, "a refused copy: off for good, no frame told clean any more" );
	}

	/* a million random steps: targets of both kinds, opens with and without a new target, fences late or
	   never reported, copies of 0 to 7 steps, a refusal now and then (then switched on again, as a new run) */
	{
		unsigned total_viol = 0u, opens = 0u, cleans = 0u;
		int pend[2] = { 0, 0 };
		reset( 1 ); cur = 0u;
		for( k = 0; k < 1000000u; k++ )
		{
			unsigned r = rnd( 1000u );
			if( r < 250u )
			{   /* a new target: most often the other buffer and a frame of the game, as the game does;
				   the buffer's earlier frames are most often reported finished first, as the game does */
				unsigned nxt = rnd( 10u ) ? ( cur ^ 1u ) : cur;
				if( pend[nxt] && rnd( 10u )) { frames_done( nxt ); pend[nxt] = 0; }
				cur = nxt; zclear_target( &z, cur, rnd( 10u ) ? 1 : 0 );
			}
			else if( r < 500u ) { cleans += (unsigned)frame_open(); opens++; pend[z.cur] = 1; }
			else if( r < 650u ) { unsigned i = rnd( 2u ); if( pend[i] || rnd( 3u ) == 0u ) { frames_done( i ); pend[i] = 0; } }
			else if( r < 985u ) pl330_step();
			else if( r < 993u ) copy_time = (int)rnd( 8u );
			else if( r < 995u ) copy_fails = 1;
			else if( !z.on && z.run < 0 && copying < 0 && !users[0] && !users[1] ) { content[0] = content[1] = WRITTEN; zclear_enable( &z, 0 ); }
			total_viol += viol; viol = 0u;
		}
		printf( "     random: %u frames opened, %u told clean\n", opens, cleans );
		ok( total_viol == 0u, "a million random steps: no rule broken" );
		ok( cleans > opens / 10u, "a million random steps: frames are told clean often enough for the test to mean something" );
	}
	printf( fails ? "ZCLEAR TESTS FAILED (%d)\n" : "ZCLEAR ALL TESTS PASSED\n", fails );
	return fails ? 1 : 0;
}
