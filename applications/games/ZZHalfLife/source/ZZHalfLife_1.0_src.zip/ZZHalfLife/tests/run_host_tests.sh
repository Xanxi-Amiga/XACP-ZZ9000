#!/bin/sh
# run_host_tests.sh - ZZHalfLife: host (PC) tests of the Core1-independent parts.
set -e
cd "$(dirname "$0")/.."
mkdir -p build/host tests/data
# build 75: miniz is compiled in, exactly as the ARM build does it - the saves are deflated now
# (mz_compress2 / mz_uncompress), so the host suite exercises the real compressor, not a stand-in.
# Same path convention as build_arm.sh.
[ -n "$XASH3D" ] || XASH3D="../../../../xash3d-fwgs"
MZ="$XASH3D/3rdparty/miniz"
[ -f "$MZ/miniz.c" ] || { echo "ERROR: miniz not found at $MZ"; exit 1; }
cc -O1 -g -Wall -Wno-unused-function -Ixacp/include -I"$MZ" -DZZHL_HOST_TEST=1 -o build/host/test_xacp_fs \
   tests/test_xacp_fs.c xacp/src/xacp_fs.c xacp/src/xacp_disk.c xacp/src/xacp_chapters.c "$MZ/miniz.c"
./build/host/test_xacp_fs
# build 59: the golden descriptor table against the scalar rix_tri_desc (the A4000 compares its
# NEON descriptors to the same table at startup, xacp/src/xacp_rixcheck.c)
cc -O1 -w -DRIX_HOST_SIM -Ilibrixgpu -Ixacp/include -o build/host/test_rixdesc \
   tests/test_rixdesc.c librixgpu/rixdesc.c librixgpu/rixclip.c xacp/src/xacp_rixcheck.c
./build/host/test_rixdesc || exit 1

# build 65: the halo-trace rejection must never reject a segment that really touches the box.
cc -O2 -w -o build/host/test_segbox tests/test_segbox.c xacp/src/xacp_segbox.c -lm
./build/host/test_segbox || exit 1

cc -O1 -g -Wall -Wno-unused-function -Ixacp/include -Izzgl -Ilibrixgpu -DZZHL_HOST_TEST=1 -o build/host/test_glq \
   tests/test_glq.c xacp/src/xacp_gl.c xacp/src/xacp_glq.c
./build/host/test_glq > build/host/test_glq.out; rc=$?
grep -v "^V \|^EN \|^DIS \|^DF \|^DM \|^BF \|^AF \|^CULL\|^FF \|^SM \|^ENV \|^LOADM\|^BEGIN\|^END\|^BIND\|^ORG" build/host/test_glq.out
[ $rc -eq 0 ] || { echo "test_glq exit code $rc"; exit 1; }
# build 84: the reports of Core1/zzhl_gpu.c (buckets with the world only, the load by origin, the
# bench bucket, the GPU price list), the adapter included whole over fakes of librixgpu and ZZGL
# build 91: the frames dropped at the presentation, counted by the engine's pace (Core1/zzhl_dropstat.h)
cc -O1 -g -Wall -o build/host/test_dropstat tests/test_dropstat.c
./build/host/test_dropstat | grep -v "^ok"
cc -O1 -g -w -DRIX_HOST_SIM -DZZQ2RIX_HOST -Ilibrixgpu -Izzgl -ICore1 -Ixacp/include -o build/host/test_gpureport tests/test_gpureport.c
./build/host/test_gpureport > build/host/test_gpureport.out; rc=$?
grep -v "^ok" build/host/test_gpureport.out
[ $rc -eq 0 ] || { echo "test_gpureport exit code $rc"; exit 1; }
# build 86: a log as the A4000 would give it (price list of 27 cases, ZCLEAR's line, a bench window
if command -v python3 >/dev/null 2>&1; then
  ZZHL_DUMP=build/host/b86_model.log ./build/host/test_gpureport > /dev/null
  python3 -I tools/perf/zzhl_benchcmp.py --origins build/host/b86_model.log > build/host/b86_model.cmp
  for s in "ZCLEAR=1 BOXFIT=2 REJECT=1 BOXPX=1 WALKSTAT=1" "RIX: ZCLEAR=1 ON" "depth clears per 1000 frames: 0 by the GPU, 1000 skipped" "box kpx  1536.0 =  3.0 x the surface" \
           "t 4 more depth clears" "A 500 x 1024 px: the same, leaning back" "= same surface, box 33 times bigger" \
           "rasteriser by its model: 18.96 a frame, of which 4.52 on lines that ran to the end of their box, 2.11 before" \
           "BOXFIT=2: 2950 lines without a pixel taken off the boxes a frame, 120 triangles not sent a frame" \
           "walk world      desc   600  kclocks    800.0 =   8.03 ms  far   200.0  ends   100.0  lines  30000  empty  1500" "sent   303  rej  3700"; do
    grep -q -- "$s" build/host/b86_model.cmp || { echo "FAIL zzhl_benchcmp.py does not show: $s"; exit 1; }
  done
  echo "BENCHCMP reads a build 86 log: ok"
fi
# build 85: the bench's rule for "the scene has loaded" (xacp/include/zzhl_benchload.h), on the
# sequences the A4000 produced on 15/11
cc -O1 -g -Wall -Ixacp/include -o build/host/test_benchload tests/test_benchload.c
./build/host/test_benchload > build/host/test_benchload.out; rc=$?
grep -v "^ok" build/host/test_benchload.out
[ $rc -eq 0 ] || { echo "test_benchload exit code $rc"; exit 1; }
# build 86: ZCLEAR=1.  The rule of the two depth buffers (xacp/include/zzhl_zclear.h) against a model
# of what it stands for, a million random steps included; then ZZGL itself, compiled whole over a
# frame library that records what it is asked: which depth buffer, which clears reach the GPU.
# (The self-test that decides on the A4000 runs against a model of the GPU in test_gpureport.)
cc -O1 -g -Wall -Ixacp/include -o build/host/test_zclear tests/test_zclear.c
./build/host/test_zclear > build/host/test_zclear.out; rc=$?
grep -v "^ok" build/host/test_zclear.out
[ $rc -eq 0 ] || { echo "test_zclear exit code $rc"; exit 1; }
cc -O1 -g -w -DRIX_HOST_SIM -DZZQ2RIX_HOST -Ilibrixgpu -Izzgl -Ixacp/include -o build/host/test_zzgl_zclear \
   tests/test_zzgl_zclear.c zzgl/zzgl.c librixgpu/rixclip.c librixgpu/rixdesc.c -lm
./build/host/test_zzgl_zclear > build/host/test_zzgl_zclear.out; rc=$?
grep -v "^ok" build/host/test_zzgl_zclear.out
[ $rc -eq 0 ] || { echo "test_zzgl_zclear exit code $rc"; exit 1; }
# build 87: the model of the rasteriser's edge walker (librixgpu/rix_walk_model.h, a transcription
# of the firmware's Rasterizer.v) against the A4000's price list of 15/11: one clock period and one
# fixed cost per triangle must give the nine measured times to 12 %.  Then rix_box_fit: 40 000
# random triangles, the pixels drawn must be exactly the same in the three modes.
cc -O1 -g -w -DRIX_HOST_SIM -DZZQ2RIX_HOST -Ilibrixgpu -Izzgl -Ixacp/include -o build/host/test_rixwalk \
   tests/test_rixwalk.c zzgl/zzgl.c librixgpu/rixclip.c librixgpu/rixdesc.c -lm
./build/host/test_rixwalk > build/host/test_rixwalk.out; rc=$?
grep -v "^ok" build/host/test_rixwalk.out
[ $rc -eq 0 ] || { echo "test_rixwalk exit code $rc"; exit 1; }
if command -v python3 >/dev/null 2>&1; then
  python3 -I tests/test_hl_loading.py | grep -v "^   "
  ZZHL_LOADSCREEN="$PWD/build/host/zzhl_loadscreen.tga"; export ZZHL_LOADSCREEN
  # build 78: the chapters live in two tables that must agree, in C and in Python, plus
  # GAME_ORDER and SV_CH.  Adding Uplink took five places at once and nothing checked them.
  python3 tests/test_chapters_sync.py | grep -E "^FAIL|TESTS PASSED|FAILED"
  # layouts be guaranteed; the swaps must be symmetric or one key of a pair is dead, and
  # that cannot be seen without a French keyboard.
  python3 -I tests/test_keylayout.py | grep -E "^FAIL|TESTS PASSED|FAILED"
  # 16/11: the data tool tells whether an install is the reference's (tools/zzhl_ref.py): what is
  # personal, what is a node graph, what differs, and a report without a path or a personal fingerprint
  python3 -I tests/test_zzhl_ref.py | grep -E "^FAIL|TESTS PASSED|FAILED"
else
  echo "(no python3: tools/hl_loading.py not tested)"
fi
# build 32: the deferred queue of the librixgpu copy, deferred and pipelined, against a behavioural GPU
cc -O1 -g -Wall -DRIX_HOST_SIM -Ilibrixgpu -o build/host/test_rixframe_pipe tests/test_rixframe_pipe.c librixgpu/rixframe.c
./build/host/test_rixframe_pipe
# build 35: the presentation copy by the PL330 (rix_dmacopy_*) against a model of the DMAC
cc -O1 -g -Wall -Wno-unused-function -DRIX_HOST_SIM -Ilibrixgpu -o build/host/test_pl330_copy tests/test_pl330_copy.c
./build/host/test_pl330_copy
for r in "640 480" "320 240"; do
  set -- $r
  cc -O1 -g -Wall -Ixacp/include -DZZHL_HOST_TEST=1 -DLW=$1 -DLH=$2 -o build/host/test_loading_$1 tests/test_loading.c xacp/src/xacp_loading.c
  (cd build/host && mkdir -p r$1 && cd r$1 && mkdir -p build/host && ../test_loading_$1)
done
# build 52: the menu - its font in 256x256 pages (xacp/menu/BaseFontBackend.cpp with mainui's stb_truetype
# backend, Xash3D-FWGS tree as build_arm.sh finds it) and pak1.pak of hl_pak.py --menu (hl_menubg.py)
MN="${XASH3D:-../../../../xash3d-fwgs}/3rdparty/mainui"
if [ -d "$MN/font" ] && command -v c++ >/dev/null 2>&1; then
  c++ -std=gnu++11 -fno-rtti -fno-exceptions -O1 -g -w -DSTDINT_H='<cstdint>' -DMAINUI_USE_CUSTOM_FONT_RENDER=1 -DMAINUI_USE_STB=1 -DNDEBUG=1 \
     -I"$MN" -I"$MN/miniutl" -I"$MN/font" -I"$MN/controls" -I"$MN/menus" -I"$MN/model" -I"$MN/sdk_includes/common" \
     -I"$MN/sdk_includes/engine" -I"$MN/sdk_includes/public" -I"$MN/sdk_includes/pm_shared" -o build/host/test_menufont \
     tests/test_menufont.cpp xacp/menu/BaseFontBackend.cpp "$MN/font/StbFont.cpp" "$MN/miniutl/utlmemory.cpp" "$MN/miniutl/strtools.cpp"
  ./build/host/test_menufont tools/menu/gfx/fonts/FiraSans-Regular.ttf build/host
else
  echo "(no mainui tree at $MN: the menu's font pages not tested)"
fi
if command -v python3 >/dev/null 2>&1; then
  python3 -I tests/test_menupak.py "$PWD/build/host/menupak" | grep -E "^ok|^FAIL|TESTS"
fi
