/* test_pl330_copy.c - the presentation copy of the librixgpu copy
 * (rix_dmacopy_*) against a model of the PL330 DMAC.
 *
 * rixgpu.c is included as is (white box: its statics are set here instead of running rix_init's
 * ladder).  The model decodes the program rix_dmacopy_start writes at dma_prog, as the DMAC would after
 * the DMAGO issued through the debug registers, and executes it on the simulated DDR: DMAMOV SAR/DAR/CCR,
 * DMALP/DMALPEND (two loop counters, backward jumps), DMALD/DMAST bursts as CCR says (beats, beat size,
 * increments, endian swap), DMAWMB, DMAEND.  Checked: the whole picture copied once, every halfword
 * byte-swapped, nothing written outside it, no burst across a 4 KiB boundary, the channel seen running
 * for a few polls then stopped, a fault reported and the channel killed, unaligned requests refused.
 *
 * cc -O1 -g -Wall -DRIX_HOST_SIM -Ilibrixgpu -o test_pl330_copy tests/test_pl330_copy.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../librixgpu/rixgpu.c"

/* ---- simulated DDR: two windows ---- */
#define MEM_A   0x06600000u            /* GPU window (colour buffers, program) */
#define MEM_B   0x00B00000u            /* P96 buffers */
#define MEM_SZ  0x00200000u
static unsigned char g_a[MEM_SZ], g_b[MEM_SZ];
void *sim_ptr(u32 a)
{
    if (a >= MEM_A && a - MEM_A < MEM_SZ) return g_a + (a - MEM_A);
    if (a >= MEM_B && a - MEM_B < MEM_SZ) return g_b + (a - MEM_B);
    fprintf(stderr, "sim_ptr: address %08x outside the model\n", a); exit(2);
}
void sim_barrier(void) { }
void sim_wfi(void) { }
void rix_frame_texture_invalidate(u32 base_arm) { (void)base_arm; }

/* ---- the DMAC model ---- */
static u32 d_inst0, d_inst1, d_csr[8], d_ftr[8], d_fsrc, d_polls_left, d_kills, d_gos, d_bursts, d_cross4k, d_fault_next;
static u32 d_ccr_seen;
static int errors;
#define FAIL(...) do { fprintf(stderr, "FAIL: " __VA_ARGS__); fprintf(stderr, "\n"); errors++; } while (0)
static unsigned char rd8(u32 a) { return *(unsigned char *)sim_ptr(a); }
static void wr8(u32 a, unsigned char v) { *(unsigned char *)sim_ptr(a) = v; }
static u32 rd32(u32 a) { return (u32)rd8(a) | ((u32)rd8(a + 1) << 8) | ((u32)rd8(a + 2) << 16) | ((u32)rd8(a + 3) << 24); }
static void run_program(u32 ch, u32 pc)
{
    u32 sar = 0, dar = 0, ccr = 0, lc[2] = { 0, 0 }, steps = 0;
    unsigned char fifo[1024];
    u32 fifo_n = 0;
    for (;;) {
        unsigned char op = rd8(pc);
        if (++steps > 10000000u) { FAIL("program does not end"); return; }
        if (op == PL330_DMAMOV) {
            u32 rd = rd8(pc + 1), v = rd32(pc + 2);
            if (rd == PL330_RD_SAR) sar = v; else if (rd == PL330_RD_DAR) dar = v; else if (rd == PL330_RD_CCR) { ccr = v; d_ccr_seen = v; }
            else FAIL("DMAMOV to register %u", rd);
            pc += 6; continue;
        }
        if ((op & 0xFDu) == PL330_DMALP) { lc[(op >> 1) & 1u] = rd8(pc + 1); pc += 2; continue; }
        if ((op & 0xE8u) == PL330_DMALPEND) {
            u32 n = (op >> 2) & 1u, jump = rd8(pc + 1);
            if (!(op & 0x10u)) FAIL("DMALPEND forever");
            if (lc[n]) { lc[n]--; pc -= jump; } else pc += 2;
            continue;
        }
        if (op == PL330_DMALD || op == PL330_DMAST) {
            u32 beats = ((op == PL330_DMALD ? (ccr >> 4) : (ccr >> 18)) & 15u) + 1u;
            u32 size = 1u << ((op == PL330_DMALD ? (ccr >> 1) : (ccr >> 15)) & 7u);
            u32 inc = (op == PL330_DMALD ? ccr : (ccr >> 14)) & 1u, bytes = beats * size, i;
            u32 *a = (op == PL330_DMALD) ? &sar : &dar;
            if ((*a & ~4095u) != ((*a + bytes - 1u) & ~4095u)) d_cross4k++;
            if (d_fault_next && d_bursts + 1u == d_fault_next) { d_csr[ch] = DMAC_CSR_FAULTING; d_ftr[ch] = 0x00000020u; d_fsrc |= 1u << ch; return; }
            d_bursts++;
            if (op == PL330_DMALD) {
                if (fifo_n + bytes > sizeof fifo) { FAIL("MFIFO overflow"); return; }
                for (i = 0; i < bytes; i++) fifo[fifo_n + i] = rd8(*a + i);
                fifo_n += bytes;
            } else {
                u32 es = (ccr >> 28) & 7u;
                if (fifo_n < bytes) { FAIL("DMAST with %u bytes in the MFIFO, %u wanted", fifo_n, bytes); return; }
                for (i = 0; i < bytes; i++) {
                    u32 j = i;
                    if (es == 1u) j = i ^ 1u;           /* 16-bit endian swap */
                    else if (es != 0u) FAIL("endian swap %u", es);
                    wr8(*a + i, fifo[j]);
                }
                memmove(fifo, fifo + bytes, fifo_n - bytes); fifo_n -= bytes;
            }
            if (inc) *a += bytes;
            pc += 1; continue;
        }
        if (op == PL330_DMAWMB || op == PL330_DMARMB) { pc += 1; continue; }
        if (op == PL330_DMAEND) { if (fifo_n) FAIL("MFIFO not empty at DMAEND (%u bytes)", fifo_n); return; }
        FAIL("opcode %02x at %08x", op, pc); return;
    }
}
u32 sim_mmio_rd(u32 a)
{
    u32 off = a - DMAC_S_BASE;
    if (a == SLCR_APER_CLK_CTRL) return 1u;
    if (a == SLCR_DMAC_RST_CTRL) return 0u;
    if (off == DMAC_DSR) return 0u;
    if (off == DMAC_DBGSTATUS) return 0u;
    if (off == DMAC_FSRC) return d_fsrc;
    if (off >= 0x100u && off < 0x140u && ((off - 0x100u) & 7u) == 0u) {
        u32 ch = (off - 0x100u) / 8u;
        if (d_csr[ch] == 1u) { if (d_polls_left) d_polls_left--; else d_csr[ch] = DMAC_CSR_STOPPED; }
        return d_csr[ch];
    }
    if (off >= 0x40u && off < 0x60u) return d_ftr[(off - 0x40u) / 4u];
    return 0u;
}
void sim_mmio_wr(u32 a, u32 v)
{
    u32 off = a - DMAC_S_BASE;
    if (off == DMAC_DBGINST0) { d_inst0 = v; return; }
    if (off == DMAC_DBGINST1) { d_inst1 = v; return; }
    if (off == DMAC_DBGCMD) {
        u32 b0 = (d_inst0 >> 16) & 0xFFu, b1 = d_inst0 >> 24;
        if ((b0 & 0xFDu) == PL330_DMAGO) {
            u32 ch = b1 & 7u;
            d_gos++;
            d_csr[ch] = 1u;                       /* executing */
            d_polls_left = 5u;
            run_program(ch, d_inst1);             /* the data moves now; the channel "stops" after a few polls */
            if (d_csr[ch] == DMAC_CSR_FAULTING) return;
        } else if (b0 == PL330_DMAKILL) {
            u32 ch = (d_inst0 >> 8) & 7u;
            d_kills++; d_csr[ch] = DMAC_CSR_STOPPED; d_fsrc &= ~(1u << ch);
        }
        return;
    }
}

static u32 sw16(u32 x) { return ((x & 0x00FF00FFu) << 8) | ((x & 0xFF00FF00u) >> 8); }
static int copy_and_wait(u32 src, u32 dst, u32 bytes, int *polls)
{
    int r = rix_dmacopy_start(src, dst, bytes);
    *polls = 0;
    if (r) return -r;
    for (;;) {
        r = rix_dmacopy_poll();
        (*polls)++;
        if (r) return r;
        if (*polls > 1000) return 99;
    }
}

int main(void)
{
    static u32 st[64], sd[256];
    const u32 src = MEM_A + 0x96500u, dst = MEM_B + 0x85C0u, bytes = 614400u, prog = MEM_A + 0x1E7000u;
    u32 i, x, bad = 0, outside = 0;
    int polls, r;
    /* what rix_init would have set: the config (program area), the stats, the DMAC found clocked */
    g_cfg.dma_prog = prog; g_st = st; g_sd = sd;
    if (dmac_probe() != 0) FAIL("dmac_probe");
    if (!rix_dmacopy_available()) FAIL("not available after the probe");
    /* a picture in the second colour buffer, guard bytes around the P96 buffer */
    for (i = 0, x = 12345u; i < bytes / 4u; i++) { x = x * 1664525u + 1013904223u; memcpy(sim_ptr(src + i * 4u), &x, 4); }
    memset(g_b, 0xA5, sizeof g_b);
    r = copy_and_wait(src, dst, bytes, &polls);
    if (r != 1) FAIL("copy: poll gave %d", r);
    if (polls < 3) FAIL("the channel was never seen running (%d polls)", polls);
    if (d_ccr_seen != PL330_CCR_SWAP16_B8) FAIL("CCR %08x", d_ccr_seen);
    if (d_cross4k) FAIL("%u bursts across a 4 KiB boundary", d_cross4k);
    if (d_bursts != 2u * bytes / 64u) FAIL("%u bursts, %u expected", d_bursts, 2u * bytes / 64u);
    for (i = 0, x = 12345u; i < bytes / 4u; i++) { u32 v; x = x * 1664525u + 1013904223u; memcpy(&v, sim_ptr(dst + i * 4u), 4); if (v != sw16(x)) bad++; }
    for (i = 0; i < MEM_SZ; i++) { u32 a = MEM_B + i; if ((a < dst || a >= dst + bytes) && g_b[i] != 0xA5u) outside++; }
    if (bad) FAIL("%u words wrong", bad);
    if (outside) FAIL("%u bytes written outside the picture", outside);
    printf("   copy 614400 bytes %08x -> %08x: %u bursts of 64 bytes, %d polls, %u wrong words, %u bytes outside\n", src, dst, d_bursts, polls, bad, outside);
    /* the 4 KiB self-test of zz_rix_present_dma_test */
    d_bursts = 0;
    r = copy_and_wait(MEM_A + 0x1EF000u, MEM_A + 0x12CA00u, 4096u, &polls);
    if (r != 1 || d_bursts != 128u) FAIL("4 KiB copy: %d, %u bursts", r, d_bursts);
    /* refused: unaligned source, destination, size; nothing started */
    i = d_gos;
    if (rix_dmacopy_start(src + 32u, dst, bytes) == 0) FAIL("unaligned source accepted");
    if (rix_dmacopy_start(src, dst + 2u, bytes) == 0) FAIL("unaligned destination accepted");
    if (rix_dmacopy_start(src, dst, bytes - 32u) == 0) FAIL("size not a multiple of 64 accepted");
    if (d_gos != i) FAIL("a refused request started the channel");
    /* a second copy while one runs: refused until polled to the end */
    if (rix_dmacopy_start(src, dst, bytes) != 0) FAIL("start");
    if (rix_dmacopy_start(src, dst, bytes) == 0) FAIL("second start accepted while busy");
    while (rix_dmacopy_poll() == 0) { }
    /* a fault in the middle: reported once, the channel killed, the next copy works */
    d_bursts = 0; d_fault_next = 100u; i = d_kills;
    r = copy_and_wait(src, dst, bytes, &polls);
    if (r != 2) FAIL("fault: poll gave %d", r);
    if (d_kills != i + 1u) FAIL("channel not killed after the fault");
    if (rix_dmacopy_fault_info() != 0x20u) FAIL("FTR %08x", rix_dmacopy_fault_info());
    d_fault_next = 0u;
    r = copy_and_wait(src, dst, bytes, &polls);
    if (r != 1) FAIL("copy after the fault: %d", r);
    printf(errors ? "PL330 COPY: FAILED (%d)\n" : "PL330 COPY: ALL TESTS PASSED\n", errors);
    return errors ? 1 : 0;
}
