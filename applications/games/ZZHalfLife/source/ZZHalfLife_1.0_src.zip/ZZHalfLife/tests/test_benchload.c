/* test_benchload.c - ZZHalfLife host test of the bench's "has the scene loaded?" rule
 * (xacp/include/zzhl_benchload.h), replaying what the A4000 did on 15/11 with build 84.
 * Build and run: tests/run_host_tests.sh
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <stdio.h>
#include "zzhl_benchload.h"

static int fails;
static void ok( int cond, const char *what ) { if( cond ) printf( "ok   %s\n", what ); else { printf( "FAIL %s\n", what ); fails++; } }

int main( void )
{
	benchload_t b;
	int f, r = BENCHLOAD_WAIT;
	double t;

	/* 1. save007 on 15/11: in a scene (client active), the command blocks 19 s reading a chapter and
	      spawning the server; first engine frame back at +19.1 s with the client STILL active; it
	      reconnects for 1.7 s; then the game shows. */
	benchload_begin( &b, 2, 1000, 100.0, 1 );
	r = benchload_step( &b, 3, 1001, 119.1, 1, 1 );
	ok( r == BENCHLOAD_WAIT, "a load that blocked 19 s: first frame back, client still on the old scene -> wait, not failed" );
	for( f = 1002, t = 119.2; t < 120.8 && r == BENCHLOAD_WAIT; f++, t += 0.1 ) r = benchload_step( &b, 3, f, t, 0, 1 );
	ok( r == BENCHLOAD_WAIT, "while the client reconnects -> wait" );
	r = benchload_step( &b, 3, f, 120.8, 1, 1 );
	ok( r == BENCHLOAD_IN_GAME, "client and server active again after the reconnect -> in the game" );

	/* 2. save009 on 15/11: not on the disk.  The command does nothing; the scene before keeps running
	      at 29 img/s. */
	benchload_begin( &b, 3, 2000, 200.0, 1 );
	for( f = 2001, t = 200.034, r = BENCHLOAD_WAIT; r == BENCHLOAD_WAIT && t < 230.0; f++, t += 0.034 ) r = benchload_step( &b, 3, f, t, 1, 1 );
	ok( r == BENCHLOAD_NOTHING && t > 206.0 && t < 207.0, "a save that is not there: given up after 6 s of frames that load nothing" );

	/* 3. from the menu (no scene to leave), a first load that blocks 70 s */
	benchload_begin( &b, 0, 72, 7.0, 0 );
	r = benchload_step( &b, 1, 73, 77.0, 0, 1 );
	ok( r == BENCHLOAD_WAIT, "from the menu: server spawned, client not in yet -> wait" );
	r = benchload_step( &b, 1, 74, 78.7, 1, 1 );
	ok( r == BENCHLOAD_IN_GAME, "from the menu: in the game as soon as both are active" );

	/* 4. from the menu, a save that is not there: the menu runs at 60 img/s */
	benchload_begin( &b, 1, 500, 50.0, 0 );
	for( f = 501, t = 50.016, r = BENCHLOAD_WAIT; r == BENCHLOAD_WAIT && t < 80.0; f++, t += 0.016 ) r = benchload_step( &b, 1, f, t, 0, 0 );
	ok( r == BENCHLOAD_NOTHING && t > 56.0 && t < 56.1, "from the menu, nothing loaded: given up after 6 s" );

	/* 5. a slow machine: 3 frames in 20 s with no spawn is NOT a failure (frames, not only the clock) */
	benchload_begin( &b, 5, 0, 0.0, 1 );
	r = benchload_step( &b, 5, 1, 7.0, 1, 1 ); r = benchload_step( &b, 5, 2, 14.0, 1, 1 ); r = benchload_step( &b, 5, 3, 20.0, 1, 1 );
	ok( r == BENCHLOAD_WAIT, "three frames in 20 s without a spawn: still waiting" );

	/* 6. the same map loaded again: the spawn count moves all the same */
	benchload_begin( &b, 7, 100, 10.0, 1 );
	r = benchload_step( &b, 8, 101, 12.0, 1, 1 );
	ok( r == BENCHLOAD_WAIT, "same map again: the old client state is not taken for the new game" );
	r = benchload_step( &b, 8, 102, 12.1, 0, 1 ); r = benchload_step( &b, 8, 103, 13.5, 1, 1 );
	ok( r == BENCHLOAD_IN_GAME, "same map again: in the game after the reconnect" );

	/* 7. a server that spawns but a game that never shows */
	benchload_begin( &b, 9, 0, 0.0, 0 );
	r = benchload_step( &b, 10, 1, 599.0, 0, 1 );
	ok( r == BENCHLOAD_WAIT, "server spawned, no client after 599 s: still waiting" );
	r = benchload_step( &b, 10, 2, 601.0, 0, 1 );
	ok( r == BENCHLOAD_NEVER_SHOWN, "after 10 minutes: given up, said so" );

	printf( fails ? "BENCHLOAD TESTS FAILED (%d)\n" : "BENCHLOAD ALL TESTS PASSED\n", fails );
	return fails ? 1 : 0;
}
