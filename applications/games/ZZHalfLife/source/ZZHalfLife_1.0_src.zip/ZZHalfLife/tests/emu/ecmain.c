/* tests/emu/ecmain.c - the caller of zzgl_early_cull_check for the emulated run (run_cull_check.sh).  ASCII only. */
extern unsigned zzgl_early_cull_check(unsigned *tris, unsigned *culled);
int rix_neon = NEONV;
volatile unsigned result[4];
void start_c(void)
{
    rix_neon = NEONV;
    result[0] = zzgl_early_cull_check((unsigned *)&result[1], (unsigned *)&result[2]);
    result[3] = 0xD00DFEEDu;
    __asm__ volatile("udf #0");
}
