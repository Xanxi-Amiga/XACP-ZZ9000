#!/usr/bin/env python3
# SPDX-License-Identifier: 0BSD
# run_game_check.py - ZZHalfLife build 103: the game image (out/zzhl_game.bin) entered on an
# emulated Cortex-A9 (Unicorn), as xacp/src/xacp_game.c enters it on the ZZ9000: its header is
# checked, it is placed at its link address, its bss cleared, and zzhl_game_entry is called with
# an imports table whose functions are played here (a heap, a console, the clock).  It must run
# its own constructors, call nothing but the imports, and hand back the two export tables with
# the names the engine looks up.  Arithmetic and control flow only: no speed, no GPU, no game.
#   python3 tests/emu/run_game_check.py [out/zzhl_game.bin]
# ASCII only.
import struct, sys, zlib
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE, UcError
from unicorn.arm_const import (UC_CPU_ARM_CORTEX_A9, UC_ARM_REG_C1_C0_2, UC_ARM_REG_FPEXC, UC_ARM_REG_SP,
                               UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3)

path = sys.argv[1] if len(sys.argv) > 1 else 'out/zzhl_game.bin'
img = open(path, 'rb').read()
m0, m1, ver, hsz, load, size, bss0, bss1, entry, crc, abi = struct.unpack('<11I', img[:44])
assert (m0, m1, ver, hsz, abi) == (0x4C48525A, 0x454D4147, 1, 64, 1), 'header'
assert size == len(img) and load == 0x3D400000 and bss1 <= 0x3D800000 and bss0 >= load + size - 64, 'sizes'
assert zlib.crc32(img[64:]) & 0xFFFFFFFF == crc, 'crc'

uc = Uc(UC_ARCH_ARM, UC_MODE_ARM, UC_CPU_ARM_CORTEX_A9)
uc.mem_map(0x3D400000, 0x400000)                  # the game image's range
uc.mem_map(0x10000000, 0x01000000)                # stack, imports, the played heap
uc.reg_write(UC_ARM_REG_C1_C0_2, 0x00F00000)
uc.reg_write(UC_ARM_REG_FPEXC, 0x40000000)
uc.mem_write(load, img)
uc.mem_write(bss0, b'\0' * (bss1 - bss0))

STUBS, IMP, EXP, STOP, HEAP = 0x10000000, 0x10001000, 0x10001200, 0x10000FF0, 0x10100000
names = ['open', 'close', 'read', 'write', 'lseek', 'fstat', 'stat', 'isatty', 'unlink', 'link', 'mkdir',
         'gettimeofday', 'getpid', 'kill', 'exit', 'sbrk', 'malloc', 'free', 'calloc', 'realloc', 'memalign',
         'pump_soon', 'us64']
BXLR = struct.pack('<I', 0xE12FFF1E)
for i in range(len(names)):
    uc.mem_write(STUBS + 16 * i, BXLR)
uc.mem_write(STOP, BXLR)
uc.mem_write(IMP, struct.pack('<2I', 1, 8 + 4 * len(names)) + b''.join(struct.pack('<I', STUBS + 16 * i) for i in range(len(names))))
uc.mem_write(EXP, struct.pack('<4I', 0, 16, 0, 0))

heap = [HEAP]; sizes = {}; calls = {}; out = []
def alloc(n, align=8):
    p = (heap[0] + align - 1) & ~(align - 1); heap[0] = p + max(n, 1); sizes[p] = n; return p
def hook(uc, addr, sz, ud):
    if not (STUBS <= addr < STUBS + 16 * len(names)): return
    nm = names[(addr - STUBS) // 16]; calls[nm] = calls.get(nm, 0) + 1
    a0, a1, a2 = uc.reg_read(UC_ARM_REG_R0), uc.reg_read(UC_ARM_REG_R1), uc.reg_read(UC_ARM_REG_R2)
    r = 0
    if nm == 'malloc': r = alloc(a0)
    elif nm == 'calloc': r = alloc(a0 * a1); uc.mem_write(r, b'\0' * (a0 * a1))
    elif nm == 'memalign': r = alloc(a1, max(a0, 8))
    elif nm == 'realloc':
        r = alloc(a1)
        if a0: uc.mem_write(r, bytes(uc.mem_read(a0, min(sizes.get(a0, 0), a1))))
    elif nm == 'write': out.append(bytes(uc.mem_read(a1, a2))); r = a2
    elif nm in ('isatty',): r = 1 if a0 < 3 else 0
    elif nm in ('open', 'stat', 'lseek', 'kill', 'unlink', 'link', 'mkdir', 'fstat', 'sbrk'): r = 0xFFFFFFFF
    elif nm == 'exit': raise SystemExit('the game image called exit(%d)' % a0)
    elif nm == 'us64': uc.reg_write(UC_ARM_REG_R1, 0); r = 1000
    uc.reg_write(UC_ARM_REG_R0, r & 0xFFFFFFFF)
uc.hook_add(UC_HOOK_CODE, hook, begin=STUBS, end=STUBS + 16 * len(names))
def stray(uc, addr, sz, ud):
    if not (load <= addr < load + size or STUBS <= addr < STUBS + 0x1000):
        raise SystemExit('the game image jumped out of itself: %08x' % addr)
uc.hook_add(UC_HOOK_CODE, stray)

uc.reg_write(UC_ARM_REG_SP, 0x10F00000)
uc.reg_write(UC_ARM_REG_LR, STOP)
uc.reg_write(UC_ARM_REG_R0, IMP); uc.reg_write(UC_ARM_REG_R1, EXP)
try:
    uc.emu_start(entry, STOP, count=500000000)
except UcError as e:
    raise SystemExit('emulation stopped at %08x: %s' % (uc.reg_read(UC_ARM_REG_PC), e))
rc = uc.reg_read(UC_ARM_REG_R0)
eabi, esz, cl, sv = struct.unpack('<4I', uc.mem_read(EXP, 16))
assert rc == 0 and eabi == 1 and cl and sv, ('entry', rc, eabi, cl, sv)
def table(p):
    names_ = []
    while True:
        n, f = struct.unpack('<2I', uc.mem_read(p, 8)); p += 8
        if not n: return names_
        assert load <= f < load + size, 'an export outside the image'
        s = bytes(uc.mem_read(n, 64)).split(b'\0')[0].decode('ascii'); names_.append(s)
c, s = table(cl), table(sv)
need_c = ['Initialize', 'HUD_Init', 'HUD_Redraw', 'HUD_Frame']; need_s = ['GiveFnptrsToDll', 'GetEntityAPI2', 'monster_ichthyosaur', 'func_water', 'worldspawn']
miss = [n for n in need_c if n not in c] + [n for n in need_s if n not in s]
assert not miss, ('missing exports', miss)
import os
for nm_, got in (('client', c), ('server', s)):   # the same names as the export lists of the build
    f = 'build/gen/%s.exports' % nm_
    if os.path.exists(f):
        want = [l.strip() for l in open(f) if l.strip()]
        assert sorted(want) == sorted(got), ('%s exports differ from %s' % (nm_, f))
print('emulated Cortex-A9, game image %s: %u bytes at %08x, entry returned 0; constructors called malloc %u times, '
      'nothing outside the imports; exports: client %u, server %u (%s found)' % (
      path, size, load, calls.get('malloc', 0), len(c), len(s), ', '.join(need_c + need_s)))
