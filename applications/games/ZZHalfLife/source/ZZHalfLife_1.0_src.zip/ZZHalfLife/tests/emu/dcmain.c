/* tests/emu/dcmain.c - the caller of glq_decal_cull_check for the emulated run (run_cull_check.sh).  ASCII only. */
extern unsigned glq_decal_cull_check(unsigned *batches, unsigned *dropped, unsigned *plain);
volatile unsigned result[4];
void start_c(void)
{
    result[0] = glq_decal_cull_check((unsigned *)&result[1], (unsigned *)&result[2], 0);
    result[3] = 0xD00DFEEDu;
    __asm__ volatile("udf #0");
}
