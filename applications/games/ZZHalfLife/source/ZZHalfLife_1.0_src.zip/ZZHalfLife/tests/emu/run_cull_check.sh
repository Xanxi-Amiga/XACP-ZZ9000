#!/bin/sh
# tests/emu/run_cull_check.sh - ZZHalfLife build 93: the start-up check of CULLEARLY
# (zzgl_early_cull_check) run on an EMULATED Cortex-A9, with the objects of the last ARM build.
# Why: the PC cannot show what NEON does differently from the scalar FPU (default NaN, flush to
# zero).  Build 92's check passed on the PC and refused the option on the A4000 (48 of 4975);
# this reproduces the 48 with build 92's objects and gives 0 with build 93's.
# Needs: arm-none-eabi-gcc, python3 with the unicorn package (pip install unicorn).
# Not part of tests/run_host_tests.sh (it needs build/ from build_arm.sh).
#   sh tests/emu/run_cull_check.sh          from the ZZHalfLife folder, after build_arm.sh
# An emulator is not the A4000: this is a check of arithmetic, never of speed.   ASCII only.
set -e
D=tests/emu; O=build/host/emu; mkdir -p "$O"
ARCH="-mcpu=cortex-a9 -marm -mfpu=neon -mfloat-abi=hard"
for neon in 1 0; do
    arm-none-eabi-gcc $ARCH -O1 -ffreestanding -DNEONV=$neon -c "$D/ecmain.c" -o "$O/ecmain$neon.o"
    arm-none-eabi-gcc $ARCH -nostartfiles -Wl,-Ttext=0x100000 -Wl,--unresolved-symbols=ignore-all -Wl,--gc-sections \
        -Wl,-e,start_c "$O/ecmain$neon.o" build/xacp/zzgl.o build/xacp/rix_rixclip.o -lc -lgcc -o "$O/ec$neon.elf" 2>&1 | grep -v -i warning || true
    arm-none-eabi-objcopy -O binary "$O/ec$neon.elf" "$O/ec$neon.elf.bin"
    python3 "$D/run_cull_check.py" "$O/ec$neon.elf" "$neon"
done
# build 94: DECALCULL's own check (xacp_glq.c is compiled for the scalar FPU: one run)
arm-none-eabi-gcc -mcpu=cortex-a9 -marm -mfpu=vfpv3-d16 -mfloat-abi=hard -O1 -ffreestanding -c "$D/dcmain.c" -o "$O/dcmain.o"
arm-none-eabi-gcc -mcpu=cortex-a9 -marm -mfpu=vfpv3-d16 -mfloat-abi=hard -nostartfiles -Wl,-Ttext=0x100000 -Wl,--unresolved-symbols=ignore-all -Wl,--gc-sections \
    -Wl,-e,start_c "$O/dcmain.o" build/xacp/xacp_glq_c.o -lc -lgcc -o "$O/dc.elf" 2>&1 | grep -v -i warning || true
arm-none-eabi-objcopy -O binary "$O/dc.elf" "$O/dc.elf.bin"
python3 "$D/run_cull_check.py" "$O/dc.elf" decal


# build 103: the game image entered with played imports (tests/emu/run_game_check.py)
[ -f out/zzhl_game.bin ] && python3 tests/emu/run_game_check.py out/zzhl_game.bin
