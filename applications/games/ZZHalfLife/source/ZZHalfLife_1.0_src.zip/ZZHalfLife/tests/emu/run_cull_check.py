# tests/emu/run_cull_check.py - see run_cull_check.sh.   ASCII only.
import struct, subprocess, sys
from unicorn import Uc, UcError, UC_ARCH_ARM, UC_MODE_ARM
from unicorn.arm_const import UC_CPU_ARM_CORTEX_A9, UC_ARM_REG_C1_C0_2, UC_ARM_REG_FPEXC, UC_ARM_REG_SP

elf, neon = sys.argv[1], sys.argv[2]
nm = subprocess.run(['arm-none-eabi-nm', elf], capture_output=True, text=True).stdout
sym = {l.split()[2]: int(l.split()[0], 16) for l in nm.splitlines() if len(l.split()) == 3}
uc = Uc(UC_ARCH_ARM, UC_MODE_ARM)
uc.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_A9)
uc.mem_map(0, 64 << 20)
uc.mem_write(0x100000, open(elf + '.bin', 'rb').read())
uc.reg_write(UC_ARM_REG_C1_C0_2, 0x00F00000)      # CPACR: cp10 and cp11
uc.reg_write(UC_ARM_REG_FPEXC, 0x40000000)        # VFP and NEON on
uc.reg_write(UC_ARM_REG_SP, 0x03F00000)
try:
    uc.emu_start(sym['start_c'], 0, count=2000000000)
except UcError:
    pass                                          # the udf that ends start_c
bad, tris, back, done = struct.unpack('<4I', uc.mem_read(sym['result'], 16))
if neon == 'decal':
    print('emulated Cortex-A9, DECALCULL: %u batches, %u dropped, dropped that the plain comparisons keep: %u%s'
          % (tris, back, bad, '' if done == 0xD00DFEED else '  *** DID NOT FINISH ***'))
else:
    print('emulated Cortex-A9, rix_project %s: %u different of %u triangles (%u back faces)%s'
          % ('NEON' if neon == '1' else 'scalar', bad, tris, back, '' if done == 0xD00DFEED else '  *** DID NOT FINISH ***'))
sys.exit(0 if bad == 0 and done == 0xD00DFEED else 1)
