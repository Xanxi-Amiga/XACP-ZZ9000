/* test_zzgl_zclear.c - ZZGL's side of ZCLEAR=1, on the PC.
 *
 * ZZGL (zzgl/zzgl.c) is compiled whole, with the real clipper and the real descriptors, over fakes
 * of the frame library that only record what ZZGL asks: which depth buffer each frame is given
 * (rix_frame_begin) and which clears reach the GPU (rix_frame_clear).  What must hold:
 *   - without a hook, nothing changes: the configured depth buffer at every frame, every depth
 *     clear sent to the GPU;
 *   - with a hook that says "clean", the frame's depth clear is NOT sent - and only then: a clear
 *     value other than 1.0, or a batch drawn with the depth mask on before the clear, and the GPU
 *     clears as before;
 *   - the hook is asked once per frame, as the frame opens, before anything is submitted;
 *   - a clear of colour + depth still clears the colour;
 *   - BOXPX: the bounding box of a triangle is counted beside its surface, and only when asked.
 * Build and run: tests/run_host_tests.sh
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <stdio.h>
#include <string.h>
#include "rixgpu.h"
#include "rixframe.h"
#include "rixtex.h"
#include "zzgl.h"

static int fails;
static void ok(int cond, const char *what) { if (cond) printf("ok   %s\n", what); else { printf("FAIL %s\n", what); fails++; } }

/* ---- the fakes: what ZZGL asked of the frame library ---- */
static u32 f_now, f_begins, f_begin_zbuf, f_clears_color, f_clears_depth, f_tris, f_flushes, f_ends, f_submitted_before_hook;
static unsigned char f_mem[1 << 20];
u32 rix_geo_w = 640u, rix_geo_h_alloc = 481u;
int zzgl_test_force_busy;
void *sim_ptr(u32 a) { return f_mem + (a & 0xFFFFFu); }
void sim_barrier(void) { }
u32 rix_now(void) { return ++f_now; }
u32 rix_ticks_to_us(u32 dt) { return dt; }
void rix_mem_clean(u32 a, u32 b) { (void)a; (void)b; }
int rix_frame_begin(rix_frame *f, const rix_frame_desc *d) { (void)f; f_begins++; f_begin_zbuf = d->zbuf; return 0; }
static unsigned long long f_desc_sig;      /* what was sent, in order: any difference in any word of any descriptor changes it */
int rix_frame_tri(rix_frame *f, const u32 *d)
{
    u32 i;
    (void)f;
    for (i = 0; i < RIX_TRI_DESC_WORDS; i++) f_desc_sig = (f_desc_sig ^ d[i]) * 0x100000001B3ull + 0x9E3779B97F4A7C15ull;
    f_tris++;
    return 0;
}
int rix_frame_clear(rix_frame *f, int color, u32 rgba, int depth, u32 d16, u32 x0, u32 y0, u32 x1, u32 y1)
{ (void)f; (void)rgba; (void)d16; (void)x0; (void)y0; (void)x1; (void)y1; if (color) f_clears_color++; if (depth) f_clears_depth++; return 0; }
int rix_frame_reg(rix_frame *f, u32 r, u32 v) { (void)f; (void)r; (void)v; return 0; }
int rix_frame_features(rix_frame *f, u32 v) { (void)f; (void)v; return 0; }
int rix_frame_fragment(rix_frame *f, u32 v) { (void)f; (void)v; return 0; }
int rix_frame_scissor(rix_frame *f, u32 a, u32 b, u32 c, u32 d) { (void)f; (void)a; (void)b; (void)c; (void)d; return 0; }
int rix_frame_texture(rix_frame *f, const rix_texture *t) { (void)f; (void)t; return 0; }
void rix_frame_texture_invalidate(u32 b) { (void)b; }
int rix_frame_end(rix_frame *f, u32 v) { (void)f; (void)v; f_ends++; return 0; }
void rix_frame_set_deferred(int on) { (void)on; }
int rix_frame_deferred(void) { return 0; }
int rix_frame_pump(rix_frame *f) { (void)f; return 0; }
u32 rix_frame_last_bind_seq(void) { return 0u; }
int rix_frame_flush(rix_frame *f) { (void)f; f_flushes++; return 0; }
int rix_frame_bind_passed(rix_frame *f, u32 s) { (void)f; (void)s; return 1; }
int rix_frame_drain(rix_frame *f) { (void)f; return 0; }
void rix_frame_set_pipelined(int on) { (void)on; }
int rix_frame_pipelined(void) { return 0; }
int rix_frame_pending(void) { return 0; }
void rix_frame_set_phase(u32 ph) { (void)ph; }
u32 rix_fragment(u32 df, int dw, u32 af, u32 ar, u32 bs, u32 bd) { return (df & 7u) | (dw ? 8u : 0u) | (af << 4) | (ar << 8) | (bs << 16) | (bd << 20) | 0x80000000u; }
int rix_texpool_init(u32 b, u32 p, int c) { (void)b; (void)p; (void)c; return 0; }
u32 rix_texpool_largest_free(void) { return 1000u; }
int rix_tex_alloc(rix_texture *t, u32 w, u32 h, int l) { (void)t; (void)w; (void)h; (void)l; return -1; }
void rix_tex_free(rix_texture *t) { (void)t; }
void rix_tex_write_rgb565(const rix_texture *t, const u16 *s, int b) { (void)t; (void)s; (void)b; }
void rix_tex_write_rect_rgb565(const rix_texture *t, u32 x, u32 y, u32 w, u32 h, const u16 *s, int b) { (void)t; (void)x; (void)y; (void)w; (void)h; (void)s; (void)b; }

/* ---- the hook ---- */
#define ZB1 0x30C80000u
#define ZB2 0x30E00000u
static u32 h_calls, h_zbuf;
static int h_clean;
static int hook(u32 *zbuf)
{
    h_calls++;
    if (f_begins || f_tris || f_clears_color || f_clears_depth) f_submitted_before_hook++;   /* of THIS frame: the counters are reset between frames */
    *zbuf = h_zbuf;
    return h_clean;
}
static void new_frame(void)
{
    zzgl_target t;
    (void)zzgl_swap();
    t.color = 0x30000000u; t.fence = 1u;
    zzgl_set_target(&t);
    f_begins = f_begin_zbuf = f_clears_color = f_clears_depth = f_tris = f_flushes = 0u; h_calls = 0u;
}
/* a right-angled triangle well inside the 640x480 screen (the screen clip leaves it alone):
   320 x 460, surface 73 600 px, box 147 200 */
static void tri(void)
{
    zzglBegin(ZGL_TRIANGLES);
    zzglVertex3f(10.0f, 10.0f, 0.0f); zzglVertex3f(330.0f, 10.0f, 0.0f); zzglVertex3f(10.0f, 470.0f, 0.0f);
    zzglEnd();
}

/* ---- REJECT=1 (a batch with nothing in view dropped whole) and WALKSTAT=1 ----
   3000 random batches of every kind under a perspective view, most of them partly or wholly out
   of it, behind the eye included.  Drawn without and with the rejection: the GPU must be sent
   exactly the same descriptors, word for word and in the same order. */
static u32 rs = 88172645u;
static float rf(float lo, float hi) { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return lo + (hi - lo) * (float)(rs & 0xFFFFFFu) / 16777215.0f; }
static void scene(u32 *tris_in, u32 *tris_rej)
{
    static const u32 mode[5] = { ZGL_TRIANGLES, ZGL_TRIANGLE_STRIP, ZGL_TRIANGLE_FAN, ZGL_POLYGON, ZGL_QUADS };
    zzgl_origin_stat os[ZZGL_ORIGINS];
    u32 b, k;
    rs = 88172645u;
    zzgl_origin_take(os, ZZGL_ORIGINS);
    zzgl_origin_set(2u);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglFrustum(-1.0, 1.0, -0.75, 0.75, 1.0, 1000.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglDisable(ZGL_CULL_FACE); zzglDisable(ZGL_DEPTH_TEST); zzglDepthMask(0u);
    for (b = 0; b < 3000u; b++) {
        /* a centre anywhere around the eye (the view looks down -z), a batch of 3 to 12 vertices within a few units of it */
        const float cx = rf(-60.0f, 60.0f), cy = rf(-40.0f, 40.0f), cz = rf(-80.0f, 30.0f), size = rf(0.2f, 25.0f);
        const u32 nv = 3u + (u32)rf(0.0f, 9.99f);
        zzglBegin(mode[b % 5u]);
        for (k = 0; k < nv; k++) { zzglTexCoord2f(rf(0, 1), rf(0, 1)); zzglVertex3f(cx + rf(-size, size), cy + rf(-size, size), cz + rf(-size, size)); }
        zzglEnd();
    }
    zzgl_origin_take(os, ZZGL_ORIGINS);
    *tris_in = os[2].tris_in; *tris_rej = os[2].tris_rej;
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
}
/* ---- zzgl_set_early_cull (back faces dropped before the triangle's set-up) ----
   3000 random batches of every kind under a perspective view, with face culling on, colours and
   texture coordinates on every vertex.  Drawn without and with the early test, for the four
   settings of glFrontFace x glCullFace: the GPU must be sent exactly the same descriptors, word
   for word and in the same order, and the early test must have dropped triangles. */
static void cull_scene(u32 front, u32 cullmode)
{
    static const u32 mode[5] = { ZGL_TRIANGLES, ZGL_TRIANGLE_STRIP, ZGL_TRIANGLE_FAN, ZGL_POLYGON, ZGL_QUADS };
    u32 b, k;
    rs = 2718281u;
    zzgl_origin_set(4u);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglFrustum(-1.0, 1.0, -0.75, 0.75, 1.0, 1000.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglEnable(ZGL_CULL_FACE); zzglFrontFace(front); zzglCullFace(cullmode);
    zzglDisable(ZGL_DEPTH_TEST); zzglDepthMask(0u);
    for (b = 0; b < 3000u; b++) {
        const float cx = rf(-60.0f, 60.0f), cy = rf(-40.0f, 40.0f), cz = rf(-80.0f, 30.0f), size = rf(0.2f, 25.0f);
        const u32 nv = 3u + (u32)rf(0.0f, 14.99f);
        zzglBegin(mode[b % 5u]);
        for (k = 0; k < nv; k++) {
            zzglColor4f(rf(-0.2f, 1.2f), rf(0, 1), rf(0, 1), rf(0, 1));
            zzglTexCoord2f(rf(-8, 8), rf(-8, 8));
            zzglVertex3f(cx + rf(-size, size), cy + rf(-size, size), cz + rf(-size, size));
        }
        zzglEnd();
    }
    zzglDisable(ZGL_CULL_FACE); zzglFrontFace(ZGL_CCW); zzglCullFace(ZGL_BACK);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
}
/* ---- zzglEndIndexed (the vertices of an indexed triangle list given once) ----
   3000 blocks of 3 to 60 vertices and 1 to 80 triangles made of them, in and out of the view, some
   behind the eye: drawn unrolled (three vertices a triangle, Begin( ZGL_TRIANGLES ) / End) and
   indexed (the vertices once, zzglEndIndexed).  The same descriptors must leave, word for word. */
static void indexed_scene(int indexed, u32 front, u32 cullmode)
{
    u32 b, k;
    rs = 1618033u;
    zzgl_origin_set(4u);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglFrustum(-1.0, 1.0, -0.75, 0.75, 1.0, 1000.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglEnable(ZGL_CULL_FACE); zzglFrontFace(front); zzglCullFace(cullmode);
    zzglDisable(ZGL_DEPTH_TEST); zzglDepthMask(0u);
    for (b = 0; b < 3000u; b++) {
        float vx[60], vy[60], vz[60], vs[60], vt[60], vc[60][4];
        unsigned char idx[240];
        const float cx = rf(-60.0f, 60.0f), cy = rf(-40.0f, 40.0f), cz = rf(-80.0f, 30.0f), size = rf(0.2f, 25.0f);
        const u32 nv = 3u + (u32)rf(0.0f, 57.99f), nt = 1u + (u32)rf(0.0f, 79.99f);
        for (k = 0; k < nv; k++) {
            vc[k][0] = rf(-0.2f, 1.2f); vc[k][1] = rf(0, 1); vc[k][2] = rf(0, 1); vc[k][3] = rf(0, 1);
            vs[k] = rf(-8, 8); vt[k] = rf(-8, 8);
            vx[k] = cx + rf(-size, size); vy[k] = cy + rf(-size, size); vz[k] = cz + rf(-size, size);
        }
        for (k = 0; k < 3u * nt; k++) idx[k] = (unsigned char)((u32)rf(0.0f, (float)nv - 0.01f));
        if (indexed) {
            zzglBegin(ZGL_TRIANGLES);
            for (k = 0; k < nv; k++) { zzglColor4f(vc[k][0], vc[k][1], vc[k][2], vc[k][3]); zzglTexCoord2f(vs[k], vt[k]); zzglVertex3f(vx[k], vy[k], vz[k]); }
            zzglEndIndexed(idx, 3u * nt);
        } else {
            u32 t;
            for (t = 0; t < nt; t += 20u) {                    /* 20 triangles a Begin/End, as the wrapper unrolls them */
                const u32 te = t + 20u < nt ? t + 20u : nt;
                zzglBegin(ZGL_TRIANGLES);
                for (k = 3u * t; k < 3u * te; k++) { const u32 i = idx[k]; zzglColor4f(vc[i][0], vc[i][1], vc[i][2], vc[i][3]); zzglTexCoord2f(vs[i], vt[i]); zzglVertex3f(vx[i], vy[i], vz[i]); }
                zzglEnd();
            }
        }
    }
    zzglDisable(ZGL_CULL_FACE); zzglFrontFace(ZGL_CCW); zzglCullFace(ZGL_BACK);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
}
static void indexed_tests(void)
{
    u32 k;
    for (k = 0; k < 4u; k++) {
        /* k bit 0: REJECT on; bit 1: the early cull on, for this origin */
        unsigned long long sig0, sig1;
        u32 sent0, sent1;
        char what[200];
        zzgl_set_batch_reject((int)(k & 1u)); zzgl_set_early_cull((int)((k >> 1) & 1u), 1u << 4);
        new_frame(); f_desc_sig = 0ull; f_tris = 0u; indexed_scene(0, ZGL_CCW, ZGL_BACK); sig0 = f_desc_sig; sent0 = f_tris;
        new_frame(); f_desc_sig = 0ull; f_tris = 0u; indexed_scene(1, ZGL_CCW, ZGL_BACK); sig1 = f_desc_sig; sent1 = f_tris;
        snprintf(what, sizeof what, "indexed triangles, REJECT %u, early cull %u: the same %u descriptors word for word as the unrolled list", k & 1u, (k >> 1) & 1u, sent0);
        ok(sent0 > 5000u && sent1 == sent0 && sig1 == sig0, what);
        if (!(sent1 == sent0 && sig1 == sig0)) printf("     sent %u / %u, signatures %016llx / %016llx\n", sent0, sent1, sig0, sig1);
    }
    {   /* culling off, and the other face */
        unsigned long long sig0;
        u32 sent0;
        zzgl_set_batch_reject(1); zzgl_set_early_cull(0, 0u);
        new_frame(); f_desc_sig = 0ull; f_tris = 0u; indexed_scene(0, ZGL_CW, ZGL_FRONT); sig0 = f_desc_sig; sent0 = f_tris;
        new_frame(); f_desc_sig = 0ull; f_tris = 0u; indexed_scene(1, ZGL_CW, ZGL_FRONT);
        ok(sent0 > 5000u && f_tris == sent0 && f_desc_sig == sig0, "indexed triangles, front CW and cull FRONT: the same descriptors");
    }
    {   /* misuse: not a Begin( ZGL_TRIANGLES ), an index past the vertices - nothing drawn, nothing read past the buffer */
        static const unsigned char bad[6] = { 0, 1, 2, 0, 1, 200 };
        new_frame(); f_desc_sig = 0ull; f_tris = 0u;
        zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglFrustum(-1.0, 1.0, -0.75, 0.75, 1.0, 1000.0);
        zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity(); zzglDisable(ZGL_CULL_FACE);
        zzglBegin(ZGL_TRIANGLES); zzglVertex3f(-1, -1, -5); zzglVertex3f(1, -1, -5); zzglVertex3f(0, 1, -5); zzglEndIndexed(bad, 6u);
        ok(f_tris == 1u, "indexed triangles: a triple with an index past the vertices is left out, the others are drawn");
        f_tris = 0u;
        zzglBegin(ZGL_TRIANGLE_STRIP); zzglVertex3f(-1, -1, -5); zzglVertex3f(1, -1, -5); zzglVertex3f(0, 1, -5); zzglEndIndexed(bad, 3u);
        ok(f_tris == 0u, "indexed triangles: only after Begin( ZGL_TRIANGLES )");
        (void)zzglGetError();
        zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -1.0, 1.0);
        zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    }
    zzgl_set_batch_reject(1); zzgl_set_early_cull(0, 0u);
}

static void early_cull_tests(void)
{
    static const char *const name[4] = { "front CCW, cull BACK", "front CW, cull BACK", "front CCW, cull FRONT", "front CW, cull FRONT" };
    u32 k, nt = 0u, nc = 0u, bad;
    zzgl_set_batch_reject(1);                                  /* as the game runs: the rejection of whole batches stays in front of it */
    for (k = 0; k < 4u; k++) {
        const u32 front = (k & 1u) ? ZGL_CW : ZGL_CCW, cm = (k & 2u) ? ZGL_FRONT : ZGL_BACK;
        unsigned long long sig0, sig1, sig2;
        u32 sent0, sent1, sent2, d0, d1, d2;
        char what[160];
        new_frame(); zzgl_set_early_cull(0, 0u); f_desc_sig = 0ull; f_tris = 0u; d0 = zzgl_early_culled();
        cull_scene(front, cm); sig0 = f_desc_sig; sent0 = f_tris; d0 = zzgl_early_culled() - d0;
        new_frame(); zzgl_set_early_cull(1, 1u << 4); f_desc_sig = 0ull; f_tris = 0u; d1 = zzgl_early_culled();
        cull_scene(front, cm); sig1 = f_desc_sig; sent1 = f_tris; d1 = zzgl_early_culled() - d1;
        new_frame(); zzgl_set_early_cull(1, ~(1u << 4)); f_desc_sig = 0ull; f_tris = 0u; d2 = zzgl_early_culled();
        cull_scene(front, cm); sig2 = f_desc_sig; sent2 = f_tris; d2 = zzgl_early_culled() - d2;
        snprintf(what, sizeof what, "early cull, %s: the same %u descriptors word for word, %u triangles dropped before their set-up", name[k], sent0, d1);
        ok(sent0 > 1000u && sent1 == sent0 && sig1 == sig0 && d0 == 0u && d1 > 1000u, what);
        if (!(sent1 == sent0 && sig1 == sig0)) printf("     sent %u / %u, signatures %016llx / %016llx, dropped %u\n", sent0, sent1, sig0, sig1, d1);
        ok(sent2 == sent0 && sig2 == sig0 && d2 == 0u, "early cull: an origin that is not in the mask goes the old way");
    }
    {   /* culling off, and glCullFace(GL_FRONT_AND_BACK): nothing for the early test to do */
        unsigned long long sig0;
        u32 sent0, d;
        new_frame(); zzgl_set_early_cull(0, 0u); f_desc_sig = 0ull; f_tris = 0u;
        cull_scene(ZGL_CCW, ZGL_FRONT_AND_BACK); sig0 = f_desc_sig; sent0 = f_tris;
        new_frame(); zzgl_set_early_cull(1, ~0u); f_desc_sig = 0ull; f_tris = 0u; d = zzgl_early_culled();
        cull_scene(ZGL_CCW, ZGL_FRONT_AND_BACK);
        ok(f_tris == sent0 && f_desc_sig == sig0 && zzgl_early_culled() == d && sent0 == 0u, "early cull: GL_FRONT_AND_BACK draws nothing, with or without it");
    }
    bad = zzgl_early_cull_check(&nt, &nc);
    {
        char what[160];
        snprintf(what, sizeof what, "early cull: its own check, %u triangles (%u back faces): %u different", nt, nc, bad);
        ok(bad == 0u && nt > 4000u && nc > 1000u && nc < nt, what);
    }
    zzgl_set_early_cull(0, 0u);
    zzgl_set_batch_reject(0);
}
static void reject_and_walk_tests(void)
{
    unsigned long long sig0, sig1;
    u32 in0, rej0, in1, rej1, sent0, sent1;
    zzgl_origin_stat os[ZZGL_ORIGINS];
    new_frame();
    zzgl_set_batch_reject(0); f_desc_sig = 0ull; f_tris = 0u;
    scene(&in0, &rej0); sig0 = f_desc_sig; sent0 = f_tris;
    new_frame();
    zzgl_set_batch_reject(1); f_desc_sig = 0ull; f_tris = 0u;
    scene(&in1, &rej1); sig1 = f_desc_sig; sent1 = f_tris;
    zzgl_set_batch_reject(0);
    printf("     %u triangles handed over, %u descriptors sent; with REJECT=1, %u triangles dropped by whole batches\n", in0, sent0, rej1);
    ok(in0 > 10000u && sent0 > 1000u, "the random scene has batches in view, across its edges, and out of it");
    ok(rej0 == 0u && rej1 > in0 / 4u, "REJECT=1 drops whole batches (more than a quarter of the triangles here), REJECT=0 none");
    ok(sent1 == sent0 && sig1 == sig0, "REJECT=1: exactly the same descriptors sent to the GPU, word for word, in the same order");
    ok(in1 == in0, "REJECT=1: the triangles handed over are counted the same");
    {   /* the check the Amiga runs at startup (there with the NEON form too) */
        u32 nb = 0u, no = 0u, bad = zzgl_batch_reject_check(&nb, &no);
        printf("     startup check of the test: %u batches, %u outside, %u wrong\n", nb, no, bad);
        ok(bad == 0u && nb == 4000u, "the startup check of the rejection test finds nothing wrong");
        ok(no > nb / 5u && no < nb * 4u / 5u, "and its batches are of both kinds: more than a fifth outside, more than a fifth not");
    }
    /* WALKSTAT */
    new_frame();
    zzgl_origin_take(os, ZZGL_ORIGINS);
    zzgl_origin_set(3u);
    zzglDepthMask(0u); tri();
    zzgl_origin_take(os, ZZGL_ORIGINS);
    ok(os[3].wk_desc == 0u && os[3].wk_clocks == 0u, "WALKSTAT off: nothing walked");
    zzgl_set_walk_stats(1);
    f_desc_sig = 0ull; tri(); sig1 = f_desc_sig;
    zzgl_origin_take(os, ZZGL_ORIGINS);
    /* the 320 x 460 right-angled triangle: its 73 600 pixels and a little more, a handful of clocks a line */
    ok(os[3].wk_desc == 1u && os[3].wk_lines >= 460u && os[3].wk_lines <= 463u && os[3].wk_clocks > 73600u && os[3].wk_clocks < 73600u + 12u * 463u + 2000u,
       "WALKSTAT on: the descriptor sent is walked by the model - its pixels plus a few clocks a line");
    if (!(os[3].wk_clocks > 73600u && os[3].wk_clocks < 73600u + 12u * 463u + 2000u)) printf("     desc %u clocks %u far %u ends %u lines %u empty %u\n", os[3].wk_desc, os[3].wk_clocks, os[3].wk_far, os[3].wk_end, os[3].wk_lines, os[3].wk_empty);
    zzgl_set_walk_stats(0);
    f_desc_sig = 0ull; tri();
    ok(f_desc_sig == sig1, "WALKSTAT changes nothing of what is sent");
}

int main(void)
{
    zzgl_config gc;
    zzgl_origin_stat os[ZZGL_ORIGINS];
    const zzgl_stats *st;
    memset(&gc, 0, sizeof gc);
    gc.pool_base = 0x30400000u; gc.pool_pages = 64u; gc.zbuf = ZB1; gc.width = 640u; gc.height = 480u;
    ok(zzgl_init(&gc) == 0, "ZZGL starts");
    { zzgl_target t; t.color = 0x30000000u; t.fence = 1u; zzgl_set_target(&t); }
    zzglViewport(0, 0, 640, 480);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglDisable(ZGL_CULL_FACE);

    /* no hook: build 85 */
    zzglClearDepth(1.0); zzglClear(ZGL_DEPTH_BUFFER_BIT);
    st = zzgl_get_stats();
    ok(f_begins == 1u && f_begin_zbuf == ZB1 && f_clears_depth == 1u && st->zclear_gpu == 1u && st->zclear_skipped == 0u, "no hook: the configured depth buffer, the depth clear sent to the GPU");

    /* a hook that says clean */
    zzgl_set_zbuf_hook(hook); h_zbuf = ZB2; h_clean = 1;
    new_frame();
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    st = zzgl_get_stats();
    ok(h_calls == 1u && f_submitted_before_hook == 0u, "the hook is asked once, as the frame opens, before anything of the frame");
    ok(f_begins == 1u && f_begin_zbuf == ZB2, "the frame is given the hook's depth buffer");
    ok(f_clears_depth == 0u && f_flushes == 0u && st->zclear_skipped == 1u && st->zclear_gpu == 0u, "clean: the depth clear is not sent, and counted as skipped");
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_depth == 0u && zzgl_get_stats()->zclear_skipped == 2u, "clean and nothing drawn: a second clear is skipped too");
    zzglDepthMask(0u); zzglDisable(ZGL_DEPTH_TEST); tri();
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_tris == 1u && f_clears_depth == 0u, "a batch with the depth mask off (the 2D) leaves the buffer clean");
    zzglDepthMask(1u); zzglEnable(ZGL_DEPTH_TEST); tri();
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_depth == 1u && zzgl_get_stats()->zclear_gpu == 1u, "after a batch with the depth mask on, the clear goes to the GPU");
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_depth == 2u, "and so do the clears after it (the GPU's own clear is not tracked as clean)");
    ok(h_calls == 1u, "still one call of the hook for the whole frame");

    new_frame();
    zzglDepthMask(1u); zzglDisable(ZGL_DEPTH_TEST); tri();            /* depth test off, mask on: not assumed harmless */
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_depth == 1u, "a batch with the depth mask on and the test off counts as a write too");

    new_frame();
    zzglClearDepth(0.5); zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_depth == 1u, "clean, but a clear value other than far: the GPU clears");
    zzglClearDepth(1.0);

    new_frame();
    zzglClear(ZGL_COLOR_BUFFER_BIT | ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_color == 1u && f_clears_depth == 0u, "clean: colour + depth clears the colour only");

    new_frame();
    zzglEnable(ZGL_SCISSOR_TEST); zzglScissor(10, 10, 100, 100);
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_clears_depth == 0u, "clean: a scissored depth clear is skipped as well (the whole buffer is far)");
    zzglDisable(ZGL_SCISSOR_TEST);

    h_clean = 0;
    new_frame();
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_begin_zbuf == ZB2 && f_clears_depth == 1u && zzgl_get_stats()->zclear_gpu == 1u, "a hook that says not clean: its buffer, and the GPU clears");

    h_clean = 1; h_zbuf = 0u;
    new_frame();
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_begin_zbuf == ZB1 && f_clears_depth == 1u, "a hook that gives no buffer: the configured one, and the GPU clears");

    h_zbuf = ZB1; h_clean = 1;
    new_frame();
    zzglDepthMask(0u); tri();                                         /* the frame opens on a draw, not on a clear */
    ok(h_calls == 1u && f_begin_zbuf == ZB1, "a frame that opens on a draw asks the hook too");
    new_frame(); new_frame();
    ok(h_calls == 0u, "the hook is not asked between frames");
    (void)zzgl_swap();
    ok(h_calls == 1u, "an empty frame that is swapped opens, and asks");

    zzgl_set_zbuf_hook(0);
    new_frame();
    zzglClear(ZGL_DEPTH_BUFFER_BIT);
    ok(f_begin_zbuf == ZB1 && f_clears_depth == 1u, "the hook removed: build 85 again");

    /* BOXPX */
    zzgl_origin_take(os, ZZGL_ORIGINS);
    zzgl_origin_set(3u);
    zzglDepthMask(0u); tri();
    zzgl_origin_take(os, ZZGL_ORIGINS);
    ok(os[3].tris == 1u && os[3].px_opaque > 73500.0f && os[3].px_opaque < 73700.0f && os[3].px_box == 0.0f, "BOXPX off: the surface is counted, the box is not");
    if (!(os[3].px_opaque > 73500.0f && os[3].px_opaque < 73700.0f)) printf("     tris %u opaque %.1f box %.1f\n", os[3].tris, os[3].px_opaque, os[3].px_box);
    zzgl_set_box_stats(1);
    tri();
    zzgl_origin_take(os, ZZGL_ORIGINS);
    ok(os[3].px_box > 147000.0f && os[3].px_box < 147400.0f && os[3].px_opaque > 73500.0f && os[3].px_opaque < 73700.0f, "BOXPX on: a right-angled triangle's box is twice its surface");
    if (!(os[3].px_box > 147000.0f && os[3].px_box < 147400.0f)) printf("     opaque %.1f box %.1f\n", os[3].px_opaque, os[3].px_box);
    zzglBegin(ZGL_TRIANGLES);                                          /* a sliver along the diagonal of a 264 x 256 box */
    zzglVertex3f(100.0f, 100.0f, 0.0f); zzglVertex3f(108.0f, 100.0f, 0.0f); zzglVertex3f(364.0f, 356.0f, 0.0f);
    zzglEnd();
    zzgl_origin_take(os, ZZGL_ORIGINS);
    ok(os[3].px_opaque > 1000.0f && os[3].px_opaque < 1050.0f && os[3].px_box > 67000.0f && os[3].px_box < 68000.0f, "BOXPX on: a diagonal sliver of 1024 px has a box of 67 584");
    zzgl_set_box_stats(0);

    reject_and_walk_tests();
    early_cull_tests();
    indexed_tests();
    printf(fails ? "ZZGL ZCLEAR TESTS FAILED (%d)\n" : "ZZGL ZCLEAR ALL TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
