#!/usr/bin/env python3
# test_chlayout.py - ZZHalfLife build 45: hl_pak.py --chapters on a made-up install that has, under
# the names of the reference lists (tools/chapters, or the lists given), files of the listed sizes
# (patterned bytes, no game data): maps that are real .bsp headers (a worldspawn, a scientist),
# .wad files with the listed textures and some more, a sentences.txt.  Checks: nothing missing,
# no size different, every file of the pak equal to its source, every texture of a rewritten .wad
# equal to the original, each chapter's ranges covering its listed files and textures, and the
# same bytes twice (pak, .crc, .chp).
#   python3 tests/test_chlayout.py [lists dir] [work dir]
# ASCII only.
import hashlib, os, shutil, struct, subprocess, sys

here = os.path.dirname(os.path.abspath(__file__))
tools = os.path.join(here, '..', 'tools')
sys.path.insert(0, tools)
import hl_chlayout as L, hl_chapters as hc

lists_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(tools, 'chapters')
work = sys.argv[2] if len(sys.argv) > 2 else '/tmp/zzhl_chlayout'
fails = 0
def check(ok, what):
    global fails
    print(('ok: ' if ok else 'FAIL: ') + what)
    if not ok: fails += 1

def pattern(name, size):
    h = hashlib.md5(name.encode()).digest()
    return (h * (size // 16 + 1))[:size]

def bsp_bytes(size):
    ents = b'{\n"classname" "worldspawn"\n"wad" "\\\\valve\\\\halflife.wad"\n}\n{\n"classname" "monster_scientist"\n}\n{\n"classname" "scripted_sentence"\n"sentence" "!SC_TEST0"\n}\n\0'
    hdr = struct.pack('<i', 30) + b''.join(struct.pack('<ii', 124 if i == 0 else 0, len(ents) if i == 0 else 0) for i in range(15))
    b = hdr + ents
    return b + b'\0' * max(0, size - len(b))

def wad_bytes(lumps):
    body, pos, dir_ = b'', 12, b''
    for n, sz in lumps:
        d = pattern('wad:' + n, sz)
        dir_ += struct.pack('<iiibbbb', pos, sz, sz, 0x43, 0, 0, 0) + n.encode('latin-1')[:15].ljust(16, b'\0')
        body += d; pos += sz
    return b'WAD3' + struct.pack('<ii', len(lumps), pos) + body + dir_

lists = L.load_lists(lists_dir)
files, wads = {}, {}
for c, ch in lists.items():
    files.update(ch['f'])
    for w, ls in ch['w'].items(): wads.setdefault(w, {}).update(ls)
    for w in ch['d']: wads.setdefault(w, {})
shutil.rmtree(work, ignore_errors=True)
valve = os.path.join(work, 'valve')
for n, sz in sorted(files.items()):
    p = os.path.join(valve, n)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    if n.startswith('maps/') and n.endswith('.bsp'): data = bsp_bytes(sz)
    elif n == 'sound/sentences.txt':
        t = b'SC_TEST0 scientist/hello there\nSC_ANSWER0 scientist/yes\n'
        data = t + b'\n' * max(0, sz - len(t))
    else: data = pattern(n, sz)
    open(p, 'wb').write(data[:sz] if len(data) > sz else data)
extra = {'sound/scientist/hello.wav': 3000, 'sound/scientist/there.wav': 2000, 'sound/scientist/yes.wav': 1000, 'models/notused.mdl': 5000}
for n, sz in extra.items():
    p = os.path.join(valve, n); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'wb').write(pattern(n, sz))
for w, ls in wads.items():
    lumps = sorted(ls.items()) + [('zz_unused%d' % i, 777 + i) for i in range(3)]
    open(os.path.join(valve, w), 'wb').write(wad_bytes(lumps))
print('made-up install: %d files, %d wads' % (len(files) + len(extra), len(wads)))

outs = []
for k in (1, 2):
    od = os.path.join(work, 'out%d' % k); os.makedirs(od, exist_ok=True)
    r = subprocess.run([sys.executable, os.path.join(tools, 'hl_pak.py'), '--chapters', lists_dir, valve, os.path.join(od, 'pak0.pak')], capture_output=True, text=True)
    if k == 1: print(r.stdout[-3000:]); print(r.stderr[-2000:])
    check(r.returncode == 0, 'hl_pak.py --chapters run %d' % k)
    outs.append(od)
md5 = lambda p: hashlib.md5(open(p, 'rb').read()).hexdigest()
for f in ('pak0.pak', 'pak0.crc', 'pak0.chp'):
    check(md5(os.path.join(outs[0], f)) == md5(os.path.join(outs[1], f)), 'same bytes twice: ' + f)
log = r.stdout
check('in the lists but not in this install: 0' in log and 'in the lists with another size here: 0' in log, 'nothing missing, no other size')
pak = hc.Pak([os.path.join(outs[0], 'pak0.pak')])
bad = 0
for n in list(files) + list(extra):
    if n.endswith('.wad'): continue
    src = open(os.path.join(valve, n), 'rb').read()
    if pak.read(n) != src: bad += 1
check(bad == 0, 'every file of the pak equal to its source (%d differ)' % bad)
badw = 0
for w, ls in wads.items():
    parsed = L.parse_wad(pak.read(w))
    orig = L.parse_wad(open(os.path.join(valve, w), 'rb').read())
    a = {l['name']: l['data'] for l in parsed[1]}; b = {l['name']: l['data'] for l in orig[1]}
    if a != b: badw += 1
check(badw == 0, 'every texture of the rewritten .wad files equal to the original')
chp = open(os.path.join(outs[0], 'pak0.chp'), 'rb').read()
check(chp[:8] == b'ZZCHP1\0\0', '.chp header')
size, n = struct.unpack('<II', chp[8:16])
check(size == os.path.getsize(os.path.join(outs[0], 'pak0.pak')), '.chp knows the pak size')
pos, cov_bad, per = 16, 0, {}
for _ in range(n):
    c, nr, tot = struct.unpack('<III', chp[pos:pos + 12]); pos += 12
    per[c] = [struct.unpack('<II', chp[pos + 8 * i:pos + 8 * i + 8]) for i in range(nr)]; pos += 8 * nr
check(255 in per, 'the common part (255) in the .chp')
for c in lists:
    rs = per.get(c, []) + per.get(255, [])
    def covered(o, l): return any(a <= o and o + l <= a + b for a, b in rs)
    for f in lists[c]['f']:
        if f in pak.idx and not f.endswith('.wad'):
            _, o, l = pak.idx[f]
            if l and not covered(o, l): cov_bad += 1
check(cov_bad == 0, 'each chapter\'s ranges with the common part cover its listed files (%d not)' % cov_bad)
check(sum(l for _, l in per[255]) > 0 and all(not any(a <= o and o + l <= a + b for a, b in per[c]) for c in lists if c in per for (o, l) in per[255][:1]), 'the common part left out of the chapters\' own ranges')
# build 48: the announcer's words of a "speaker" (message or preset) and the client sounds, read ahead only
small = os.path.join(work, 'small'); os.makedirs(os.path.join(small, 'maps'), exist_ok=True); os.makedirs(os.path.join(small, 'sound', 'vox'), exist_ok=True)
os.makedirs(os.path.join(small, 'sound', 'debris'), exist_ok=True)
ents = b'{\n"classname" "worldspawn"\n}\n{\n"classname" "speaker"\n"message" "C1A3_"\n}\n{\n"classname" "speaker"\n"preset" "1"\n}\n\0'
hdr = struct.pack('<i', 30) + b''.join(struct.pack('<ii', 124 if i == 0 else 0, len(ents) if i == 0 else 0) for i in range(15))
open(os.path.join(small, 'maps', 'm1.bsp'), 'wb').write(hdr + ents)
open(os.path.join(small, 'sound', 'sentences.txt'), 'wb').write(b'C1A3_0 vox/attention this\nC1A0_1 vox/bravo\nC2A1_0 vox/charlie\n')
for w in ('attention', 'this', 'bravo', 'charlie'): open(os.path.join(small, 'sound', 'vox', w + '.wav'), 'wb').write(b'x' * 100)
open(os.path.join(small, 'sound', 'debris', 'wood2.wav'), 'wb').write(b'y' * 50)
ent = {}
for root, _, fs in os.walk(small):
    for fn in fs:
        full = os.path.join(root, fn); rel = os.path.relpath(full, small).replace(os.sep, '/')
        ent[rel.lower()] = (rel, full, 0, os.path.getsize(full))
rep = []
per, com = L.extras(L.Source(ent), {7: {'f': {}, 'w': {}, 'd': {}, 'maps': ['m1']}}, rep)
check(per[7] == {'sound/vox/attention.wav', 'sound/vox/this.wav', 'sound/vox/bravo.wav'}, 'announcer: the words of the speaker groups C1A3_ (message) and C1A0_ (preset 1), not C2A1_')
check(com == {'sound/debris/wood2.wav'}, 'client sounds: those of the engine\'s list present in the install')
print('ALL TESTS PASSED' if not fails else 'SOME TESTS FAILED')
sys.exit(1 if fails else 0)
