/* test_gpureport.c - ZZHalfLife host test of the reports of Core1/zzhl_gpu.c (build 84).
 *
 * The GPU adapter cannot run on the PC, but everything it PRINTS can: this file includes it whole
 * and fakes librixgpu, ZZGL and the release glue with counters.  It drives frames through
 * zz_rix_end_frame the way xacp_video.c does and checks what the build 84 report says:
 *   - a frame without the world stays out of the three period buckets and of the histogram;
 *   - what ZZGL sent by origin comes out per bucket, pixels and all, on the right lines;
 *   - the bench bucket holds the frames between its begin and its end, and nothing else;
 *   - the engine split (server, client, sound) lands in the frame it was measured in;
 *   - no report overflows its buffer and no line passes 220 characters, also with every number of
 *     a record at five digits: the mirror keeps 239 of a line (xacp_libc.c, MIR_LINE) and the
 *     engine puts its colour reset and its time stamp in front (15 more), which cut a line of
 *     build 84 on the A4000 just before its last number;
 *   - the price list (GPUBENCH=1) draws what it says: frames, layers, binds, and its arithmetic.
 * Build and run: tests/run_host_tests.sh
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <stdio.h>
#include <stdlib.h>
#include "../Core1/zzhl_gpu.c"

/* ---- the fakes ---- */
static u32 f_now;                     /* the timer: 1 tick = 1 us here */
static u32 f_step = 3u;               /* every reading moves it */
u32 rix_now(void) { f_now += f_step; return f_now; }
u32 rix_ticks_to_us(u32 dt) { return dt; }
u32 rix_us_to_ticks(u32 us) { return us; }
static unsigned char f_mem[1 << 16];
static unsigned char *m_zarr(u32 a);
void *sim_ptr(u32 a) { unsigned char *z = m_zarr(a); return z ? (void *)z : (void *)(f_mem + (a & 0x7FFFu)); }
void (*zzhl_dma_guard)(void);         /* Core1/zzhl_present.c's, build 86 */
void sim_barrier(void) { }
u32 rix_geo_w = 640u, rix_geo_h_alloc = 481u, rix_geo_fence_off;
void Sys_Error(char *e, ...) { printf("FAIL Sys_Error: %s\n", e); exit(2); }
static u32 m_dma_left, m_bad;
/* as dma_present does: the guard first, then the channel must be free for the picture's own copy */
void zzq2_present_rgb565(const unsigned short *p, unsigned pitch)
{
    (void)p; (void)pitch;
    if (zzhl_dma_guard) zzhl_dma_guard();
    if (m_dma_left) { printf("FAIL the presentation found the PL330 busy with a depth clear\n"); m_bad++; }
    f_now += 600u;
}
unsigned zzq2_last_pak_end(void) { return 0u; }
void zzq_s2_begin(int p) { (void)p; }
void zzq_s2_end(int p) { (void)p; }
void (*zzq2_present_hook)(void);
volatile u32 zzq2_world_count;
void zzhl_fs_io_totals(unsigned *n, unsigned *b, unsigned *u) { *n = 0; *b = 0; *u = 0; }
u32 zzhl_mus_play, zzhl_mus_stop, zzhl_mus_dropped, zzhl_mus_vol = 65536u, zzhl_mus_volsent;
void zzhl_present_dma_stats(unsigned v[8]) { int i; for (i = 0; i < 8; i++) v[i] = 0u; }
void zzhl_present_drop_stats(unsigned v[7]) { v[0] = 1000u; v[1] = 70u; v[2] = 50u; v[3] = 12u; v[4] = 5u; v[5] = 2u; v[6] = 1u; }   /* build 91 */
void zzhl_present_set_dma(int on) { (void)on; }
int zzq2rix_mmu_setup(zz_mmu_report *r) { (void)r; return 0; }
int zzq2rix_mmu_restore(void) { return 0; }
u32 rix_caps(void) { return 0u; }
static int m_on, m_dma_avail, m_k_dma_dead, m_k_dma_err, m_k_dma_unseen, m_k_late_copy;
static u32 m_copies, m_dma_busy_polls, m_dma_fail_at, m_shadow, m_shadow_valid, m_inflight[2], m_last_dst;
static u32 m_centre(u32 zb);
void rix_dmacopy_abort(void) { m_dma_left = 0u; }
int rix_dmacopy_available(void) { return m_dma_avail; }
u32 rix_dmacopy_dsr(void) { return 0u; }
u32 rix_dmacopy_fault_info(void) { return 0x00010000u; }
int rix_dmacopy_poll(void) { f_now += 5u; if (m_dma_left) { m_dma_left--; return 0; } return 1; }
int rix_dmacopy_start(u32 s, u32 d, u32 b)
{
    if (!m_on) return 0;
    if (m_dma_left) return 0xE1;                       /* the previous copy is still running: the real one refuses too */
    m_copies++;
    if (m_k_dma_err || (m_dma_fail_at && m_copies == m_dma_fail_at)) return 0xE2;
    if ((d == RIXQ2_ZBUF && m_inflight[0]) || (d == RIXQ2_ZBUF2 && m_inflight[1])) { printf("FAIL the PL330 was started over a depth buffer a frame still uses (copy %u)\n", m_copies); m_bad++; }
    if (m_k_dma_unseen) { m_shadow = m_centre(d); m_shadow_valid = 1u; }
    if (!m_k_dma_dead) memcpy(sim_ptr(d), sim_ptr(s), b);
    if (m_k_late_copy && m_copies == (u32)m_k_late_copy) { unsigned short *p = (unsigned short *)sim_ptr(d); u32 i; for (i = 0; i < 37u; i++) p[1000u + i * 97u] = 0x6666u; }
    m_last_dst = d; m_dma_left = m_dma_busy_polls;
    return 0;
}
int rix_frame_deferred(void) { return 0; }
void rix_frame_diag_last(void) { }
int rix_frame_drain(rix_frame *f) { (void)f; return 0; }
void rix_frame_idle_take(u32 *t, u32 *s) { *t = 0u; *s = 0u; }
void rix_frame_phase_stats(u32 ph, u32 fr, u32 v[6]) { int i; (void)ph; (void)fr; for (i = 0; i < 6; i++) v[i] = 0u; }
int rix_frame_pipelined(void) { return 0; }
u32 rix_frame_queued(void) { return 0u; }
int rix_frame_set_bind_mode(int m) { (void)m; return 0; }
void rix_frame_set_phase(u32 ph) { (void)ph; }
void rix_frame_set_sync(int on) { (void)on; }
static u32 f_starved;                                  /* what the next frame end reads as "GPU idle, nothing queued" */
static u32 g_t89_v[4]; static int g_t89_n;
static void t89_hook(unsigned us) { if (g_t89_n < 4) g_t89_v[g_t89_n] = us; g_t89_n++; }
void rix_frame_starved_take(u32 *t) { *t = f_starved; f_starved = 0u; }
static u32 f_gpu_us;                  /* what the next frame's fence wait costs */
static int f_wait_rc;
/* a frame's fence waited: nothing of the frames drawn on that colour buffer is in the GPU any more */
static u32 m_ghost_zb, m_ghost_d, m_ghost_valid, m_frame_zb, m_ghost_new_zb, m_ghost_new_d, m_ghost_new_valid;
static void m_fenced(u32 c)
{
    m_inflight[c == g_color_bufs[1] ? 1 : 0] = 0u;
    /* the defect "a cache emptied during the next frame": what a frame left in the GPU's cache is
       written to its depth buffer while the GPU draws the next frame, on another buffer */
    if (m_ghost_valid && m_frame_zb != m_ghost_zb) {
        unsigned short *p = (unsigned short *)sim_ptr(m_ghost_zb); u32 i;
        for (i = 0; i < 50u; i++) p[640u * 470u + i] = (unsigned short)m_ghost_d;
        m_ghost_valid = 0u;
    }
    if (m_ghost_new_valid) { m_ghost_zb = m_ghost_new_zb; m_ghost_d = m_ghost_new_d; m_ghost_valid = 1u; m_ghost_new_valid = 0u; }
}
int rix_frame_wait(u32 c, u32 fv, u32 to, volatile u32 *stop, u32 *polls) { (void)fv; (void)to; (void)stop; if (polls) *polls = 1u; f_now += f_gpu_us; m_fenced(c); return f_wait_rc; }
int rix_frame_wait_pumped(u32 c, u32 fv, u32 to) { (void)fv; (void)to; f_now += f_gpu_us; m_fenced(c); return f_wait_rc; }
void rix_hw_caps(rix_hwcaps *o) { memset(o, 0, sizeof *o); }
int rix_init(const rix_config *c) { (void)c; return 0; }
int rix_ring_init(const rix_ring_cfg *c) { (void)c; return 0; }
int rix_set_geometry(u32 w, u32 h) { (void)w; (void)h; return 0; }
void rix_shutdown(void) { }
u32 rix_texpool_free_pages(void) { return 8192u; }
int rix_tri_desc(const rix_vertex *a, const rix_vertex *b, const rix_vertex *c, u32 *o) { (void)a; (void)b; (void)c; (void)o; return 1; }
static zzgl_stats f_st;
static rix_frame f_fr;
const rix_frame *zzgl_frame(void) { return &f_fr; }
static int f_open;
int zzgl_frame_open(void) { return f_open; }
const zzgl_stats *zzgl_get_stats(void) { return &f_st; }
int zzgl_init(const zzgl_config *c) { (void)c; return 0; }
void zzgl_pump(void) { }
void zzgl_set_alpha4444(int on) { (void)on; }
void zzgl_set_alpha_textures(int on) { (void)on; }
void zzgl_set_pipelined(int on) { (void)on; }
static u32 f_targets, f_swaps;
void zzgl_set_target(const zzgl_target *t) { (void)t; f_targets++; }
void zzgl_set_texel_bias(float t) { (void)t; }
static void m_frame(void);
static int m_selftest;                /* the frames are the self-test's hidden ones: the model draws them */
int zzgl_swap(void) { f_swaps++; if (m_on && m_selftest) m_frame(); return 0; }
static zzgl_zbuf_hook f_hook;
static int f_box_on;
void zzgl_set_zbuf_hook(zzgl_zbuf_hook fn) { f_hook = fn; }
void zzgl_set_box_stats(int on) { f_box_on = on; }
static int f_walk_on, f_reject_on;
void zzgl_set_walk_stats(int on) { f_walk_on = on; }
void zzgl_set_batch_reject(int on) { f_reject_on = on; }
static u32 f_reject_bad;                               /* what the startup check of the rejection test finds wrong */
u32 zzgl_batch_reject_check(u32 *batches, u32 *outside) { if (batches) *batches = 4000u; if (outside) *outside = 1900u; return f_reject_bad; }
static int f_ec_on; static u32 f_ec_mask, f_ec_bad;                        /* build 92 */
void zzgl_set_early_cull(int on, u32 mask) { f_ec_on = on; f_ec_mask = mask; }
u32 zzgl_early_cull_check(u32 *tris, u32 *culled) { if (tris) *tris = 5000u; if (culled) *culled = 3029u; return f_ec_bad; }
u32 zzgl_early_culled(void) { return 123456u; }
u32 zzgl_early_cull_check_detail(u32 *nan2) { if (nan2) *nan2 = 48u; return f_ec_bad ? 8u : 0u; }
int rix_box_fit; u32 rix_box_fit_lines, rix_box_fit_dropped;      /* librixgpu/rixdesc.c's, build 87 */
static u32 m_clear_bits, m_quad, m_depth_test;
static float m_quad_z, m_col[3], m_clearcol[3];
static unsigned char m_pix[3];
static zzgl_origin_stat f_os[ZZGL_ORIGINS];
static int f_px_on = 1;
void zzgl_origin_take(zzgl_origin_stat *dst, u32 n) { u32 i; for (i = 0; i < n; i++) dst[i] = f_os[i]; memset(f_os, 0, sizeof f_os); }
void zzgl_set_origin_stats(int on) { f_px_on = on; }
/* the GL calls the price list makes: counted */
static u32 f_begins, f_verts, f_binds, f_bound = 0xFFFFFFFFu, f_teximg, f_clears, f_deleted, f_reads;
void zzglAlphaFunc(u32 f, float r) { (void)f; (void)r; }
void zzglBegin(u32 m) { (void)m; f_begins++; f_now += 2u; }
void zzglBindTexture(u32 t, u32 n) { (void)t; if (n != f_bound) { f_bound = n; f_binds++; } }
void zzglBlendFunc(u32 s, u32 d) { (void)s; (void)d; }
void zzglClear(u32 m) { f_clears++; m_clear_bits |= m; }
void zzglClearColor(float r, float g, float b, float a) { (void)a; m_clearcol[0] = r; m_clearcol[1] = g; m_clearcol[2] = b; }
void zzglClearDepth(double d) { (void)d; }
void zzglColor4f(float r, float g, float b, float a) { (void)a; m_col[0] = r; m_col[1] = g; m_col[2] = b; }
void zzglDeleteTextures(s32 n, const u32 *t) { (void)t; f_deleted += (u32)n; }
void zzglDepthFunc(u32 f) { (void)f; }
void zzglDepthMask(u32 m) { (void)m; }
void zzglDisable(u32 c) { if (c == ZGL_DEPTH_TEST) m_depth_test = 0u; }
void zzglEnable(u32 c) { if (c == ZGL_DEPTH_TEST) m_depth_test = 1u; }
void zzglEnd(void) { }
void zzglLoadIdentity(void) { }
void zzglMatrixMode(u32 m) { (void)m; }
void zzglOrtho(double l, double r, double b, double t, double n, double f) { (void)l; (void)r; (void)b; (void)t; (void)n; (void)f; }
void zzglReadPixels(s32 x, s32 y, s32 w, s32 h, u32 f, u32 t, void *p)
{
    unsigned char *d = (unsigned char *)p;
    (void)x; (void)y; (void)w; (void)h; (void)f; (void)t;
    if (m_on) { d[0] = m_pix[0]; d[1] = m_pix[1]; d[2] = m_pix[2]; } else { d[0] = 255u; d[1] = 0u; d[2] = 0u; }
    f_reads++;
}
void zzglTexCoord2f(float s, float t) { (void)s; (void)t; }
void zzglTexEnvf(u32 t, u32 p, float v) { (void)t; (void)p; (void)v; }
void zzglTexImage2D(u32 t, s32 l, s32 i, s32 w, s32 h, s32 b, u32 f, u32 ty, const void *px) { (void)t; (void)l; (void)i; (void)w; (void)h; (void)b; (void)f; (void)ty; (void)px; f_teximg++; }
void zzglTexParameterf(u32 t, u32 p, float v) { (void)t; (void)p; (void)v; }
void zzglVertex2f(float x, float y) { (void)x; (void)y; f_verts++; }
void zzglVertex3f(float x, float y, float z) { (void)x; (void)y; f_verts++; m_quad = 1u; m_quad_z = z; }
void zzglViewport(s32 x, s32 y, s32 w, s32 h) { (void)x; (void)y; (void)w; (void)h; }

/* ---- a GPU with a depth buffer, for ZCLEAR ------------------------------------------------
   The self-test of ZCLEAR=1 (zz_rix_zclear_test) decides on the A4000 whether the PL330 may clear
   the depth.  It cannot run on the PC against the real GPU, but its LOGIC can run against a model:
   a good GPU must pass, and a GPU with any one of the defects the test exists to catch must be
   refused, at the right step.  The frames of the self-test are uniform (full-screen quads, whole
   buffers), so the model keeps one colour for the screen and real memory for the depth buffers.
   m_on = 0: none of this, the fakes behave as before. */
#define M_ZB (640u * 481u * 2u)
static unsigned char m_z1[M_ZB], m_z2[M_ZB], m_far[M_ZB];
static int m_k_clear_fffe, m_k_clear_480, m_k_no_zwrite, m_k_sticky, m_k_lazy, m_k_blind, m_k_grey, m_k_ghost;
static u32 m_sticky = 0xFFFFu, m_lazy, m_lazy_valid, m_lazy_zb;
static unsigned char *m_zarr(u32 a)
{
    if (a >= RIXQ2_ZBUF && a < RIXQ2_ZBUF + M_ZB) return m_z1 + (a - RIXQ2_ZBUF);
    if (a >= RIXQ2_ZBUF2 && a < RIXQ2_ZBUF2 + M_ZB) return m_z2 + (a - RIXQ2_ZBUF2);
    if (a >= RIXQ2_ZFAR && a < RIXQ2_ZFAR + M_ZB) return m_far + (a - RIXQ2_ZFAR);
    return NULL;
}
static void m_fill16(u32 zb, u32 v, u32 words) { unsigned short *p = (unsigned short *)m_zarr(zb); u32 i; for (i = 0; i < words; i++) p[i] = (unsigned short)v; }
static u32 m_centre(u32 zb) { return ((unsigned short *)m_zarr(zb))[240u * 640u + 320u]; }
/* the frame the fakes have collected, as the modelled GPU draws it */
static void m_frame(void)
{
    u32 zb = RIXQ2_ZBUF, view;
    if (f_hook) (void)f_hook(&zb);
    m_frame_zb = zb;
    if (m_k_lazy && m_lazy_valid) { m_fill16(m_lazy_zb, m_lazy, M_ZB / 2u); m_lazy_valid = 0u; }   /* the depth of the frame before reaches the memory only now */
    if (m_clear_bits & ZGL_COLOR_BUFFER_BIT) { m_pix[0] = (unsigned char)(m_clearcol[0] * 255.0f); m_pix[1] = (unsigned char)(m_clearcol[1] * 255.0f); m_pix[2] = (unsigned char)(m_clearcol[2] * 255.0f); }
    if (m_clear_bits & ZGL_DEPTH_BUFFER_BIT) { m_fill16(zb, m_k_clear_fffe ? 0xFFFEu : 0xFFFFu, m_k_clear_480 ? 640u * 480u : M_ZB / 2u); m_sticky = 0xFFFFu; m_shadow_valid = 0u; }
    view = m_centre(zb);
    if (m_k_dma_unseen) { if (m_shadow_valid && view == 0xFFFFu) view = m_shadow; else m_shadow_valid = 0u; }
    if (m_k_sticky && m_sticky < view) view = m_sticky;
    if (m_k_blind) view = m_sticky;                        /* its own idea of the depth, whatever the memory holds */
    if (m_quad) {
        u32 d16 = (u32)((1.0f - m_quad_z) * 0.5f * 65535.0f);
        if (!m_depth_test || d16 < view) {
            m_pix[0] = (unsigned char)(m_col[0] * 255.0f); m_pix[1] = (unsigned char)(m_col[1] * 255.0f); m_pix[2] = (unsigned char)(m_col[2] * 255.0f);
            if (m_k_grey) m_pix[0] = m_pix[1] = m_pix[2] = 128u;              /* a flat quad that does not come out in its colour */
            if (m_depth_test && !m_k_no_zwrite) {
                if (m_k_lazy) { m_lazy = d16; m_lazy_valid = 1u; m_lazy_zb = zb; } else m_fill16(zb, d16, M_ZB / 2u);
                m_sticky = d16;
                if (m_k_ghost) { m_ghost_new_zb = zb; m_ghost_new_d = d16; m_ghost_new_valid = 1u; }   /* a few lines of it stay in a cache of the GPU's */
            }
        }
    }
    m_clear_bits = 0u; m_quad = 0u;
}
static void m_reset(void)
{
    m_k_clear_fffe = m_k_clear_480 = m_k_dma_dead = m_k_dma_err = m_k_no_zwrite = m_k_sticky = m_k_dma_unseen = m_k_lazy = m_k_late_copy = m_k_blind = m_k_grey = m_k_ghost = 0; m_ghost_valid = m_ghost_new_valid = 0u;
    m_copies = m_dma_left = m_dma_busy_polls = m_dma_fail_at = m_bad = 0u; m_sticky = 0xFFFFu; m_shadow_valid = m_lazy_valid = 0u;
    m_inflight[0] = m_inflight[1] = 0u; m_clear_bits = m_quad = m_depth_test = 0u;
    memset(m_z1, 0x33, sizeof m_z1); memset(m_z2, 0x33, sizeof m_z2); memset(m_far, 0x33, sizeof m_far);
}

/* ---- the checks ---- */
static int fails;
static void ok(int cond, const char *what) { if (cond) printf("ok   %s\n", what); else { printf("FAIL %s\n", what); fails++; } }
static int has(const char *text, const char *s) { return strstr(text, s) != NULL; }
static u32 longest_line(const char *t)
{
    u32 best = 0u, n = 0u;
    for (; *t; t++) { if (*t == '\n') { if (n > best) best = n; n = 0u; } else n++; }
    return n > best ? n : best;
}
static int f_last_clean;
static u32 f_last_zb, f_bf_lines, f_bf_dropped;
/* one frame: `period` us from end to end, with or without the world, sending `os` */
static void frame(u32 period, int world, const zzgl_origin_stat *os, u32 nos)
{
    u32 t_begin = f_now, spent, i;
    f_open = 0; zz_rix_begin_frame(); f_open = 1;   /* nothing drawn before the frame begins, something in it */
    /* as ZZGL does when the frame opens: the hook gives the depth buffer, and the frame's one
       depth clear is skipped or made */
    f_last_clean = 0; f_last_zb = RIXQ2_ZBUF;
    if (f_hook) f_last_clean = f_hook(&f_last_zb);
    m_inflight[f_last_zb == RIXQ2_ZBUF2 ? 1 : 0] = 1u;
    f_st.zclear_skipped = (world && f_last_clean) ? 1u : 0u; f_st.zclear_gpu = (world && !f_last_clean) ? 1u : 0u;
    rix_box_fit_lines = f_bf_lines; rix_box_fit_dropped = f_bf_dropped;            /* what the descriptor builder counted during the frame */
    zzhl_host_mark(0u); f_now += 1000u;          /* the server: about 1 ms */
    zzhl_host_mark(1u); f_now += 2000u;          /* the client up to the 3D scene: about 2 ms */
    if (world) {
        zzhl_refphase(0u); f_now += 200u;
        zzhl_refphase(1u); f_now += 1500u;
        zzhl_refphase(4u);
        zzhl_refphase(2u); zzhl_entphase(6u);
        zzhl_entphase(5u); f_now += 300u;
        { u32 was = zzhl_entphase_swap(ZZ_ENTPH_REPLAY); f_now += 4000u; (void)zzhl_entphase_swap(was); }   /* the replay a sprite forces */
        f_now += 100u; zzhl_entphase(6u);
        zzhl_entphase(0u); zzhl_refphase(4u);
        zzhl_refphase(3u); zzhl_refphase(5u);
        zzhl_fx[ZFX_FLUSH_STATE] += 1u; zzhl_fx[ZFX_FLUSHBY0 + ZORG_SPRITE] += 1u; zzhl_fx[ZFX_MID_BATCHES] += 300u;
        zzhl_fx[ZFX_BINDS_REQ] += 204u; zzhl_fx[ZFX_TEX_DISTINCT] += 59u; zzhl_fx[ZFX_REPLAY_US] += 4000u;
        zzhl_fx[ZFX_SND_US] += 700u; zzhl_fx[ZFX_SND_MIXES] += 2u;
        zzhl_fx[ZFX_ORG(ZORG_WORLD, ZFXO_US)] += 3000u; zzhl_fx[ZFX_ORG(ZORG_WORLD, ZFXO_WAIT_US)] += 1200u;
        zzhl_fx[ZFX_SPR_QUADS] += 12u; zzhl_fx[ZFX_SPR_TRIMMABLE] += 8u; zzhl_fx[ZFX_SPR_KEPT1000] += 8u * 400u;
    }
    zzhl_fx[ZFX_FLUSH_FRAME] += 1u;
    for (i = 0; i < nos && i < ZZGL_ORIGINS; i++) f_os[i] = os[i];
    spent = f_now - t_begin;
    f_gpu_us = 0u;
    if (period > spent + 700u) f_now += period - spent - 700u;   /* 600 us of presentation + the timer readings to come */
    zz_rix_end_frame();
}

/* one run of ZCLEAR's self-test against the model, from a fresh adapter */
static int zt_run(int expect_ok, const char *expect, const char *what)
{
    static char l[720];
    int r;
    zzgl_set_zbuf_hook(0); zclear_init(&g_zc); g_zc_hooked = 0; g_zc_force = 0u; zzhl_dma_guard = 0;
    g_zc_copies = g_zc_late = g_zc_waits = g_zc_wait_us = g_zc_wait_max_us = g_zc_fail_code = 0u;
    m_on = 1; m_selftest = 1; m_copies = 0u;
    r = zz_rix_zclear_test(1, l, (int)sizeof l);
    m_selftest = 0;
    ok(r == expect_ok && has(l, expect) && longest_line(l) <= 220u && (r ? (f_hook != NULL && zzhl_dma_guard != NULL && g_zc.on) : (f_hook == NULL && zzhl_dma_guard == NULL && !g_zc.on)), what);
    if (!(r == expect_ok && has(l, expect))) printf("     got (%d): %s", r, l);
    if (longest_line(l) > 220u) printf("     longest line %u\n", longest_line(l));
    return r;
}

int main(void)
{
    static char rep[8192], big[32768];
    static zzgl_origin_stat os[ZZGL_ORIGINS], none[ZZGL_ORIGINS];
    u32 i;
    unsigned v[8];

    g_open = 1;
    g_overlap_req = 0;
    /* what a heavy frame sends */
    os[ZORG_WORLD].tris_in = 5200u; os[ZORG_LIGHTMAP].tris_in = 5000u; os[ZORG_SPRITE].tris_in = 24u; os[ZORG_2D].tris_in = 160u;
    os[ZORG_WORLD].batches = 310u; os[ZORG_WORLD].tris = 2400u; os[ZORG_WORLD].binds = 41u; os[ZORG_WORLD].pages = 330u; os[ZORG_WORLD].px_opaque = 512000.0f;
    os[ZORG_LIGHTMAP].batches = 300u; os[ZORG_LIGHTMAP].tris = 2300u; os[ZORG_LIGHTMAP].binds = 9u; os[ZORG_LIGHTMAP].pages = 144u; os[ZORG_LIGHTMAP].px_blend = 498000.0f;
    os[ZORG_SPRITE].batches = 12u; os[ZORG_SPRITE].tris = 24u; os[ZORG_SPRITE].binds = 5u; os[ZORG_SPRITE].pages = 20u; os[ZORG_SPRITE].px_blend = 921600.0f;   /* three screens */
    os[ZORG_2D].batches = 80u; os[ZORG_2D].tris = 160u; os[ZORG_2D].binds = 4u; os[ZORG_2D].pages = 256u; os[ZORG_2D].px_blend = 30720.0f;
    none[ZORG_2D].batches = 40u; none[ZORG_2D].tris = 80u; none[ZORG_2D].binds = 2u; none[ZORG_2D].pages = 64u; none[ZORG_2D].px_opaque = 307200.0f;

    frame(20000u, 0, none, ZORG_COUNT);                                   /* the first period is not one */
    for (i = 0; i < 500u; i++) frame(9000u, 0, none, ZORG_COUNT);         /* a menu: 110 img/s, no world */
    for (i = 0; i < 100u; i++) frame(20000u, 1, os, ZORG_COUNT);          /* normal */
    for (i = 0; i < 200u; i++) frame(36000u, 1, os, ZORG_COUNT);          /* slow */
    for (i = 0; i < 30u; i++)  frame(57000u, 1, os, ZORG_COUNT);          /* over 45 ms (and in "slow" too) */

    ok(g_norm.frames == 100u && g_slow.frames == 230u && g_over45.frames == 30u, "the three buckets hold the frames with the world, by period");
    ok(g_noworld_frames == 501u, "the 501 menu frames are counted apart");
    { u32 h = 0u; for (i = 0; i < ZZ_NHIST; i++) h += g_hist[i]; ok(h == 330u, "the histogram holds the 330 frames with the world only"); }
    ok(g_fxframes[FXB_RUN] == 330u && g_fxframes[FXB_NORM] == 100u && g_fxframes[FXB_SLOW] == 230u && g_fxframes[FXB_OVER45] == 30u, "the counters by origin follow the same buckets");
    ok(g_pt.frames == 831u, "the run total still holds every frame");

    zz_rix_perf_report(rep, (int)sizeof rep);
    ok(strlen(rep) > 1000u && strlen(rep) < sizeof rep - 512u, "the performance report fits its buffer");
    ok(has(rep, "frames without the world (menu, console, loading), counted apart since build 84: 501 in "), "the report says how many frames had no world");
    ok(has(rep, "REPLAY 4"), "the replay has its own entity phase (about 4000 us)");
    ok(has(rep, "frames not shown (no display buffer free): 70 of 1000; engine pace over its last 8 frames: above 60/s 50 (the screen had no room), 50-60/s 12, 40-50/s 5, under 40/s 2, not known 1\n"),
       "build 91: the frames dropped at the presentation, by the engine's pace");
    ok(has(rep, " spr:quad 0") || has(rep, " sprite 4") , "the sprite's phase no longer holds the replay");
    ok(longest_line(rep) <= 220u, "performance report: no line over 220 characters");
    if (longest_line(rep) > 220u) printf("     longest line %u\n", longest_line(rep));

    {   /* the longest lines a real run can print: every number of a record at 99 999 */
        static zz_perf worst;
        u32 *w = (u32 *)&worst, k;
        for (k = 0; k < (u32)(sizeof worst / sizeof(u32)); k++) w[k] = 99999u;
        worst.frames = 1u;
        rep[0] = 0;
        period_line(rep, "  slow 25-100 ms", &worst);
        ok(longest_line(rep) <= 220u, "a period line with five digits everywhere: no line over 220 characters");
        if (longest_line(rep) > 220u) printf("     longest line %u\n", longest_line(rep));
        ok(has(rep, "REPLAY 99999\n"), "the replay's time ends its line whole");
    }
    big[0] = 0;
    for (i = 0; zz_rix_fx_report((int)i, rep, (int)sizeof rep); i++) {
        if (strlen(rep) >= sizeof rep - 1024u) { printf("FAIL bucket %u report is %u bytes\n", i, (unsigned)strlen(rep)); fails++; }
        strcat(big, rep);
    }
    ok(i == 4u, "four buckets reported (the run, normal, slow, over 45 ms)");
    ok(longest_line(big) <= 220u, "load by origin: no line over 220 characters");
    if (longest_line(big) > 220u) printf("     longest line %u\n", longest_line(big));
    ok(has(big, "load by origin, slow 25-100 ms: 230 frames"), "bucket header with its frame count");
    ok(has(big, "  S world      batches 310.0 tris in 5200 sent 2400 kpx opaque 512.0 blended 0.0 binds 41.0 pages 330 us 3000 of which GPU waits 1200\n"), "the world's line: batches, triangles in and sent, pixels, binds, pages, time and its waits");
    ok(has(big, "  O sprites    batches 12.0 tris in 24 sent 24 kpx opaque 0.0 blended 921.6 binds 5.0 pages 20"), "the sprites' three screens of blended pixels are on their line");
    ok(has(big, "  N TOTAL      batches 702.0 tris in 10384 sent 4884 kpx opaque 512.0 blended 1450.3 binds 59.0 pages 750 us 3000 of which GPU waits 1200 | screens covered 6.3"), "the total line and the screens covered");
    ok(has(big, "  S GL queue flushes x1000: end of frame 1000, order-dependent draw 1000,"), "flushes per bucket, times 1000");
    ok(has(big, "early (EARLY=1) 0\n  S batches replayed before the frame's end 300; order-dependent flushes forced by, x1000: sprites 1000\n"), "the batches replayed early and who forced it, on a line that is not cut");
    ok(has(big, "binds asked by ref_gl 204.0, distinct textures 59.0, GL queue replays 4000 us | engine: server 100"), "binds asked, distinct textures, replays, and the server's time");
    ok(has(big, "sound mix 700 us in 2.0 mixes"), "the sound mix and how often it runs");
    ok(!has(big, "other     "), "an origin that drew nothing has no line");
    ok(has(big, "  S sprite quads 12.0, with an empty margin the drawing mode cannot show 8.0: 40 % of their quad can show (SPRTRIM=0: drawn whole)"), "the sprites' empty margins, measured with the option off");
    {   /* the client's time: from the mark to the start of the scene, 2000 us plus a few timer readings */
        u32 cl = fxv(FXB_SLOW, ZFX_CL_US, 1u), sv = fxv(FXB_SLOW, ZFX_SV_US, 1u);
        ok(sv >= 1000u && sv < 1050u && cl >= 2000u && cl < 2050u, "server about 1000 us, client about 2000 us, as driven");
    }

    {   /* the waits of the frame under way, as the GL queue reads them */
        f_fr.dq_wait_us = 700u; f_fr.bind_wait_us = 50u;
        ok(zzhl_gpu_wait_us() == 750u, "the frame's GPU waits so far: the deferred queue's and the bind fences'");
        f_open = 0; ok(zzhl_gpu_wait_us() == 0u, "no frame open: no waits to read"); f_open = 1;
        f_fr.dq_wait_us = 0u; f_fr.bind_wait_us = 0u;
    }
    /* the bench bucket: only what is between begin and end, world frames only */
    zz_rix_bench_begin();
    for (i = 0; i < 50u; i++) frame(30000u, 1, os, ZORG_COUNT);
    for (i = 0; i < 3u; i++)  frame(9000u, 0, none, ZORG_COUNT);
    for (i = 0; i < 10u; i++) frame(50000u, 1, os, ZORG_COUNT);
    zz_rix_bench_end();
    for (i = 0; i < 20u; i++) frame(30000u, 1, os, ZORG_COUNT);
    zz_rix_bench_numbers(v);
    ok(v[0] == 60u, "bench: 60 frames with the world between begin and end");
    ok(v[1] > 33000u && v[1] < 33700u, "bench: average period (50 x 30 ms + 10 x 50 ms) / 60 = 33,3 ms");
    ok(v[2] >= 49800u && v[2] < 50100u && v[3] == 10u, "bench: longest frame 50 ms, 10 frames over 45 ms");
    ok(v[4] == 4884u && v[5] == 59u && v[6] == 512u && v[7] == 1450u, "bench: triangles, binds and thousands of pixels per frame");
    zz_rix_bench_report("save002 live", rep, (int)sizeof rep);
    ok(strlen(rep) > 800u && strlen(rep) < sizeof rep - 1024u, "bench report fits its buffer");
    ok(has(rep, "BENCH save002 live: frames 60 (and 3 without the world, left out), period 33"), "bench header: frames, the menu frames left out, the period");
    ok(has(rep, "frames over 25 ms 60, over 33 ms 10, over 45 ms 10"), "bench header: the frames over each limit");
    ok(has(rep, "  B sprites    batches 12.0 tris in 24 sent 24 kpx opaque 0.0 blended 921.6"), "bench: its own load by origin");
    ok(longest_line(rep) <= 220u, "bench report: no line over 220 characters");
    zz_rix_bench_begin(); zz_rix_bench_end();
    zz_rix_bench_report("empty", rep, (int)sizeof rep);
    ok(has(rep, "NOTHING MEASURED"), "a bench window without a frame says so");

    /* the price list */
    f_begins = f_verts = f_binds = f_teximg = f_swaps = f_clears = f_deleted = f_reads = 0u; f_bound = 0xFFFFFFFFu;
    f_step = 1u; f_gpu_us = 5000u;
    zz_rix_gpubench(rep, (int)sizeof rep);
    ok(strlen(rep) > 1500u && strlen(rep) < sizeof rep - 1024u, "price list fits its buffer");
    ok(longest_line(rep) <= 220u, "price list: no line over 220 characters");
    if (longest_line(rep) > 220u) printf("     longest line %u\n", longest_line(rep));
    ok(f_swaps == 2u * (u32)GBC_COUNT && f_clears == f_swaps + 2u * 2u * GB_LAYERS, "price list: every case drawn twice, each in a frame of its own with its clear (and the 4 extra clears of the two clear cases)");
    ok(f_teximg == 4u + 2u + 3u * 2u, "price list: 4 textures, and the pair of the bind cases at each of its 4 sizes");
    ok(f_deleted == 6u, "price list: its 6 textures deleted at the end");
    ok(f_reads == 2u && has(rep, "(read back: rejected)"), "price list: the rejected case reads a pixel back");
    /* Begin/End pairs: per run, fills 4+5+4+4+4+4+4+5+4+4+4 = 46, then 64 x 5, then 100 + 100 */
    ok(f_begins == 2u * (46u + 5u * 64u + 200u + 6u * (GB_SH_N / 20u)), "price list: the batches of every case add up (build 86: six shapes of 500 triangles, 20 a batch)");
    ok(f_px_on == 1, "price list: the pixel sums are switched back on");
    ok(has(rep, "a clears only") && has(rep, "s 2000 triangles of 32 px a side"), "price list: the 19 lines of build 84, a letter each");
    ok(has(rep, "  t 4 more depth clears") && has(rep, " us a depth clear\n") && has(rep, "  u 4 more colour clears") && has(rep, " us a colour clear\n"), "price list (build 86): a depth clear and a colour clear, each alone");
    ok(has(rep, "  v 500 x 1024 px: right-angled 32x64, left") && has(rep, " ns a triangle, box 2048 px\n") && has(rep, "  z 500 x 1024 px: diagonal sliver, 264x256") && has(rep, "  A 500 x 1024 px: the same, leaning back")
       && has(rep, " ns a triangle, box 67584 px\n"), "price list (build 86): six shapes of the same surface, with their boxes, the 27th line under the letter A");
    ok(has(rep, "  = same surface, box 33 times bigger: the diagonal sliver costs 1.0 times the right-angled triangle: the GPU pays for the surface, not the box\n"), "price list (build 86): equal times read as 'the surface'");
    ok(has(rep, "ns a triangle all included (1024 kpx in all)") && has(rep, "  = "), "price list: the triangle cases give a price per triangle, then the two are solved");
    {   /* the arithmetic, on times set by hand: 4 layers in 20 000 us over a 2 000 us clear = 4 500 us a screen */
        char line[400];
        u32 px4 = GB_LAYERS * 640u * 480u;
        u32 h = (u32)(((unsigned long long)18000u * 100000ull) / px4);
        sprintf(line, "%u.%u%u ns/px = 4500 us a screen", h / 100u, (h / 10u) % 10u, h % 10u);
        ok(h == 1464u && !strcmp(line, "14.64 ns/px = 4500 us a screen"), "price list: 18 000 us for 4 screens is 14,64 ns a pixel, 4 500 us a screen");
    }
    f_wait_rc = 7;
    zz_rix_gpubench(rep, (int)sizeof rep);
    ok(has(rep, "RIX price list: frame E0007 at case 0, stopped"), "price list: a frame that does not close stops the list and says where");
    f_wait_rc = 0;

    /* ---- the depth clears in the reports, ZCLEAR off: one a frame with the world, by the GPU ---- */
    big[0] = 0;
    for (i = 0; zz_rix_fx_report((int)i, rep, (int)sizeof rep); i++) strcat(big, rep);
    ok(has(big, "  S depth clears x1000: by the GPU 1000, skipped (the PL330 had cleared the buffer) 0; PL330 clears made late x1000 0, Core1 waited for the PL330 0 us\n"), "ZCLEAR off: the report counts one depth clear a frame, by the GPU");
    ok(!has(big, " box "), "BOXPX off: no box column");
    {   static char l[720];
        ok(zz_rix_zclear_test(0, l, (int)sizeof l) == 0 && has(l, "RIX: ZCLEAR=0, the GPU clears the depth at every frame (as build 85)\n") && f_hook == NULL, "ZCLEAR=0: said, nothing installed");
        ok(m_copies == 0u, "ZCLEAR=0: the PL330 is never started"); }

    /* ---- the self-test against the model: a good GPU passes, each defect is refused at its step ---- */
    f_wait_rc = 0; f_gpu_us = 3000u; f_step = 3u;
    m_reset(); m_dma_avail = 0;
    zt_run(0, "RIX: ZCLEAR=1 REFUSED, the GPU clears the depth as build 85. Step 0: no PL330", "self-test: no PL330, refused before anything is written");
    ok(m_z2[0] == 0x33 && m_far[0] == 0x33, "self-test without a PL330: the two blocks were not touched");
    m_reset(); m_dma_avail = 1; m_k_clear_fffe = 1;
    zt_run(0, "Step 1: the GPU's depth clear does not leave 0xFFFF words: 307840 differ, the first at word 0 = fffe", "self-test: a GPU whose cleared depth is not 0xFFFF is refused (step 1)");
    m_reset(); m_dma_avail = 1; m_k_dma_dead = 1;
    zt_run(0, "Step 2: the PL330's copy left 307840 words that are not 0xFFFF, the first at 0", "self-test: a PL330 that does not write the buffer is refused (step 2)");
    m_reset(); m_dma_avail = 1; m_k_dma_err = 1;
    zt_run(0, "Step 2: PL330 copy, step 10, FTR 00010000", "self-test: a PL330 that refuses the copy is refused (step 2)");
    m_reset(); m_dma_avail = 1; m_k_blind = 1;
    zt_run(0, "Step 3: a quad passed a depth buffer Core1 had filled with NEAR: the GPU does not test against the memory", "self-test: a GPU that ignores the memory is refused (step 3)");
    m_reset(); m_dma_avail = 1; m_k_dma_unseen = 1;
    zt_run(0, "Step 4: a quad did not pass a depth buffer the PL330 had filled with FAR: the GPU does not see the copy", "self-test: a GPU that does not see the PL330's writes is refused (step 4)");
    m_reset(); m_dma_avail = 1; m_k_no_zwrite = 1;
    zt_run(0, "Step 5: control: a quad behind the previous frame's passed without any clear", "self-test: a set-up where the depth test rejects nothing fails its control (step 5)");
    m_reset(); m_dma_avail = 1; m_k_sticky = 1;
    zt_run(0, "Step 6: a quad was rejected by the depth of the frame BEFORE the PL330's copy: the GPU keeps depth of its own", "self-test: a GPU that keeps the depth it wrote is refused (step 6)");
    m_reset(); m_dma_avail = 1; m_k_lazy = 1;
    zt_run(0, "Step 7: at its fence the frame's depth is not all in memory: 302736 pixels of the picture still read 0xFFFF", "self-test: a GPU whose depth reaches the memory after the fence is refused (step 7)");
    m_reset(); m_dma_avail = 1; m_k_ghost = 1;
    zt_run(0, "Step 8: the second depth buffer changed while the GPU drew on the first: 50 words are not 0xFFFF after the PL330's copy", "self-test: a GPU that writes a frame's depth late, during the next frame, is refused (step 8)");
    m_reset(); m_dma_avail = 1; m_k_late_copy = 5;
    zt_run(0, "Step 7: depth written by the GPU arrived AFTER its frame's fence: 37 words changed under the PL330's copy", "self-test: depth words landing after the fence are caught by the read-back (step 7)");
    m_reset(); m_dma_avail = 1; m_k_grey = 1;
    zt_run(0, "Step 4: the picture read back is neither the quad nor the background, centre pixel RGB 128 128 128", "self-test: a picture that is neither answer is refused and its colour said (step 4)");
    m_reset(); m_dma_avail = 1; f_wait_rc = 7;
    zt_run(0, "Step 1: frame E0007", "self-test: a frame that does not close is said so");
    f_wait_rc = 0;
    m_reset(); m_dma_avail = 1; m_k_clear_480 = 1;
    zt_run(1, "GPU clear = 0xFFFF words but line 481, PL330 615680 bytes in ", "self-test: a clear that leaves the 481st line alone is accepted, and said");
    m_reset(); m_dma_avail = 1;
    zt_run(1, "RIX: ZCLEAR=1 ON: depth cleared by the PL330 on two buffers (self-test ok: GPU clear = 0xFFFF words, PL330 615680 bytes in ", "self-test: a good GPU passes");
    ok(m_copies == 6u, "self-test: six copies (two timed, one before each of two frames, one at a fence, one while the GPU draws)");
    ok(g_zc.st[1] == ZC_DIRTY && g_zc.st[0] == ZC_DIRTY && g_zc.run < 0, "after the self-test: both buffers were drawn on, no copy runs");

    /* ---- ZCLEAR on, frames as the game makes them: without the overlap, then with it ---- */
    {
        u32 c0, k, cleans = 0u, z1 = 0u, z2 = 0u;
        g_overlap_req = 0;
        c0 = m_copies;
        zz_rix_bench_begin();
        for (k = 0; k < 40u; k++) { frame(30000u, 1, os, ZORG_COUNT); cleans += (u32)f_last_clean; if (f_last_zb == RIXQ2_ZBUF) z1++; else if (f_last_zb == RIXQ2_ZBUF2) z2++; }
        zz_rix_bench_end();
        ok(cleans == 40u && z1 == 20u && z2 == 20u, "ZCLEAR, no overlap: every frame finds its depth buffer clean, the two buffers alternate");
        ok(m_copies - c0 >= 40u && m_copies - c0 <= 42u, "ZCLEAR, no overlap: one PL330 copy a frame (and the late clear of the first frame on each buffer)");
        zz_rix_bench_report("zc", rep, (int)sizeof rep);
        ok(has(rep, "  B depth clears x1000: by the GPU 0, skipped (the PL330 had cleared the buffer) 1000; PL330 clears made late x1000 "), "ZCLEAR: the bench window says the depth clears were skipped");
        ok(longest_line(rep) <= 220u, "ZCLEAR: bench report, no line over 220 characters");
        g_overlap_req = 1;
        for (k = 0; k < 4u; k++) frame(30000u, 1, os, ZORG_COUNT);         /* the change of mode settles */
        c0 = m_copies; cleans = 0u; z1 = z2 = 0u;
        m_dma_busy_polls = 40u;                                             /* a copy now takes 40 polls to end */
        g_zc_waits = 0u;
        for (k = 0; k < 40u; k++) { frame(30000u, 1, os, ZORG_COUNT); cleans += (u32)f_last_clean; if (f_last_zb == RIXQ2_ZBUF) z1++; else z2++; }
        ok(cleans == 40u && z1 == 20u && z2 == 20u, "ZCLEAR, overlap (a frame pending): every frame clean, the buffers alternate");
        ok(m_copies - c0 == 40u, "ZCLEAR, overlap: one copy a frame");
        /* 39: the copy the first of these 40 frames met had been started before copies were made slow */
        ok(g_zc_waits == 39u && g_zc_late == 2u, "ZCLEAR: a frame that opens while its copy still runs waits for it; the only late clears were those of the first frame on each buffer");
        if (!(g_zc_waits == 39u && g_zc_late == 2u)) printf("     waits %u late %u\n", g_zc_waits, g_zc_late);
        m_dma_busy_polls = 0u;
        {   /* the presentation's guard: a copy is running when a picture is shown */
            (void)zc_poll();
            m_dma_busy_polls = 1000u;
            if (g_zc.run < 0 && g_zc.st[0] != ZC_CLEARING) { g_zc.st[0] = ZC_DIRTY; (void)zc_start(0u); }
            ok(m_dma_left != 0u && g_zc.run >= 0, "a copy is running");
            zzq2_present_rgb565(0, 0u);
            ok(m_dma_left == 0u && g_zc.run < 0, "the presentation waited for the depth copy before using the PL330");
            m_dma_busy_polls = 0u;
        }
        for (k = 0; k < 6u; k++) frame(30000u, 1, os, ZORG_COUNT);
        ok(f_last_clean == 1, "ZCLEAR: clean again after the guard's detour");
        /* a stray frame: something is drawn between two frames, on the pending frame's buffers */
        {
            u32 zb = 0u; int cl;
            cl = f_hook(&zb);                                               /* ZZGL opens a frame with no new target */
            ok(cl == 0, "a frame that opens without a new target (a stray draw) never counts on a clean depth buffer");
        }
        for (k = 0; k < 6u; k++) frame(30000u, 1, os, ZORG_COUNT);
        ok(f_last_clean == 1, "ZCLEAR: clean again after the stray frame");
        /* the PL330 refuses a copy in the middle of the run */
        m_dma_fail_at = m_copies + 3u;
        for (k = 0; k < 12u; k++) frame(30000u, 1, os, ZORG_COUNT);
        ok(!g_zc.on && f_last_clean == 0 && g_zc_fail_code == 1u, "a copy refused in the middle of the run: ZCLEAR stops, the GPU clears again");
        c0 = m_copies;
        for (k = 0; k < 10u; k++) frame(30000u, 1, os, ZORG_COUNT);
        ok(m_copies == c0 && f_last_clean == 0, "after the stop: no copy is ever started again");
        zz_rix_perf_report(rep, (int)sizeof rep);
        ok(has(rep, "RIX: ZCLEAR=1 ON: depth cleared by the PL330") && has(rep, "depth clears by the PL330: ") && has(rep, "*** ZCLEAR STOPPED at frame ") && has(rep, ": the PL330 refused a copy, E000000e2; the GPU cleared the depth from there on\n"),
           "the exit report says the self-test's verdict again, the copies, and the stop with its code");
        ok(longest_line(rep) <= 220u, "exit report with ZCLEAR: no line over 220 characters");
        if (longest_line(rep) > 220u) printf("     longest line %u\n", longest_line(rep));
        ok(m_bad == 0u, "never a copy over a depth buffer a frame still used, never a picture that found the PL330 busy");
        g_overlap_req = 0;
    }
    /* BOXPX=1: the box column */
    zz_rix_set_boxpx(1);
    os[ZORG_WORLD].px_box = 1536000.0f;
    zz_rix_bench_begin();
    for (i = 0; i < 5u; i++) frame(30000u, 1, os, ZORG_COUNT);
    zz_rix_bench_end();
    zz_rix_bench_report("box", rep, (int)sizeof rep);
    ok(f_box_on == 1 && has(rep, "pages 330 us 3000 of which GPU waits 1200 box 1536.0\n") && has(rep, " box 1536.0 | screens covered "), "BOXPX=1: the box pixels by origin and in the total");
    ok(longest_line(rep) <= 220u, "BOXPX=1: no line over 220 characters");
    zz_rix_set_boxpx(0); os[ZORG_WORLD].px_box = 0.0f;

    /* WALKSTAT=1 and BOXFIT in the reports */
    zz_rix_set_walkstat(1); zz_rix_set_boxfit(2);
    os[ZORG_WORLD].wk_desc = 600u; os[ZORG_WORLD].wk_clocks = 800000u; os[ZORG_WORLD].wk_far = 200000u; os[ZORG_WORLD].wk_end = 100000u; os[ZORG_WORLD].wk_lines = 30000u; os[ZORG_WORLD].wk_empty = 1500u;
    os[ZORG_LIGHTMAP].wk_desc = 700u; os[ZORG_LIGHTMAP].wk_clocks = 900000u; os[ZORG_LIGHTMAP].wk_far = 250000u; os[ZORG_LIGHTMAP].wk_end = 110000u; os[ZORG_LIGHTMAP].wk_lines = 33000u; os[ZORG_LIGHTMAP].wk_empty = 1700u;
    f_bf_lines = 2950u; f_bf_dropped = 120u;
    zz_rix_bench_begin();
    for (i = 0; i < 5u; i++) frame(30000u, 1, os, ZORG_COUNT);
    zz_rix_bench_end();
    zz_rix_bench_report("walk", rep, (int)sizeof rep);
    ok(f_walk_on == 1 && has(rep, "  B walk world      desc 600 kclocks 800.0 far 200.0 ends 100.0 lines 30000 empty 1500\n")
       && has(rep, "  B walk TOTAL      desc 1300 kclocks 1700.0 far 450.0 ends 210.0 lines 63000 empty 3200\n"), "WALKSTAT=1: the rasteriser's clocks by origin and in total");
    /* 1 700 000 clocks x 10.04 ns = 17 068 us, + 1300 descriptors x 1.456 us = 1 892 us; far 450 000 -> 4 518 us; ends 210 000 -> 2 108 us */
    ok(has(rep, "  B rasteriser, by its model: 18960 us a frame (10.04 ns a clock + 1.46 us a descriptor); 4518 us on lines that ran to the end of their box, 2108 us on lines before the first / after the last pixel\n"),
       "WALKSTAT=1: the model's time for the frame, and what the two kinds of wasted lines cost");
    ok(has(rep, "  B box fit (BOXFIT=2): lines without a pixel taken off the boxes 2950 a frame, triangles not sent because their box held no pixel 120 a frame\n"), "BOXFIT: what was taken off, per frame");
    ok(longest_line(rep) <= 220u, "WALKSTAT + BOXFIT: no line over 220 characters");
    if (longest_line(rep) > 220u) printf("     longest line %u\n", longest_line(rep));
    zz_rix_set_reject(1); os[ZORG_DECAL].batches = 577u; os[ZORG_DECAL].tris_in = 4120u; os[ZORG_DECAL].tris = 303u; os[ZORG_DECAL].tris_rej = 3700u;
    zz_rix_bench_begin();
    for (i = 0; i < 5u; i++) frame(30000u, 1, os, ZORG_COUNT);
    zz_rix_bench_end();
    zz_rix_bench_report("rej", rep, (int)sizeof rep);
    ok(f_reject_on == 1 && has(rep, "  B decals     batches 577.0 tris in 4120 sent 303 ") && has(rep, " of which GPU waits 0 rej 3700\n") && has(rep, " rej 3700 | screens covered "),
       "REJECT=1: the triangles of the batches dropped whole, by origin and in total");
    ok(longest_line(rep) <= 220u, "WALKSTAT + BOXFIT + REJECT: no line over 220 characters");
    {   /* the startup check of the rejection test decides: anything wrong, and REJECT is off */
        unsigned nb = 0, no = 0, bad;
        f_reject_bad = 0u; bad = zz_rix_reject_check(&nb, &no);
        ok(bad == 0u && nb == 4000u && no == 1900u && zz_rix_reject() == 1 && f_reject_on == 1, "REJECT: a clean startup check leaves it on");
        f_reject_bad = 3u; bad = zz_rix_reject_check(&nb, &no);
        ok(bad == 3u && zz_rix_reject() == 0 && f_reject_on == 0, "REJECT: a startup check that finds 3 batches wrong turns it off");
        {   /* CULLEARLY */
            unsigned nt = 0, nc = 0, b2;
            static char rep2[65536];
            zz_rix_set_cull_early(1);
            ok(zz_rix_cull_early() == 1 && f_ec_on == 1 && f_ec_mask == ((1u << ZORG_STUDIO) | (1u << ZORG_VIEWMODEL)), "CULLEARLY=1: the models and the weapon in hand only");
            zz_rix_set_cull_early(2);
            ok(zz_rix_cull_early() == 2 && f_ec_on == 2 - 0 && f_ec_mask == ~0u, "CULLEARLY=2: every origin");
            f_ec_bad = 0u; b2 = zz_rix_cull_early_check(&nt, &nc);
            ok(b2 == 0u && nt == 5000u && nc == 3029u && zz_rix_cull_early() == 2, "CULLEARLY: a clean startup check leaves it on");
            rep2[0] = 0; zz_rix_perf_report(rep2, (int)sizeof rep2);
            ok(has(rep2, "CULLEARLY=2: back faces dropped before their set-up 123456 over the run\n"), "CULLEARLY: the report says how many triangles it dropped");
            f_ec_bad = 7u; b2 = zz_rix_cull_early_check(&nt, &nc);
            ok(b2 == 7u && zz_rix_cull_early() == 0 && f_ec_on == 0, "CULLEARLY: a startup check that finds 7 triangles different turns it off");
            rep2[0] = 0; zz_rix_perf_report(rep2, (int)sizeof rep2);
            ok(!has(rep2, "CULLEARLY="), "CULLEARLY off: no line in the report");
            f_ec_bad = 0u;
        }
        f_reject_bad = 0u;
    }
    zz_rix_set_reject(0);
    {   /* the hook EARLY=2 listens to gets each frame's "GPU idle, nothing queued" */
        extern void zz_rix_set_starved_hook(void (*fn)(unsigned us));
        g_t89_n = 0;
        zz_rix_set_starved_hook(t89_hook);
        f_starved = 5221u; frame(30000u, 1, os, ZORG_COUNT);
        f_starved = 0u;    frame(30000u, 1, os, ZORG_COUNT);
        zz_rix_set_starved_hook(0);
        f_starved = 777u;  frame(30000u, 1, os, ZORG_COUNT);
        ok(g_t89_n == 2 && g_t89_v[0] == 5221u && g_t89_v[1] == 0u, "build 89: the starved hook gets 5221 us then 0, and nothing once it is taken away");
    }
    zz_rix_set_walkstat(0); zz_rix_set_boxfit(0); f_bf_lines = f_bf_dropped = 0u;
    memset(os, 0, sizeof os);
    big[0] = 0;
    zz_rix_bench_begin(); for (i = 0; i < 3u; i++) frame(30000u, 1, os, ZORG_COUNT); zz_rix_bench_end();
    zz_rix_bench_report("plain", rep, (int)sizeof rep);
    ok(!has(rep, " walk ") && !has(rep, "box fit") && !has(rep, "rasteriser, by its model") && !has(rep, " rej "), "WALKSTAT, BOXFIT and REJECT off: none of their lines");

    if (getenv("ZZHL_DUMP")) {
        /* a log as the A4000 would give it, for tools/perf/zzhl_benchcmp.py (tests/run_host_tests.sh
           reads it back): the price list, one bench window with BOXPX, the summary */
        FILE *o = fopen(getenv("ZZHL_DUMP"), "w");
        if (o) {
            static char l[720];
            m_reset(); m_dma_avail = 1; m_on = 1; m_selftest = 1;
            zzgl_set_zbuf_hook(0); zclear_init(&g_zc); g_zc_hooked = 0; zzhl_dma_guard = 0;
            (void)zz_rix_zclear_test(1, l, (int)sizeof l); m_selftest = 0;
            fprintf(o, "\033[0m[18:00:00] %s", l);
            f_step = 1u; f_gpu_us = 5000u;
            zz_rix_gpubench(rep, (int)sizeof rep); fputs(rep, o);
            f_step = 3u; f_gpu_us = 0u;
            memset(os, 0, sizeof os);
            os[ZORG_WORLD].batches = 213u; os[ZORG_WORLD].tris_in = 619u; os[ZORG_WORLD].tris = 591u; os[ZORG_WORLD].px_opaque = 512000.0f;
            os[ZORG_LIGHTMAP].batches = 271u; os[ZORG_LIGHTMAP].tris_in = 761u; os[ZORG_LIGHTMAP].tris = 732u; os[ZORG_LIGHTMAP].px_blend = 498000.0f;
            os[ZORG_DECAL].batches = 577u; os[ZORG_DECAL].tris_in = 4120u; os[ZORG_DECAL].tris = 303u; os[ZORG_DECAL].tris_rej = 3700u; os[ZORG_DECAL].px_blend = 58000.0f;
            zz_rix_set_boxpx(1); os[ZORG_WORLD].px_box = 1536000.0f; os[ZORG_LIGHTMAP].px_box = 1494000.0f;
            zz_rix_set_walkstat(1); zz_rix_set_boxfit(2); zz_rix_set_reject(1); f_bf_lines = 2950u; f_bf_dropped = 120u;
            os[ZORG_WORLD].wk_desc = 600u; os[ZORG_WORLD].wk_clocks = 800000u; os[ZORG_WORLD].wk_far = 200000u; os[ZORG_WORLD].wk_end = 100000u; os[ZORG_WORLD].wk_lines = 30000u; os[ZORG_WORLD].wk_empty = 1500u;
            os[ZORG_LIGHTMAP].wk_desc = 700u; os[ZORG_LIGHTMAP].wk_clocks = 900000u; os[ZORG_LIGHTMAP].wk_far = 250000u; os[ZORG_LIGHTMAP].wk_end = 110000u; os[ZORG_LIGHTMAP].wk_lines = 33000u; os[ZORG_LIGHTMAP].wk_empty = 1700u;
            for (i = 0; i < 4u; i++) frame(30000u, 1, os, ZORG_COUNT);
            zz_rix_bench_begin();
            for (i = 0; i < 20u; i++) frame(30000u, 1, os, ZORG_COUNT);
            zz_rix_bench_end();
            zz_rix_bench_report("save009 frozen c2a5f", rep, (int)sizeof rep); fputs(rep, o);
            zz_rix_bench_numbers(v);
            fprintf(o, "BENCH SUMMARY, 6 s windows, EARLY=0 F2B=0 SPRTRIM=0 SORT=1 DECALQ=2 RING=1 PUMP=32 PIPE=1 ZCLEAR=%d BOXFIT=%d REJECT=%d BOXPX=1 WALKSTAT=1 DEV=-1\n", zz_rix_zclear_on(), zz_rix_boxfit(), zz_rix_reject());
            fprintf(o, "BENCH = a %-28s: %4u frames, %6u us, %2u.%u img/s, longest %6u us, over 45 ms %3u | %5u tris, %3u binds, %5u kpx opaque, %5u kpx blended\n",
                    "save009 frozen c2a5f", v[0], v[1], v[1] ? 10000000u / v[1] / 10u : 0u, v[1] ? (10000000u / v[1]) % 10u : 0u, v[2], v[3], v[4], v[5], v[6], v[7]);
            fclose(o);
        }
    }
    printf(fails ? "GPUREPORT TESTS FAILED (%d)\n" : "GPUREPORT ALL TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
