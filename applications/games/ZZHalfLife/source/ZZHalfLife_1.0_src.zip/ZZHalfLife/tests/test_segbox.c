/* A valid segment-box intersection must never be rejected; compare against dense reference sampling. */
#include <stdio.h>
#include <stdlib.h>

int zzhl_seg_box( const float *p0, const float *p1, const float *bmin, const float *bmax );

static unsigned s_rng = 12345u;
static float frnd( float lo, float hi )
{
	s_rng = s_rng * 1103515245u + 12345u;
	return lo + ( hi - lo ) * (float)(( s_rng >> 8 ) & 0xFFFFFF ) / (float)0x1000000;
}

int main( void )
{
	const int ITER = 400000, SAMPLES = 2000;
	int it, k, bad = 0, kept = 0, rejected = 0;

	for( it = 0; it < ITER; it++ )
	{
		float p0[3], p1[3], bmin[3], bmax[3];
		int i, inside = 0, said;

		for( i = 0; i < 3; i++ )
		{
			float c = frnd( -200.0f, 200.0f ), h = frnd( 0.5f, 60.0f );
			bmin[i] = c - h; bmax[i] = c + h;
			p0[i] = frnd( -400.0f, 400.0f );
			p1[i] = frnd( -400.0f, 400.0f );
		}
		said = zzhl_seg_box( p0, p1, bmin, bmax );
		if( said ) kept++; else rejected++;

		for( k = 0; k <= SAMPLES && !inside; k++ )
		{
			const float t = (float)k / (float)SAMPLES;
			const float x = p0[0] + ( p1[0] - p0[0] ) * t;
			const float y = p0[1] + ( p1[1] - p0[1] ) * t;
			const float z = p0[2] + ( p1[2] - p0[2] ) * t;
			if( x >= bmin[0] && x <= bmax[0] && y >= bmin[1] && y <= bmax[1]
			 && z >= bmin[2] && z <= bmax[2] ) inside = 1;
		}
		if( inside && !said )
		{
			if( bad < 5 )
				printf( "SEGBOX FAIL: segment touches the box but was rejected\n"
				        "  p0 %.3f %.3f %.3f  p1 %.3f %.3f %.3f\n"
				        "  box %.3f %.3f %.3f .. %.3f %.3f %.3f\n",
				        p0[0], p0[1], p0[2], p1[0], p1[1], p1[2],
				        bmin[0], bmin[1], bmin[2], bmax[0], bmax[1], bmax[2] );
			bad++;
		}
	}
	printf( "SEGBOX: %d cases, kept %d, rejected %d (%d%% of the hull traces saved), "
	        "false rejections %d\n", ITER, kept, rejected, rejected * 100 / ITER, bad );
	if( bad ) { printf( "SEGBOX: FAILED\n" ); return 1; }
	printf( "SEGBOX ALL TESTS PASSED\n" );
	return 0;
}
