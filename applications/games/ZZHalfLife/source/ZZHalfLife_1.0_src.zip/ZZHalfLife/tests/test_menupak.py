#!/usr/bin/env python3
# test_menupak.py - ZZHalfLife: hl_pak.py --menu on a made-up install (build 52).  The install has
# a 21:9 HD background (three tiles, red, green and blue, bright top half), Steam's black 800_
# set and other files; pak1.pak must hold the background made by hl_menubg.py (our layout, four
# tiles of 512 x 384: the middle 4:3 part, in the right place and the right way up), the two free
# fonts and the port's own gfx/shell pictures of tools/menu, nothing of the install as it is.
#   python3 tests/test_menupak.py [work dir]   ASCII only.
import os, shutil, struct, subprocess, sys
here = os.path.dirname(os.path.abspath(__file__))
tools = os.path.join(here, '..', 'tools')
sys.path.insert(0, tools)
import hl_chapters as hc
from hl_loading import tga_decode
work = sys.argv[1] if len(sys.argv) > 1 else '/tmp/zzhl_menupak'
shutil.rmtree(work, ignore_errors=True)
v = os.path.join(work, 'valve')

def tga(w, h, colour_top, colour_bottom, bottom_first=True):
    hdr = struct.pack('<BBBHHBHHHHBB', 0, 0, 2, 0, 0, 0, 0, 0, w, h, 24, 0 if bottom_first else 0x20)
    rows = [bytes(colour_top[::-1]) * w if y < h // 2 else bytes(colour_bottom[::-1]) * w for y in range(h)]   # BGR
    return hdr + b''.join(rows[::-1] if bottom_first else rows)

files = {
    'resource/HD_BackgroundLayout.txt': b'resolution 840 360\n"resource/background/21_9_1_a_loading.tga" scaled 0 0\n'
                                        b'"resource/background/21_9_1_b_loading.tga" scaled 280 0\n"resource/background/21_9_1_c_loading.tga" scaled 560 0\n',
    'resource/background/21_9_1_a_loading.tga': tga(280, 360, (250, 0, 0), (120, 0, 0)),
    'resource/background/21_9_1_b_loading.tga': tga(280, 360, (0, 250, 0), (0, 120, 0), bottom_first=False),
    'resource/background/21_9_1_c_loading.tga': tga(280, 360, (0, 0, 250), (0, 0, 120)),
    'resource/BackgroundLayout.txt': b'resolution 800 600\nresource/background/800_1_a_loading.tga scaled 0 0\n',
    'resource/background/800_1_a_loading.tga': tga(256, 256, (0, 0, 0), (0, 0, 0)),
    'resource/logo.tga': b'l' * 50, 'maps/c0a0.bsp': b'm' * 70, 'gfx/shell/head_load.tga': b'h' * 40}
for n, d in files.items():
    p = os.path.join(v, n); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, 'wb').write(d)
out = os.path.join(work, 'out', 'pak1.pak'); os.makedirs(os.path.dirname(out))
r = subprocess.run([sys.executable, os.path.join(tools, 'hl_pak.py'), '--menu', v, out], capture_output=True, text=True)
print(r.stdout[-1500:]); print(r.stderr[-800:])
pak = hc.Pak([out])
menu = os.path.join(tools, 'menu')
shipped = {}                                   # name in the pak -> file of tools/menu
for root, dirs, fs in os.walk(menu):
    for f in fs:
        rel = os.path.relpath(os.path.join(root, f), menu).replace('\\', '/')
        if '/' in rel: shipped[rel.lower()] = os.path.join(root, f)
tiles = ['resource/background/zzhl_menu_%s.tga' % t for t in ('1_a', '1_b', '2_a', '2_b')]
want = set(shipped) | {'resource/backgroundlayout.txt'} | set(tiles)
fails = 0
def check(ok, what):
    global fails
    print(('ok: ' if ok else 'FAIL: ') + what)
    if not ok: fails += 1
check(r.returncode == 0 and os.path.exists(out[:-4] + '.crc'), 'hl_pak.py --menu ran, pak1.crc written')
check(set(pak.idx) == want, 'pak1.pak: our background, the fonts and gfx/shell of tools/menu, nothing of the install as it is')
check(any(n.startswith('gfx/shell/cb_') for n in pak.idx) and 'gfx/shell/slider.tga' in pak.idx, 'check boxes and slider in pak1')
check(all(pak.read(n) == open(f, 'rb').read() for n, f in shipped.items()), 'fonts and pictures equal to tools/menu')
lay = pak.read('resource/backgroundlayout.txt').decode('latin-1')
check('resolution 512 384' in lay and all(('%s scaled' % t) in lay for t in tiles), 'layout: 512 x 384, the four tiles')
check('hd_backgroundlayout.txt' in lay.lower(), 'layout made from the HD set, not the black 800_ one')
pics = {}
for t in tiles:
    d = pak.read(t)
    check(d[2] == 2 and d[16] == 24 and not d[17] & 0x20, '%s: 24-bit TGA, bottom line first (mainui: PIC_NOFLIP_TGA)' % t)
    pics[t] = tga_decode(d)
sizes = [(pics[t][0], pics[t][1]) for t in tiles]
check(sizes == [(256, 256), (256, 256), (256, 128), (256, 128)], 'tile sizes 256x256 twice, 256x128 twice: %s' % sizes)
def px(t, x, y):
    w, h, n, p = pics[t]; o = (y * w + x) * n
    return p[o + 2], p[o + 1], p[o]          # R G B
# middle 4:3 of 840 x 360: x 180..660 -> red 180-280, green 280-560, blue 560-660, scaled to 512
r_, g_, b_ = px(tiles[0], 20, 20), px(tiles[0], 250, 20), px(tiles[1], 230, 20)
check(r_[0] > 200 and r_[1] < 30 and g_[1] > 200 and g_[0] < 30 and b_[2] > 200 and b_[1] < 30, 'the middle 4:3 part: red, green, blue left to right %s %s %s' % (r_, g_, b_))
top, bottom = px(tiles[0], 128, 10), px(tiles[2], 128, 100)
check(top[1] > 200 and 100 < bottom[1] < 140, 'the right way up: the bright half on top (green column) %s %s' % (top, bottom))
print('ALL TESTS PASSED' if not fails else 'SOME TESTS FAILED')
sys.exit(1 if fails else 0)
