/* test_glq.c - ZZHalfLife host test of the draw queue (xacp_glq.c) and the GL shim (xacp_gl.c)
 * over a mock ZZGL that logs every call.  Checks: pass-through order with SORT=0; with SORT=1
 * the texture-sorted replay, the lightmap pass moved after the opaque group, the state and
 * matrices applied per batch and restored after, the flush points (blended draw, texture
 * update of a queued texture, depth range, 2D), BINDTEST, PICMIP.
 * Build and run: tests/run_host_tests.sh
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "zzgl.h"
#include "xacp_glq.h"
#include "zzhl_fx.h"

/* ---- the mock ZZGL: a log of calls, matrix stacks for GetFloatv ---- */
static char g_log[4000000];
static int g_logn;
static void L( const char *fmt, ... ) __attribute__((format(printf, 1, 2)));
#include <stdarg.h>
static void L( const char *fmt, ... )
{
	va_list ap; int n;
	if( g_logn + 256 >= (int)sizeof( g_log )) { printf( "FAIL mock log full\n" ); exit( 2 ); }
	va_start( ap, fmt );
	n = vsnprintf( g_log + g_logn, sizeof( g_log ) - g_logn - 2, fmt, ap );
	va_end( ap );
	if( n > 0 ) g_logn += n;
	g_log[g_logn++] = '\n';
	g_log[g_logn] = 0;
}
static float g_mv[8][16], g_pr[8][16];
static int g_mvt, g_prt, g_mode = ZGL_MODELVIEW;
static float g_cs, g_ct; static unsigned char g_cc[4];
static const float IDENT[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
static float *cur( void ) { return g_mode == ZGL_PROJECTION ? g_pr[g_prt] : g_mv[g_mvt]; }
void zzglMatrixMode( u32 m ) { g_mode = m; }
void zzglLoadIdentity( void ) { memcpy( cur(), IDENT, 64 ); }
void zzglLoadMatrixf( const float *m ) { memcpy( cur(), m, 64 ); L( "LOADM %s %g %g %g", g_mode == ZGL_PROJECTION ? "P" : "MV", m[12], m[13], m[15] ); }
void zzglMultMatrixf( const float *m ) { float *c = cur(), r[16]; int i, j, k; for( i = 0; i < 4; i++ ) for( j = 0; j < 4; j++ ) { float s = 0; for( k = 0; k < 4; k++ ) s += c[k * 4 + j] * m[i * 4 + k]; r[i * 4 + j] = s; } memcpy( c, r, 64 ); }
void zzglPushMatrix( void ) { if( g_mode == ZGL_PROJECTION ) { memcpy( g_pr[g_prt + 1], g_pr[g_prt], 64 ); g_prt++; } else { memcpy( g_mv[g_mvt + 1], g_mv[g_mvt], 64 ); g_mvt++; } }
void zzglPopMatrix( void ) { if( g_mode == ZGL_PROJECTION ) g_prt--; else g_mvt--; }
void zzglTranslatef( float x, float y, float z ) { float m[16]; memcpy( m, IDENT, 64 ); m[12] = x; m[13] = y; m[14] = z; zzglMultMatrixf( m ); }
void zzglScalef( float x, float y, float z ) { float m[16]; memcpy( m, IDENT, 64 ); m[0] = x; m[5] = y; m[10] = z; zzglMultMatrixf( m ); }
void zzglRotatef( float a, float x, float y, float z ) { (void)a; (void)x; (void)y; (void)z; }
void zzglOrtho( double l, double r, double b, double t, double n, double f ) { float m[16]; memset( m, 0, 64 ); m[0] = (float)( 2.0 / ( r - l )); m[5] = (float)( 2.0 / ( t - b )); m[10] = (float)( -2.0 / ( f - n )); m[15] = 1.0f; zzglMultMatrixf( m ); }
void zzglFrustum( double l, double r, double b, double t, double n, double f ) { float m[16]; memset( m, 0, 64 ); m[0] = (float)( 2.0 * n / ( r - l )); m[5] = (float)( 2.0 * n / ( t - b )); m[10] = (float)( -( f + n ) / ( f - n )); m[11] = -1.0f; m[14] = (float)( -2.0 * f * n / ( f - n )); zzglMultMatrixf( m ); }
void zzglGetFloatv( u32 pname, float *p ) { if( pname == ZGL_MODELVIEW_MATRIX ) memcpy( p, g_mv[g_mvt], 64 ); else if( pname == ZGL_PROJECTION_MATRIX ) memcpy( p, g_pr[g_prt], 64 ); }
void zzglGetIntegerv( u32 pname, s32 *p ) { *p = pname == ZGL_MAX_TEXTURE_SIZE ? 256 : 0; }
void zzglViewport( s32 x, s32 y, s32 w, s32 h ) { L( "VIEWPORT %d %d %d %d", x, y, w, h ); }
void zzglDepthRange( double n, double f ) { L( "DEPTHRANGE %g %g", n, f ); }
void zzglScissor( s32 x, s32 y, s32 w, s32 h ) { L( "SCISSOR %d %d %d %d", x, y, w, h ); }
void zzglEnable( u32 cap ) { L( "EN %x", cap ); }
void zzglDisable( u32 cap ) { L( "DIS %x", cap ); }
void zzglDepthFunc( u32 f ) { L( "DF %x", f ); }
void zzglDepthMask( u32 m ) { L( "DM %u", m ); }
void zzglBlendFunc( u32 s, u32 d ) { L( "BF %x %x", s, d ); }
void zzglAlphaFunc( u32 f, float r ) { L( "AF %x %g", f, r ); }
void zzglColorMask( u32 r, u32 g, u32 b, u32 a ) { L( "CM %u", r || g || b || a ); }
void zzglCullFace( u32 m ) { L( "CULL %x", m ); }
void zzglFrontFace( u32 m ) { L( "FF %x", m ); }
void zzglShadeModel( u32 m ) { L( "SM %x", m ); }
void zzglPolygonMode( u32 f, u32 m ) { (void)f; L( "PM %x", m ); }
void zzglTexEnvf( u32 t, u32 p, float v ) { (void)t; (void)p; L( "ENV %x", (unsigned)v ); }
void zzglHint( u32 t, u32 m ) { (void)t; (void)m; }
void zzglDrawBuffer( u32 m ) { (void)m; }
void zzglReadBuffer( u32 m ) { (void)m; }
void zzglClearColor( float r, float g, float b, float a ) { (void)r; (void)g; (void)b; (void)a; }
void zzglClearDepth( double d ) { (void)d; }
void zzglClear( u32 mask ) { L( "CLEAR %x", mask ); }
void zzglFinish( void ) { L( "FINISH" ); }
void zzglFlush( void ) { L( "FLUSH" ); }
u32  zzglGetError( void ) { return 0; }
void xacp_loading_tick( void ) { }   /* xacp_loading.c (build 22): not part of this test */
const unsigned char *zzglGetString( u32 n ) { (void)n; return (const unsigned char *)""; }
void zzglReadPixels( s32 x, s32 y, s32 w, s32 h, u32 f, u32 t, void *p ) { (void)x; (void)y; (void)w; (void)h; (void)f; (void)t; (void)p; L( "READPIXELS" ); }
static int g_gen_fail;
void zzglGenTextures( s32 n, u32 *t ) { static u32 next = 1; s32 i; for( i = 0; i < n; i++ ) t[i] = g_gen_fail ? 0u : next++; }
void zzglDeleteTextures( s32 n, const u32 *t ) { s32 i; for( i = 0; i < n; i++ ) L( "DELTEX %u", t[i] ); }
static u32 g_bound, g_bound_sent = 0xFFFFFFFFu;
void zzglBindTexture( u32 t, u32 n ) { (void)t; g_bound = n; }   /* as ZZGL: the bind is sent at the next Begin if it changed */
void zzglTexParameterf( u32 t, u32 p, float v ) { (void)t; L( "TEXPARAM %x %g", p, v ); }
void zzglTexImage2D( u32 t, s32 level, s32 i, s32 w, s32 h, s32 b, u32 f, u32 ty, const void *px ) { (void)t; (void)i; (void)b; (void)f; (void)ty; L( "TEXIMAGE tex %u level %d %dx%d first %u", g_bound, level, w, h, px ? ((const unsigned char *)px)[0] : 999u ); }
void zzglTexSubImage2D( u32 t, s32 level, s32 x, s32 y, s32 w, s32 h, u32 f, u32 ty, const void *px ) { (void)t; (void)f; (void)ty; (void)px; L( "TEXSUB tex %u level %d %d,%d %dx%d", g_bound, level, x, y, w, h ); }
void zzglColor3f( float r, float g, float b ) { zzglColor4f( r, g, b, 1 ); }
void zzglColor3fv( const float *v ) { zzglColor4f( v[0], v[1], v[2], 1 ); }
void zzglColor4f( float r, float g, float b, float a ) { g_cc[0] = (unsigned char)( r * 255 + 0.5f ); g_cc[1] = (unsigned char)( g * 255 + 0.5f ); g_cc[2] = (unsigned char)( b * 255 + 0.5f ); g_cc[3] = (unsigned char)( a * 255 + 0.5f ); }
void zzglColor4fv( const float *v ) { zzglColor4f( v[0], v[1], v[2], v[3] ); }
void zzglColor3ubv( const unsigned char *v ) { g_cc[0] = v[0]; g_cc[1] = v[1]; g_cc[2] = v[2]; g_cc[3] = 255; }
void zzglColor4ubv( const unsigned char *v ) { memcpy( g_cc, v, 4 ); }
void zzglTexCoord2f( float s, float t ) { g_cs = s; g_ct = t; }
void zzglTexCoord2fv( const float *v ) { g_cs = v[0]; g_ct = v[1]; }
static int g_inb, g_nv;
static u32 g_bmode;                    /* the mode of the Begin in progress */
static unsigned g_wait_us;
void zzglBegin( u32 mode ) { g_wait_us += 3u; if( g_bound != g_bound_sent ) { L( "BIND %u", g_bound ); g_bound_sent = g_bound; } L( "BEGIN %x", mode ); g_inb = 1; g_nv = 0; g_bmode = mode; }
/* the triangles ZZGL would draw from a Begin( ZGL_TRIANGLES ), as text: three vertices each */
static char g_tlog[600000]; static int g_tlogn;
static char g_vs[64][160];
static void tri_log( int a, int b, int c ) { if( g_tlogn < (int)sizeof( g_tlog ) - 600 ) g_tlogn += snprintf( g_tlog + g_tlogn, 600, "T %s | %s | %s\n", g_vs[a], g_vs[b], g_vs[c] ); }
void zzglEnd( void ) { if( g_bmode == ZGL_TRIANGLES ) { int i; for( i = 0; i + 2 < g_nv && i + 2 < 64; i += 3 ) tri_log( i, i + 1, i + 2 ); } L( "END %d", g_nv ); g_inb = 0; }
void zzglEndIndexed( const unsigned char *idx, u32 n ) { u32 i; for( i = 0; i + 2u < n; i += 3u ) if( idx[i] < g_nv && idx[i + 1u] < g_nv && idx[i + 2u] < g_nv ) tri_log( idx[i], idx[i + 1u], idx[i + 2u] ); L( "ENDX %d %u", g_nv, n ); g_inb = 0; }
static void vtx( float x, float y, float z )
{
	float m[16], p[16], ox, oy, oz, ow; int i;
	memcpy( m, g_mv[g_mvt], 64 ); memcpy( p, g_pr[g_prt], 64 );
	/* clip = P * MV * v, written compactly: only the translation matters for the checks */
	ox = m[0] * x + m[4] * y + m[8] * z + m[12]; oy = m[1] * x + m[5] * y + m[9] * z + m[13]; oz = m[2] * x + m[6] * y + m[10] * z + m[14]; ow = m[3] * x + m[7] * y + m[11] * z + m[15];
	(void)i;
	L( "V %g %g %g w%g st %g %g c %u %u %u %u tex %u", ox, oy, oz, ow, g_cs, g_ct, g_cc[0], g_cc[1], g_cc[2], g_cc[3], g_bound );
	if( g_nv < 64 ) snprintf( g_vs[g_nv], sizeof( g_vs[0] ), "%.9g %.9g %.9g %.9g st %.9g %.9g c %u %u %u %u tex %u", ox, oy, oz, ow, g_cs, g_ct, g_cc[0], g_cc[1], g_cc[2], g_cc[3], g_bound );
	g_nv++;
}
void zzglVertex2f( float x, float y ) { vtx( x, y, 0 ); }
void zzglVertex3f( float x, float y, float z ) { vtx( x, y, z ); }
void zzglVertex3fv( const float *v ) { vtx( v[0], v[1], v[2] ); }
unsigned long long zzhl_us64( void ) { static unsigned long long t; return t += 7; }
/* the origin of a draw.  The engine side (Core1/zzhl_gpu.c) is mocked: the test says
   who is drawing, the mock ZZGL logs the origin it is told when it changes. */
unsigned zzhl_fx[ZFX_COUNT];
static unsigned g_test_org = ZORG_OTHER, g_zz_org = 999u, g_swaps;
unsigned zzhl_origin_now( void ) { return g_test_org; }
unsigned zzhl_entphase_swap( unsigned slot ) { (void)slot; g_swaps++; return 0u; }
void zzgl_origin_set( u32 o ) { if( o != g_zz_org ) { g_zz_org = o; L( "ORG %u", o ); } }
/* Core1's waits for the GPU.  The mock adds 3 us of wait to every Begin of the mock ZZGL
   (g_wait_us below), so a draw's wait can be told from its time (7 us a clock reading). */
unsigned zzhl_gpu_wait_us( void ) { return g_wait_us; }
static u32 g_reduced;                          /* textures ZZGL had to store reduced (SPRTRIM gives up then) */
void zzgl_tex_counts( u32 *up, u32 *ds, u32 *rf, u32 *ev ) { *up = 0u; *ds = g_reduced; *rf = 0u; *ev = 0u; }

/* ---- the GL 1.1 names through the shim's table, as ref_gl would ---- */
extern void *zzhl_gl_proc( const char *name );
extern void xacp_gl_frame_end( void );
extern void xacp_gl_set_picmip( int n );
#define GLFN( ret, name, ... ) static ret (*p##name)( __VA_ARGS__ );
GLFN( void, glEnable, unsigned ) GLFN( void, glDisable, unsigned ) GLFN( void, glDepthFunc, unsigned ) GLFN( void, glDepthMask, unsigned char )
GLFN( void, glBlendFunc, unsigned, unsigned ) GLFN( void, glAlphaFunc, unsigned, float ) GLFN( void, glBindTexture, unsigned, unsigned )
GLFN( void, glBegin, unsigned ) GLFN( void, glEnd, void ) GLFN( void, glVertex3f, float, float, float ) GLFN( void, glTexCoord2f, float, float )
GLFN( void, glColor4f, float, float, float, float ) GLFN( void, glMatrixMode, unsigned ) GLFN( void, glLoadIdentity, void ) GLFN( void, glLoadMatrixf, const float * )
GLFN( void, glOrtho, double, double, double, double, double, double ) GLFN( void, glTexSubImage2D, unsigned, int, int, int, int, int, unsigned, unsigned, const void * )
GLFN( void, glTexImage2D, unsigned, int, int, int, int, int, unsigned, unsigned, const void * ) GLFN( void, glDepthRange, double, double )
GLFN( void, glTexEnvi, unsigned, unsigned, int ) GLFN( void, glTranslatef, float, float, float ) GLFN( void, glPushMatrix, void ) GLFN( void, glPopMatrix, void )
GLFN( void, glTexParameteri, unsigned, unsigned, int ) GLFN( void, glCullFace, unsigned ) GLFN( void, glShadeModel, unsigned )
GLFN( void, glColor4ubv, const unsigned char * ) GLFN( void, glColor4ub, unsigned char, unsigned char, unsigned char, unsigned char )   /* build 92 */
#define GET( name ) p##name = zzhl_gl_proc( #name ); if( !p##name ) { printf( "missing %s\n", #name ); return 1; }

typedef void (*po_fn)( float, float );
static po_fn zzhl_proc_po( void ) { return (po_fn)zzhl_gl_proc( "glPolygonOffset" ); }
static int fails;
static void expect_seq( const char *what, const char *const *lines, int n )
{
	/* every line must appear, in this order (other lines may sit between) */
	const char *pos = g_log; int i;
	for( i = 0; i < n; i++ )
	{
		const char *f = strstr( pos, lines[i] );
		if( !f ) { printf( "FAIL %s: line %d '%s' not found in order\nLOG:\n%s\n", what, i, lines[i], g_log ); fails++; return; }
		pos = f + strlen( lines[i] );
	}
	printf( "ok   %s\n", what );
}
static void expect_absent( const char *what, const char *s )
{
	if( strstr( g_log, s )) { printf( "FAIL %s: '%s' present\nLOG:\n%s\n", what, s, g_log ); fails++; return; }
	printf( "ok   %s\n", what );
}
static int count_of( const char *s ) { int n = 0; const char *p = g_log; while(( p = strstr( p, s ))) { n++; p += strlen( s ); } return n; }
static void expect_count( const char *what, const char *s, int n )
{
	int c = count_of( s );
	if( c != n ) { printf( "FAIL %s: '%s' %d times, expected %d\nLOG:\n%s\n", what, s, c, n, g_log ); fails++; return; }
	printf( "ok   %s\n", what );
}
/* present at least once / never present */
static void expect_has( const char *what, const char *s )
{
	if( !strstr( g_log, s )) { printf( "FAIL %s: '%s' never sent\nLOG:\n%s\n", what, s, g_log ); fails++; return; }
	printf( "ok   %s\n", what );
}
static void expect_none( const char *what, const char *s )
{
	if( strstr( g_log, s )) { printf( "FAIL %s: '%s' was sent\nLOG:\n%s\n", what, s, g_log ); fails++; return; }
	printf( "ok   %s\n", what );
}
static void reset_log( void ) { g_logn = 0; g_log[0] = 0; g_bound_sent = 0xFFFFFFFFu; }   /* a new run: the TMU holds nothing */

static float PERSP[16] = { 1,0,0,0, 0,1,0,0, 0,0,-1,-1, 0,0,-2,0 };   /* p[15] = 0: perspective */

/* a world polygon: textured, 4 vertices, colour c */
static void poly( unsigned tex, float x, float c )
{
	pglBindTexture( ZGL_TEXTURE_2D, tex );
	pglColor4f( c, c, c, 1 );
	pglBegin( ZGL_POLYGON );
	pglTexCoord2f( 0, 0 ); pglVertex3f( x, 0, -5 );
	pglTexCoord2f( 1, 0 ); pglVertex3f( x + 1, 0, -5 );
	pglTexCoord2f( 1, 1 ); pglVertex3f( x + 1, 1, -5 );
	pglTexCoord2f( 0, 1 ); pglVertex3f( x, 1, -5 );
	pglEnd();
}
static void opaque_state( void )
{
	pglEnable( ZGL_TEXTURE_2D ); pglEnable( ZGL_DEPTH_TEST ); pglDisable( ZGL_BLEND ); pglDisable( ZGL_ALPHA_TEST );
	pglDepthFunc( ZGL_LEQUAL ); pglDepthMask( 1 ); pglTexEnvi( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, ZGL_REPLACE );
}
static void lightmap_state( void )
{
	pglEnable( ZGL_BLEND ); pglDisable( ZGL_ALPHA_TEST ); pglDepthMask( 0 ); pglDepthFunc( ZGL_EQUAL );
	pglBlendFunc( ZGL_ZERO, ZGL_SRC_COLOR ); pglTexEnvi( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, ZGL_MODULATE );
}
static void frame_3d( void )
{
	pglMatrixMode( ZGL_PROJECTION ); pglLoadMatrixf( PERSP );
	pglMatrixMode( ZGL_MODELVIEW ); pglLoadIdentity();
}

int main( void )
{
	GET( glEnable ) GET( glDisable ) GET( glDepthFunc ) GET( glDepthMask ) GET( glBlendFunc ) GET( glAlphaFunc ) GET( glBindTexture )
	GET( glBegin ) GET( glEnd ) GET( glVertex3f ) GET( glTexCoord2f ) GET( glColor4f ) GET( glMatrixMode ) GET( glLoadIdentity ) GET( glLoadMatrixf )
	GET( glOrtho ) GET( glTexSubImage2D ) GET( glTexImage2D ) GET( glDepthRange ) GET( glTexEnvi ) GET( glTranslatef ) GET( glPushMatrix ) GET( glPopMatrix )
	GET( glTexParameteri ) GET( glCullFace ) GET( glShadeModel )
	GET( glColor4ubv ) GET( glColor4ub )

	/* ---- 1. SORT=0: pass-through, the order is ref_gl's ---- */
	glq_set_sort( 0 );
	reset_log(); frame_3d(); opaque_state();
	poly( 10, 0, 1 ); poly( 11, 1, 1 ); poly( 10, 2, 1 );
	xacp_gl_frame_end();
	{ const char *const s[] = { "BIND 10\n", "BEGIN 9", "END 4", "BIND 11\n", "BEGIN 9", "BIND 10\n", "BEGIN 9" }; expect_seq( "SORT=0 keeps the order", s, 7 ); }
	expect_count( "SORT=0: three binds", "BIND 1", 3 );

	/* ---- 2. SORT=1: world A B A + lightmaps L1 L2 L1 per entity, then a blended sprite ---- */
	glq_set_sort( 1 );
	reset_log(); frame_3d(); opaque_state();
	poly( 10, 0, 1 ); poly( 11, 1, 1 ); poly( 10, 2, 0.5f );
	lightmap_state();
	poly( 1024, 0, 0.667f ); poly( 1025, 1, 0.667f ); poly( 1024, 2, 0.667f );
	/* a brush model with its own matrix: base then lightmap */
	opaque_state(); pglMatrixMode( ZGL_MODELVIEW ); pglPushMatrix(); pglTranslatef( 100, 0, 0 );
	poly( 11, 3, 1 );
	lightmap_state(); poly( 1025, 3, 0.667f );
	pglPopMatrix();
	expect_count( "nothing drawn while recording", "BEGIN", 0 );
	/* the sprite: blended, order dependent -> flush then draw */
	opaque_state(); pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA ); pglDepthMask( 0 );
	poly( 50, 4, 1 );
	xacp_gl_frame_end();
	{   /* group 0 sorted by texture: 10 (x=0, x=2), 11 (x=1, then the bmodel x=3 at +100); group 1: 1024 (0, 2), 1025 (1, then +100 bmodel); then the sprite */
		const char *const s[] = {
			"BIND 10\n", "BEGIN 9", "V 0 0 -5", "END 4", "BEGIN 9", "V 2 0 -5", "c 128 128 128 255", "END 4",
			"BIND 11\n", "BEGIN 9", "V 1 0 -5", "END 4", "LOADM MV 100 0 1", "BEGIN 9", "V 103 0 -5", "END 4",
			"DF 202", "DM 0", "BF 0 300", "BIND 1024\n", "BEGIN 9", "V 0 0 -5", "c 170 170 170 255", "END 4", "BEGIN 9", "V 2 0 -5",
			"BIND 1025\n", "BEGIN 9", "V 1 0 -5", "LOADM MV 100 0 1", "BEGIN 9", "V 103 0 -5", "END 4",
			/* restore: the engine's state (blend SRC_ALPHA, depth mask 0, LEQUAL) and matrices, then the sprite */
			"LOADM MV 0 0 1", "DF 203", "BF 302 303", "BIND 50\n", "BEGIN 9", "V 4 0 -5", "END 4" };
		expect_seq( "SORT=1 replay: grouped, sorted by texture, matrices per batch, state restored", s, sizeof( s ) / sizeof( s[0] ));
	}
	expect_count( "SORT=1: 5 binds instead of 9", "BIND ", 5 );
	expect_count( "SORT=1: 8 batches replayed + the sprite", "BEGIN 9", 9 );
	{ const glq_stats_t *q = glq_stats(); printf( "     stats: req %u done %u distinct %u rebinds %u recorded %u flushes state %u frame %u\n", q->binds_req, q->binds_done, q->distinct, q->rebinds, q->batches_recorded, q->flushes[GLQ_WHY_STATE], q->flushes[GLQ_WHY_FRAME] ); }

	/* ---- 3. dynamic lightmap: upload into the block between two draws of it -> the draw before the upload is replayed first ---- */
	reset_log(); frame_3d(); opaque_state();
	poly( 10, 0, 1 );
	lightmap_state();
	poly( 1100, 0, 1 );                                    /* dlight block, surface 1 */
	pglBindTexture( ZGL_TEXTURE_2D, 1100 );
	pglTexSubImage2D( ZGL_TEXTURE_2D, 0, 0, 0, 16, 16, ZGL_RGBA, ZGL_UNSIGNED_BYTE, g_log );   /* surface 2's rect */
	poly( 1100, 1, 1 );                                    /* surface 2 */
	xacp_gl_frame_end();
	{ const char *const s[] = { "BIND 10\n", "V 0 0 -5", "BIND 1100\n", "V 0 0 -5", "END 4", "TEXSUB tex 1100", "BEGIN 9", "V 1 0 -5" }; expect_seq( "texture update of a queued texture flushes first", s, 8 ); }

	/* ---- 4. depth range change (viewmodel) flushes; 2D (ortho) passes through ---- */
	reset_log(); frame_3d(); opaque_state();
	poly( 10, 0, 1 );
	pglDepthRange( 0, 0.3 );
	poly( 20, 1, 1 );
	pglDepthRange( 0, 1 );
	pglMatrixMode( ZGL_PROJECTION ); pglLoadIdentity(); pglOrtho( 0, 640, 480, 0, -99999, 99999 ); pglMatrixMode( ZGL_MODELVIEW ); pglLoadIdentity();
	pglDisable( ZGL_DEPTH_TEST );
	poly( 30, 2, 1 ); poly( 31, 3, 1 ); poly( 30, 4, 1 );
	xacp_gl_frame_end();
	{ const char *const s[] = { "BIND 10\n", "END 4", "DEPTHRANGE 0 0.3", "BIND 20\n", "END 4", "DEPTHRANGE 0 1", "BIND 30\n", "BIND 31\n", "BIND 30\n" }; expect_seq( "depth range flushes, 2D is not sorted", s, 9 ); }

	/* ---- 5. BINDTEST=1: every 3D draw on the tiny texture (one bind), 2D untouched ---- */
	glq_set_bindtest( 1 );
	reset_log(); frame_3d(); opaque_state(); pglEnable( ZGL_DEPTH_TEST );
	poly( 10, 0, 1 ); poly( 11, 1, 1 );
	xacp_gl_frame_end();
	{ const char *const s[] = { "TEXIMAGE tex 2294 level 0 8x8", "TEXIMAGE tex 2295 level 0 8x8", "BIND 2294\n", "BEGIN 9", "BEGIN 9" }; expect_seq( "BINDTEST=1: the tiny texture", s, 5 ); }
	expect_absent( "BINDTEST=1: no bind of 10 for a draw", "BIND 10\nBEGIN" );
	glq_set_bindtest( 0 );

	/* ---- 6. PICMIP=1: level 1 replaces level 0 for a mipmapped texture, level 0 alone stays ---- */
	xacp_gl_set_picmip( 1 );
	reset_log();
	{
		static unsigned char l0[128 * 128 * 4], l1[64 * 64 * 4], l2[32 * 32 * 4], f0[256 * 64 * 4];
		memset( l0, 10, sizeof l0 ); memset( l1, 11, sizeof l1 ); memset( l2, 12, sizeof l2 ); memset( f0, 13, sizeof f0 );
		pglBindTexture( ZGL_TEXTURE_2D, 200 );
		pglTexImage2D( ZGL_TEXTURE_2D, 0, 4, 128, 128, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, l0 );
		pglTexImage2D( ZGL_TEXTURE_2D, 1, 4, 64, 64, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, l1 );
		pglTexImage2D( ZGL_TEXTURE_2D, 2, 4, 32, 32, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, l2 );
		pglTexParameteri( ZGL_TEXTURE_2D, ZGL_TEXTURE_MAG_FILTER, ZGL_LINEAR );
		pglBindTexture( ZGL_TEXTURE_2D, 201 );                 /* a font sheet: level 0 only */
		pglTexImage2D( ZGL_TEXTURE_2D, 0, 4, 256, 64, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, f0 );
		pglBindTexture( ZGL_TEXTURE_2D, 202 );
		pglTexImage2D( ZGL_TEXTURE_2D, 0, 4, 8, 8, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, l2 );   /* too small to shrink */
		pglTexImage2D( ZGL_TEXTURE_2D, 1, 4, 4, 4, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, l2 );
		xacp_gl_frame_end();
	}
	{ const char *const s[] = { "TEXIMAGE tex 200 level 0 64x64 first 11", "TEXPARAM", "TEXIMAGE tex 201 level 0 256x64 first 13", "TEXIMAGE tex 202 level 0 8x8 first 12" }; expect_seq( "PICMIP=1: level 1 for the mipmapped texture, level 0 for the others", s, 4 ); }
	expect_count( "PICMIP=1: one upload per texture", "TEXIMAGE", 3 );
	xacp_gl_set_picmip( 0 );

	/* ---- 7. flat shading and alpha test are part of the key; cull too ---- */
	reset_log(); frame_3d(); opaque_state(); pglEnable( ZGL_ALPHA_TEST ); pglAlphaFunc( ZGL_GREATER, 0.666f );
	poly( 10, 0, 1 );
	pglDisable( ZGL_ALPHA_TEST ); pglShadeModel( ZGL_FLAT );
	poly( 10, 1, 1 );
	xacp_gl_frame_end();
	{ const char *const s[] = { "EN bc0", "SM 1d01", "BIND 10\n", "BEGIN 9", "V 0 0 -5", "END 4", "DIS bc0", "SM 1d00", "BEGIN 9", "V 1 0 -5" }; expect_seq( "alpha test / shade model: two keys, one bind", s, 10 ); }
	expect_count( "key change, same texture: one bind", "BIND 10\n", 1 );

	/* ---- 8. strips / fans over 64 vertices are cut at 60 and restarted ---- */
	{
		int i;
		/* a beam: blended triangle strip of 100 vertices, passes through */
		reset_log(); frame_3d(); opaque_state(); pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE ); pglDepthMask( 0 );
		pglBindTexture( ZGL_TEXTURE_2D, 60 );
		pglBegin( ZGL_TRIANGLE_STRIP );
		for( i = 0; i < 100; i++ ) { pglColor4f( i / 255.0f, 0, 0, 1 ); pglTexCoord2f( (float)i, 0 ); pglVertex3f( (float)i, (float)( i & 1 ), -5 ); }
		pglEnd();
		xacp_gl_frame_end();
		{ const char *const sq[] = { "BEGIN 5", "V 0 0 -5", "V 59 1 -5", "END 60", "BEGIN 5", "V 58 0 -5 w1 st 58 0 c 58 0 0 255", "V 59 1 -5 w1 st 59 0 c 59 0 0 255", "V 60 0 -5 w1 st 60 0 c 60 0 0 255", "V 99 1 -5", "END 42" };
		  expect_seq( "strip of 100: cut at 60, restarted on the last two with their own attributes", sq, 10 ); }
		expect_absent( "strip of 100: no block over 64", "END 100" );
		/* a fan of 100 (texture coordinate left at the strip's last, 99) */
		reset_log(); frame_3d(); opaque_state(); pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE ); pglDepthMask( 0 );
		pglBegin( ZGL_TRIANGLE_FAN );
		for( i = 0; i < 100; i++ ) { pglColor4f( i / 255.0f, 0, 0, 1 ); pglVertex3f( (float)i, 0, -5 ); }
		pglEnd();
		xacp_gl_frame_end();
		{ const char *const sq[] = { "BEGIN 6", "V 0 0 -5", "V 59 0 -5", "END 60", "BEGIN 6", "V 0 0 -5 w1 st 99 0 c 0 0 0 255", "V 59 0 -5 w1 st 99 0 c 59 0 0 255", "V 60 0 -5 w1 st 99 0 c 60 0 0 255", "V 99 0 -5", "END 42" };
		  expect_seq( "fan of 100: restarted on the first and the last", sq, 10 ); }
		/* an opaque strip of 130 recorded then replayed: cut twice */
		reset_log(); frame_3d(); opaque_state();
		pglBindTexture( ZGL_TEXTURE_2D, 61 );
		pglBegin( ZGL_TRIANGLE_STRIP );
		for( i = 0; i < 130; i++ ) { pglColor4f( 1, 1, 1, 1 ); pglVertex3f( (float)i, (float)( i & 1 ), -5 ); }
		pglEnd();
		expect_count( "recorded strip: nothing drawn yet", "BEGIN", 0 );
		xacp_gl_frame_end();
		{ const char *const sq[] = { "BEGIN 5", "V 0 0 -5", "END 60", "BEGIN 5", "V 58 0 -5", "V 59 1 -5", "V 60 0 -5", "END 60", "BEGIN 5", "V 116 0 -5", "V 117 1 -5", "V 118 0 -5", "V 129 1 -5", "END 14" };
		  expect_seq( "recorded strip of 130: replayed in 3 blocks with the right restarts", sq, 14 ); }
	}
	{   /* no Begin/End block of the whole test log over 64: checked on a final pass of all modes */
		int i, m, bad = 0;
		static const unsigned modes[] = { ZGL_POINTS, ZGL_LINES, ZGL_LINE_STRIP, ZGL_TRIANGLES, ZGL_TRIANGLE_STRIP, ZGL_TRIANGLE_FAN, ZGL_QUADS, ZGL_QUAD_STRIP, ZGL_POLYGON };
		reset_log(); frame_3d(); opaque_state(); pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE ); pglDepthMask( 0 );
		for( m = 0; m < 9; m++ ) { pglBegin( modes[m] ); for( i = 0; i < 300; i++ ) pglVertex3f( (float)i, 0, -5 ); pglEnd(); }
		opaque_state(); pglDisable( ZGL_BLEND ); pglDepthMask( 1 );
		for( m = 3; m < 9; m++ ) { pglBegin( modes[m] ); for( i = 0; i < 300; i++ ) pglVertex3f( (float)i, 0, -5 ); pglEnd(); }
		xacp_gl_frame_end();
		{ const char *p = g_log; while(( p = strstr( p, "END " ))) { if( atoi( p + 4 ) > 64 ) bad++; p += 4; } }
		if( bad ) { printf( "FAIL every mode, 300 vertices: %d blocks over 64\n", bad ); fails++; }
		else printf( "ok   every mode, 300 vertices, pass-through and replayed: no block over 64 (%u cuts so far)\n", glq_splits());
	}

	{   /* polygon offset on an overlay (decal): vertices pulled towards the eye, modelview restored */
		void (*po)( float, float ) = zzhl_proc_po();
		reset_log(); frame_3d(); opaque_state();
		pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA ); pglDepthMask( 0 );
		pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		pglMatrixMode( ZGL_MODELVIEW ); pglPushMatrix(); pglTranslatef( 100, 0, 0 );
		poly( 70, 0, 1 );                     /* x 100..101 in eye space, z -5: d = 5, n = 1, 8 steps: k = 8*5/65536 */
		pglPopMatrix();
		pglDisable( ZGL_POLYGON_OFFSET_FILL );
		poly( 70, 0, 1 );                     /* no offset any more: untouched */
		xacp_gl_frame_end();
		/* the biased overlay is recorded (group 2) and replayed with its identity modelview
		   (its vertices are already in eye space); the blended poly without offset still passes through */
		{ const char *const sq[] = { "BEGIN 9", "V 99.939 0 -4.99695", "V 100.938 0 -4.99695", "END 4", "LOADM MV 0 0 1", "BEGIN 9", "V 0 0 -5", "END 4" };
		  expect_seq( "decal with polygon offset: pulled along the view ray, modelview restored after", sq, 8 ); }
		/* the lightmap pass (EQUAL) is never biased, even with the offset on */
		reset_log(); frame_3d(); opaque_state(); lightmap_state();
		pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -0.5f, -2.0f );
		poly( 1024, 0, 1 );
		pglDisable( ZGL_POLYGON_OFFSET_FILL );
		xacp_gl_frame_end();
		{ const char *const sq[] = { "BEGIN 9", "V 0 0 -5", "END 4" }; expect_seq( "lightmap pass with offset on: not biased", sq, 3 ); }
		/* a biased run over 60 vertices restarts with biased vertices */
		reset_log(); frame_3d(); opaque_state();
		pglEnable( ZGL_BLEND ); pglDepthMask( 0 ); pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		{ int i; pglBegin( ZGL_TRIANGLE_FAN ); for( i = 0; i < 70; i++ ) pglVertex3f( 0, 0, -5 ); pglEnd(); }
		pglDisable( ZGL_POLYGON_OFFSET_FILL );
		xacp_gl_frame_end();
		expect_absent( "biased fan of 70: no unbiased vertex re-sent at the cut", "V 0 0 -5 " );

		/* an overlay no longer cuts the queue - the world textures are bound once each,
		   and the overlays keep the order ref_gl recorded them in (never sorted by texture) */
		reset_log(); frame_3d(); opaque_state();
		poly( 10, 0, 1 );                                    /* world */
		pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA ); pglDepthMask( 0 );
		pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		poly( 81, 0, 1 ); poly( 80, 1, 1 ); poly( 81, 2, 1 );   /* three overlays: 81, 80, 81 */
		pglDisable( ZGL_POLYGON_OFFSET_FILL ); pglDepthMask( 1 ); pglDisable( ZGL_BLEND );
		opaque_state();
		poly( 11, 3, 1 ); poly( 10, 4, 1 );                  /* more world, texture 10 again */
		xacp_gl_frame_end();
		{ const char *const sq[] = { "BIND 10\n", "BIND 11\n", "BIND 81\n", "BIND 80\n", "BIND 81\n" };
		  expect_seq( "overlays: world grouped and bound once, overlays last and in their own order", sq, 5 ); }
		expect_count( "overlays: texture 10 bound once in the frame", "BIND 10\n", 1 );

		/* DECALQ=0 goes back to the build 53 behaviour: the overlay flushes the queue */
		glq_set_decal_group( 0 );
		reset_log(); frame_3d(); opaque_state();
		poly( 10, 0, 1 );
		pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA ); pglDepthMask( 0 );
		pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		poly( 81, 0, 1 );
		pglDisable( ZGL_POLYGON_OFFSET_FILL ); pglDepthMask( 1 ); pglDisable( ZGL_BLEND );
		opaque_state();
		poly( 10, 4, 1 );
		xacp_gl_frame_end();
		expect_count( "DECALQ=0: texture 10 bound twice again (the overlay cuts the queue)", "BIND 10\n", 2 );

		/* DECALQ=2 sorts the overlays by texture too; the sort is stable, so two overlays
		   of the SAME texture keep the order ref_gl recorded them in */
		glq_set_decal_group( 2 );
		reset_log(); frame_3d(); opaque_state();
		poly( 10, 0, 1 );                                    /* world */
		pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA ); pglDepthMask( 0 );
		pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		poly( 81, 0, 1 ); poly( 80, 1, 1 ); poly( 81, 2, 1 );   /* three overlays: 81, 80, 81 */
		pglDisable( ZGL_POLYGON_OFFSET_FILL ); pglDepthMask( 1 ); pglDisable( ZGL_BLEND );
		opaque_state();
		poly( 11, 3, 1 );
		xacp_gl_frame_end();
		{ const char *const sq[] = { "BIND 10\n", "BIND 11\n", "BIND 80\n", "BIND 81\n" };
		  expect_seq( "DECALQ=2: overlays sorted by texture, still replayed after the world", sq, 4 ); }
		expect_count( "DECALQ=2: texture 81 bound once instead of twice", "BIND 81\n", 1 );
		{   /* the replay split by group - the frame above had 2 opaque batches (10, 11) and
		       3 overlays of 2 textures */
			const glq_stats_t *q = glq_stats();
			if( q->grp_batches[2] < 3u || q->grp_binds[2] < 2u || q->grp_batches[0] < 2u )
			{ printf( "FAIL replay by group: opaque %u/%u binds, overlays %u/%u binds\n",
			          q->grp_batches[0], q->grp_binds[0], q->grp_batches[2], q->grp_binds[2] ); fails++; }
			else printf( "ok   replay by group: %u opaque batches, %u overlay batches and %u overlay binds counted\n",
			          q->grp_batches[0], q->grp_batches[2], q->grp_binds[2] );
		}
		/* the two 81 overlays kept their order: the one recorded at x 0 is replayed before the one
		   at x 2 (both biased towards the eye, z -4.99695) */
		{ const char *const sq[] = { "BIND 81\n", "V 0 0 -4.99695", "V 1.99878 0 -4.99695" };
		  expect_seq( "DECALQ=2: two overlays of one texture keep the recorded order", sq, 3 ); }
		glq_set_decal_group( 1 );

		/* LMDEPTH.  The lightmap pass keeps GL_EQUAL in the recorded state (so it is still
		   group 1, replayed after the opaque group) but reaches ZZGL as GL_LEQUAL or GL_ALWAYS. */
		{
			int m;
			const unsigned want[3] = { ZGL_EQUAL, ZGL_LEQUAL, ZGL_ALWAYS };
			for( m = 0; m < 3; m++ )
			{
				char ex[32];
				const int mode[3] = { 1, 0, 2 };
				glq_set_lm_depth( mode[m] );
				reset_log(); frame_3d(); opaque_state();
				poly( 10, 0, 1 );                       /* the world first */
				lightmap_state(); poly( 1024, 0, 1 );   /* then its lightmap */
				xacp_gl_frame_end();
				sprintf( ex, "DF %x", want[m] );
				{ const char *const sq[] = { "BIND 10\n", "BIND 1024\n" };
				  expect_seq( mode[m] == 1 ? "LMDEPTH=1: the lightmap still replayed after the world"
				            : mode[m] == 0 ? "LMDEPTH=0: the lightmap still replayed after the world"
				            : "LMDEPTH=2: the lightmap still replayed after the world", sq, 2 ); }
				expect_has( mode[m] == 1 ? "LMDEPTH=1: GL_EQUAL reaches ZZGL"
				          : mode[m] == 0 ? "LMDEPTH=0: GL_LEQUAL reaches ZZGL instead of GL_EQUAL"
				          : "LMDEPTH=2: GL_ALWAYS reaches ZZGL instead of GL_EQUAL", ex );
				if( mode[m] != 1 )
					expect_none( mode[m] == 0 ? "LMDEPTH=0: GL_EQUAL never reaches ZZGL"
					           : "LMDEPTH=2: GL_EQUAL never reaches ZZGL", "DF 202" );
			}
			glq_set_lm_depth( 1 );
		}
	}
	{   /* a 1D texture (ref_gl: picture one pixel high) is uploaded as a 2D texture one line
	       high, and glEnable/glDisable( GL_TEXTURE_1D ) acts on the texture state */
		void (*t1d)( unsigned, int, int, int, int, unsigned, unsigned, const void * ) = zzhl_gl_proc( "glTexImage1D" );
		static unsigned char row[16 * 4];
		reset_log(); frame_3d(); opaque_state();
		pglBindTexture( ZGL_TEXTURE_2D, 90 );
		t1d( ZGL_TEXTURE_1D, 0, ZGL_RGBA, 16, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, row );
		{ const char *const sq[] = { "TEXIMAGE tex 90 level 0 16x8" }; expect_seq( "glTexImage1D uploads the row tiled to the smallest texture, 16x8", sq, 1 ); }
		reset_log(); frame_3d(); opaque_state();
		pglDisable( ZGL_TEXTURE_1D ); poly( 91, 0, 1 ); xacp_gl_frame_end();
		{ const char *const sq[] = { "DIS de1", "BEGIN 9" };          /* de1 = GL_TEXTURE_2D */
		  expect_seq( "glDisable( GL_TEXTURE_1D ) turns the texture state off", sq, 2 ); }
	}
	{   /* every batch carries the origin it was BEGUN under, whenever it is replayed */
		reset_log(); frame_3d(); opaque_state(); memset( zzhl_fx, 0, sizeof( zzhl_fx )); g_zz_org = 999u;
		g_test_org = ZORG_WORLD; poly( 10, 0, 1 );
		g_test_org = ZORG_STUDIO; poly( 11, 1, 1 );
		g_test_org = ZORG_WORLD; lightmap_state(); poly( 1024, 0, 1 );
		g_test_org = ZORG_SPRITE; opaque_state(); pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE ); pglDepthMask( 0 );
		poly( 50, 4, 1 );                         /* order dependent: replays the three above from inside its own Begin */
		{ char ex[5][16]; const char *sq[10]; int i;
		  sprintf( ex[0], "ORG %u\n", (unsigned)ZORG_WORLD ); sprintf( ex[1], "ORG %u\n", (unsigned)ZORG_STUDIO );
		  sprintf( ex[2], "ORG %u\n", (unsigned)ZORG_LIGHTMAP ); sprintf( ex[3], "ORG %u\n", (unsigned)ZORG_SPRITE );
		  i = 0; sq[i++] = ex[0]; sq[i++] = "BIND 10\n"; sq[i++] = ex[1]; sq[i++] = "BIND 11\n"; sq[i++] = ex[2]; sq[i++] = "BIND 1024\n"; sq[i++] = ex[3]; sq[i++] = "BIND 50\n";
		  expect_seq( "origins: world, studio, the lightmap pass, then the sprite that forced the replay", sq, i ); }
		if( zzhl_fx[ZFX_FLUSH_STATE] == 1u && zzhl_fx[ZFX_FLUSHBY0 + ZORG_SPRITE] == 1u && zzhl_fx[ZFX_MID_BATCHES] == 3u && zzhl_fx[ZFX_FLUSH_FRAME] == 0u )
			printf( "ok   the replay is counted as forced by the sprite: 3 batches before the frame's end\n" );
		else { printf( "FAIL flush counters: state %u, by sprite %u, mid batches %u, frame %u\n", zzhl_fx[ZFX_FLUSH_STATE], zzhl_fx[ZFX_FLUSHBY0 + ZORG_SPRITE], zzhl_fx[ZFX_MID_BATCHES], zzhl_fx[ZFX_FLUSH_FRAME] ); fails++; }
		/* the mock clock moves 7 us a reading: the sprite's own draw is one interval, and the replay it
		   forced (several readings) is NOT in it - the trap of 15/11, "spr:quad 25 727 us" */
		if( zzhl_fx[ZFX_BINDS_REQ] == 4u && zzhl_fx[ZFX_TEX_DISTINCT] == 4u && zzhl_fx[ZFX_REPLAY_US] > 7u && zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_US )] == 7u )
			printf( "ok   binds asked 4, distinct 4; the replay is timed apart and is not in the sprite's time\n" );
		else { printf( "FAIL bind counters: asked %u distinct %u replay %u sprite us %u\n", zzhl_fx[ZFX_BINDS_REQ], zzhl_fx[ZFX_TEX_DISTINCT], zzhl_fx[ZFX_REPLAY_US], zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_US )] ); fails++; }
		xacp_gl_frame_end();
		if( zzhl_fx[ZFX_ORG( ZORG_WORLD, ZFXO_US )] && zzhl_fx[ZFX_ORG( ZORG_STUDIO, ZFXO_US )] && zzhl_fx[ZFX_ORG( ZORG_LIGHTMAP, ZFXO_US )] && zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_US )] )
			printf( "ok   Core1's time goes to each origin, the replayed ones included\n" );
		else { printf( "FAIL time by origin\n" ); fails++; }
		/* each of the four batches waited 3 us in its Begin, and that wait is its origin's */
		if( zzhl_fx[ZFX_ORG( ZORG_WORLD, ZFXO_WAIT_US )] == 3u && zzhl_fx[ZFX_ORG( ZORG_STUDIO, ZFXO_WAIT_US )] == 3u
		 && zzhl_fx[ZFX_ORG( ZORG_LIGHTMAP, ZFXO_WAIT_US )] == 3u && zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_WAIT_US )] == 3u && zzhl_fx[ZFX_ORG( ZORG_2D, ZFXO_WAIT_US )] == 0u )
			printf( "ok   the GPU waits inside the draws go to the origin that waited: 3 us each, replayed or not\n" );
		else { printf( "FAIL waits by origin: world %u studio %u lightmap %u sprite %u 2D %u\n", zzhl_fx[ZFX_ORG( ZORG_WORLD, ZFXO_WAIT_US )], zzhl_fx[ZFX_ORG( ZORG_STUDIO, ZFXO_WAIT_US )],
			zzhl_fx[ZFX_ORG( ZORG_LIGHTMAP, ZFXO_WAIT_US )], zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_WAIT_US )], zzhl_fx[ZFX_ORG( ZORG_2D, ZFXO_WAIT_US )] ); fails++; }
		{   /* the counter restarts when a frame opens: a reading below the one before is taken whole */
			g_wait_us = 1000u; reset_log(); frame_3d(); opaque_state(); memset( zzhl_fx, 0, sizeof( zzhl_fx ));
			pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE ); pglDepthMask( 0 ); g_test_org = ZORG_SPRITE;
			pglBindTexture( ZGL_TEXTURE_2D, 50 ); pglBegin( ZGL_POLYGON ); g_wait_us = 5u; pglVertex3f( 0, 0, -5 ); pglVertex3f( 1, 0, -5 ); pglVertex3f( 1, 1, -5 ); pglEnd();
			if( zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_WAIT_US )] == 5u ) printf( "ok   a wait counter that restarted inside the draw is not read as a huge wait\n" );
			else { printf( "FAIL wait across a frame opening: %u\n", zzhl_fx[ZFX_ORG( ZORG_SPRITE, ZFXO_WAIT_US )] ); fails++; }
			xacp_gl_frame_end(); opaque_state();
		}
		/* 2D is an origin of its own, whatever the phase says */
		reset_log(); g_zz_org = 999u; g_test_org = ZORG_WORLD;
		pglMatrixMode( ZGL_PROJECTION ); pglLoadIdentity(); pglOrtho( 0, 640, 480, 0, -1, 1 ); pglMatrixMode( ZGL_MODELVIEW ); pglLoadIdentity();
		pglDisable( ZGL_DEPTH_TEST ); poly( 60, 0, 1 ); xacp_gl_frame_end();
		{ char ex[16]; const char *sq[2]; sprintf( ex, "ORG %u\n", (unsigned)ZORG_2D ); sq[0] = ex; sq[1] = "BIND 60\n"; expect_seq( "origins: an orthographic draw is 2D", sq, 2 ); }
		g_test_org = ZORG_OTHER;
	}
	{   /* EARLY.  The world is replayed when ref_gl says it has walked it. */
		reset_log(); frame_3d(); opaque_state(); memset( zzhl_fx, 0, sizeof( zzhl_fx ));
		poly( 11, 0, 1 ); poly( 10, 1, 1 ); lightmap_state(); poly( 1024, 0, 1 );
		zzhl_world_done();
		expect_count( "EARLY=0: the end of the world's walk replays nothing", "BEGIN", 0 );
		glq_set_early( 1 );
		zzhl_world_done();
		{ const char *const sq[] = { "BIND 10\n", "BEGIN 9", "BIND 11\n", "BEGIN 9", "BIND 1024\n", "BEGIN 9" };
		  expect_seq( "EARLY=1: the world replayed at the end of its walk, sorted, lightmaps last", sq, 6 ); }
		expect_count( "EARLY=1: three batches drawn at that point", "BEGIN", 3 );
		opaque_state(); poly( 11, 5, 1 );            /* an entity that shares a world texture: recorded again, drawn at the frame's end */
		expect_count( "EARLY=1: the entities after it are recorded as before", "BEGIN", 3 );
		xacp_gl_frame_end();
		expect_count( "EARLY=1: and drawn at the frame's end", "BEGIN", 4 );
		if( zzhl_fx[ZFX_FLUSH_EARLY] == 1u && zzhl_fx[ZFX_FLUSH_FRAME] == 1u && zzhl_fx[ZFX_MID_BATCHES] == 3u ) printf( "ok   EARLY=1: one early flush of 3 batches, one at the frame's end\n" );
		else { printf( "FAIL EARLY counters: early %u frame %u mid %u\n", zzhl_fx[ZFX_FLUSH_EARLY], zzhl_fx[ZFX_FLUSH_FRAME], zzhl_fx[ZFX_MID_BATCHES] ); fails++; }
		zzhl_world_done();                          /* nothing queued: nothing happens */
		glq_set_early( 0 );
	}
	{   /* EARLY=2, chosen on the GPU's idle time with nothing queued (us a frame) */
		int i, on_at = -1, off_at = -1;
		glq_set_early( 2 );
		if( glq_early() == 2 && !glq_early_now()) printf( "ok   EARLY=2: starts as EARLY=0\n" ); else { printf( "FAIL EARLY=2 start: mode %d now %d\n", glq_early(), glq_early_now()); fails++; }
		reset_log(); frame_3d(); opaque_state(); poly( 11, 0, 1 );
		zzhl_world_done();
		expect_count( "EARLY=2, GPU never idle: the end of the world's walk replays nothing", "BEGIN", 0 );
		xacp_gl_frame_end();
		for( i = 0; i < 12; i++ ) { glq_early_feed( 0u ); if( glq_early_now()) break; }          /* c1a1d: 0 us */
		if( i == 12 ) printf( "ok   EARLY=2: 12 frames with a GPU never idle: stays off\n" ); else { printf( "FAIL EARLY=2 went on with 0 us\n" ); fails++; }
		for( i = 0; i < 12; i++ ) { glq_early_feed( 5221u ); if( glq_early_now() && on_at < 0 ) on_at = i + 1; }   /* c2a5f: 5221 us */
		if( on_at >= 2 && on_at <= 4 && glq_early_now()) printf( "ok   EARLY=2: 5,2 ms of idle GPU a frame: on after %d frames\n", on_at ); else { printf( "FAIL EARLY=2 on_at %d\n", on_at ); fails++; }
		reset_log(); frame_3d(); opaque_state(); poly( 11, 0, 1 );
		zzhl_world_done();
		expect_count( "EARLY=2, on: the world replayed at the end of its walk", "BEGIN", 1 );
		xacp_gl_frame_end();
		for( i = 0; i < 12; i++ ) glq_early_feed( 4313u );                                       /* c2a5f with EARLY: 4313 us */
		if( glq_early_now()) printf( "ok   EARLY=2: stays on at 4,3 ms (what EARLY=1 leaves on c2a5f)\n" ); else { printf( "FAIL EARLY=2 dropped at 4313 us\n" ); fails++; }
		for( i = 0; i < 40; i++ ) { glq_early_feed( 1500u ); }                                   /* between the two thresholds: as before */
		if( glq_early_now()) printf( "ok   EARLY=2: 1,5 ms, between the thresholds: stays as it was (on)\n" ); else { printf( "FAIL EARLY=2 flapped at 1500 us\n" ); fails++; }
		for( i = 0; i < 12; i++ ) { glq_early_feed( 636u ); if( !glq_early_now() && off_at < 0 ) off_at = i + 1; }  /* c1a1d with EARLY: 636 us */
		if( off_at >= 1 && off_at <= 6 && !glq_early_now()) printf( "ok   EARLY=2: 0,6 ms (what EARLY=1 leaves on c1a1d): off after %d frames\n", off_at ); else { printf( "FAIL EARLY=2 off_at %d\n", off_at ); fails++; }
		for( i = 0; i < 40; i++ ) glq_early_feed( 1500u );
		if( !glq_early_now()) printf( "ok   EARLY=2: 1,5 ms again: stays as it was (off)\n" ); else { printf( "FAIL EARLY=2 flapped on at 1500 us\n" ); fails++; }
		glq_early_feed( 2000000u );                                                              /* one frame of a level load */
		glq_set_early( 1 ); if( glq_early_now()) printf( "ok   EARLY=1 is always on, whatever was fed\n" ); else { printf( "FAIL EARLY=1\n" ); fails++; }
		glq_set_early( 0 ); glq_early_feed( 50000u ); if( !glq_early_now()) printf( "ok   EARLY=0 is always off, whatever is fed\n" ); else { printf( "FAIL EARLY=0\n" ); fails++; }
	}
	{   /* F2B.  Same batches, same vertices, the opaque textures from the nearest to the farthest. */
		int f, nv[2];
		for( f = 0; f < 2; f++ )
		{
			glq_set_f2b( f );
			reset_log(); frame_3d(); opaque_state();
			pglMatrixMode( ZGL_MODELVIEW ); pglPushMatrix(); pglTranslatef( 0, 0, -900 ); poly( 20, 0, 1 ); pglPopMatrix();   /* texture 20: far */
			pglPushMatrix(); pglTranslatef( 0, 0, -10 ); poly( 21, 1, 1 ); pglPopMatrix();                                 /* texture 21: near */
			pglPushMatrix(); pglTranslatef( 0, 0, -100 ); poly( 22, 2, 1 ); poly( 20, 3, 1 ); pglPopMatrix();                /* 22: middle; 20 again, nearer than its first */
			lightmap_state(); poly( 1024, 0, 1 );
			xacp_gl_frame_end();
			nv[f] = count_of( "\nV " );
			if( !f ) { const char *const sq[] = { "BIND 20\n", "BIND 21\n", "BIND 22\n", "BIND 1024\n" }; expect_seq( "F2B=0: the opaque textures in texture order", sq, 4 ); }
			else     { const char *const sq[] = { "BIND 21\n", "BIND 22\n", "BIND 20\n", "V 0 0 -905", "V 3 0 -105", "BIND 1024\n" };
			           expect_seq( "F2B=1: nearest texture first (21, 22, 20), order kept inside a texture, lightmaps still last", sq, 6 ); }
			expect_count( f ? "F2B=1: one bind a texture, as without" : "F2B=0: one bind a texture", "BIND 2", 3 );
		}
		if( nv[0] == nv[1] && nv[0] == 20 ) printf( "ok   F2B: the same %d vertices either way\n", nv[0] );
		else { printf( "FAIL F2B: %d vertices without, %d with\n", nv[0], nv[1] ); fails++; }
		glq_set_f2b( 0 );
	}
	{   /* SPRTRIM.  A 64x64 picture whose texels are empty outside columns 16..47 and rows
	       24..39, and black outside columns 20..43 (same rows): what may be left out depends on the state. */
		extern int zzhl_sprite_trim( float *u0, float *v0, float *u1, float *v1 );
		extern void xacp_gl_set_sprtrim( int on );
		static unsigned char pic[64 * 64 * 4], wall[64 * 64 * 4];
		float u0, v0, u1, v1;
		int x, y, r;
		for( y = 0; y < 64; y++ ) for( x = 0; x < 64; x++ )
		{
			unsigned char *p = &pic[( y * 64 + x ) * 4];
			int in_a = ( x >= 16 && x <= 47 && y >= 24 && y <= 39 ), in_c = ( x >= 20 && x <= 43 && y >= 24 && y <= 39 );
			p[0] = p[1] = p[2] = (unsigned char)( in_c ? 200 : 0 ); p[3] = (unsigned char)( in_a ? 255 : 0 );
			memset( &wall[( y * 64 + x ) * 4], 180, 4 );
		}
		reset_log(); frame_3d(); memset( zzhl_fx, 0, sizeof( zzhl_fx ));
		pglBindTexture( ZGL_TEXTURE_2D, 70 ); pglTexImage2D( ZGL_TEXTURE_2D, 0, ZGL_RGBA, 64, 64, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, pic );
		pglBindTexture( ZGL_TEXTURE_2D, 71 ); pglTexImage2D( ZGL_TEXTURE_2D, 0, ZGL_RGBA, 64, 64, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, wall );
		/* a glow: additive on alpha, no depth write, alpha test above 0, MODULATE (ref/gl/gl_sprite.c) */
		pglEnable( ZGL_TEXTURE_2D ); pglEnable( ZGL_DEPTH_TEST ); pglDepthMask( 0 ); pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE );
		pglEnable( ZGL_ALPHA_TEST ); pglAlphaFunc( ZGL_GREATER, 0.0f ); pglTexEnvi( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, ZGL_MODULATE );
		pglBindTexture( ZGL_TEXTURE_2D, 70 );
		u0 = v0 = 0; u1 = v1 = 1;
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( !r && u0 == 0 && u1 == 1 && zzhl_fx[ZFX_SPR_QUADS] == 1u && zzhl_fx[ZFX_SPR_TRIMMABLE] == 1u && zzhl_fx[ZFX_SPR_KEPT1000] == 26u * 18u * 1000u / 4096u )
			printf( "ok   SPRTRIM=0: the quad is left whole, and counted as having a margin (26 x 18 texels of 64 x 64 can show)\n" );
		else { printf( "FAIL SPRTRIM=0: r %d u %g..%g quads %u trimmable %u kept %u\n", r, u0, u1, zzhl_fx[ZFX_SPR_QUADS], zzhl_fx[ZFX_SPR_TRIMMABLE], zzhl_fx[ZFX_SPR_KEPT1000] ); fails++; }
		xacp_gl_set_sprtrim( 1 );
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		/* additive on alpha: black OR alpha 0 adds nothing -> columns 20..43, rows 24..39, one texel more around */
		if( r && u0 == 19.0f / 64.0f && u1 == 45.0f / 64.0f && v0 == 23.0f / 64.0f && v1 == 41.0f / 64.0f ) printf( "ok   SPRTRIM=1, additive glow: the box of the coloured texels plus one texel around\n" );
		else { printf( "FAIL SPRTRIM=1 additive: r %d u %g..%g v %g..%g\n", r, u0 * 64, u1 * 64, v0 * 64, v1 * 64 ); fails++; }
		pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA );
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		/* alpha blend: only alpha 0 leaves the picture alone -> columns 16..47 (a black texel with alpha darkens) */
		if( r && u0 == 15.0f / 64.0f && u1 == 49.0f / 64.0f && v0 == 23.0f / 64.0f && v1 == 41.0f / 64.0f ) printf( "ok   SPRTRIM=1, alpha blend: the box of the texels with alpha, black ones kept\n" );
		else { printf( "FAIL SPRTRIM=1 alpha: r %d u %g..%g v %g..%g\n", r, u0 * 64, u1 * 64, v0 * 64, v1 * 64 ); fails++; }
		pglDepthMask( 1 );
		u0 = v0 = 0; u1 = v1 = 1;
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( !r && u0 == 0 && v1 == 1 ) printf( "ok   SPRTRIM=1: never a quad that writes the depth buffer\n" ); else { printf( "FAIL SPRTRIM with depth write: r %d\n", r ); fails++; }
		pglDepthMask( 0 ); pglDisable( ZGL_BLEND ); pglDisable( ZGL_ALPHA_TEST );
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( !r ) printf( "ok   SPRTRIM=1: never an opaque quad without alpha test\n" ); else { printf( "FAIL SPRTRIM opaque: r %d\n", r ); fails++; }
		pglEnable( ZGL_ALPHA_TEST );
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( r && u0 == 15.0f / 64.0f && u1 == 49.0f / 64.0f ) printf( "ok   SPRTRIM=1, alpha test alone: the texels it kills are left out\n" ); else { printf( "FAIL SPRTRIM alpha test: r %d u %g..%g\n", r, u0 * 64, u1 * 64 ); fails++; }
		pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE );
		pglBindTexture( ZGL_TEXTURE_2D, 71 );
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( !r ) printf( "ok   SPRTRIM=1: a picture full to its corners is left whole\n" ); else { printf( "FAIL SPRTRIM full picture: r %d\n", r ); fails++; }
		pglBindTexture( ZGL_TEXTURE_2D, 70 );
		g_reduced = 1u;
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( !r ) printf( "ok   SPRTRIM=1: off for the session once ZZGL stored a texture reduced\n" ); else { printf( "FAIL SPRTRIM with reduced textures: r %d\n", r ); fails++; }
		g_reduced = 0u;
		{ void (*sub)( unsigned, int, int, int, int, int, unsigned, unsigned, const void * ) = zzhl_gl_proc( "glTexSubImage2D" );
		  sub( ZGL_TEXTURE_2D, 0, 0, 0, 8, 8, ZGL_RGBA, ZGL_UNSIGNED_BYTE, wall ); }
		r = zzhl_sprite_trim( &u0, &v0, &u1, &v1 );
		if( !r ) printf( "ok   SPRTRIM=1: a texture updated in place is no longer trimmed\n" ); else { printf( "FAIL SPRTRIM after a sub-image: r %d\n", r ); fails++; }
		xacp_gl_set_sprtrim( 0 );
		pglDisable( ZGL_BLEND ); pglDisable( ZGL_ALPHA_TEST ); pglDepthMask( 1 );
		xacp_gl_frame_end();
	}
	{   /* glGenTextures never answers 0 */
		unsigned (*gen)( int, unsigned * ) = zzhl_gl_proc( "glGenTextures" );
		unsigned names[3] = { 9, 9, 9 };
		extern unsigned xacp_gl_name_overflows( void );
		g_gen_fail = 1;
		gen( 3, names );
		g_gen_fail = 0;
		if( names[0] == 2288u && names[1] == 2288u && names[2] == 2288u && xacp_gl_name_overflows() == 3u ) printf( "ok   names exhausted: the overflow name, never 0\n" );
		else { printf( "FAIL names exhausted: %u %u %u, overflows %u\n", names[0], names[1], names[2], xacp_gl_name_overflows()); fails++; }
	}

	{   /* build 92, RECFAST=1: a recorded vertex's colour kept in bytes.  A model as ref_gl draws it -
		   strips, a byte colour and texture coordinates on every vertex - then a blended polygon that
		   sets no colour of its own, so the state the model left is seen.  The log of everything ZZGL
		   is given must be the same without and with it, to the character. */
		static char log0[400000];
		int pass, len0 = 0, same = 1;
		unsigned x, wrong = 0;
		for( x = 0; x < 256u; x++ ) { volatile float f = (unsigned char)x / 255.0f; int v = (int)( f * 255.0f + 0.5f ); if( v != (int)x ) wrong++; }
		if( !wrong && glq_recfast_check() == 0u ) printf( "ok   RECFAST: the 256 byte values come back as themselves through the division and the rounding\n" );
		else { printf( "FAIL RECFAST: %u byte values change\n", wrong ); fails++; }
		glq_set_sort( 1 ); glq_set_early( 0 );
		for( pass = 0; pass < 2; pass++ )
		{
			unsigned b, k, seed = 12345u;
			glq_set_recfast( pass );
			g_test_org = ZORG_STUDIO;
			reset_log(); frame_3d(); opaque_state(); pglTexEnvi( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, ZGL_MODULATE );
			pglColor4f( 0.25f, 0.5f, 0.75f, 1.0f );
			for( b = 0; b < 40u; b++ )
			{
				pglBindTexture( ZGL_TEXTURE_2D, 20u + b % 3u );
				pglBegin( b & 1u ? ZGL_TRIANGLE_FAN : ZGL_TRIANGLE_STRIP );
				for( k = 0; k < 3u + b % 17u; k++ )
				{
					unsigned char c[4];
					seed = seed * 1103515245u + 12345u;
					c[0] = (unsigned char)( seed >> 24 ); c[1] = (unsigned char)( seed >> 16 ); c[2] = (unsigned char)( seed >> 8 ); c[3] = (unsigned char)( b % 5u ? 255u : seed );
					if( k % 7u == 3u ) pglColor4f( 0.1f * (float)( k % 10u ), 0.3f, 1.5f, -0.2f );        /* a float colour in the middle, out of range too */
					else if( k % 5u == 1u ) pglColor4ub( c[0], c[1], c[2], c[3] );
					else if( k % 11u != 6u ) pglColor4ubv( c );                                       /* and sometimes none: the previous colour again */
					if( k % 13u != 9u ) pglTexCoord2f( (float)( seed & 1023u ) / 64.0f, (float)(( seed >> 10 ) & 1023u ) / 64.0f );
					pglVertex3f( (float)k, (float)b, -5.0f - (float)( k & 3u ));
				}
				pglEnd();
			}
			/* an empty Begin/End that only sets attributes, then the order-dependent draw that forces the replay */
			pglBegin( ZGL_TRIANGLES ); pglColor4ub( 10, 20, 30, 40 ); pglTexCoord2f( 0.125f, 0.875f ); pglEnd();
			g_test_org = ZORG_SPRITE;
			pglEnable( ZGL_BLEND ); pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE ); pglDepthMask( 0 );
			pglBindTexture( ZGL_TEXTURE_2D, 30 );
			pglBegin( ZGL_POLYGON );
			pglVertex3f( 0, 0, -5 ); pglVertex3f( 1, 0, -5 ); pglVertex3f( 1, 1, -5 );
			pglEnd();
			xacp_gl_frame_end();
			if( pass == 0 ) { len0 = g_logn; memcpy( log0, g_log, (size_t)g_logn + 1u ); }
			else same = ( g_logn == len0 && !memcmp( log0, g_log, (size_t)g_logn ));
		}
		if( len0 > 20000 && same ) printf( "ok   RECFAST: 40 recorded strips and fans of a model, byte and float colours mixed: ZZGL is given the same %d characters of calls\n", len0 );
		else { printf( "FAIL RECFAST: the logs differ (%d characters without, %d with)\n", len0, g_logn ); fails++; }
		if( strstr( log0, "c 10 20 30 40 tex 30" ) && strstr( log0, "st 0.125 0.875 c 10 20 30 40" )) printf( "ok   RECFAST: the colour and the coordinates a recorded batch leaves are the ones the next draw uses\n" );
		else { printf( "FAIL RECFAST: the state left by the batch is not seen\n" ); fails++; }
		glq_set_recfast( 0 ); g_test_org = ZORG_OTHER;
		pglDisable( ZGL_BLEND ); pglDepthMask( 1 );
	}

	{   /* build 94, DECALCULL=1: an overlay wholly out of view is dropped at its glEnd.  What ZZGL is
		   given must be, to the character, what it is given when those overlays are never drawn. */
		static char logref[200000];
		unsigned nb = 0, nd = 0, np = 0, bad, b0, v0 = 0, b1, v1 = 0;
		int pass, lenref = 0;
		void (*po)( float, float ) = zzhl_proc_po();
		bad = glq_decal_cull_check( &nb, &nd, &np );
		if( bad == 0u && nb == 4000u && nd > 500u && nd < np ) printf( "ok   DECALCULL: its own check, %u batches: it drops %u, the plain comparisons %u, never one they keep\n", nb, nd, np );
		else { printf( "FAIL DECALCULL: check: %u batches, drops %u, plain %u, dropped alone %u\n", nb, nd, np, bad ); fails++; }
		glq_set_sort( 1 ); glq_set_early( 0 ); glq_set_decal_group( 2 ); glq_set_decal_bias( 4 );
		/* pass 0: off, the out-of-view overlays not drawn at all (the reference); 1: off, all drawn;
		   2: on, all drawn; 3: on but REJECT off, all drawn */
		for( pass = 0; pass < 4; pass++ )
		{
			const int all = pass != 0;
			glq_set_decal_cull( pass >= 2 ); glq_decal_cull_reject_is( pass != 3 );
			b0 = glq_decal_culled( &v0 );
			pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA );   /* the same state in the four passes, whatever the test before left */
			reset_log(); frame_3d(); opaque_state();
			poly( 10, 0, 1 );                                    /* world */
			pglEnable( ZGL_BLEND ); pglDepthMask( 0 );
			pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
			poly( 81, 0, 1 );                                    /* in view */
			if( all ) poly( 82, 100, 1 );                        /* far beyond the right side */
			poly( 84, 4.5f, 1 );                                 /* across the right side */
			if( all ) poly( 83, -200, 1 );                       /* far beyond the left side */
			poly( 85, 5.01f, 1 );                                /* beyond the side by less than the margin: kept, ZZGL's business */
			if( all )
			{   /* far above */
				pglBindTexture( ZGL_TEXTURE_2D, 86 ); pglBegin( ZGL_TRIANGLES );
				pglTexCoord2f( 0, 0 ); pglVertex3f( 0, 300, -5 ); pglTexCoord2f( 1, 0 ); pglVertex3f( 1, 300, -5 ); pglTexCoord2f( 1, 1 ); pglVertex3f( 1, 301, -5 );
				pglEnd();
			}
			poly( 87, -3, 1 );                                   /* in view, after the dropped ones */
			pglDisable( ZGL_POLYGON_OFFSET_FILL ); pglDepthMask( 1 ); pglDisable( ZGL_BLEND );
			xacp_gl_frame_end();
			b1 = glq_decal_culled( &v1 ) - b0; v1 -= v0;
			/* what is compared is the replay (from the first ORG line): while it records, a dropped
			   overlay has had its modelview set to identity and put back, like any biased batch -
			   two matrix loads with no draw between them */
			if( pass == 0 ) { const char *r = strstr( g_log, "ORG " ); lenref = r ? (int)strlen( r ) : 0; if( r ) memcpy( logref, r, (size_t)lenref + 1u ); }
			if( pass == 1 )
			{
				if( count_of( "BEGIN " ) == 8 && b1 == 0u && strstr( g_log, "BIND 82" ) && strstr( g_log, "BIND 83" ) && strstr( g_log, "BIND 86" )) printf( "ok   DECALCULL=0: the three out-of-view overlays are replayed as before\n" );
				else { printf( "FAIL DECALCULL=0: %d BEGIN, %u dropped\n", count_of( "BEGIN " ), b1 ); fails++; }
			}
			if( pass == 2 )
			{
				if( b1 == 3u && v1 == 11u ) printf( "ok   DECALCULL=1: three overlays dropped at their glEnd (11 vertices)\n" );
				else { printf( "FAIL DECALCULL=1: %u batches, %u vertices dropped, expected 3 and 11\n", b1, v1 ); fails++; }
				const char *r = strstr( g_log, "ORG " );
				if( r && (int)strlen( r ) == lenref && !memcmp( r, logref, (size_t)lenref ) && lenref > 300 ) printf( "ok   DECALCULL=1: the replay gives ZZGL the %d characters it gets when those overlays are never drawn\n", lenref );
				else { printf( "FAIL DECALCULL=1: the replay differs from the reference (%d against %d)\nREF:\n%s\nGOT:\n%s\n", r ? (int)strlen( r ) : -1, lenref, logref, r ? r : "(none)" ); fails++; }
				if( strstr( g_log, "BIND 85" )) printf( "ok   DECALCULL=1: an overlay beyond the side by less than the margin is kept\n" );
				else { printf( "FAIL DECALCULL=1: the overlay inside the margin was dropped\n" ); fails++; }
			}
			if( pass == 3 )
			{
				if( b1 == 0u && count_of( "BEGIN " ) == 8 ) printf( "ok   DECALCULL=1 without REJECT: nothing dropped\n" );
				else { printf( "FAIL DECALCULL=1 without REJECT: %u dropped\n", b1 ); fails++; }
			}
		}
		glq_set_decal_cull( 0 ); glq_decal_cull_reject_is( 1 );
	}

	{   /* build 97, MESHIDX=1: an indexed triangle list with each vertex given once.  The triangles ZZGL
		   draws - their order, the three vertices of each with their colour and coordinates - must be
		   those of the unrolled list, recorded or passed through; and far fewer vertices travel. */
		extern void xacp_gl_set_meshidx( int on );
		extern void xacp_gl_meshidx_stats( unsigned v[3] );
		typedef void (*ptr_fn)( int, unsigned, int, const void * );
		typedef void (*cs_fn)( unsigned );
		typedef void (*de_fn)( unsigned, int, unsigned, const void * );
		ptr_fn vp = (ptr_fn)zzhl_gl_proc( "glVertexPointer" ), cp = (ptr_fn)zzhl_gl_proc( "glColorPointer" ), tp = (ptr_fn)zzhl_gl_proc( "glTexCoordPointer" );
		cs_fn ecs = (cs_fn)zzhl_gl_proc( "glEnableClientState" ), dcs = (cs_fn)zzhl_gl_proc( "glDisableClientState" );
		de_fn de = (de_fn)zzhl_gl_proc( "glDrawElements" );
		static float av[400][3], at[400][2]; static unsigned char ac[400][4]; static unsigned short ai[3000];
		static char tref[600000];
		unsigned nvv = 0, ni = 0, seed = 424242u, strip, v3[3];
		int pass, lenref = 0, nvref = 0, nbref = 0;
		/* strips and fans turned into triples the way R_StudioBuildIndices does */
		for( strip = 0; strip < 24u && nvv < 380u; strip++ )
		{
			const unsigned len = 3u + ( seed = seed * 1103515245u + 12345u, ( seed >> 16 ) % 30u ), fan = strip % 3u == 2u, first = nvv;
			unsigned k;
			for( k = 0; k < len && nvv < 400u; k++, nvv++ )
			{
				av[nvv][0] = (float)( nvv % 20u ) * 0.2f - 2.0f; av[nvv][1] = (float)( nvv / 20u ) * 0.2f - 2.0f + (float)( k & 1u ) * 0.1f; av[nvv][2] = -5.0f - (float)( nvv % 7u ) * 0.01f;
				at[nvv][0] = (float)nvv * 0.0078125f; at[nvv][1] = (float)k * 0.03125f;
				ac[nvv][0] = (unsigned char)nvv; ac[nvv][1] = (unsigned char)( 255u - nvv ); ac[nvv][2] = (unsigned char)( 3u * nvv ); ac[nvv][3] = 255;
				if( k >= 2u )
				{
					if( fan ) { ai[ni++] = (unsigned short)first; ai[ni++] = (unsigned short)( nvv - 1u ); ai[ni++] = (unsigned short)nvv; }
					else if( k & 1u ) { ai[ni++] = (unsigned short)( nvv - 1u ); ai[ni++] = (unsigned short)( nvv - 2u ); ai[ni++] = (unsigned short)nvv; }
					else { ai[ni++] = (unsigned short)( nvv - 2u ); ai[ni++] = (unsigned short)( nvv - 1u ); ai[ni++] = (unsigned short)nvv; }
				}
			}
		}
		/* passes: 0 unrolled and recorded (the reference), 1 indexed and recorded, 2 unrolled passed through, 3 indexed passed through */
		for( pass = 0; pass < 4; pass++ )
		{
			xacp_gl_set_meshidx( pass & 1 ); glq_set_sort( pass < 2 ); glq_set_early( 0 );
			g_test_org = ZORG_STUDIO;
			reset_log(); g_tlogn = 0; g_tlog[0] = 0; frame_3d(); opaque_state(); pglTexEnvi( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, ZGL_MODULATE );
			pglBindTexture( ZGL_TEXTURE_2D, 30 );
			ecs( 0x8074 ); vp( 3, 0x1406, 12, av ); ecs( 0x8078 ); tp( 2, 0x1406, 0, at ); ecs( 0x8076 ); cp( 4, 0x1401, 0, ac );
			de( ZGL_TRIANGLES, (int)ni, 0x1403, ai );
			dcs( 0x8074 ); dcs( 0x8078 ); dcs( 0x8076 );
			xacp_gl_frame_end();
			if( getenv( "MESHIDX_DEBUG" )) { const char *q = g_log; printf( "pass %d:", pass ); while(( q = strstr( q, "ENDX " ))) { int a = 0; unsigned b = 0; sscanf( q, "ENDX %d %u", &a, &b ); printf( " %d/%u", a, b ); q += 5; } printf( "  V lines %d, 'V ' anywhere %d\n", count_of( "\nV " ), count_of( "V " )); }
			if( pass == 0 ) { lenref = g_tlogn; memcpy( tref, g_tlog, (size_t)g_tlogn + 1u ); nvref = count_of( "V " ); nbref = count_of( "BEGIN " ); }
			else
			{
				static const char *const nm[4] = { "", "indexed, recorded", "unrolled, passed through", "indexed, passed through" };
				if( lenref > 10000 && g_tlogn == lenref && !memcmp( g_tlog, tref, (size_t)lenref )) printf( "ok   MESHIDX, %s: the same %u triangles, vertex for vertex, in the same order\n", nm[pass], ni / 3u );
				else { printf( "FAIL MESHIDX, %s: the triangles differ (%d characters against %d)\n", nm[pass], g_tlogn, lenref ); fails++; }
				if( pass & 1 )
				{
					if( count_of( "V " ) * 2 < nvref && count_of( "BEGIN " ) < nbref && count_of( "V " ) >= (int)nvv ) printf( "ok   MESHIDX, %s: %d vertices in %d batches instead of %d in %d\n", nm[pass], count_of( "V " ), count_of( "BEGIN " ), nvref, nbref );
					else { printf( "FAIL MESHIDX, %s: %d vertices in %d batches (unrolled %d in %d)\n", nm[pass], count_of( "V " ), count_of( "BEGIN " ), nvref, nbref ); fails++; }
				}
			}
		}
		xacp_gl_meshidx_stats( v3 );
		if( v3[1] == 2u * ( ni / 3u ) && v3[2] < 3u * v3[1] / 2u ) printf( "ok   MESHIDX: its counters: %u blocks, %u triangles, %u vertices over the two indexed passes\n", v3[0], v3[1], v3[2] );
		else { printf( "FAIL MESHIDX: counters %u blocks %u triangles %u vertices\n", v3[0], v3[1], v3[2] ); fails++; }
		xacp_gl_set_meshidx( 0 ); glq_set_sort( 1 ); g_test_org = ZORG_OTHER;
	}

	{   /* build 96, DECALFRUST=2, the queue's side of the check: a decal ref_gl marks as out of view must
		   have all its vertices outside one side by the plain comparisons; one that has not is wrong. */
		extern unsigned zzhl_decal_mark;
		unsigned v[5];
		void (*po)( float, float ) = zzhl_proc_po();
		glq_set_sort( 1 ); glq_set_early( 0 ); glq_set_decal_group( 2 ); glq_set_decal_bias( 4 ); glq_set_decal_cull( 0 );
		glq_set_decal_frust( 2 );
		pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA );
		reset_log(); frame_3d(); opaque_state();
		poly( 10, 0, 1 );
		pglEnable( ZGL_BLEND ); pglDepthMask( 0 ); pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		zzhl_decal_mark = 1u; poly( 82, 100, 1 );            /* marked, and really out of view: right */
		poly( 81, 0, 1 );                                    /* not marked */
		zzhl_decal_mark = 1u; poly( 83, 5.01f, 1 );          /* marked, beyond the side by a hair: still right */
		zzhl_decal_mark = 1u; poly( 84, 4.5f, 1 );           /* marked, but across the side: WRONG */
		zzhl_decal_mark = 1u; poly( 85, 0, 1 );              /* marked, in the middle of the view: WRONG */
		pglDisable( ZGL_POLYGON_OFFSET_FILL ); pglDepthMask( 1 ); pglDisable( ZGL_BLEND );
		zzhl_decal_mark = 1u; poly( 11, 0, 1 );              /* marked, not an overlay, in view: WRONG (checked all the same) */
		zzhl_decal_mark = 1u; poly( 11, 100, 1 );            /* marked, not an overlay, out of view: right */
		pglEnable( ZGL_BLEND );
		zzhl_decal_mark = 1u; poly( 12, 100, 1 );            /* marked, blended and not biased (passed through), out of view: right */
		zzhl_decal_mark = 1u; poly( 12, 0, 1 );              /* the same in view: WRONG */
		pglDisable( ZGL_BLEND );
		xacp_gl_frame_end();
		glq_decal_frust_stats( v );
		if( v[2] == 8u && v[3] == 4u && v[4] == 0u && count_of( "BEGIN " ) == 10 ) printf( "ok   DECALFRUST=2: of 8 marked polygons (4 biased overlays, 2 opaque, 2 blended passed through), 4 right, 4 wrong, 0 not checked; all ten drawn\n" );
		else { printf( "FAIL DECALFRUST=2: marked %u wrong %u unchecked %u, %d BEGIN\n", v[2], v[3], v[4], count_of( "BEGIN " )); fails++; }
		glq_set_decal_frust( 0 );
	}

	{   /* the overlays by source (what ref_gl says it is drawing), with DECALCULL on, and
		   WATERCULL=2's check through the same mark as DECALFRUST=2. */
		extern unsigned zzhl_decal_mark, zzhl_emit_decal;
		extern int zzhl_emit_water, zzhl_emit_bmodel;
		unsigned d0[GLQ_OV_SRC], dv0[GLQ_OV_SRC], k0[GLQ_OV_SRC], kv0[GLQ_OV_SRC], d[GLQ_OV_SRC], dv[GLQ_OV_SRC], k[GLQ_OV_SRC], kv[GLQ_OV_SRC], v0[5], v[5], i, good = 1;
		void (*po)( float, float ) = zzhl_proc_po();
		glq_set_sort( 1 ); glq_set_early( 0 ); glq_set_decal_group( 2 ); glq_set_decal_bias( 4 ); glq_set_decal_cull( 1 ); glq_set_water_cull( 2 );
		glq_overlay_src_stats( d0, dv0, k0, kv0 ); glq_decal_frust_stats( v0 );
		pglBlendFunc( ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA );
		reset_log(); frame_3d(); opaque_state();
		poly( 10, 0, 1 );
		pglEnable( ZGL_BLEND ); pglDepthMask( 0 ); pglEnable( ZGL_POLYGON_OFFSET_FILL ); po( -1.0f, -2.0f );
		zzhl_emit_bmodel = 1;
		zzhl_emit_water = 1;
		zzhl_decal_mark = 1u; poly( 82, 100, 1 );            /* water, out of view, marked: dropped, right */
		poly( 82, 0, 1 );                                    /* water, in view: recorded */
		zzhl_decal_mark = 1u; poly( 82, 0, 1 );              /* water, in view but marked: recorded, WRONG */
		zzhl_emit_water = 0;
		zzhl_emit_decal = 1u; poly( 81, 100, 1 );            /* a decal, out of view: dropped */
		poly( 83, 100, 1 );                                  /* the flag was cleared: a surface of the entity at rest, dropped */
		zzhl_emit_decal = 1u; poly( 81, 0, 1 );              /* a decal, in view: recorded */
		zzhl_emit_bmodel = 2; poly( 84, 100, 1 ); poly( 84, 0, 1 );   /* a moved entity: one dropped, one recorded */
		zzhl_emit_bmodel = 0; poly( 85, 100, 1 );            /* the rest: dropped */
		pglDisable( ZGL_POLYGON_OFFSET_FILL ); pglDepthMask( 1 ); pglDisable( ZGL_BLEND );
		xacp_gl_frame_end();
		glq_overlay_src_stats( d, dv, k, kv ); glq_decal_frust_stats( v );
		for( i = 0; i < GLQ_OV_SRC; i++ ) { d[i] -= d0[i]; k[i] -= k0[i]; dv[i] -= dv0[i]; kv[i] -= kv0[i]; }
		{
			static const unsigned wd[GLQ_OV_SRC] = { 1, 1, 1, 1, 1 }, wk[GLQ_OV_SRC] = { 2, 1, 0, 1, 0 };
			for( i = 0; i < GLQ_OV_SRC; i++ ) if( d[i] != wd[i] || k[i] != wk[i] || ( d[i] && !dv[i] ) || ( k[i] && !kv[i] )) good = 0;
		}
		if( good && !zzhl_emit_decal ) printf( "ok   overlays by source: water 1 dropped 2 recorded, decals 1 and 1, entity at rest 1 and 0, moved 1 and 1, the rest 1 and 0\n" );
		else { printf( "FAIL overlays by source: dropped %u %u %u %u %u, recorded %u %u %u %u %u\n", d[0], d[1], d[2], d[3], d[4], k[0], k[1], k[2], k[3], k[4] ); fails++; }
		if( v[2] - v0[2] == 2u && v[3] - v0[3] == 1u && v[4] - v0[4] == 0u ) printf( "ok   WATERCULL=2: of 2 marked water polygons, 1 right and 1 wrong\n" );
		else { printf( "FAIL WATERCULL=2: marked %u wrong %u unchecked %u\n", v[2] - v0[2], v[3] - v0[3], v[4] - v0[4] ); fails++; }
		glq_set_water_cull( 0 ); glq_set_decal_cull( 0 );
	}

	{   /* build 95, EMITPROF=1: a measure.  It must change nothing ZZGL is given, and count the calls. */
		static char log0[40000];
		int pass, len0 = 0, k;
		for( pass = -1; pass < 2; pass++ )            /* -1: a first pass that leaves the state the two others start from */
		{
			glq_set_emit_prof( pass == 1 );
			g_test_org = ZORG_STUDIO;
			reset_log(); frame_3d(); opaque_state(); pglTexEnvi( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, ZGL_MODULATE );
			pglBindTexture( ZGL_TEXTURE_2D, 30 );
			pglBegin( ZGL_TRIANGLE_STRIP );
			for( k = 0; k < 10; k++ )
			{
				unsigned char c[4]; c[0] = (unsigned char)( 20 * k ); c[1] = 40; c[2] = 60; c[3] = 255;
				pglColor4ubv( c ); pglTexCoord2f( 0.125f * (float)k, 0.5f ); pglVertex3f( (float)k * 0.25f, (float)( k & 1 ), -5 );
			}
			pglEnd();
			xacp_gl_frame_end();
			if( pass == 0 ) { len0 = g_logn; memcpy( log0, g_log, (size_t)g_logn + 1u ); }
		}
		if( len0 > 200 && g_logn == len0 && !memcmp( g_log, log0, (size_t)len0 )) printf( "ok   EMITPROF: ZZGL is given the same %d characters with the measure on\n", len0 );
		else { printf( "FAIL EMITPROF: the logs differ (%d without, %d with)\nREF:\n%s\nGOT:\n%s\n", len0, g_logn, log0, g_log ); fails++; }
		{
			unsigned long long tk = 0ull;
			const unsigned nb = glq_emit_prof_get( 0, 0, &tk ), nc = glq_emit_prof_get( 0, 1, &tk ), nt = glq_emit_prof_get( 0, 2, &tk ), nv = glq_emit_prof_get( 0, 3, &tk ),
				ne = glq_emit_prof_get( 0, 4, &tk ), g1 = glq_emit_prof_get( 0, 6, &tk ), g2 = glq_emit_prof_get( 0, 7, &tk ), g3 = glq_emit_prof_get( 0, 8, &tk ), g4 = glq_emit_prof_get( 0, 9, &tk );
			if( nb == 1u && nc == 10u && nt == 10u && nv == 10u && ne == 1u && g1 == 9u && g2 == 10u && g3 == 10u && g4 == 0u && glq_emit_prof_get( 1, 3, &tk ) == 0u )
				printf( "ok   EMITPROF: a strip of 10 vertices of a model: 1 begin, 10 of each call, 1 end, gaps 9 / 10 / 10\n" );
			else { printf( "FAIL EMITPROF: begin %u colour %u texcoord %u vertex %u end %u gaps %u %u %u other %u\n", nb, nc, nt, nv, ne, g1, g2, g3, g4 ); fails++; }
		}
		glq_set_emit_prof( 0 ); g_test_org = ZORG_OTHER;
	}

	printf( fails ? "GLQ TESTS FAILED (%d)\n" : "GLQ ALL TESTS PASSED\n", fails );
	return fails ? 1 : 0;
}
