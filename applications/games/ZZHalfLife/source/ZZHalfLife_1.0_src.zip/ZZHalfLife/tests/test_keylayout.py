#!/usr/bin/env python3
# test_keylayout.py - ZZHalfLife build 81.
#
# Keys by position (xacp/src/xacp_input.c, by_position()).  The launcher sends the CHARACTER the
# AmigaOS keymap gives, so on AZERTY the key at QWERTY's W place sends 'z'.  Half-Life's bindings
# are QWERTY names, so each character has to be turned back into the key at the same place.
#
# Nothing checked that table.  It is a hand-written switch, and its letter swaps must be
# SYMMETRIC: 'a'->'q' without 'q'->'a' would leave one of the two keys dead, and the only way to
# both be guaranteed; this is that guarantee, taken from the source itself.
#
# Standard library only.  ASCII only.
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
fails = []


def check(ok, what):
    print(("PASS  " if ok else "FAIL  ") + what)
    if not ok:
        fails.append(what)


src = open(os.path.join(ROOT, "xacp/src/xacp_input.c"), encoding="latin-1").read()
body = src[src.index("static int by_position("):]
body = body[:body.index("\n}\n")]
az = body[body.index("if( layout() == 1 )"):body.index("else if( layout() == 2 )")]
qz = body[body.index("else if( layout() == 2 )"):]

# AZERTY: the letter swaps, as "case 'x': return 'y';"
amap = {}
for m in re.finditer(r"case '(\\?.)'\s*:\s*(?:\*digit = 1;\s*)?return '(\\?.)';", az):
    a, b = m.group(1).replace("\\", ""), m.group(2).replace("\\", "")
    amap[a] = b
check(len(amap) >= 9, "the AZERTY table is read (%d entries)" % len(amap))

for a, b in (('a', 'q'), ('z', 'w'), ('q', 'a'), ('w', 'z')):
    check(amap.get(a) == b, "AZERTY: %r gives QWERTY's %r" % (a, b))
check(amap.get('m') == ';', "AZERTY: 'm' gives QWERTY's ';'")

# the invariant that cannot be seen without a French keyboard: the swaps go BOTH ways
letters = {k: v for k, v in amap.items() if k.isalpha() and v.isalpha()}
oneway = ["%r->%r but %r is not mapped back" % (k, v, v)
          for k, v in letters.items() if letters.get(v) != k]
check(not oneway, "AZERTY: every letter swap is symmetric" + (" -- " + "; ".join(oneway) if oneway else ""))

# the number row: only the ASCII ones can arrive at all (the accented 2 7 9 0 never leave the
# launcher), and those that do must be named, or the weapon slot is unreachable without Shift
digits = {k: v for k, v in amap.items() if v.isdigit()}
check(digits == {'&': '1', '"': '3', "'": '4', '(': '5'},
      "AZERTY: the number row maps & \" ' ( to 1 3 4 5 (got %r)" % (sorted(digits.items()),))
check(all(k not in amap for k in ('-', '_')),
      "AZERTY: '-' and '_' are deliberately NOT taken as 6 and 8 "
      "(they stay usable as themselves; weapons 6 and 8 need Shift)")

# du pave numerique marchent c'est bon").  The Amiga passes the keypad through MapRawKey, which
# gives the CHARACTERS '0'..'9', and no layout branch may touch them: they must reach the game as
# the digits they are, whatever the keyboard.  The accented top row of AZERTY is then irrelevant.
for d in "0123456789":
    check(d not in amap, "keypad: %r is not remapped by the AZERTY table" % d)
check(not [d for d in "0123456789" if "'%s'" % d in qz],
      "keypad: the QWERTZ table does not touch the digits either")
check("*digit = ( c >= '0' && c <= '9' );" in body,
      "keypad: a digit character is flagged as a digit before any layout branch runs")

# QWERTZ: y and z swap, and that swap must be symmetric too
qmap = dict(re.findall(r"if\( c == '(.)' \) return '(.)';", qz))
check(qmap.get('z') == 'y' and qmap.get('y') == 'z', "QWERTZ: 'y' and 'z' swap, both ways")

# QWERTY is the identity: layout 0 must have no table at all
check("layout() == 0" not in body, "QWERTY: no translation, the characters pass through as sent")
check(body.rstrip().endswith("return c;"), "any character not named passes through unchanged")

print()
if fails:
    print("%d FAILED" % len(fails))
    sys.exit(1)
print("ALL TESTS PASSED")
