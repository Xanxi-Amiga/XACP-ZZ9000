/* SPDX-License-Identifier: GPL-3.0-or-later */
/* zzhl2.ld - ZZHalfLife engine image (stage 2, zzhl_core.bin): Xash3D-FWGS + HLSDK + ref_gl +
 * ZZGL + librixgpu, linked at ZZHL_CORE_LOAD in the Core1 arena, loaded there by the stage-1
 * blob (Core1/zzhl_glue.c) through the launcher's READAT. The 64-byte header comes first
 * (xacp/src/xacp_main.c, section .zzhlhdr), tools/mkcore.py fills it after the link.
 *   0x3A800000  header, text, rodata, data, init_array        (in the file)
 *   ...         bss (NOLOAD, cleared by the loader)           must end <= 0x3D400000
 *   0x3D400000  the game image zzhl_game.bin (Core1/zzhl_game.ld), its bss <= 0x3D800000
 * Below: the 8 MiB engine stack (0x3A000000..0x3A800000) and the heap (0x30000000.. after
 * the boot container). Above: the RasterIX reservation of ZZQuake2RIX, unchanged.
 */
ENTRY(zzhl_core_entry)
SECTIONS {
    . = 0x3A800000;
    .zzhlhdr : { KEEP(*(.zzhlhdr)) }
    .text : {
        _text_start = .;
        *(.text*)
        . = ALIGN(4);
        _text_end = .;
    }
    .rodata : { *(.rodata*) . = ALIGN(4); }
    .ARM.extab : { *(.ARM.extab*) }
    .ARM.exidx : { __exidx_start = .; *(.ARM.exidx*) __exidx_end = .; }
    .preinit_array : { . = ALIGN(4); __preinit_array_start = .; KEEP(*(.preinit_array*)) __preinit_array_end = .; }
    .init_array : { . = ALIGN(4); __init_array_start = .; KEEP(*(SORT_BY_INIT_PRIORITY(.init_array.*))) KEEP(*(.init_array)) __init_array_end = .; }
    .fini_array : { . = ALIGN(4); __fini_array_start = .; KEEP(*(.fini_array*)) __fini_array_end = .; }
    .data : { . = ALIGN(16); _data_start = .; *(.data*) . = ALIGN(16); _data_end = .; }
    _image_end = .;
    .bss (NOLOAD) : { . = ALIGN(32); _bss_start = .; *(.bss*) *(COMMON) . = ALIGN(32); _bss_end = .; }
    _end = .;
    /DISCARD/ : { *(.note*) *(.comment*) }
}
/* the game image (zzhl_game.bin, Core1/zzhl_game.ld) is linked at 0x3D400000, inside the
   same range: the engine image and its bss end below it */
ASSERT(_end <= 0x3D400000, "ZZHalfLife: engine image + bss reaches the game image (0x3D400000, xacp/include/zzhl_game.h)")
