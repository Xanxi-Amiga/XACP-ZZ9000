/* SPDX-License-Identifier: GPL-3.0-or-later */
/*
 * zzhl_glue.c - ZZHalfLife stage 1: what the ZZQuake640 release runtime calls at its
 * bifurcation point (QG_Create / QG_Tick / Host_Shutdown, exactly where ZZQuake2 and
 * ZZOpenLara take over). The runtime (boot, MMU, shared protocol, file service, key queue,
 * presentation handshake) is compiled from the release tree, unmodified.
 *
 * QG_Create:
 *   1. reads the engine image PROGDIR:data/zzhl_core.bin through the launcher's READAT
 *      (Core1/zzhl_fsat.c) into the arena at its link address (header checked: magic,
 *      version, load address, size, CRC-32, screen size);
 *   2. clears its bss, cleans the caches (code written through the data side);
 *   3. fills the runtime API (xacp/include/xacp_rt.h) and calls the image's entry on the
 *      8 MiB engine stack (Core1/zzhl_stack.S); the engine runs until it quits.
 * QG_Tick: the engine has returned: the release loop ends (zzq_running = 0).
 * The release expects a preloaded PACK0 (pak_check): the 68k wrapper gives it a small boot
 * container with the options file; nothing else is preloaded.
 * ASCII only.
 */
#include <stdio.h>
#include <string.h>
#include "zzquake_config.h"
#include "xacp_rt.h"
#include "zzhl_core.h"
#include "zzq2_res.h"
#include "zzhl_conlog.h"

typedef unsigned int u32;
typedef unsigned char u8;

/* release runtime */
extern volatile u32 *shared;
extern volatile int zzq_running;
extern u32   zzq_us_now(void);
extern int   zzq_printf(const char *fmt, ...);
extern void  zzq_fatal_end(u32 code);
extern FILE  *zzq_fopen(const char *path, const char *mode);
extern int    zzq_fclose(FILE *f);
extern size_t zzq_fread(void *dst, size_t sz, size_t n, FILE *f);
extern size_t zzq_fwrite(const void *src, size_t sz, size_t n, FILE *f);
extern int    zzq_fseek(FILE *f, long off, int whence);
extern long   zzq_ftell(FILE *f);
extern int    Sys_FileTime(char *path);
extern int    QG_GetKey(int *down, int *key);
extern void   QG_GetMouseMove(int *x, int *y);
extern void   dcache_clean_range(u32 start, u32 len);
extern void   dcache_invalidate_range(u32 start, u32 len);
/* stage 1 */
extern int  zzhl_read_at(const char *name, unsigned off, void *dst, unsigned len, unsigned *total);
extern void zzhl_read_at_stats(unsigned *requests, unsigned *failures, unsigned *us, unsigned *bytes);
extern int  zzhl_call_on_stack(int (*fn)(const void *), const void *arg, unsigned stack_top);

/* the identity the 68k wrapper (launcher/ZZHalfLife.c) looks for in zzhl.bin */
/* kept out of --gc-sections (used) and read at start-up, so that it is in the blob whatever the
   linker does: A0 v1 lost it to the garbage collector ("not a ZZHalfLife blob", 30/10) */
#ifdef ZZHL_BLOB_320
__attribute__((used, section(".rodata.zzhl_ident"))) const char zzhl_blob_ident[] = "ZZHALFLIFE-A0 320";
#define ZZHL_CORE_FILE "zzhl_core_320.bin"
#elif defined(ZZHL_BLOB_800)
__attribute__((used, section(".rodata.zzhl_ident"))) const char zzhl_blob_ident[] = "ZZHALFLIFE-A0 800";
#define ZZHL_CORE_FILE "zzhl_core_800.bin"
#else
__attribute__((used, section(".rodata.zzhl_ident"))) const char zzhl_blob_ident[] = "ZZHALFLIFE-A0";
#define ZZHL_CORE_FILE "zzhl_core.bin"
#endif

static zzhl_rt_t g_rt;
static int g_rc = -1;

static int file_time(const char *path) { return Sys_FileTime((char *)path); }

static int pump(void)
{
    shared[SH_HB]++;
    if (shared[SH_CMD] == ZZQ_CMD_STOP) return 1;
    return 0;
}

static u32 crc32_calc(const u8 *p, u32 n)
{
    static u32 tab[256];
    u32 c, i, k;
    if (!tab[1]) for (i = 0; i < 256u; i++) { c = i; for (k = 0; k < 8; k++) c = (c & 1u) ? 0xEDB88320u ^ (c >> 1) : c >> 1; tab[i] = c; }
    c = 0xFFFFFFFFu;
    for (i = 0; i < n; i++) c = tab[(c ^ p[i]) & 0xFFu] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

static void diag(const char *s) { zzq_printf("%s", s); zzhl_conlog_line(s); }

/* loads PROGDIR:data/zzhl_core.bin at its link address; 0 = ok, else a step number for the diag */
static int load_core(zzhl_core_hdr_t *h)
{
    u8 head[64];
    unsigned total = 0, got, done, size;
    u8 *dst;
    int n;
    n = zzhl_read_at(ZZHL_CORE_FILE, 0, head, 64, &total);
    if (n != 64) return 1;
    memcpy(h, head, sizeof *h);
    if (h->magic0 != ZZHL_CORE_MAGIC0 || h->magic1 != ZZHL_CORE_MAGIC1) return 2;
    if (h->version != ZZHL_CORE_VERSION || h->hdr_size != 64u) return 3;
    if (h->load != ZZHL_CORE_LOAD || h->image_size != total || h->image_size < 64u) return 4;
    if (h->bss_end > ZZHL_CORE_LIMIT || h->bss_start < h->load + h->image_size - 64u) return 5;
    if (h->vid_w != (u32)ZZHL_VID_W || h->vid_h != (u32)ZZHL_VID_H) return 6;
    size = h->image_size;
    dst = (u8 *)h->load;
    memcpy(dst, head, 64);
    done = 64;
    while (done < size) {
        unsigned want = size - done;
        if (want > 4u * 1024u * 1024u) want = 4u * 1024u * 1024u;
        n = zzhl_read_at(ZZHL_CORE_FILE, done, dst + done, want, 0);
        if (n <= 0) return 7;
        got = (unsigned)n;
        done += got;
        pump();
        if (got < want) break;
    }
    if (done != size) return 8;
    if (crc32_calc(dst + 64, size - 64) != h->crc32) return 9;
    return 0;
}

static int run_core(const void *arg)
{
    const zzhl_core_hdr_t *h = (const zzhl_core_hdr_t *)arg;
    zzhl_core_entry_t entry = (zzhl_core_entry_t)h->entry;
    return entry(&g_rt);
}

void QG_Create(int argc, char *argv[])
{
    static zzhl_core_hdr_t h;
    int rc;
    u32 t0 = zzq_us_now();
    (void)argc; (void)argv;
    shared[SH_STAGE] = 1;
    zzhl_conlog_init();          /* post-mortem console for ZZSlots; staging is idle after PRELOAD */
    diag(zzhl_blob_ident);
    diag("ZZHL: loading " ZZHL_CORE_FILE);
    rc = load_core(&h);
    if (rc) {
        unsigned req, fail, us, bytes;
        zzhl_read_at_stats(&req, &fail, &us, &bytes);
        zzq_printf("ZZHL: core load failed step %d (req %u fail %u)", rc, req, fail);
        shared[SH_ERROR] = ZZQ_FATAL_BAD_FILE;
        shared[SH_EXIT_REASON] = ZZQ_EXIT_FATAL;
        zzq_running = 0;
        return;
    }
    /* bss, then the caches: the image was written through the data side */
    memset((void *)h.bss_start, 0, h.bss_end - h.bss_start);
    dcache_clean_range(h.load, h.bss_end - h.load);
    __asm__ volatile("dsb sy" ::: "memory");
    __asm__ volatile("mcr p15, 0, %0, c7, c5, 0" :: "r"(0));   /* ICIALLU */
    __asm__ volatile("mcr p15, 0, %0, c7, c5, 6" :: "r"(0));   /* BPIALL */
    __asm__ volatile("dsb sy\n\tisb" ::: "memory");
    zzq_printf("ZZHL: core %u KiB loaded in %u ms", h.image_size / 1024u, (zzq_us_now() - t0) / 1000u);

    memset(&g_rt, 0, sizeof g_rt);
    g_rt.magic = ZZHL_RT_MAGIC; g_rt.version = ZZHL_RT_VERSION; g_rt.size = sizeof g_rt;
    g_rt.shared = shared;
    g_rt.us_now = zzq_us_now;
    g_rt.printf = zzq_printf;
    g_rt.fatal = zzq_fatal_end;
    g_rt.fopen = zzq_fopen; g_rt.fclose = zzq_fclose; g_rt.fread = zzq_fread; g_rt.fwrite = zzq_fwrite;
    g_rt.fseek = zzq_fseek; g_rt.ftell = zzq_ftell;
    g_rt.file_time = file_time;
    g_rt.read_at = zzhl_read_at;
    g_rt.get_key = QG_GetKey;
    g_rt.get_mouse_move = QG_GetMouseMove;
    g_rt.dcache_clean = dcache_clean_range;
    g_rt.dcache_invalidate = dcache_invalidate_range;
    g_rt.pack0_addr = shared[SH_PACK0_ADDR];
    g_rt.pack0_size = shared[SH_PACK0_SIZE];
    {   /* heap: from the first MiB boundary after the boot container to the engine stack */
        u32 lo = g_rt.pack0_addr + g_rt.pack0_size;
        if (lo < ZZHL_HEAP_LO) lo = ZZHL_HEAP_LO;
        lo = (lo + 0xFFFFFu) & ~0xFFFFFu;
        g_rt.heap_lo = lo; g_rt.heap_hi = ZZHL_HEAP_HI;
        if (lo >= ZZHL_HEAP_HI) {
            zzq_printf("ZZHL: boot container too large (%u KiB)", g_rt.pack0_size / 1024u);
            shared[SH_ERROR] = ZZQ_FATAL_PAK_TOO_BIG; shared[SH_EXIT_REASON] = ZZQ_EXIT_FATAL; zzq_running = 0;
            return;
        }
    }
    g_rt.image_lo = h.load; g_rt.image_hi = h.bss_end;
    g_rt.vid_w = (u32)ZZHL_VID_W; g_rt.vid_h = (u32)ZZHL_VID_H;
    g_rt.vid_bpp = (shared[SH_FB_BPP] == 2u) ? 16u : 32u;
    g_rt.pump = pump;
    shared[SH_HUNK_BASE] = g_rt.heap_lo;
    shared[SH_HUNK_SIZE] = g_rt.heap_hi - g_rt.heap_lo;

    shared[SH_STAGE] = 2;
    g_rc = zzhl_call_on_stack(run_core, &h, ZZHL_STACK_HI);
    shared[SH_STAGE] = 3;
    zzq_printf("ZZHL: engine ended, rc %d", g_rc);
    {   char m[40] = "ZZHL: engine ended, rc "; int v = g_rc, k = 23, neg = v < 0; char d[12]; int n = 0;
        if (neg) v = -v;
        do { d[n++] = (char)('0' + v % 10); v /= 10; } while (v && n < 11);
        if (neg) m[k++] = '-';
        while (n) m[k++] = d[--n];
        m[k] = 0;
        zzhl_conlog_line(m);
    }
    if (!shared[SH_EXIT_REASON]) shared[SH_EXIT_REASON] = ZZQ_EXIT_QG_QUIT;
}

void QG_Tick(double dt)
{
    (void)dt;
    zzq_running = 0;       /* the engine ran inside QG_Create; nothing to tick */
}

void Host_Shutdown(void)
{
}

/* ---- release callbacks the runtime expects from the engine side (as ZZQuake2's glue) ---- */
void zzq_publish_engine_state(void)
{
    shared[SH_SV_ACTIVE]    = (shared[SH_STAGE] == 2u) ? 1u : 0u;
    shared[SH_DEMOPLAYBACK] = 0;
    shared[SH_DEMONUM]      = 0;
}

/* used by the release zzq_fprintf() for %f and %g; taken as it is from zzquake_qgmain.c */
void zzq_ftoa_prec(char *dst, int cap, float v, int prec)
{
    int neg = 0, i = 0, j, n, k;
    long ip, fp, scale = 1;
    char tmp[16];
    if (cap < 4) { if (cap > 0) dst[0] = 0; return; }
    if (prec < 0) prec = 0;
    if (prec > 6) prec = 6;
    for (k = 0; k < prec; k++) scale *= 10;
    if (v != v) { dst[0]='n'; dst[1]='a'; dst[2]='n'; dst[3]=0; return; }
    if (v < 0.0f) { neg = 1; v = -v; }
    if (v > 2000000000.0f) v = 2000000000.0f;
    ip = (long)v;
    fp = (long)((v - (float)ip) * (float)scale + 0.5f);
    if (fp >= scale) { fp = 0; ip++; }
    if (neg) dst[i++] = '-';
    n = 0;
    if (ip == 0) tmp[n++] = '0';
    while (ip > 0 && n < 15) { tmp[n++] = (char)('0' + (ip % 10)); ip /= 10; }
    for (j = n - 1; j >= 0 && i < cap - 2; j--) dst[i++] = tmp[j];
    if (prec > 0 && i < cap - 2) {
        dst[i++] = '.';
        for (j = prec - 1; j >= 0 && i < cap - 1; j--) {
            long d = fp;
            for (k = 0; k < j; k++) d /= 10;
            dst[i++] = (char)('0' + (d % 10));
        }
    }
    dst[i] = 0;
}
