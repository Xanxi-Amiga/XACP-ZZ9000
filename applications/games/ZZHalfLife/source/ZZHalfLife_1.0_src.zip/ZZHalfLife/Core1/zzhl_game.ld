/* SPDX-License-Identifier: 0BSD */
/* zzhl_game.ld - the game image (zzhl_game.bin): the HLSDK server and client,
 * FreeVGUI, their own newlib and libstdc++, xacp/game/zzhl_game_rt.c.  Linked at ZZHL_GAME_LOAD
 * (xacp/include/zzhl_game.h), above the engine image and its bss, below the RasterIX reservation:
 * the range the engine image had alone until build 102, shared now.
 * The engine (xacp/src/xacp_game.c) reads it, checks the 64-byte header that comes first
 * (tools/mkcore.py fills it), clears the bss and calls zzhl_game_entry.
 */
ENTRY(zzhl_game_entry)
SECTIONS {
    . = 0x3D400000;
    .zzhlhdr : { KEEP(*(.zzhlhdr)) }
    .text : {
        _text_start = .;
        *(.text*)
        . = ALIGN(4);
        _text_end = .;
    }
    .rodata : { *(.rodata*) . = ALIGN(4); }
    .ARM.extab : { *(.ARM.extab*) }
    .ARM.exidx : { __exidx_start = .; *(.ARM.exidx*) __exidx_end = .; }
    .preinit_array : { . = ALIGN(4); __preinit_array_start = .; KEEP(*(.preinit_array*)) __preinit_array_end = .; }
    .init_array : { . = ALIGN(4); __init_array_start = .; KEEP(*(SORT_BY_INIT_PRIORITY(.init_array.*))) KEEP(*(.init_array)) __init_array_end = .; }
    .fini_array : { . = ALIGN(4); __fini_array_start = .; KEEP(*(.fini_array*)) __fini_array_end = .; }
    .data : { . = ALIGN(16); _data_start = .; *(.data*) . = ALIGN(16); _data_end = .; }
    _image_end = .;
    .bss (NOLOAD) : { . = ALIGN(32); _bss_start = .; *(.bss*) *(COMMON) . = ALIGN(32); _bss_end = .; }
    _end = .;
    /DISCARD/ : { *(.note*) *(.comment*) }
}
ASSERT(_end <= 0x3D800000, "ZZHalfLife: game image + bss reaches the RasterIX reservation (0x3D800000)")
