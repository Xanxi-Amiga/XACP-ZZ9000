/* SPDX-License-Identifier: GPL-2.0-or-later */
/* RasterIX GPU adapter derived from ZZQuake2RIX.
 * Handles frame submission, depth buffers, presentation and GPU profiling.
 * Changes for Half-Life are kept in this tree and in build_arm.sh.
 */


#include <string.h>
#include "rixgpu.h"
#include "rixframe.h"
#include "rixtex.h"
#include "rixdesc.h"
#include "rix_diag.h"
#include "rix_window.h"
#include "zzgl.h"
#include "zzq2rix_mmu.h"
#include "zzq2_res.h"         /* ZZQ2_VID_W x ZZQ2_VID_H: the size of this blob (0.10) */
#include "zzhl_fx.h"          /* the per-frame counters by origin */
#include "zzhl_zclear.h"      /* ZCLEAR=1, the two depth buffers */

/* release / glue */
extern void Sys_Error(char *error, ...);
extern void zzq2_present_rgb565(const unsigned short *pixels, unsigned pitch_bytes);
extern unsigned zzq2_last_pak_end(void);
extern void zzq_s2_begin(int p);
extern void zzq_s2_end(int p);

/* ---- placement --------------------------------------------------------- */
#ifdef ZZQ2RIX_HOST
#define RIXQ2_POOL_BASE   0x30400000u
#define RIXQ2_POOL_PAGES  4096u            /* 8 MiB inside the model's arena */
#define RIXQ2_POOL_CACHE  0
#define RIXQ2_RING_BASE   0x30C00000u
#define RIXQ2_ZBUF        0x30C80000u
#define RIXQ2_BIND_BASE   0x30D80000u
#define RIXQ2_ZBUF2       0x30E00000u
#define RIXQ2_ZFAR        0x30F00000u
#else
#define RIXQ2_POOL_BASE   0x3D800000u
#define RIXQ2_POOL_PAGES  8192u            /* 16 MiB */
#define RIXQ2_POOL_CACHE  1
#define RIXQ2_RING_BASE   0x3E800000u
#define RIXQ2_ZBUF        0x3E880000u
#define RIXQ2_BIND_BASE   0x3E980000u
/* The asynchronous depth-buffer copy uses reserved GPU-window memory without changing the MMU mapping. */
#define RIXQ2_ZBUF2       0x3EA00000u
#define RIXQ2_ZFAR        0x3EB00000u
#endif
/* 0.9.2: the same 512 KiB as 8 x 64 KiB (mode 0) or 32 x 16 KiB (mode 1, ZZQuake2RIX default, read
   at the first GLimp_SetMode: archived, takes effect at the next start).
   mode 2 = 64 x 8 KiB (new default) and mode 3 = 128 x 4 KiB, same 512 KiB.
   A chunk closes at every bind (rule 11) and filled only 14 % of a 16 KiB slot on c2a5f (21 % on
   c1a3b) for 187 chunks a frame: Core1 waited 11,7 ms a frame for a free slot while the GPU was
   idle 7,8 ms with nothing queued (A4000, 13/11).  Smaller slots give more runway at equal memory.
   4 KiB is librixgpu's floor (rix_frame_ring_init refuses less). */
static u32 g_ring_slots = 8u, g_chunk_bytes = 65536u;
static int g_open;
void zz_rix_set_ring(int mode)
{
    if (g_open) return;
    if (mode == 3) { g_ring_slots = 128u; g_chunk_bytes = 4096u; }
    else if (mode == 2) { g_ring_slots = 64u; g_chunk_bytes = 8192u; }
    else if (mode == 1) { g_ring_slots = 32u; g_chunk_bytes = 16384u; }
    else { g_ring_slots = 8u; g_chunk_bytes = 65536u; }
}
#define RIXQ2_RING_SLOTS  g_ring_slots
#define RIXQ2_CHUNK_BYTES g_chunk_bytes
#define RIXQ2_RESERVE_LO  0x3D800000u      /* HEAP_LIMIT of the adapter */
#define RIXQ2_RESERVE_HI  0x3EC00000u

/* ---- state --------------------------------------------------------------- */
static volatile u32 g_rs[RS_COUNT];
static volatile u32 g_sd[SD_COUNT];
static volatile u32 g_caps_out, g_timer_hz;
static u32 g_probe_desc[RIX_TRI_DESC_WORDS];
/* 0.10: the GPU frame geometry of the build (the 320 build draws inside the 640 x 481 buffers) */
#if ZZQ2_VID_W > 640
#define RIXQ2_GEO_W       ((u32)ZZQ2_VID_W)
#define RIXQ2_GEO_H       ((u32)ZZQ2_VID_H)
#define RIXQ2_FB_STRIDE   ((RIXQ2_GEO_W * (RIXQ2_GEO_H + 1u) * 2u + 255u) & ~255u)
static const u32 g_color_bufs[2] = { RIX_FB0_ARM, RIX_FB0_ARM + RIXQ2_FB_STRIDE };
#else
#define RIXQ2_GEO_W       RIX_W
#define RIXQ2_GEO_H       RIX_H
#define RIXQ2_FB_STRIDE   RIX_FB_STRIDE
static const u32 g_color_bufs[2] = { RIX_FB0_ARM, RIX_FB1_ARM };
#endif
#define RIXQ2_ZBUF_BYTES  0x00100000u      /* Z-buffer room (bind lists above) */
/* first byte of the picture shown (ref_gl's top line): the window is at the bottom of the buffer in
   RasterIX coordinates (y up, line 0 = top), so it starts (h_alloc - 1 - height) lines down */
#define RIXQ2_SHOW_OFF    ((RIXQ2_GEO_H - (u32)ZZQ2_VID_H) * RIXQ2_GEO_W * 2u)
#define RIXQ2_PITCH       (RIXQ2_GEO_W * 2u)
/* 0.10: the span of the two colour buffers, for the glue's check of the P96 buffers (zzq2_glue.c) */
void zz_rix_buffers(unsigned *lo, unsigned *hi) { *lo = g_color_bufs[0]; *hi = g_color_bufs[1] + RIXQ2_FB_STRIDE; }
static zz_mmu_report g_mmu;
static int g_bind_mode, g_init_rc;   /* g_open: above (0.9.2) */
static u32 g_cur, g_fence_seq, g_frames, g_frames_dropped;
static u32 g_t_gpu_us, g_t_present_us, g_t_gpu_max_us;
/* 0.7: run totals for the performance report (zz_rix_perf_report, baseq2/rixstat.txt) */
static u32 g_begin_tick;
/* 0.8.2: draw batches by category (zz_rix_cat_begin/end, called by zzq2rix_qgl.c around each
   glBegin..glEnd; the category comes from the ref_gl function being run, zzq2_glue.c, and from
   the blend state of the lightmap pass) */
#define ZZ_NCAT 7
static const char *const g_cat_name[ZZ_NCAT] = {
    "  world      ", "  lightmaps  ", "  bmodels    ", "  models     ", "  water/glass", "  other 3D   ", "  2D         " };
typedef struct { u32 batches, tris, binds, wall_us, begin_us, end_us, bwait_us; } zz_catsum;
/* ref_gl's own time, phase by phase.  Our report gives ref_gl as a residual
   (everything between GL calls), 11,8 ms on a heavy frame of c2a5f on 14/11, without saying which
   phase spends it.  zzhl_refphase() is called from R_RenderScene (generated patch, build_arm.sh)
   at each phase boundary; the time is WALL time, so a phase includes the GL work it issues.
   Cost: about 8 timer reads a frame, nothing measurable. */
#define ZZ_NREFPH 6
static const char *const g_refph_name[ZZ_NREFPH] = {
    "setup+leaves", "world", "entities", "water", "rest", "outside" };
static u32 g_refph_cur[ZZ_NREFPH];
static u32 g_refph_slot = ZZ_NREFPH - 1u;   /* "outside": before the first phase of the frame */
static u32 g_refph_t0;
/* inside R_DrawEntitiesOnList, which the build 63 run showed to be 28 680 us of a
   38 024 us heavy frame (75 %).  Same machine as zzhl_refphase, separate state, so the two
   nest without disturbing each other.  Wall time again. */
#define ZZ_NENTPH 18
static const char *const g_entph_name[ZZ_NENTPH] = {
    "outside", "bones", "verts+lightpos", "emit", "brush", "sprite", "dispatch", "efx", "light+chrome",
    "studio rest",
    /* inside R_DrawSpriteModel.  The 65 run gave sprite = 16 625 us on the frames above
       45 ms while the halo traces cost 14 us, so the cost is elsewhere in that function. */
    "spr:occluded", "spr:state+light", "spr:frame", "spr:quad",
    /* what "dispatch" swallowed (the second CL_DrawEFX, the client's triangles, the
       start of the view model), and the GL queue's replays, which were charged to whichever
       phase drew the first order-dependent thing of the frame. */
    "efx:trans", "client tris", "viewmodel", "REPLAY" };
static u32 g_entph_cur[ZZ_NENTPH];
/* the halo traces.  R_SpriteGlowBlend() casts one ray from the eye to every
   kRenderGlow sprite, every frame, and PM_PlayerTraceExt runs a full hull trace against every
   visible entity with no cheap rejection in front of it.  These count what that costs and what
   the rejection saves.  Written from gl_sprite.c and pm_trace.c (generated patches). */
u32 zzhl_glow_traces, zzhl_glow_cached, zzhl_glow_us, zzhl_pm_ents, zzhl_pm_rejected;
static u32 g_entph_slot;                    /* 0 = outside the entity loop */
static u32 g_entph_t0;
/* Per-frame origin counters use 64-bit accumulators for pixel totals. */
unsigned zzhl_fx[ZFX_COUNT];
enum { FXB_RUN = 0, FXB_NORM, FXB_SLOW, FXB_OVER45, FXB_BENCH, FXB_COUNT };
static unsigned long long g_fxsum[FXB_COUNT][ZFX_COUNT];
static u32 g_fxframes[FXB_COUNT];
static void fx_add(u32 b) { u32 i; for (i = 0; i < (u32)ZFX_COUNT; i++) g_fxsum[b][i] += zzhl_fx[i]; g_fxframes[b]++; }
static int g_org_sky, g_org_vm;
static int g_sprtrim_on;                    /* for the report's wording only */
void zz_rix_note_sprtrim(int on) { g_sprtrim_on = on ? 1 : 0; }
static u32 g_world_seen;                    /* R_DrawWorld ran in the frame under way */
static u32 g_noworld_frames, g_noworld_ms;
static u32 g_host_t, g_host_sv_on, g_host_cl_on;
/* the bench (BENCH=, xacp/src/xacp_bench.c): one more bucket, opened and closed by
   the caller around the frames of a scene */
static int g_bench_on;
static u32 g_bench_max, g_bench_min, g_bench_n25, g_bench_n33, g_bench_n45, g_bench_noworld;
void zzhl_org_sky(int on) { g_org_sky = on; }
void zzhl_org_viewmodel(int on) { g_org_vm = on; }
/* the frame-time histogram.  The 25-100 ms bucket of the report is one seau of 7450
   frames and tells us nothing about the floor: 22 img/s means NO frame above 45454 us. */
#define ZZ_NHIST 10
static const u32 g_hist_hi[ZZ_NHIST] = { 20000u, 25000u, 30000u, 35000u, 40000u,
                                         45000u, 50000u, 60000u, 80000u, 0xFFFFFFFFu };
static u32 g_hist[ZZ_NHIST];
/* every field a u32: perf_add() adds two records word by word */
typedef struct {
    u32 frames, ref_us, swap_us, end_us, flush_us, bind_us, bind_wait_us, ringwait_us, upload_us;
    u32 tris_in, tris_out, culled, clipped, begins, verts, binds, binds_skipped, uploads, subuploads, chunks, words, state_words;
    u32 gpu_us, present_us, wall_us;
    u32 desc_us, emit_us, end_bwait_us;     /* 0.8.3: zzglEnd split (desc/emit with rix_prof 1 only) */
    u32 dq_frames, dq_peak, dq_held, dq_wait_us, dq_tex_us, dq_end_us, dq_refused;   /* 0.9: deferred submission (rix_defer 1) */
    u32 sync_frames, sync_gpu_us, sync_wall_us;
    u32 tex_versions, tex_version_us, tex_version_fail;   /* 0.9.2: lightmap versions (rix_texver 1) */
    u32 dq_starved, idle_between_us, idle_frames;         /* 0.9.2: GPU found idle at a submission; GPU idle from the frame fence to the next frame's first chunk */
    u32 overlap_frames;                                   /* 0.9.3: frames closed with rix_overlap 1 */
    u32 engine_us;                                        /* from the previous frame's end to this one's first GL draw (engine logic, client, sound) */
    u32 gpu_idle_us, gpu_idle_spells;                     /* GPU idle seen by the pumps (rix_frame_idle_take, upper bound); with events waiting only */
    u32 gpu_starved_us;                                   /* GPU idle with nothing queued (rix_frame_starved_take) */           /* 0.9.1: rix_sync 1 (every chunk and bind waited at once: Core1 waits = GPU time) */
    zz_catsum cat[ZZ_NCAT];
    u32 ref_ph_us[ZZ_NREFPH];                             /* where ref_gl's own time goes (R_RenderScene phases) */
    u32 ent_ph_us[ZZ_NENTPH];                             /* inside R_DrawEntitiesOnList */
    u32 glow_traces, glow_cached, glow_us, pm_ents, pm_rejected;   /* the halo traces */
} zz_perf;
static zz_perf g_pt;        /* the run (baseq2/rixstat.txt) */
static zz_perf g_seg;       /* 0.8.2: the timedemo under way (baseq2/rixtd.txt) */
/* frames by period (end to end): slow = 25-100 ms (gameplay frames under 40
   img/s; map loads, which are longer, left out), normal = under 25 ms.  Where the slow ones lose
   their time sets what raises the minimum frame rate. */
static zz_perf g_slow, g_norm, g_over45;   /* the frames that break a 22 img/s floor */
static zz_perf g_bench;                    /* the scene the bench is measuring */
/* Keep the first 32 slow-frame records with GPU and I/O timing for diagnostics. */
extern void zzhl_fs_io_totals(unsigned *n, unsigned *bytes, unsigned *us);
typedef struct { u32 frame, t_ms, wall, engine, ref, binds, tris, upl, gwait, present, ntris, nbinds, uploads, subup, versions, io_n, io_kib, io_ms; } zz_hitch;
static zz_hitch g_hitch[32];
static u32 g_nhitch, g_hitch_all, g_hitch_t_ms, g_io_n0, g_io_b0, g_io_u0;
static void hitch_note(const void *rp);
static void perf_add(zz_perf *d, const zz_perf *a)
{
    u32 i, *dw = (u32 *)d;
    const u32 *aw = (const u32 *)a;
    for (i = 0; i < (u32)(sizeof(zz_perf) / sizeof(u32)); i++) dw[i] += aw[i];
}
static void hitch_note(const void *rp)
{
    const zz_perf *r = (const zz_perf *)rp;
    u32 n, b, u, rest;
    zzhl_fs_io_totals(&n, &b, &u);
    g_hitch_t_ms += r->wall_us / 1000u;
    if (r->wall_us >= 80000u) {
        g_hitch_all++;
        if (g_nhitch < 32u) {
            zz_hitch *h = &g_hitch[g_nhitch++];
            rest = (r->ref_us > r->flush_us + r->end_us + r->upload_us + r->engine_us) ? r->ref_us - r->flush_us - r->end_us - r->upload_us - r->engine_us : 0u;
            h->frame = g_frames; h->t_ms = g_hitch_t_ms; h->wall = r->wall_us; h->engine = r->engine_us; h->ref = rest;
            h->binds = r->flush_us; h->tris = r->end_us; h->upl = r->upload_us; h->gwait = r->dq_wait_us; h->present = r->present_us;
            h->ntris = r->tris_in; h->nbinds = r->binds; h->uploads = r->uploads; h->subup = r->subuploads; h->versions = r->tex_versions;
            h->io_n = n - g_io_n0; h->io_kib = (b - g_io_b0) / 1024u; h->io_ms = (u - g_io_u0) / 1000u;
        }
    }
    g_io_n0 = n; g_io_b0 = b; g_io_u0 = u;
}
/* current frame, per category, in timer ticks (converted once per frame) */
static struct { u32 batches, tris, binds, wall, begin, end, bwait_us; } g_cf[ZZ_NCAT];
static u32 c_t0, c_flush, c_end, c_tris, c_binds, c_bwait;
/* 0.8.2: timedemo segments */
extern volatile u32 zzq2_world_count;      /* zzq2_glue.c: calls of R_DrawWorld so far */
static u32 g_world_at_begin, g_last_end_tick, g_have_last_end;
static int g_td;                           /* cvar timedemo, given every frame by zzq2rix_video.c */
static int g_td_armed;                     /* a map was loaded while timedemo was set */
static int g_regseq, g_regseq_seen;        /* ref_gl's registration_sequence: one more per map load */
static char g_td_text[32768];
static u32 g_td_count, g_td_full;
static int g_td_new;
static u32 g_dq_peak_max;                  /* 0.9 */
static u32 g_fence_done_tick, g_have_fence_done;   /* 0.9.2 */
/* 0.9.3: rix_overlap 1 = frame N-1 is presented at the end of frame N, while the GPU still draws N; frame N
   is then closed without waiting for its fence and stays pending until the end of N+1.  N+1 draws into the
   buffer of N-1, presented by then.  The single Z-buffer is safe: the GPU runs everything in order, so N+1's
   depth clear comes after the last chunk of N.  No bind of N is in the GPU when N+1 begins (the end of N
   drains the queue: its last chunk is submitted only once the last bind has passed). */
extern void (*zzq2_present_hook)(void);
static u32 fence_pixel(u32 buf);
static int g_overlap_req, g_pend;
static u32 g_pend_buf, g_pend_fence, g_overlap_frames;
void zz_rix_set_overlap(int on) { g_overlap_req = on ? 1 : 0; }
/* ZZHalfLife build 32 (R1): pipelined frames (librixgpu copy, rixframe.h; ZZGL 0.8.0).  With rix_overlap
   the end of frame N no longer drains the deferred queue: N+1 begins (on the buffer of N-1, shown at the
   end of N) while the GPU still has N's binds and chunks, which Core1 pumps while it walks N+1 (GL queue,
   presentation, GL_SwapBuffers: zzhl_gpu_pump).  Every wait for a frame fence pumps the queue. */
static int g_pipe_req = 1;
static u32 g_pipe_frames, g_pend_wait_us, g_pend_wait_max_us, g_queued_at_end, g_pumps_outside;
void zz_rix_set_pipeline(int on) { g_pipe_req = on ? 1 : 0; }
static int wait_frame(u32 buf, u32 fence)
{
    if (rix_frame_deferred()) return rix_frame_wait_pumped(buf, fence, 2000000u);
    return rix_frame_wait(buf, fence, 2000000u, 0, 0);
}
void zzhl_gpu_pump(void)
{
    if (!g_open || !rix_frame_pipelined()) return;
    g_pumps_outside++;
    zzgl_pump();
}
/* pumps from the game libraries' hot calls (xacp/dll/zzhl_sv_pump.cpp, zzhl_cl_pump.cpp: traces,
   searches, random numbers, think/touch, client entities and temporary entities), i.e. during the engine
   phase that had none.  Each call reads the timer (every 4th); a pump when 15 us (35: 25) have
   passed and events wait. */
static int g_soon_on = 1;
static u32 g_soon_last, g_soon_gap, g_soon_calls, g_soon_pumps;
void zz_rix_set_engine_pump(int on) { g_soon_on = on ? 1 : 0; }
void zzhl_pump_soon(void)
{
    u32 now;
    if (!g_soon_on || !g_open) return;
    g_soon_calls++;
    now = rix_now();                               /* every call (35: every 4th, 9 pumps a frame) */
    if ((u32)(now - g_soon_last) < g_soon_gap) return;
    g_soon_last = now;
    if (!rix_frame_pipelined() || !rix_frame_queued()) return;
    g_soon_pumps++;
    zzhl_gpu_pump();
}
/* ---- ZCLEAR=1, the depth cleared by the PL330 ---------------------------------------------
   The rule and its reasons are in xacp/include/zzhl_zclear.h (run on the PC by tests/test_zclear.c);
   here are the copies, the waits and the counters.  Depth buffer i goes with colour buffer i.
     zc_frame_opens   ZZGL's hook: called as a frame opens, before anything of it is submitted.
                      Gives the frame its depth buffer and says whether the PL330 left it clean.
     zc_release_buf   a frame has passed its fence and was shown: the PL330 starts on its depth
                      buffer, without Core1 (0,45 ms of copy; nobody waits for it here).
     zc_guard         the presentation copy uses the same PL330 channel: it waits for ours first.
   Nothing of this runs, and neither RIXQ2_ZBUF2 nor RIXQ2_ZFAR is read or written, unless ZCLEAR=1
   was asked AND the self-test below (zz_rix_zclear_test) passed on this machine.  Any failure of
   the PL330 afterwards: the GPU clears for the rest of the run, as build 85. */
#define RIXQ2_Z_BYTES     (RIXQ2_GEO_W * (RIXQ2_GEO_H + 1u) * 2u)
static const u32 g_zbufs[2] = { RIXQ2_ZBUF, RIXQ2_ZBUF2 };
static zclear_t g_zc = { 0, { 0, 0 }, { 0, 0 }, -1, 0u, 0 };
static int g_zc_hooked;                    /* the hook is installed (the self-test passed) */
static u32 g_zc_force;                     /* the self-test's own frames: this depth buffer, never clean */
static u32 g_zc_copies, g_zc_late, g_zc_waits, g_zc_wait_us, g_zc_wait_max_us, g_zc_fail_code, g_zc_fail_info, g_zc_fail_frame;
extern void (*zzhl_dma_guard)(void);       /* Core1/zzhl_present.c */
/* the PL330 failed (nothing of ours runs any more): 1 start refused, 2 fault, 3 no end in 30 ms */
static void zc_stop(u32 code, u32 info)
{
    zclear_fail(&g_zc);
    if (!g_zc_fail_code) { g_zc_fail_code = code; g_zc_fail_info = info; g_zc_fail_frame = g_frames; }
}
/* the running copy: 1 = there is none any more */
static int zc_poll(void)
{
    int r;
    if (g_zc.run < 0) return 1;
    r = rix_dmacopy_poll();
    if (r == 0) return 0;
    if (r == 1) zclear_done(&g_zc); else zc_stop(2u, rix_dmacopy_fault_info());
    return 1;
}
/* wait for the running copy, the GPU fed meanwhile */
static void zc_finish(void)
{
    u32 t0;
    if (g_zc.run < 0) return;
    t0 = rix_now();
    while (!zc_poll()) {
        if (rix_ticks_to_us((u32)(rix_now() - t0)) > 30000u) { rix_dmacopy_abort(); zc_stop(3u, 0u); break; }
        zzhl_gpu_pump();
    }
}
static int zc_start(u32 i)
{
    int r = rix_dmacopy_start(RIXQ2_ZFAR, g_zbufs[i & 1u], RIXQ2_Z_BYTES);
    if (r) { zc_stop(1u, (u32)r); return 0; }
    g_zc_copies++;
    zclear_started(&g_zc, i);
    return 1;
}
static int zc_frame_opens(u32 *zbuf)
{
    u32 t0 = 0u;
    int a, waited = 0;
    if (g_zc_force) { *zbuf = g_zc_force; return 0; }
    (void)zc_poll();                               /* a copy that ended since is not a wait */
    while ((a = zclear_open_need(&g_zc)) != ZCA_NONE) {
        if (!waited) { waited = 1; t0 = rix_now(); }
        if (a == ZCA_WAIT) zc_finish();
        else { g_zc_late++; zzhl_fx[ZFX_ZC_LATE]++; (void)zc_start(g_zc.cur); }
    }
    if (waited) {
        u32 us = rix_ticks_to_us((u32)(rix_now() - t0));
        g_zc_waits++; g_zc_wait_us += us; zzhl_fx[ZFX_ZC_WAIT_US] += us;
        if (us > g_zc_wait_max_us) g_zc_wait_max_us = us;
    }
    *zbuf = g_zbufs[g_zc.cur];
    return zclear_open(&g_zc);
}
static void zc_release_buf(u32 buf)
{
    u32 i = (buf == g_color_bufs[1]) ? 1u : 0u;
    if (!g_zc_hooked) return;
    (void)zc_poll();
    if (zclear_release(&g_zc, i)) (void)zc_start(i);
}
static void zc_guard(void) { zc_finish(); }

static void pend_present(void)
{
    int rc;
    u32 t0;
    if (!g_pend) return;
    t0 = rix_now();
    rc = wait_frame(g_pend_buf, g_pend_fence);
    {
        u32 us = rix_ticks_to_us((u32)(rix_now() - t0));
        g_pend_wait_us += us;
        if (us > g_pend_wait_max_us) g_pend_wait_max_us = us;
    }
    if (rc) {
        rix_frame_diag_last();
        Sys_Error("RIX E%04x pending fence %04x pix %04x fr %u", (unsigned)rc & 0xFFFFu, g_pend_fence, fence_pixel(g_pend_buf), g_frames);
    }
    zzq2_present_hook = (zzgl_frame_open() || rix_frame_pipelined()) ? zzgl_pump : 0;   /* keep the GPU fed while Core1 converts (also between frames) */
    zzq2_present_rgb565((const unsigned short *)rix_ptr(g_pend_buf + RIXQ2_SHOW_OFF), RIXQ2_PITCH);
    zzq2_present_hook = 0;
    g_pend = 0;
    zc_release_buf(g_pend_buf);                    /* fenced and shown, its depth buffer is free */
}
/* end of run: the GPU idle (the pending frame is not shown) */
static void pend_wait(void)
{
    if (rix_frame_deferred()) (void)rix_frame_drain(0);   /* pipelined, the queue may still hold it */
    if (!g_pend) return;
    (void)wait_frame(g_pend_buf, g_pend_fence);
    g_pend = 0;
}
static int g_sync_req, g_sync_on;          /* 0.9.1: rix_sync */
void zz_rix_set_sync(int on) { g_sync_req = on ? 1 : 0; }
static u32 g_frame_fence, g_frame_buf;

/* a 256x256 RGB565 pattern for the ladder's texture stages (L11..L15) */
static void probe_texture_fill(u32 base)
{
    volatile u16 *p = (volatile u16 *)rix_ptr(base);
    u32 x, y;
    for (y = 0; y < 256u; y++)
        for (x = 0; x < 256u; x++)
            p[y * 256u + x] = (u16)(((x & 31u) << 11) | ((y & 63u) << 5) | ((x ^ y) & 31u));
}

static int probe_triangle(void)
{
    rix_vertex a, b, c;
    a.sx = 200.0f; a.sy = 151.0f; a.z = 0.5f; a.invw = 1.0f; a.u = 0.0f; a.v = 0.0f; a.r = a.g = a.b = a.a = 1.0f;
    b = a; b.sx = 440.0f; b.sy = 151.0f; b.u = 1.0f; b.v = 0.0f;
    c = a; c.sx = 320.0f; c.sy = 401.0f; c.u = 0.5f; c.v = 1.0f;
    return rix_tri_desc(&a, &b, &c, g_probe_desc);
}

static void why_set(char *why, int cap, const char *s)
{
    int i;
    if (!why || cap <= 0) return;
    for (i = 0; i < cap - 1 && s[i]; i++) why[i] = s[i];
    why[i] = 0;
}

/* ---- open ------------------------------------------------------------------ */
int zz_rix_open(int w, int h, char *why, int why_cap)
{
    rix_config cfg;
    rix_ring_cfg rc;
    zzgl_config gc;
    int rc_i;
    u32 caps;

    if (g_open) return 1;
    if (w != ZZQ2_VID_W || h != ZZQ2_VID_H) { why_set(why, why_cap, "not the size of this blob"); return 0; }
    /* 0.10: the buffers of the build stay in the window, below the firmware staging; the Z-buffer in its room */
    if (g_color_bufs[1] + RIXQ2_FB_STRIDE > RIX_STAGE_ARM || RIXQ2_GEO_W * (RIXQ2_GEO_H + 1u) * 2u > RIXQ2_ZBUF_BYTES)
        Sys_Error("RIX layout: FB1 end %08x, Z %u bytes", g_color_bufs[1] + RIXQ2_FB_STRIDE, RIXQ2_GEO_W * (RIXQ2_GEO_H + 1u) * 2u);

    /* 1. the reservation under .q2bss must be free of engine data: the
          heap limit is enforced by the adapter before any allocation
          (zzq2_glue.c); checked here once more against the real pak end */
    if (zzq2_last_pak_end() > RIXQ2_RESERVE_LO)
        Sys_Error("RIX pak end %08x above GPU reservation %08x", zzq2_last_pak_end(), RIXQ2_RESERVE_LO);

    /* 2. MMU attributes (checked, maintained, verified: zzq2rix_mmu.c) */
    rc_i = zzq2rix_mmu_setup(&g_mmu);
    if (rc_i)   /* the launcher shows 60 characters: the values first */
        Sys_Error("RIX MMU e%d ttbr0 %08x sctlr %08x i%03x d%08x ttbcr %x",
                  rc_i, g_mmu.ttbr0, g_mmu.sctlr, g_mmu.bad_index, g_mmu.bad_desc, g_mmu.ttbcr);

    /* 3. librixgpu init: ID, FIFO, ladder L0..L15 (textured stages with a
          pattern in the window's texture area), no PL330, no WFI */
    memset(&cfg, 0, sizeof cfg);
    cfg.flags = RIXF_SPIN | RIXF_NODMA | RIXF_NOSWAP;
    cfg.idle_tick_us = 100u;
    cfg.stats = g_rs; cfg.sd = g_sd; cfg.caps_out = &g_caps_out; cfg.timer_hz_out = &g_timer_hz;
    cfg.dma_prog = RIX_DL1_ARM;                     /* required by the config check; never used (NODMA) */
    probe_texture_fill(RIX_TEX_ARM);
    if (probe_triangle()) {
        cfg.probe_tri = g_probe_desc; cfg.probe_x = 320u; cfg.probe_y = (RIX_H_ALLOC - 1u) - 230u;
        cfg.tmu_env = RIX_TMU_ENV_REPLACE; cfg.tmu_env_color = 0u;
        cfg.tmu_cfg = RIX_TMU_CFG_RGB565(8u, 8u, 1);
        cfg.tex_pages = 64u; cfg.tex_base = RIX_TEX_ARM;
    }
    g_init_rc = rix_init(&cfg);
    caps = rix_caps();
    if (!(caps & RIXCAP_ID))
        Sys_Error("RIX: no RasterIX (magic %08x ver %08x)", g_sd[SD_ID_MAGIC], g_sd[SD_ID_VERSION]);
    if (!(caps & RIXCAP_FENCE_MEM) || !(caps & RIXCAP_TEX) || !(caps & RIXCAP_TRI_DDR))
        Sys_Error("RIX init E%04x ladder L%u failed caps %04x (power cycle?)",
                  (unsigned)g_init_rc & 0xFFFFu, g_sd[SD_LADDER_FAILED] ? g_sd[SD_LADDER_FAILED] - 1u : 99u, caps);

    /* 3b. 0.10: the frame geometry of the build, after the ladder (640 x 481) and before the ring (which
          zeroes the fence pixels of the buffers on their fence line); nothing at all for 640 and 320 */
    if (RIXQ2_GEO_W != RIX_W || RIXQ2_GEO_H != RIX_H) {
        rc_i = rix_set_geometry(RIXQ2_GEO_W, RIXQ2_GEO_H);
        if (rc_i) Sys_Error("RIX geometry %ux%u E%04x", RIXQ2_GEO_W, RIXQ2_GEO_H, (unsigned)rc_i & 0xFFFFu);
    }

    /* 4. the chunk ring and the bind transport */
    memset(&rc, 0, sizeof rc);
    rc.ring_base = RIXQ2_RING_BASE; rc.ring_slots = RIXQ2_RING_SLOTS; rc.chunk_bytes = RIXQ2_CHUNK_BYTES;
    rc.fence_x = RIX_CHUNK_FENCE_X; rc.color_bufs = g_color_bufs; rc.color_count = 2u; rc.ring_cacheable = 0u;
    rc.bind_base = RIXQ2_BIND_BASE; rc.bind_cacheable = 0u;
    rc_i = rix_ring_init(&rc);
    if (rc_i) Sys_Error("RIX ring E%04x", (unsigned)rc_i & 0xFFFFu);
    g_bind_mode = (caps & RIXCAP_TEX_DDR) ? RIX_BIND_LIST : RIX_BIND_FIFO;
    rc_i = rix_frame_set_bind_mode(g_bind_mode);
    if (rc_i) { g_bind_mode = RIX_BIND_FIFO; (void)rix_frame_set_bind_mode(RIX_BIND_FIFO); }

    /* 5. ZZGL: pool, Z-buffer, the size of the build */
    memset(&gc, 0, sizeof gc);
    gc.pool_base = RIXQ2_POOL_BASE; gc.pool_pages = RIXQ2_POOL_PAGES; gc.pool_cacheable = RIXQ2_POOL_CACHE;
    gc.zbuf = RIXQ2_ZBUF; gc.width = (u32)ZZQ2_VID_W; gc.height = (u32)ZZQ2_VID_H; gc.ztrick = 0;
    rc_i = zzgl_init(&gc);
    if (rc_i) Sys_Error("RIX ZZGL init E%04x", (unsigned)rc_i & 0xFFFFu);

    g_cur = 0u; g_fence_seq = 0u; g_frames = 0u;
    g_soon_gap = rix_us_to_ticks(15u);             /* 25 us; 15 us */
    g_open = 1;
    return 1;
}

/* ---- frames -------------------------------------------------------------- */
static u32 next_fence(void)
{
    g_fence_seq++;
    if (g_fence_seq == 0u || g_fence_seq > 65534u) g_fence_seq = 1u;
    return g_fence_seq;
}

static u32 g_stray_frames;

/* fence diagnostics for a lost frame fence: what the polled buffer and the other one hold at the
   frame-fence pixel (line 480, pixel 0) */
static u32 fence_pixel(u32 buf) { return *(volatile u16 *)rix_ptr(buf + rix_geo_fence_off); }

void zz_rix_begin_frame(void)
{
    zzgl_target t;
    if (!g_open) return;
    if (zzgl_frame_open()) {
        /* a draw or a clear reached ZZGL between the previous EndFrame and this BeginFrame: that
           frame was opened on the previous target.  Close it there, with a fence of its own, and
           wait for it; otherwise its fence would land on the other buffer than the one polled
           (ZZQuake2RIX 0.1, frame 980 at the end of demo1: "fence lost", GPU alive). */
        int rc;
        g_frame_fence = next_fence();
        t.color = g_frame_buf; t.fence = g_frame_fence;
        zzgl_set_target(&t);
        rc = zzgl_swap();
        if (rc) Sys_Error("RIX stray frame %u: submit E%04x", g_frames, (unsigned)rc & 0xFFFFu);
        rc = wait_frame(g_frame_buf, g_frame_fence);
        if (rc) Sys_Error("RIX E%04x stray fence %04x lost fr %u pix %04x", (unsigned)rc & 0xFFFFu, g_frame_fence, g_frames, fence_pixel(g_frame_buf));
        g_stray_frames++;
        /* 0.9.3: the stray drew on the pending frame's buffer, after it: its fence (just waited) is now the one
           that buffer shows; present the buffer now, before the next frame can target it */
        if (g_pend && g_pend_buf == g_frame_buf) g_pend_fence = g_frame_fence;
        pend_present();
#ifdef ZZQ2RIX_HOST
        { extern int printf(const char *, ...); const zzgl_stats *st = zzgl_get_stats();
          printf("STRAY frame at rix frame %u: begins %u tris_in %u tris_out %u binds %u uploads %u\n", g_frames, st->begins, st->tris_in, st->tris_out, st->binds, st->tex_uploads); }
#endif
        g_cur ^= 1u;
    }
    g_frame_buf = g_color_bufs[g_cur];
    g_frame_fence = next_fence();
    t.color = g_frame_buf; t.fence = g_frame_fence;
    zzgl_set_target(&t);
    zclear_target(&g_zc, g_cur, 1);                /* a frame of the game, on depth buffer g_cur */
    memset(g_cf, 0, sizeof g_cf);
    g_world_at_begin = zzq2_world_count;
    /* 0.9.1: SYNC mode switched here, between frames (the queue of the deferred mode is empty; pipelined, drained first) */
    if (g_sync_req != g_sync_on) { if (rix_frame_deferred()) (void)rix_frame_drain(0); rix_frame_set_sync(g_sync_req); g_sync_on = g_sync_req; }
    /* pipelined frames with the overlap only (ZZGL applies it when a frame opens with nothing pending) */
    zzgl_set_pipelined(g_pipe_req && g_overlap_req && !g_sync_req);
    g_begin_tick = rix_now();
}

/* ---- 0.8.2: categories ----------------------------------------------------------------------------
   One batch = glBegin .. glEnd, state flush and bind included (they happen in zzglBegin).  The ZZGL
   and frame counters restart when a frame opens, which can happen inside zzglBegin: a batch that
   starts with no frame open counts from zero. */
void zz_rix_cat_begin(void)
{
    if (zzgl_frame_open()) {
        const zzgl_stats *st = zzgl_get_stats();
        const rix_frame *fr = zzgl_frame();
        c_flush = st->flush_ticks; c_end = st->end_ticks; c_tris = st->tris_in; c_binds = st->binds;
        c_bwait = fr->bind_wait_us + fr->dq_wait_us;
    } else c_flush = c_end = c_tris = c_binds = c_bwait = 0u;
    c_t0 = rix_now();
}
void zz_rix_cat_end(int c)
{
    const zzgl_stats *st = zzgl_get_stats();
    const rix_frame *fr = zzgl_frame();
    u32 t = rix_now();
    if (c < 0 || c >= ZZ_NCAT) c = ZZ_NCAT - 1;
    g_cf[c].batches++;
    g_cf[c].wall += t - c_t0;
    g_cf[c].begin += st->flush_ticks - c_flush;
    g_cf[c].end += st->end_ticks - c_end;
    g_cf[c].tris += st->tris_in - c_tris;
    g_cf[c].binds += st->binds - c_binds;
    g_cf[c].bwait_us += fr->bind_wait_us + fr->dq_wait_us - c_bwait;
}
void zz_rix_set_timedemo(int on, int regseq) { g_td = on; g_regseq = regseq; }

static void perf_format(char *out, const zz_perf *p);
static void u2s(char *d, u32 v);
static void cat(char *d, const char *s);
/* the timedemo segment is over: its report goes to the end of g_td_text */
static void td_close(void)
{
    static char one[4096];
    char n[16];
    u32 w10 = g_seg.wall_us / 10000u;              /* hundredths of a second */
    one[0] = 0;
    g_td_count++;
    cat(one, "timedemo "); u2s(n, g_td_count); cat(one, n);
    cat(one, ": frames "); u2s(n, g_seg.frames); cat(one, n);
    cat(one, ", Core1 time "); u2s(n, w10 / 100u); cat(one, n); cat(one, ".");
    u2s(n, (w10 / 10u) % 10u); cat(one, n); cat(one, " s, ");
    if (w10) { u32 f10 = g_seg.frames * 1000u / w10; u2s(n, f10 / 10u); cat(one, n); cat(one, "."); u2s(n, f10 % 10u); cat(one, n); }
    else cat(one, "-");
    cat(one, " fps (the console line of the engine is the reference)\n");
    perf_format(one + strlen(one), &g_seg);
    cat(one, "\n");
    if (strlen(g_td_text) + strlen(one) < sizeof(g_td_text)) cat(g_td_text, one);
    else g_td_full++;
    memset(&g_seg, 0, sizeof g_seg);
    g_td_new = 1;
}
/* zzq2rix_video.c: 1 when a segment closed since the last call; the text of all of them */
int zz_rix_td_take(void) { int r = g_td_new; g_td_new = 0; return r; }
const char *zz_rix_td_text(void) { return g_td_text; }
u32 zz_rix_td_lost(void) { return g_td_full; }
/* quit or vid_restart during a timedemo: close it as it stands */
void zz_rix_td_flush(void) { if (g_seg.frames) td_close(); }

/* called from R_RenderScene (generated patch) at each phase boundary.  Closes the slot
   under way and opens `slot`.  Slot ZZ_NREFPH-1 ("outside") covers everything before the first
   boundary of the frame and everything after the last one. */
void zzhl_refphase(unsigned slot)
{
    u32 now = rix_now();
    if (g_refph_t0) g_refph_cur[g_refph_slot] += rix_ticks_to_us((u32)(now - g_refph_t0));
    g_refph_t0 = now ? now : 1u;
    g_refph_slot = (slot < ZZ_NREFPH) ? slot : (ZZ_NREFPH - 1u);
    /* the client's part of the engine time ends where the 3D scene starts */
    if (slot == 0u && g_host_cl_on) { zzhl_fx[ZFX_CL_US] += rix_ticks_to_us((u32)(now - g_host_t)); g_host_cl_on = 0u; }
    if (slot == 1u) g_world_seen = 1u;
}
/* Host_Frame (generated patch of host.c): 0 before Host_ServerFrame, 1 between it and
   Host_ClientFrame.  The timer is 32 bits of 333 MHz ticks: fine for one frame. */
void zzhl_host_mark(unsigned what)
{
    u32 now = rix_now();
    if (what == 0u) { g_host_t = now; g_host_sv_on = 1u; g_host_cl_on = 0u; return; }
    if (g_host_sv_on) zzhl_fx[ZFX_SV_US] += rix_ticks_to_us((u32)(now - g_host_t));
    g_host_sv_on = 0u; g_host_t = now; g_host_cl_on = 1u;
}
/* who is drawing (zzhl_fx.h).  Asked by the GL queue when a batch BEGINS, so a batch
   keeps its origin whenever it is replayed. */
unsigned zzhl_origin_now(void)
{
    if (g_org_sky) return ZORG_SKY;
    switch (g_refph_slot) {
    case 1u: return ZORG_WORLD;
    case 3u: return ZORG_WATER;
    case 2u:
        if (g_org_vm) return ZORG_VIEWMODEL;
        switch (g_entph_slot) {
        case 4u: return ZORG_BRUSH;
        case 1u: case 2u: case 3u: case 8u: case 9u: return ZORG_STUDIO;
        case 5u: case 10u: case 11u: case 12u: case 13u: return ZORG_SPRITE;
        case 7u: case 14u: case 15u: return ZORG_EFX;
        default: return ZORG_OTHER;
        }
    default: return ZORG_OTHER;
    }
}

/* entity sub-phases, called from gl_rmain.c and gl_studio.c (generated patches). */
void zzhl_entphase(unsigned slot)
{
    u32 now = rix_now();
    if (g_entph_t0) g_entph_cur[g_entph_slot] += rix_ticks_to_us((u32)(now - g_entph_t0));
    g_entph_t0 = now ? now : 1u;
    g_entph_slot = (slot < ZZ_NENTPH) ? slot : 0u;
}
/* Core1's waits for the GPU in the frame under way (zzhl_fx.h).  The same sum as the
   "GPU waits in these" of the period lines: the deferred queue's waits and the bind fences. */
unsigned zzhl_gpu_wait_us(void)
{
    const rix_frame *fr;
    if (!g_open || !zzgl_frame_open()) return 0u;
    fr = zzgl_frame();
    return fr->dq_wait_us + fr->bind_wait_us;
}
/* the GL queue's replay borrows the clock and gives it back (zzhl_fx.h) */
unsigned zzhl_entphase_swap(unsigned slot)
{
    u32 was = g_entph_slot;
    if (was == 0u || slot == 0u) return 0u;
    zzhl_entphase(slot);
    return was;
}

static void (*g_starved_hook)(unsigned us);          /* zz_rix_set_starved_hook, below */
void zz_rix_end_frame(void)
{
    int rc, overlap;
    u32 t0, t1, polls = 0u, t_ref, pres_us = 0u;
    zz_perf rec;
    if (!g_open) return;
    if (!zzgl_frame_open()) {                      /* nothing was drawn: nothing to show */
        g_frames_dropped++;
        return;
    }
    rix_frame_set_phase(RIX_PH_PRESENT);           /* build 35 */
    t_ref = rix_now();
    overlap = g_overlap_req && !g_sync_on;
    if (overlap) {                                 /* 0.9.3: frame N-1 shown while the GPU works on this one */
        pend_present();
        pres_us = rix_ticks_to_us((u32)(rix_now() - t_ref));
    }
    t0 = rix_now();
    rc = zzgl_swap();
    if (rc) Sys_Error("RIX frame %u: submit E%04x", g_frames, (unsigned)rc & 0xFFFFu);
    memset(&rec, 0, sizeof rec);
    {   /* 0.7: this frame's numbers (into the run totals below, 0.8.2: and the timedemo's) */
        const zzgl_stats *st = zzgl_get_stats();
        const rix_frame *fr = zzgl_frame();
        u32 t_sw = rix_now(), c;
        rec.frames = 1u;
        rec.ref_us = rix_ticks_to_us((u32)(t_ref - g_begin_tick));
        rec.swap_us = rix_ticks_to_us((u32)(t_sw - t0));
        rec.end_us = rix_ticks_to_us(st->end_ticks);
        rec.bind_us = rix_ticks_to_us(st->bind_ticks);
        rec.flush_us = rix_ticks_to_us(st->flush_ticks);
        rec.upload_us = st->upload_us;
        if (st->open_tick && (u32)(st->open_tick - g_begin_tick) < (u32)(t_ref - g_begin_tick)) rec.engine_us = rix_ticks_to_us((u32)(st->open_tick - g_begin_tick));   /* build 33 */
        { u32 it, isp; rix_frame_idle_take(&it, &isp); rec.gpu_idle_us = rix_ticks_to_us(it); rec.gpu_idle_spells = isp; }
        { u32 st2; rix_frame_starved_take(&st2); rec.gpu_starved_us = rix_ticks_to_us(st2); }   /* build 35 */
        if (g_starved_hook) g_starved_hook(rec.gpu_starved_us);                                 /* EARLY=2 decides on it */
        rec.tris_in = st->tris_in; rec.tris_out = st->tris_out; rec.culled = st->culled; rec.clipped = st->clipped;
        rec.begins = st->begins; rec.verts = st->verts; rec.binds = st->binds; rec.binds_skipped = st->binds_skipped;
        rec.uploads = st->tex_uploads; rec.subuploads = st->tex_subuploads; rec.state_words = st->state_words;
        rec.chunks = fr->chunks; rec.words = fr->words; rec.ringwait_us = fr->ringwait_us; rec.bind_wait_us = fr->bind_wait_us;
        rec.desc_us = rix_ticks_to_us(st->desc_ticks); rec.emit_us = rix_ticks_to_us(st->emit_ticks); rec.end_bwait_us = st->end_bwait_us;
        rec.tex_versions = st->tex_versions; rec.tex_version_us = st->tex_version_us; rec.tex_version_fail = st->tex_version_fail;
        rec.dq_starved = fr->dq_starved;
        if (g_have_fence_done && fr->first_submit_tick) {
            u32 idle = rix_ticks_to_us((u32)(fr->first_submit_tick - g_fence_done_tick));
            if (idle < 1000000u) { rec.idle_between_us = idle; rec.idle_frames = 1u; }
        }
        if (g_sync_on) { rec.sync_frames = 1u; rec.sync_gpu_us = fr->ringwait_us + fr->bind_wait_us; }
        if (rix_frame_deferred()) {
            rec.dq_frames = 1u; rec.dq_peak = fr->dq_peak; rec.dq_held = fr->dq_held; rec.dq_wait_us = fr->dq_wait_us;
            rec.dq_tex_us = fr->dq_tex_us; rec.dq_end_us = fr->dq_end_us; rec.dq_refused = fr->dq_refused;
            if (fr->dq_peak > g_dq_peak_max) g_dq_peak_max = fr->dq_peak;
        }
        for (c = 0; c < ZZ_NCAT; c++) {
            rec.cat[c].batches = g_cf[c].batches; rec.cat[c].tris = g_cf[c].tris; rec.cat[c].binds = g_cf[c].binds;
            rec.cat[c].wall_us = rix_ticks_to_us(g_cf[c].wall); rec.cat[c].begin_us = rix_ticks_to_us(g_cf[c].begin);
            rec.cat[c].end_us = rix_ticks_to_us(g_cf[c].end); rec.cat[c].bwait_us = g_cf[c].bwait_us;
        }
        t0 = rix_now();                            /* the GPU wait below starts here */
    }
    if (overlap) {
        /* 0.9.3: this frame stays pending; no fence wait, no presentation here */
        u32 t2 = rix_now(), period;
        if (rix_frame_pipelined()) { g_pipe_frames++; g_queued_at_end += rix_frame_queued(); }   /* build 32 */
        g_pend = 1; g_pend_buf = g_frame_buf; g_pend_fence = g_frame_fence;
        g_have_fence_done = 0u; g_overlap_frames++;
        rec.overlap_frames = 1u;
        rec.present_us = pres_us;
        g_t_present_us += pres_us;
        period = g_have_last_end ? rix_ticks_to_us((u32)(t2 - g_last_end_tick)) : 0u;
        g_last_end_tick = t2; g_have_last_end = 1u;
        rec.wall_us = (period < 1000000u) ? period : 0u;
        goto accounted;
    }
    /* the GPU wait is reported as the release profile step TEX (rasterisation) */
    zzq_s2_begin(2);
    if (rix_frame_deferred()) rc = rix_frame_wait_pumped(g_frame_buf, g_frame_fence, 2000000u);   /* build 32 */
    else rc = rix_frame_wait(g_frame_buf, g_frame_fence, 2000000u, 0, &polls);
    zzq_s2_end(2);
    t1 = rix_now();
    g_fence_done_tick = t1; g_have_fence_done = 1u;   /* 0.9.2: the GPU has nothing more from here */
    if (rc) {
        /* the frame fence never showed: pix = what the polled buffer holds at the fence pixel,
           oth = the other buffer, ch = chunks of the frame, cs = last chunk fence seq / pixel,
           alive 1 = the parser still takes NOPs (fence lost, not a hang), 2 = hung (power cycle) */
        rix_frame_diag_last();
        Sys_Error("RIX E%04x f%04x pix %04x oth %04x ch %u cs %04x/%04x al %u fr %u",
                  (unsigned)rc & 0xFFFFu, g_frame_fence, fence_pixel(g_frame_buf), fence_pixel(g_color_bufs[g_cur ^ 1u]),
                  g_sd[SD_FD_CHUNKS], g_sd[SD_FD_LAST_CSEQ], g_sd[SD_FD_CSEQ_PIX], g_sd[SD_FD_ALIVE], g_frames);
    }
    {
        u32 us = rix_ticks_to_us((u32)(t1 - t0));
        g_t_gpu_us += us;
        if (us > g_t_gpu_max_us) g_t_gpu_max_us = us;
        rec.gpu_us = us;
        if (g_sync_on) rec.sync_gpu_us += us;
    }
    pend_present();                                /* 0.9.3: rix_overlap just switched off: the pending frame first */
    zzq2_present_rgb565((const unsigned short *)rix_ptr(g_frame_buf + RIXQ2_SHOW_OFF), RIXQ2_PITCH);
    zc_release_buf(g_frame_buf);                   /* build 86 */
    {
        u32 t2 = rix_now(), period;
        rec.present_us = rix_ticks_to_us((u32)(t2 - t1));
        g_t_present_us += rec.present_us;
        /* 0.8.2: frame period (end to end), long ones (map loads) left out */
        period = g_have_last_end ? rix_ticks_to_us((u32)(t2 - g_last_end_tick)) : 0u;
        g_last_end_tick = t2; g_have_last_end = 1u;
        rec.wall_us = (period < 1000000u) ? period : 0u;
        if (g_sync_on) rec.sync_wall_us = rec.wall_us;
    }
accounted:
    /* close the phase under way and hand the frame's phase times to the record */
    zzhl_refphase(ZZ_NREFPH - 1u);
    { u32 i; for (i = 0; i < ZZ_NREFPH; i++) { rec.ref_ph_us[i] = g_refph_cur[i]; g_refph_cur[i] = 0u; } }
    zzhl_entphase(0u);                                     /* build 64 */
    { u32 i; for (i = 0; i < ZZ_NENTPH; i++) { rec.ent_ph_us[i] = g_entph_cur[i]; g_entph_cur[i] = 0u; } }
    rec.glow_traces = zzhl_glow_traces; rec.glow_cached = zzhl_glow_cached;   /* build 65 */
    rec.glow_us = zzhl_glow_us; rec.pm_ents = zzhl_pm_ents; rec.pm_rejected = zzhl_pm_rejected;
    zzhl_glow_traces = zzhl_glow_cached = zzhl_glow_us = zzhl_pm_ents = zzhl_pm_rejected = 0u;
    hitch_note(&rec);                              /* build 39 */
    perf_add(&g_pt, &rec);
    {   /* what ZZGL sent for this frame, by origin, joins the frame's counters */
        zzgl_origin_stat os[ZORG_COUNT];
        u32 o;
        zzgl_origin_take(os, (u32)ZORG_COUNT);
        for (o = 0; o < (u32)ZORG_COUNT; o++) {
            zzhl_fx[ZFX_ORG(o, ZFXO_BATCHES)] = os[o].batches; zzhl_fx[ZFX_ORG(o, ZFXO_TRIS)] = os[o].tris;
            zzhl_fx[ZFX_ORG(o, ZFXO_PX_OPAQUE)] = (u32)os[o].px_opaque; zzhl_fx[ZFX_ORG(o, ZFXO_PX_BLEND)] = (u32)os[o].px_blend;
            zzhl_fx[ZFX_ORG(o, ZFXO_BINDS)] = os[o].binds; zzhl_fx[ZFX_ORG(o, ZFXO_PAGES)] = os[o].pages;
            zzhl_fx[ZFX_ORG(o, ZFXO_TRIS_IN)] = os[o].tris_in;
            zzhl_fx[ZFX_ORG(o, ZFXO_PX_BOX)] = (u32)os[o].px_box;      /* build 86, BOXPX=1 */
            zzhl_fx[ZFX_ORG(o, ZFXO_WK_DESC)] = os[o].wk_desc;         /* build 87, WALKSTAT=1 */
            zzhl_fx[ZFX_ORG(o, ZFXO_WK_CLOCKS)] = os[o].wk_clocks; zzhl_fx[ZFX_ORG(o, ZFXO_WK_FAR)] = os[o].wk_far; zzhl_fx[ZFX_ORG(o, ZFXO_WK_END)] = os[o].wk_end;
            zzhl_fx[ZFX_ORG(o, ZFXO_WK_LINES)] = os[o].wk_lines; zzhl_fx[ZFX_ORG(o, ZFXO_WK_EMPTY)] = os[o].wk_empty;
            zzhl_fx[ZFX_ORG(o, ZFXO_TRIS_REJ)] = os[o].tris_rej;        /* build 87, REJECT=1 */
        }
        /* build 87, BOXFIT: what the descriptor builder took off the boxes of this frame's triangles */
        zzhl_fx[ZFX_BF_LINES] = rix_box_fit_lines; zzhl_fx[ZFX_BF_DROPPED] = rix_box_fit_dropped;
        rix_box_fit_lines = 0u; rix_box_fit_dropped = 0u;
        {   /* the frame's depth clears, sent to the GPU or not (ZZGL counts them) */
            const zzgl_stats *zs = zzgl_get_stats();
            zzhl_fx[ZFX_ZC_SKIPPED] = zs->zclear_skipped; zzhl_fx[ZFX_ZC_GPU] = zs->zclear_gpu;
        }
    }
    if (g_world_seen) {
        /* the buckets and the histogram hold the frames that drew the world, nothing else */
        if (rec.wall_us) { u32 i; for (i = 0; i < ZZ_NHIST; i++) if (rec.wall_us < g_hist_hi[i]) { g_hist[i]++; break; } }
        fx_add(FXB_RUN);
        if (rec.wall_us > 25000u && rec.wall_us < 100000u) { perf_add(&g_slow, &rec); fx_add(FXB_SLOW); }   /* build 33 */
        else if (rec.wall_us && rec.wall_us <= 25000u) { perf_add(&g_norm, &rec); fx_add(FXB_NORM); }
        if (rec.wall_us > 45454u) { perf_add(&g_over45, &rec); fx_add(FXB_OVER45); }                          /* build 64 */
        if (g_bench_on && rec.wall_us) {
            perf_add(&g_bench, &rec); fx_add(FXB_BENCH);
            if (rec.wall_us > g_bench_max) g_bench_max = rec.wall_us;
            if (rec.wall_us < g_bench_min) g_bench_min = rec.wall_us;
            if (rec.wall_us > 25000u) g_bench_n25++;
            if (rec.wall_us > 33333u) g_bench_n33++;
            if (rec.wall_us > 45454u) g_bench_n45++;
        }
    } else {
        g_noworld_frames++; g_noworld_ms += rec.wall_us / 1000u;
        if (g_bench_on) g_bench_noworld++;
    }
    g_world_seen = 0u;
    memset(zzhl_fx, 0, sizeof zzhl_fx);
    /* 0.8.2: a timedemo segment = the frames that draw the world after a map load (ref_gl's
       registration_sequence moved) that happened while timedemo was set, up to the first frame
       without the world (demo over: disconnect) or the next map load.  "timedemo 1" typed over
       the attract demo starts nothing; the map load of "d1" does. */
    if (g_regseq != g_regseq_seen) {
        g_regseq_seen = g_regseq;
        if (g_seg.frames) td_close();
        g_td_armed = g_td;
    }
    if (!g_td) {
        g_td_armed = 0;
        if (g_seg.frames) td_close();
    } else if (zzq2_world_count != g_world_at_begin) {
        if (g_td_armed) {
            if (!g_seg.frames) rec.wall_us = 0u;   /* the period before the first frame is not the demo's */
            perf_add(&g_seg, &rec);
        }
    } else if (g_seg.frames) {
        td_close();
        g_td_armed = 0;
    }
    g_frames++;
    g_cur ^= 1u;
    rix_frame_set_phase(RIX_PH_ENGINE);            /* the engine's logic, client and sound until the next GL call */
}
/* xacp_glq.c's replay (2) and its end (1) */
void zzhl_gpu_phase(unsigned ph) { if (g_open) rix_frame_set_phase(ph); }

/* ---- reports --------------------------------------------------------------- */
static void u2s(char *d, u32 v)              /* decimal, no stdio on this side */
{
    char t[12]; int n = 0;
    if (v == 0u) { *d++ = '0'; *d = 0; return; }
    while (v) { t[n++] = (char)('0' + v % 10u); v /= 10u; }
    while (n) *d++ = t[--n];
    *d = 0;
}
static void x2s(char *d, u32 v, int digits)
{
    static const char hx[] = "0123456789abcdef";
    int i;
    for (i = digits - 1; i >= 0; i--) *d++ = hx[(v >> (4 * i)) & 15u];
    *d = 0;
}
static void cat(char *d, const char *s) { while (*d) d++; while (*s) *d++ = *s++; *d = 0; }

/* the presentation copy by the PL330 (Core1/zzhl_present.c), tested once after the open on
   the window's two scratch areas of this build: SCRATCH (4 KiB, the ladder's) and FB2 (no colour
   buffer here: rix_init's NEON self-test already writes it).  4 KiB of a pattern copied and checked
   word by word, then a whole picture FB0 -> FB2 twice (timed) and 600 of its words checked.
   PRESENTDMA=0 (xacp_video.c) or any failure: Core1 copies, as up to build 34. */
extern void zzhl_present_set_dma(int on);
static int dcopy_run(u32 src, u32 dst, u32 bytes, u32 *us)
{
    u32 t0 = rix_now();
    int r = rix_dmacopy_start(src, dst, bytes);
    if (r) return 10;
    for (;;) {
        r = rix_dmacopy_poll();
        if (r == 1) break;
        if (r == 2) return 11;
        if (rix_ticks_to_us((u32)(rix_now() - t0)) > 50000u) { rix_dmacopy_abort(); return 12; }
    }
    *us = rix_ticks_to_us((u32)(rix_now() - t0));
    return 0;
}
static u32 sw16(u32 x) { return ((x & 0x00FF00FFu) << 8) | ((x & 0xFF00FF00u) >> 8); }
int zz_rix_present_dma_test(int want, char *l, int cap)
{
    volatile u32 *a = (volatile u32 *)rix_ptr(RIX_SCRATCH_ARM), *b = (volatile u32 *)rix_ptr(RIX_FB2_ARM);
    volatile u32 *f0 = (volatile u32 *)rix_ptr(RIX_FB0_ARM);
    u32 i, x = 0x2468ACE1u, us = 0u, best = 0xFFFFFFFFu, bad = 0u;
    int rc = 0, ok;
    char n[16], t[200];
    t[0] = 0;
    if (!g_open) { zzhl_present_set_dma(0); why_set(l, cap, "RIX: presentation copy by Core1 (GPU not open)"); return 0; }
    if (!want) { zzhl_present_set_dma(0); why_set(l, cap, "RIX: presentation copy by Core1 (PRESENTDMA=0)"); return 0; }
    if (!rix_dmacopy_available()) {
        zzhl_present_set_dma(0);
        cat(t, "RIX: presentation copy by Core1: PL330 not usable (SLCR clock/reset "); x2s(n, g_sd[SD_DMAC_DSR], 8); cat(t, n); cat(t, ")");
        why_set(l, cap, t);
        return 0;
    }
    for (i = 0; i < 1024u; i++) { x = x * 1664525u + 1013904223u; a[i] = x; b[i] = 0u; }
    dsb();
    rc = dcopy_run(RIX_SCRATCH_ARM, RIX_FB2_ARM, 4096u, &us);
    if (!rc) {
        dmb();
        x = 0x2468ACE1u;
        for (i = 0; i < 1024u; i++) { x = x * 1664525u + 1013904223u; if (b[i] != sw16(x)) bad++; }
    }
    for (i = 0; !rc && !bad && i < 2u; i++) {
        rc = dcopy_run(RIX_FB0_ARM, RIX_FB2_ARM, RIX_FB_BYTES, &us);
        if (!rc && us < best) best = us;
    }
    if (!rc && !bad) {
        dmb();
        for (i = 0; i < 600u; i++) if (b[i * 256u] != sw16(f0[i * 256u])) bad++;
    }
    ok = (rc == 0 && bad == 0u);
    zzhl_present_set_dma(ok);
    if (ok) {
        cat(t, "RIX: presentation copy by the PL330 (test ok: "); u2s(n, RIX_FB_BYTES); cat(t, n); cat(t, " bytes in ");
        u2s(n, best); cat(t, n); cat(t, " us, DSR "); x2s(n, rix_dmacopy_dsr(), 8); cat(t, n); cat(t, ")");
    } else {
        cat(t, "RIX: presentation copy by Core1: PL330 test failed (step "); u2s(n, (u32)rc); cat(t, n);
        cat(t, ", wrong words "); u2s(n, bad); cat(t, n); cat(t, ", FTR "); x2s(n, rix_dmacopy_fault_info(), 8); cat(t, n);
        cat(t, ", DSR "); x2s(n, rix_dmacopy_dsr(), 8); cat(t, n); cat(t, ")");
    }
    why_set(l, cap, t);
    return ok;
}

/* the report (xacp_video.c prints it apart, line by line: up to 32 lines, ~7 KiB) */
void zz_rix_hitch_report(char *out, int cap)
{
    char n[16];
    u32 i;
    out[0] = 0;
    if (cap < 8192) return;
    cat(out, "frames of 80 ms or more: "); u2s(n, g_hitch_all); cat(out, n); cat(out, " (the first 32; ms; t = sum of the frame times so far)\n");
    for (i = 0; i < g_nhitch; i++) {
        const zz_hitch *h = &g_hitch[i];
#define HL(label, v) do { cat(out, label); u2s(n, (v)); cat(out, n); } while (0)
        {   /* a letter of its own, or the console mirror folds lines that differ only by digits */
            char tag[4]; tag[0] = ' '; tag[1] = (char)(i < 26u ? 'a' + i : 'A' + (i - 26u)); tag[2] = ' '; tag[3] = 0;
            cat(out, " "); cat(out, tag);
        }
        HL("#", h->frame); HL(" t ", h->t_ms / 1000u); HL(".", (h->t_ms % 1000u) / 100u); HL(" s: ", h->wall / 1000u);
        HL(" = engine ", h->engine / 1000u); HL(" ref_gl ", h->ref / 1000u); HL(" binds ", h->binds / 1000u); HL(" tris ", h->tris / 1000u);
        HL(" uploads ", h->upl / 1000u); HL(" (GPU waits ", h->gwait / 1000u); HL(") present ", h->present / 1000u);
        HL(" | disk ", h->io_n); HL(" req ", h->io_kib); HL(" KiB ", h->io_ms); cat(out, " ms");   /* every request (xacp_disk.c) */
        HL(" | ", h->ntris); HL(" tris ", h->nbinds); HL(" binds, tex uploads ", h->uploads); HL(" sub ", h->subup); HL(" versions ", h->versions);
        cat(out, "\n");
#undef HL
    }
}
/* console lines after GLimp_SetMode: the ladder, the transport, the memory */
void zz_rix_console_report(void (*out)(const char *line))
{
    char l[128], n[16];
    u32 i, stages = g_sd[SD_LADDER_STAGES], failed = g_sd[SD_LADDER_FAILED];
    l[0] = 0; cat(l, "RIX: ladder "); u2s(n, stages); cat(l, n); cat(l, " stages, ");
    if (failed) { cat(l, "first failed L"); u2s(n, failed - 1u); cat(l, n); } else cat(l, "all passed");
    cat(l, ", caps "); x2s(n, rix_caps(), 4); cat(l, n);
    cat(l, ", init E"); x2s(n, (u32)g_init_rc & 0xFFFFu, 4); cat(l, n);
    out(l);
    l[0] = 0; cat(l, "RIX: binds "); cat(l, g_bind_mode == RIX_BIND_LIST ? "short DDR lists (BINDLIST)" : "FIFO packets");
    cat(l, ", chunks "); u2s(n, RIXQ2_RING_SLOTS); cat(l, n); cat(l, "x"); u2s(n, RIXQ2_CHUNK_BYTES / 1024u); cat(l, n); cat(l, "K, pool ");
    u2s(n, RIXQ2_POOL_PAGES * 2u / 1024u); cat(l, n); cat(l, " MiB at "); x2s(n, RIXQ2_POOL_BASE, 8); cat(l, n);
    out(l);
    l[0] = 0; cat(l, "RIX: frame "); u2s(n, (u32)ZZQ2_VID_W); cat(l, n); cat(l, "x"); u2s(n, (u32)ZZQ2_VID_H); cat(l, n);
    cat(l, " in buffers "); u2s(n, rix_geo_w); cat(l, n); cat(l, "x"); u2s(n, rix_geo_h_alloc); cat(l, n);
    cat(l, " at "); x2s(n, g_color_bufs[0], 8); cat(l, n); cat(l, " "); x2s(n, g_color_bufs[1], 8); cat(l, n);
    out(l);
    l[0] = 0; cat(l, "RIX: MMU table "); x2s(n, g_mmu.table, 8); cat(l, n);
    cat(l, " TTBR0 "); x2s(n, g_mmu.ttbr0, 8); cat(l, n);
    cat(l, " L1 "); u2s(n, g_mmu.l1_us); cat(l, n); cat(l, " us, L2 ");
    if (g_mmu.l2_done) { u2s(n, g_mmu.l2_us); cat(l, n); cat(l, " us"); } else cat(l, "off");
    out(l);
    for (i = 0; i < 4u; i++) {
        /* ladder stages 4 per line: Lk status/checks (status 0 = ok) */
        u32 k;
        l[0] = 0;
        for (k = i * 4u; k < i * 4u + 4u && k < SD_LADDER_MAX; k++) {
            u32 st = g_sd[SD_LADDER + k * SD_LADDER_SLOTS], ck = g_sd[SD_LADDER + k * SD_LADDER_SLOTS + 2u];
            cat(l, "L"); u2s(n, k); cat(l, n); cat(l, ":");
            if (st == 0xEEEEEEEEu) cat(l, "-");
            else { x2s(n, st & 0xFFFFu, 4); cat(l, n); cat(l, "/"); x2s(n, ck & 0xFFFFu, 2); cat(l, n); }
            cat(l, " ");
        }
        out(l);
    }
}

/* ---- performance report (0.7) ---------------------------------------------------------------------
   Per frame averages over the run, written to baseq2/rixstat.txt at R_Shutdown (zzq2rix_video.c).
   ref   = GLimp_BeginFrame -> GLimp_EndFrame: everything ref_gl does for a frame (BSP walk, models,
           2D) including ZZGL; zzglBegin = the state flush of each batch (registers, binds); binds =
           its part in rix_frame_texture; zzglEnd = vertex batches -> descriptors in the chunk ring
           (ring slot waits included); swap = closing the frame; gpu = waiting for the frame fence;
           present = RGB565 -> P96.  ref - zzglBegin - zzglEnd - uploads = ref_gl's own CPU time
           (BSP walk, lighting, model lerp) plus the cheap qgl calls (glVertex: the transform). */
static void line_kv(char *out, const char *k, u32 v, const char *unit)
{
    char n[16];
    cat(out, k); u2s(n, v); cat(out, n); cat(out, unit);
}
static void cat_line(char *out, const char *name, const zz_catsum *c, u32 f)
{
    char n[16];
    cat(out, name);
    cat(out, "  batch "); u2s(n, c->batches / f); cat(out, n);
    cat(out, "  tri "); u2s(n, c->tris / f); cat(out, n);
    cat(out, "  bind "); u2s(n, (c->binds * 10u) / f / 10u); cat(out, n); cat(out, "."); u2s(n, ((c->binds * 10u) / f) % 10u); cat(out, n);
    cat(out, "  | us "); u2s(n, c->wall_us / f); cat(out, n);
    cat(out, " = begin "); u2s(n, c->begin_us / f); cat(out, n);
    cat(out, " (bind wait "); u2s(n, c->bwait_us / f); cat(out, n); cat(out, ")");
    cat(out, " + end "); u2s(n, c->end_us / f); cat(out, n);
    cat(out, " + vertices "); u2s(n, (c->wall_us > c->begin_us + c->end_us) ? (c->wall_us - c->begin_us - c->end_us) / f : 0u); cat(out, n);
    cat(out, "\n");
}
static void perf_format(char *out, const zz_perf *p)
{
    u32 f = p->frames ? p->frames : 1u, c;
    zz_catsum all;
    out[0] = 0;
    cat(out, "frames "); { char n[16]; u2s(n, p->frames); cat(out, n); } cat(out, "\n");
    cat(out, "per frame, microseconds:\n");
    line_kv(out, "  ref (BeginFrame->EndFrame) ", p->ref_us / f, "\n");
    line_kv(out, "    zzglBegin (state+binds)  ", p->flush_us / f, "\n");
    line_kv(out, "      of which binds         ", p->bind_us / f, "\n");
    line_kv(out, "      bind fence waits       ", p->bind_wait_us / f, "\n");
    line_kv(out, "    zzglEnd (triangles)      ", p->end_us / f, "\n");
    line_kv(out, "      ring slot waits        ", p->ringwait_us / f, "\n");
    line_kv(out, "    texture uploads          ", p->upload_us / f, "\n");
    line_kv(out, "    ref_gl rest (engine)     ", (p->ref_us > p->flush_us + p->end_us + p->upload_us) ? (p->ref_us - p->flush_us - p->end_us - p->upload_us) / f : 0u, "\n");
    line_kv(out, "  swap (close the frame)     ", p->swap_us / f, "\n");
    line_kv(out, "  gpu (fence wait)           ", p->gpu_us / f, "\n");
    line_kv(out, "  present (RGB565 -> P96)    ", p->present_us / f, "\n");
    cat(out, "per frame, counts:\n");
    line_kv(out, "  glBegin batches            ", p->begins / f, "\n");
    line_kv(out, "  vertices                   ", p->verts / f, "\n");
    line_kv(out, "  triangles in               ", p->tris_in / f, "\n");
    line_kv(out, "  culled                     ", p->culled / f, "\n");
    line_kv(out, "  clipped                    ", p->clipped / f, "\n");
    line_kv(out, "  descriptors out            ", p->tris_out / f, "\n");
    line_kv(out, "  binds sent                 ", p->binds / f, "\n");
    line_kv(out, "  binds skipped              ", p->binds_skipped / f, "\n");
    line_kv(out, "  chunks                     ", p->chunks / f, "\n");
    line_kv(out, "  list words                 ", p->words / f, "\n");
    line_kv(out, "  state words                ", p->state_words / f, "\n");
    line_kv(out, "  uploads x1000              ", (p->uploads * 1000u) / f, "\n");
    line_kv(out, "  sub-uploads x1000          ", (p->subuploads * 1000u) / f, "\n");
    if (p->tris_in >= f) line_kv(out, "zzglEnd ns per triangle in   ", (p->end_us / f) * 1000u / (p->tris_in / f), "\n");
    if (p->binds) line_kv(out, "bind us each                 ", p->bind_us / p->binds, "\n");
    /* 0.8.3: inside zzglEnd, and how full the chunks are */
    cat(out, "zzglEnd split, per frame, microseconds:\n");
    line_kv(out, "  bind waits inside zzglEnd  ", p->end_bwait_us / f, " (a full chunk closed behind a pending bind)\n");
    if (p->desc_us || p->emit_us) {
        u32 de = p->desc_us + p->emit_us;
        line_kv(out, "  descriptor computation     ", p->desc_us / f, " (rix_tri_desc)\n");
        line_kv(out, "  descriptor writes          ", (p->emit_us > p->end_bwait_us ? p->emit_us - p->end_bwait_us : 0u) / f, " (rix_frame_tri, 40 words each into the chunk)\n");
        line_kv(out, "  the rest                   ", (p->end_us > de ? p->end_us - de : 0u) / f, " (copy, clamps, near clip, project, cull, screen clip)\n");
    } else cat(out, "  (rix_prof 0: set rix_prof 1 for descriptor computation / writes / rest)\n");
    if (p->chunks) {
        line_kv(out, "  chunk fill, % of a slot    ", (p->words / p->chunks) * 400u / RIXQ2_CHUNK_BYTES, "\n");
        line_kv(out, "  ring slots x KiB           ", RIXQ2_RING_SLOTS * 1000u + RIXQ2_CHUNK_BYTES / 1024u, " (slots * 1000 + KiB per slot)\n");
        line_kv(out, "  chunks closed full         ", p->chunks > p->binds + f ? (p->chunks - p->binds - f) / f : 0u, " per frame (the others end at a bind or at the frame's end)\n");
    }
    /* 0.9.1: GPU time measured in SYNC mode */
    if (p->sync_frames) {
        u32 g = p->sync_frames;
        cat(out, "GPU time (rix_sync 1: Core1 waits for every chunk and bind, nothing overlaps), per frame:\n");
        { char n[16]; cat(out, "  frames in this mode         "); u2s(n, g); cat(out, n); cat(out, " of "); u2s(n, p->frames); cat(out, n); cat(out, "\n"); }
        line_kv(out, "  GPU busy, us               ", p->sync_gpu_us / g, " (chunk + bind fence waits + final wait; polling adds up to ~50 us per wait)\n");
        line_kv(out, "  Core1 alone, us            ", (p->sync_wall_us > p->sync_gpu_us) ? (p->sync_wall_us - p->sync_gpu_us) / g : 0u, " (frame period minus the waits above)\n");
    }
    /* 0.9.2: GPU idle, texture versions */
    cat(out, "GPU idle and texture updates, per frame:\n");
    if (p->idle_frames) line_kv(out, "  GPU idle between frames, us", p->idle_between_us / p->idle_frames, " (frame fence passed -> first chunk of the next frame: present + start of frame)\n");
    if (p->overlap_frames) {
        char n[16];
        cat(out, "  presentation overlapped     "); u2s(n, p->overlap_frames); cat(out, n); cat(out, " frames (rix_overlap 1: frame N-1 shown during N; idle between frames not measured)\n");
        if (g_pipe_frames) {   /* build 32 */
            u32 pf = g_pipe_frames;
            cat(out, "  pipelined frames            "); u2s(n, pf); cat(out, n); cat(out, " (frame N+1 begun with N still queued), events queued at the end: "); u2s(n, g_queued_at_end / pf); cat(out, n); cat(out, " avg\n");
            cat(out, "  wait for the pending frame  "); u2s(n, g_pend_wait_us / pf); cat(out, n); cat(out, " us avg, "); u2s(n, g_pend_wait_max_us); cat(out, n); cat(out, " us max (pumped; in present above)\n");
            cat(out, "  pumps outside ZZGL          "); u2s(n, g_pumps_outside / pf); cat(out, n); cat(out, " per frame (GL queue recording, GL_SwapBuffers)\n");
        }
    }
    line_kv(out, "  draws sent to an idle GPU  ", (p->dq_starved * 10u) / f / 10u, " (deferred mode: the GPU had finished everything before)\n");
    line_kv(out, "  texture versions x1000     ", (p->tex_versions * 1000u) / f, " (rix_texver 1: lightmap updates without a drain)\n");
    if (p->tex_versions) line_kv(out, "  us per version             ", p->tex_version_us / p->tex_versions, " (allocation + 32 KiB copy + clean)\n");
    line_kv(out, "  versions refused           ", p->tex_version_fail, " (pool or retired list full: drained instead)\n");
    /* 0.9: deferred submission */
    if (p->dq_frames) {
        u32 g = p->dq_frames;
        cat(out, "deferred submission (rix_defer 1), per frame:\n");
        { char n[16]; cat(out, "  frames in this mode         "); u2s(n, g); cat(out, n); cat(out, " of "); u2s(n, p->frames); cat(out, n); cat(out, "\n"); }
        line_kv(out, "  queue peak, events (avg)   ", p->dq_peak / g, "\n");
        line_kv(out, "  queue peak, events (max)   ", g_dq_peak_max, " (whole run)\n");
        line_kv(out, "  chunks held behind a bind  ", p->dq_held / g, "\n");
        line_kv(out, "  waits for the queue, us    ", p->dq_wait_us / g, " (ring slot, full queue, texture drains, end of frame)\n");
        line_kv(out, "    texture drains, us       ", p->dq_tex_us / g, "\n");
        line_kv(out, "    end of frame, us         ", p->dq_end_us / g, "\n");
        line_kv(out, "  rule-11 guard refusals     ", p->dq_refused, " (must be 0)\n");
    }
    /* 0.8.2 */
    cat(out, "per frame by category (batch = glBegin..glEnd; begin = state + binds, end = triangles,\n"
             "vertices = the glVertex/glColor/glTexCoord calls and ref_gl code between them; bind wait = every\n"
             "wait of Core1 for the GPU inside the batch, deferred queue included):\n");
    memset(&all, 0, sizeof all);
    for (c = 0; c < ZZ_NCAT; c++) {
        const zz_catsum *k = &p->cat[c];
        cat_line(out, g_cat_name[c], k, f);
        all.batches += k->batches; all.tris += k->tris; all.binds += k->binds; all.wall_us += k->wall_us;
        all.begin_us += k->begin_us; all.end_us += k->end_us; all.bwait_us += k->bwait_us;
    }
    cat_line(out, "  all batches", &all, f);
}
/* one line of the slow / normal comparison */
/* the GPU between two samples (pumps, phase changes), by phase of Core1, per frame of the run
   (librixgpu copy: rix_frame_phase_stats).  "waiting" = the GPU had finished and events were queued: the
   time a closer pump would give back; "nothing queued" = Core1 had not produced the work yet. */
static void phase_report(char *out)
{
    static const char *nm[RIX_PHASES] = { "engine ", "ref_gl ", "replay ", "present" };
    char n[16];
    u32 ph, f = g_frames ? g_frames : 1u, v[6];
    cat(out, "GPU by phase of Core1, per frame, us (waiting = GPU idle while events were queued; nothing = idle, queue empty):\n");
    for (ph = 0; ph < RIX_PHASES; ph++) {
        rix_frame_phase_stats(ph, f, v);
        cat(out, "  "); cat(out, nm[ph]);
        cat(out, "  time "); u2s(n, v[0]); cat(out, n);
        cat(out, ", pumps "); u2s(n, v[1]); cat(out, n);
        cat(out, " (longest gap "); u2s(n, v[2]); cat(out, n); cat(out, ")");
        cat(out, ", GPU waiting "); u2s(n, v[3]); cat(out, n);
        cat(out, " in "); u2s(n, v[4]); cat(out, n);
        cat(out, ", nothing queued "); u2s(n, v[5]); cat(out, n); cat(out, "\n");
    }
    cat(out, "  game library calls that may pump (ENGPUMP "); cat(out, g_soon_on ? "1" : "0"); cat(out, "): ");
    u2s(n, g_soon_calls / f); cat(out, n); cat(out, " per frame, pumps made "); u2s(n, g_soon_pumps / f); cat(out, n); cat(out, "\n");
}
/* ZCLEAR.  The self-test's verdict is said again here: the start of the log may have left the mirror */
static char g_zc_line[720];
static void zclear_report(char *out)
{
    char n[16];
    if (g_zc_line[0]) cat(out, g_zc_line);
    if (!g_zc_hooked) return;
    cat(out, "depth clears by the PL330: "); u2s(n, g_zc_copies); cat(out, n); cat(out, " copies, of which made late (as the frame opened) "); u2s(n, g_zc_late); cat(out, n);
    cat(out, "; frames that waited for a copy "); u2s(n, g_zc_waits); cat(out, n);
    cat(out, ", "); u2s(n, g_zc_waits ? g_zc_wait_us / g_zc_waits : 0u); cat(out, n); cat(out, " us avg, "); u2s(n, g_zc_wait_max_us); cat(out, n); cat(out, " us max\n");
    if (g_zc_fail_code) {
        cat(out, "*** ZCLEAR STOPPED at frame "); u2s(n, g_zc_fail_frame); cat(out, n);
        cat(out, g_zc_fail_code == 1u ? ": the PL330 refused a copy, E" : g_zc_fail_code == 2u ? ": PL330 fault, FTR " : ": a copy did not end in 30 ms, ");
        x2s(n, g_zc_fail_info, 8); cat(out, n); cat(out, "; the GPU cleared the depth from there on\n");
    }
}
extern void zzhl_present_dma_stats(unsigned v[8]);
extern void zzhl_present_drop_stats(unsigned v[7]);   /* build 91 */
int zz_rix_cull_early(void);                          /* build 92, below */
static void present_dma_report(char *out)
{
    char n[16];
    unsigned v[8];
    zzhl_present_dma_stats(v);
    cat(out, "presentation copy: PL330 "); u2s(n, v[1]); cat(out, n); cat(out, " frames, ");
    u2s(n, v[2]); cat(out, n); cat(out, " us avg, "); u2s(n, v[3]); cat(out, n); cat(out, " us max, ");
    u2s(n, v[7]); cat(out, n); cat(out, " pumps during each; Core1 "); u2s(n, v[4]); cat(out, n); cat(out, " frames");
    if (v[5]) {
        cat(out, "; DMA stopped (");
        cat(out, v[5] == 1u ? "start refused " : v[5] == 2u ? "channel fault, FTR " : "no end in 30 ms");
        if (v[5] != 3u) { x2s(n, v[6], 8); cat(out, n); }
        cat(out, "), Core1 from there");
    }
    cat(out, v[0] ? " (DMA on at the end)\n" : "\n");
    {   /* Core1/zzhl_dropstat.h: the frames that found no display buffer free */
        unsigned d[7];
        zzhl_present_drop_stats(d);
        cat(out, "frames not shown (no display buffer free): "); u2s(n, d[1]); cat(out, n); cat(out, " of "); u2s(n, d[0]); cat(out, n);
        cat(out, "; engine pace over its last 8 frames: above 60/s "); u2s(n, d[2]); cat(out, n);
        cat(out, " (the screen had no room), 50-60/s "); u2s(n, d[3]); cat(out, n);
        cat(out, ", 40-50/s "); u2s(n, d[4]); cat(out, n);
        cat(out, ", under 40/s "); u2s(n, d[5]); cat(out, n);
        cat(out, ", not known "); u2s(n, d[6]); cat(out, n); cat(out, "\n");
    }
    if (zz_rix_cull_early()) {   /* build 92 */
        cat(out, "CULLEARLY="); u2s(n, (u32)zz_rix_cull_early()); cat(out, n);
        cat(out, ": back faces dropped before their set-up "); u2s(n, zzgl_early_culled()); cat(out, n);
        cat(out, " over the run\n");
    }
}
static void period_line(char *out, const char *name, const zz_perf *p)
{
    char n[16];
    u32 f = p->frames, ref, rest, waits, eng;
    if (!f) { cat(out, name); cat(out, " none\n"); return; }
    ref = p->ref_us / f;
    eng = p->engine_us / f;
    rest = (p->ref_us > p->flush_us + p->end_us + p->upload_us + p->engine_us) ? (p->ref_us - p->flush_us - p->end_us - p->upload_us - p->engine_us) / f : 0u;
    waits = p->dq_wait_us / f;
#define PL(label, v) do { cat(out, label); u2s(n, (v)); cat(out, n); } while (0)
    cat(out, name);
    PL(" frames ", f); PL(" | period ", p->wall_us / f); PL(" = engine ", eng); PL(" + ref_gl ", rest);
    PL(" + begin/binds ", p->flush_us / f); PL(" + triangles ", p->end_us / f); PL(" + uploads ", p->upload_us / f);
    PL(" (GPU waits in these ", waits); PL(") + present ", p->present_us / f); PL(" + swap ", p->swap_us / f);
    cat(out, "\n      ");   /* the console cuts a line near 250 characters (build 35's report) */
    PL("GPU idle, work waiting <= ", p->gpu_idle_us / f); PL(" in ", p->gpu_idle_spells / f); PL(", nothing queued <= ", p->gpu_starved_us / f);
    cat(out, "\n      ");
    PL("tris in ", p->tris_in / f); PL(", batches ", p->begins / f); PL(", binds ", p->binds / f); PL(", chunks ", p->chunks / f);
    PL(", lightmap updates x1000 ", (u32)((p->subuploads * 1000ull) / f)); PL(", versions x1000 ", (u32)((p->tex_versions * 1000ull) / f));
    cat(out, "\n      ");
    /* where ref_gl spends the frame (wall time, GL work issued by the phase included) */
    cat(out, "ref_gl by phase");
    { u32 i; for (i = 0; i < ZZ_NREFPH; i++) { cat(out, " "); cat(out, g_refph_name[i]); cat(out, " "); u2s(n, p->ref_ph_us[i] / f); cat(out, n); } }
    /* build 64; on two lines.  The mirror keeps 239 characters of a line (xacp_libc.c,
       MIR_LINE) and eighteen phases with real numbers pass it: the last one, the replay, is the
       one that must not be cut. */
    {   static const unsigned char l1[] = { 1, 2, 3, 8, 9, 4, 6, 7, 14, 15, 16 }, l2[] = { 5, 10, 11, 12, 13, ZZ_ENTPH_REPLAY };
        u32 i;
        cat(out, "\n      entities by phase");
        for (i = 0; i < (u32)sizeof l1; i++) { cat(out, " "); cat(out, g_entph_name[l1[i]]); cat(out, " "); u2s(n, p->ent_ph_us[l1[i]] / f); cat(out, n); }
        cat(out, "\n      sprites, and the GL queue's replays inside the entities:");
        for (i = 0; i < (u32)sizeof l2; i++) { cat(out, " "); cat(out, g_entph_name[l2[i]]); cat(out, " "); u2s(n, p->ent_ph_us[l2[i]] / f); cat(out, n); }
    }
    /* music.  Core1 only queues; the 68k launcher plays with its MUSIC= backend. */
    cat(out, "\n      music: play "); { extern u32 zzhl_mus_play, zzhl_mus_stop, zzhl_mus_dropped;
      u2s(n, zzhl_mus_play); cat(out, n); cat(out, ", stop "); u2s(n, zzhl_mus_stop); cat(out, n);
      cat(out, ", dropped "); u2s(n, zzhl_mus_dropped); cat(out, n); }
    /* the volume, which build 80 sent without any way of checking that it left.
       "vol sent 0" means Core1 never saw MP3Volume move (the poll, the cvar, or the patch);
       "vol sent N, now X" means Core1 did its part and the rest is the 68k's. */
    { extern u32 zzhl_mus_vol, zzhl_mus_volsent;
      cat(out, ", vol sent "); u2s(n, zzhl_mus_volsent); cat(out, n);
      cat(out, ", now "); u2s(n, zzhl_mus_vol); cat(out, n);
      cat(out, " of 65536"); }
    cat(out, "\n      halo traces ");   /* build 65 */
    u2s(n, p->glow_traces / f); cat(out, n);
    cat(out, ", reused "); u2s(n, p->glow_cached / f); cat(out, n);
    cat(out, ", us "); u2s(n, p->glow_us / f); cat(out, n);
    cat(out, ", entities looked at "); u2s(n, p->pm_ents / f); cat(out, n);
    cat(out, ", rejected cheaply "); u2s(n, p->pm_rejected / f); cat(out, n);
    cat(out, "\n");
#undef PL
}
void zz_rix_perf_report(char *out, int cap)
{
    out[0] = 0;
    if (cap < 6144) return;
    perf_format(out, &g_pt);
    cat(out, "stray frames "); { char n[16]; u2s(n, g_stray_frames); cat(out, n); } cat(out, "\n");
    /* build 33 */
    cat(out, "frames by period, per frame, us (engine = logic, client, sound before the first GL call; ref_gl = its CPU work between GL calls):\n");
    /* these three and the histogram hold the frames that drew the world only */
    { char n[16]; cat(out, "  frames without the world (menu, console, loading), counted apart since build 84: ");
      u2s(n, g_noworld_frames); cat(out, n); cat(out, " in "); u2s(n, g_noworld_ms / 1000u); cat(out, n); cat(out, " s\n"); }
    period_line(out, "  slow 25-100 ms", &g_slow);
    period_line(out, "  normal <25 ms ", &g_norm);
    period_line(out, "  over 45 ms    ", &g_over45);   /* the frames that break a 22 img/s floor */
    /* the histogram.  22 img/s as a FLOOR means no frame above 45454 us. */
    { u32 i; char n[16];
      cat(out, "frame times of the frames with the world, by bucket (ms; 22 img/s as a floor = nothing past 45):\n ");
      for (i = 0; i < ZZ_NHIST; i++) {
          cat(out, "  ");
          if (i + 1 == ZZ_NHIST) cat(out, ">=80 ");
          else { cat(out, "<"); u2s(n, g_hist_hi[i] / 1000u); cat(out, n); cat(out, " "); }
          u2s(n, g_hist[i]); cat(out, n);
      }
      cat(out, "\n"); }
    phase_report(out);
    present_dma_report(out);
    zclear_report(out);
}

/* ---- the load by origin, per bucket -----------------------------------------------------
   One line per origin that drew something, then the GL queue's flushes and the engine split.
   Every line starts with the bucket's letter: the console mirror folds consecutive lines that
   differ only by their digits (xacp_libc.c). */
static int g_boxpx;                         /* BOXPX=1, the box pixels are counted (ZZGL) and printed */
void zz_rix_set_boxpx(int on) { g_boxpx = on ? 1 : 0; zzgl_set_box_stats(g_boxpx); }
/* build 87.  WALKSTAT=1: every triangle sent is walked by the model of the rasteriser (librixgpu/
   rix_walk_model.h) and its clocks are printed by origin - Core1 then does the GPU's walking a
   second time, the frame takes about twice as long: a measurement run.  BOXFIT=1|2: the boxes
   of the triangles are cut to the lines that hold a pixel (librixgpu/rixdesc.c, rix_box_fit). */
static int g_walkstat;
void zz_rix_set_walkstat(int on) { g_walkstat = on ? 1 : 0; zzgl_set_walk_stats(g_walkstat); }
void zz_rix_set_boxfit(int mode) { rix_box_fit = mode < 0 ? 0 : mode > 2 ? 2 : mode; }
int zz_rix_boxfit(void) { return rix_box_fit; }
/* build 87, REJECT=1: ZZGL drops at zzglEnd a batch that is wholly outside one side of the view
   volume (zzgl.h, zzgl_set_batch_reject).  The column "rej" says how many triangles that was. */
static int g_reject;
void zz_rix_set_reject(int on) { g_reject = on ? 1 : 0; zzgl_set_batch_reject(g_reject); }
/* called at the end of every frame shown with the time (us) the GPU spent idle with
   nothing queued during it - what EARLY=2 chooses on (xacp_glq.c).  0 = nobody listens. */
void zz_rix_set_starved_hook(void (*fn)(unsigned us)) { g_starved_hook = fn; }
/* the test of REJECT checked on this machine (zzgl.h): the batches on which it is wrong, of
   *batches tried, *outside of them outside the view.  Not 0: REJECT is refused, whatever was
   asked. */
unsigned zz_rix_reject_check(unsigned *batches, unsigned *outside)
{
    u32 nb = 0u, no = 0u;
    const u32 bad = zzgl_batch_reject_check(&nb, &no);
    if (batches) *batches = nb;
    if (outside) *outside = no;
    if (bad) zz_rix_set_reject(0);
    return bad;
}
int zz_rix_reject(void) { return g_reject; }
/* build 92, CULLEARLY=1|2 (off by default): the back faces of the studio models and of the weapon in
   hand (1), or of every origin (2), dropped before the triangle's set-up (zzgl.h,
   zzgl_set_early_cull).  A4000, 16/11, Xen: frames bound by Core1, 5 300 triangles of models a
   heavy frame of which 2 450 are back faces.  What reaches the GPU does not change. */
static int g_cull_early;
void zz_rix_set_cull_early(int mode)
{
    g_cull_early = mode == 2 ? 2 : mode ? 1 : 0;
    zzgl_set_early_cull(g_cull_early, g_cull_early == 2 ? ~0u : ((1u << ZORG_STUDIO) | (1u << ZORG_VIEWMODEL)));
}
unsigned zz_rix_cull_early_check(unsigned *tris, unsigned *culled)
{
    u32 nt = 0u, nc = 0u;
    const u32 bad = zzgl_early_cull_check(&nt, &nc);
    if (tris) *tris = nt;
    if (culled) *culled = nc;
    if (bad) zz_rix_set_cull_early(0);
    return bad;
}
/* what the check found, for the startup line (zzgl.h) */
unsigned zz_rix_cull_early_check_detail(unsigned *nan_two_ways)
{
    u32 n = 0u;
    const u32 what = zzgl_early_cull_check_detail(&n);
    if (nan_two_ways) *nan_two_ways = n;
    return what;
}
int zz_rix_cull_early(void) { return g_cull_early; }
/* the model's two constants, fitted on the A4000's price list of 15/11 (tests/test_rixwalk.c):
   10.04 ns a clock of the walker, 1.456 us a descriptor */
#define WK_CLOCKS_US(c) ((u32)((unsigned long long)(c) * 1004ull / 100000ull))
#define WK_DESC_US(d)   ((u32)((unsigned long long)(d) * 1456ull / 1000ull))
static const char *const g_org_name[ZORG_COUNT] = {
    "other     ", "world     ", "lightmaps ", "brush ents", "studio    ", "viewmodel ", "sprites   ", "efx       ",
    "decals    ", "sky       ", "water     ", "2D/HUD    " };
static const char *const g_fxb_name[FXB_COUNT] = {
    "all the frames with the world", "normal <25 ms", "slow 25-100 ms", "over 45 ms", "bench scene" };
static const char g_fxb_tag[FXB_COUNT] = { 'R', 'N', 'S', 'O', 'B' };
static u32 fxv(u32 b, u32 i, u32 mul) { u32 f = g_fxframes[b]; return f ? (u32)((g_fxsum[b][i] * mul) / f) : 0u; }
static void fx_format(u32 b, char *out)
{
    char n[16], tag[5];
    u32 o, k, f = g_fxframes[b], tot[ZFXO_COUNT];
    tag[0] = ' '; tag[1] = ' '; tag[2] = g_fxb_tag[b]; tag[3] = ' '; tag[4] = 0;
#define FL(label, v) do { cat(out, label); u2s(n, (v)); cat(out, n); } while (0)
#define FL1(label, v10) do { u32 q_ = (v10); cat(out, label); u2s(n, q_ / 10u); cat(out, n); cat(out, "."); u2s(n, q_ % 10u); cat(out, n); } while (0)
    cat(out, "load by origin, "); cat(out, g_fxb_name[b]); FL(": ", f);
    if (!f) { cat(out, " frames\n"); return; }
    cat(out, " frames, per frame (kpx = thousands of pixels SUBMITTED after the screen clip, depth test not counted;\n"
             "      tris in = handed to ZZGL, sent = left after culling and clipping; pages = 2 KiB of texels streamed by the binds;\n"
             "      us = Core1 inside the draws, of which its waits for the GPU: the rest is Core1's own work)\n");
    if (g_boxpx) cat(out, "      box = thousands of pixels of the bounding boxes of the triangles sent (BOXPX=1), to set against opaque + blended\n");
    if (g_reject) cat(out, "      rej (REJECT=1) = of tris in, the triangles of batches dropped whole at zzglEnd: nothing of them was in view\n");
    if (g_walkstat) cat(out, "      walk (WALKSTAT=1) = the rasteriser's own clocks for these triangles, by its model, in thousands: far = on lines where it ran to the\n"
                             "      end of the box, ends = on the lines before the first and after the last line with a pixel; desc = descriptors sent)\n");
    for (k = 0; k < (u32)ZFXO_COUNT; k++) tot[k] = 0u;
    for (o = 0; o < (u32)ZORG_COUNT; o++) {
        if (!g_fxsum[b][ZFX_ORG(o, ZFXO_BATCHES)]) continue;
        cat(out, tag); cat(out, g_org_name[o]);
        FL1(" batches ", fxv(b, ZFX_ORG(o, ZFXO_BATCHES), 10u)); FL(" tris in ", fxv(b, ZFX_ORG(o, ZFXO_TRIS_IN), 1u)); FL(" sent ", fxv(b, ZFX_ORG(o, ZFXO_TRIS), 1u));
        FL1(" kpx opaque ", (u32)(g_fxsum[b][ZFX_ORG(o, ZFXO_PX_OPAQUE)] / 100u / f)); FL1(" blended ", (u32)(g_fxsum[b][ZFX_ORG(o, ZFXO_PX_BLEND)] / 100u / f));
        FL1(" binds ", fxv(b, ZFX_ORG(o, ZFXO_BINDS), 10u)); FL(" pages ", fxv(b, ZFX_ORG(o, ZFXO_PAGES), 1u));
        FL(" us ", fxv(b, ZFX_ORG(o, ZFXO_US), 1u)); FL(" of which GPU waits ", fxv(b, ZFX_ORG(o, ZFXO_WAIT_US), 1u));
        if (g_boxpx) FL1(" box ", (u32)(g_fxsum[b][ZFX_ORG(o, ZFXO_PX_BOX)] / 100u / f));
        if (g_reject) FL(" rej ", fxv(b, ZFX_ORG(o, ZFXO_TRIS_REJ), 1u));
        cat(out, "\n");
        for (k = 0; k < (u32)ZFXO_COUNT; k++) tot[k] += (k == ZFXO_PX_OPAQUE || k == ZFXO_PX_BLEND || k == ZFXO_PX_BOX) ? (u32)(g_fxsum[b][ZFX_ORG(o, k)] / 100u / f) : fxv(b, ZFX_ORG(o, k), 10u);
    }
    cat(out, tag); cat(out, "TOTAL     ");
    FL1(" batches ", tot[ZFXO_BATCHES]); FL(" tris in ", tot[ZFXO_TRIS_IN] / 10u); FL(" sent ", tot[ZFXO_TRIS] / 10u); FL1(" kpx opaque ", tot[ZFXO_PX_OPAQUE]); FL1(" blended ", tot[ZFXO_PX_BLEND]);
    FL1(" binds ", tot[ZFXO_BINDS]); FL(" pages ", tot[ZFXO_PAGES] / 10u); FL(" us ", tot[ZFXO_US] / 10u); FL(" of which GPU waits ", tot[ZFXO_WAIT_US] / 10u);
    if (g_boxpx) FL1(" box ", tot[ZFXO_PX_BOX]);
    if (g_reject) FL(" rej ", tot[ZFXO_TRIS_REJ] / 10u);
    /* tot[] holds hundreds of pixels here: screens x 10 = px * 10 / (W * H) */
    FL1(" | screens covered ", (tot[ZFXO_PX_OPAQUE] + tot[ZFXO_PX_BLEND]) * 1000u / ((u32)ZZQ2_VID_W * (u32)ZZQ2_VID_H));
    cat(out, "\n");
    if (g_walkstat) {                           /* the rasteriser's clocks, by its model */
        unsigned long long tc = 0ull, tf = 0ull, te = 0ull, td = 0ull, tl = 0ull, ty = 0ull;
        for (o = 0; o < (u32)ZORG_COUNT; o++) {
            if (!g_fxsum[b][ZFX_ORG(o, ZFXO_WK_DESC)]) continue;
            cat(out, tag); cat(out, "walk "); cat(out, g_org_name[o]);
            FL(" desc ", fxv(b, ZFX_ORG(o, ZFXO_WK_DESC), 1u)); FL1(" kclocks ", (u32)(g_fxsum[b][ZFX_ORG(o, ZFXO_WK_CLOCKS)] / 100u / f));
            FL1(" far ", (u32)(g_fxsum[b][ZFX_ORG(o, ZFXO_WK_FAR)] / 100u / f)); FL1(" ends ", (u32)(g_fxsum[b][ZFX_ORG(o, ZFXO_WK_END)] / 100u / f));
            FL(" lines ", fxv(b, ZFX_ORG(o, ZFXO_WK_LINES), 1u)); FL(" empty ", fxv(b, ZFX_ORG(o, ZFXO_WK_EMPTY), 1u));
            cat(out, "\n");
            td += g_fxsum[b][ZFX_ORG(o, ZFXO_WK_DESC)]; tc += g_fxsum[b][ZFX_ORG(o, ZFXO_WK_CLOCKS)]; tf += g_fxsum[b][ZFX_ORG(o, ZFXO_WK_FAR)];
            te += g_fxsum[b][ZFX_ORG(o, ZFXO_WK_END)]; tl += g_fxsum[b][ZFX_ORG(o, ZFXO_WK_LINES)]; ty += g_fxsum[b][ZFX_ORG(o, ZFXO_WK_EMPTY)];
        }
        cat(out, tag); cat(out, "walk TOTAL     ");
        FL(" desc ", (u32)(td / f)); FL1(" kclocks ", (u32)(tc / 100u / f)); FL1(" far ", (u32)(tf / 100u / f)); FL1(" ends ", (u32)(te / 100u / f));
        FL(" lines ", (u32)(tl / f)); FL(" empty ", (u32)(ty / f)); cat(out, "\n");
        cat(out, tag); FL("rasteriser, by its model: ", WK_CLOCKS_US(tc / f) + WK_DESC_US(td / f));
        FL(" us a frame (10.04 ns a clock + 1.46 us a descriptor); ", WK_CLOCKS_US(tf / f));
        FL(" us on lines that ran to the end of their box, ", WK_CLOCKS_US(te / f)); cat(out, " us on lines before the first / after the last pixel\n");
    }
    if (rix_box_fit) {                          /* build 87 */
        cat(out, tag); FL("box fit (BOXFIT=", (u32)rix_box_fit); FL("): lines without a pixel taken off the boxes ", fxv(b, ZFX_BF_LINES, 1u));
        FL(" a frame, triangles not sent because their box held no pixel ", fxv(b, ZFX_BF_DROPPED, 1u)); cat(out, " a frame\n");
    }
    cat(out, tag); cat(out, "GL queue flushes x1000:");
    FL(" end of frame ", fxv(b, ZFX_FLUSH_FRAME, 1000u)); FL(", order-dependent draw ", fxv(b, ZFX_FLUSH_STATE, 1000u));
    FL(", texture update ", fxv(b, ZFX_FLUSH_TEXTURE, 1000u)); FL(", clear/viewport/depth range ", fxv(b, ZFX_FLUSH_CLEAR, 1000u));
    FL(", full ", fxv(b, ZFX_FLUSH_FULL, 1000u)); FL(", early (EARLY=1) ", fxv(b, ZFX_FLUSH_EARLY, 1000u));
    cat(out, "\n");
    /* on a line of its own.  With the engine's time stamp in front, the mirror cut the
       line above before this number (A4000, 15/11): a console line holds about 220 characters. */
    cat(out, tag); FL("batches replayed before the frame's end ", fxv(b, ZFX_MID_BATCHES, 1u));
    cat(out, "; order-dependent flushes forced by, x1000:");
    for (o = 0; o < (u32)ZORG_COUNT; o++) if (g_fxsum[b][ZFX_FLUSHBY0 + o]) {
        const char *s = g_org_name[o]; char nm[12]; u32 q = 0u;
        while (s[q] && q < 10u) { nm[q] = s[q]; q++; }
        while (q && nm[q - 1u] == ' ') q--;
        nm[q] = 0;
        cat(out, " "); cat(out, nm); FL(" ", fxv(b, ZFX_FLUSHBY0 + o, 1000u));
    }
    cat(out, "\n");
    cat(out, tag); FL1("binds asked by ref_gl ", fxv(b, ZFX_BINDS_REQ, 10u)); FL1(", distinct textures ", fxv(b, ZFX_TEX_DISTINCT, 10u));
    FL(", GL queue replays ", fxv(b, ZFX_REPLAY_US, 1u)); cat(out, " us");
    FL(" | engine: server ", fxv(b, ZFX_SV_US, 1u)); FL(" us, client up to the 3D scene ", fxv(b, ZFX_CL_US, 1u));
    FL(" us, sound mix ", fxv(b, ZFX_SND_US, 1u)); FL1(" us in ", fxv(b, ZFX_SND_MIXES, 10u)); cat(out, " mixes\n");
    /* the frame's depth clears.  "skipped": not sent to the GPU, the PL330 had cleared the buffer (ZCLEAR=1) */
    cat(out, tag); FL("depth clears x1000: by the GPU ", fxv(b, ZFX_ZC_GPU, 1000u)); FL(", skipped (the PL330 had cleared the buffer) ", fxv(b, ZFX_ZC_SKIPPED, 1000u));
    FL("; PL330 clears made late x1000 ", fxv(b, ZFX_ZC_LATE, 1000u)); FL(", Core1 waited for the PL330 ", fxv(b, ZFX_ZC_WAIT_US, 1u)); cat(out, " us\n");
    if (g_fxsum[b][ZFX_SPR_QUADS]) {   /* SPRTRIM: what the sprites' empty margins are worth, measured whether the option is on or not */
        unsigned long long tq = g_fxsum[b][ZFX_SPR_TRIMMABLE];
        cat(out, tag); FL1("sprite quads ", fxv(b, ZFX_SPR_QUADS, 10u)); FL1(", with an empty margin the drawing mode cannot show ", fxv(b, ZFX_SPR_TRIMMABLE, 10u));
        if (tq) { FL(": ", (u32)(g_fxsum[b][ZFX_SPR_KEPT1000] / tq / 10u)); cat(out, " % of their quad can show"); }
        cat(out, g_sprtrim_on ? " (SPRTRIM=1: only that part is drawn)\n" : " (SPRTRIM=0: drawn whole)\n");
    }
#undef FL
#undef FL1
}
/* xacp_video.c prints the buckets one by one (b = 0 the run, 1 normal, 2 slow, 3 over 45 ms);
   returns 0 past the last */
int zz_rix_fx_report(int b, char *out, int cap)
{
    out[0] = 0;
    if (b < 0 || b >= (int)FXB_BENCH || cap < 4096) return 0;
    fx_format((u32)b, out);
    return 1;
}
/* the bench (xacp/src/xacp_bench.c): the frames between begin and end, with the world */
void zz_rix_bench_begin(void)
{
    memset(&g_bench, 0, sizeof g_bench);
    memset(g_fxsum[FXB_BENCH], 0, sizeof g_fxsum[FXB_BENCH]);
    g_fxframes[FXB_BENCH] = 0u;
    g_bench_max = 0u; g_bench_min = 0xFFFFFFFFu; g_bench_n25 = g_bench_n33 = g_bench_n45 = g_bench_noworld = 0u;
    g_bench_on = 1;
}
void zz_rix_bench_end(void) { g_bench_on = 0; }
unsigned zz_rix_bench_frames(void) { return g_bench.frames; }
/* average period in us and what the scene sent, for the caller's summary table */
void zz_rix_bench_numbers(unsigned v[8])
{
    u32 f = g_bench.frames ? g_bench.frames : 1u, o;
    unsigned long long po = 0ull, pb = 0ull, tr = 0ull, bi = 0ull;
    for (o = 0; o < (u32)ZORG_COUNT; o++) {
        po += g_fxsum[FXB_BENCH][ZFX_ORG(o, ZFXO_PX_OPAQUE)]; pb += g_fxsum[FXB_BENCH][ZFX_ORG(o, ZFXO_PX_BLEND)];
        tr += g_fxsum[FXB_BENCH][ZFX_ORG(o, ZFXO_TRIS)]; bi += g_fxsum[FXB_BENCH][ZFX_ORG(o, ZFXO_BINDS)];
    }
    v[0] = g_bench.frames; v[1] = g_bench.wall_us / f; v[2] = g_bench.frames ? g_bench_max : 0u; v[3] = g_bench_n45;
    v[4] = (u32)(tr / f); v[5] = (u32)(bi / f); v[6] = (u32)(po / 1000u / f); v[7] = (u32)(pb / 1000u / f);
}
void zz_rix_bench_report(const char *name, char *out, int cap)
{
    char n[16];
    u32 f = g_bench.frames;
    out[0] = 0;
    if (cap < 8192) return;
    cat(out, "BENCH "); cat(out, name); cat(out, ": frames "); u2s(n, f); cat(out, n);
    if (g_bench_noworld) { cat(out, " (and "); u2s(n, g_bench_noworld); cat(out, n); cat(out, " without the world, left out)"); }
    if (!f) { cat(out, " - NOTHING MEASURED\n"); return; }
    {
        u32 avg = g_bench.wall_us / f, fps10 = avg ? 10000000u / avg : 0u;
        cat(out, ", period "); u2s(n, avg); cat(out, n); cat(out, " us = "); u2s(n, fps10 / 10u); cat(out, n); cat(out, "."); u2s(n, fps10 % 10u); cat(out, n);
        cat(out, " img/s, shortest "); u2s(n, g_bench_min); cat(out, n); cat(out, ", longest "); u2s(n, g_bench_max); cat(out, n);
        cat(out, "; frames over 25 ms "); u2s(n, g_bench_n25); cat(out, n); cat(out, ", over 33 ms "); u2s(n, g_bench_n33); cat(out, n);
        cat(out, ", over 45 ms "); u2s(n, g_bench_n45); cat(out, n); cat(out, "\n");
    }
    period_line(out, "  bench         ", &g_bench);
    fx_format(FXB_BENCH, out);
}

/* ---- 0.8.3: start-up micro-benchmark --------------------------------------------------------------
   Run once after the texel self-test (GPU idle: that frame's fence was waited).  Per descriptor:
   rix_tri_desc on a typical textured triangle; the 40 word stores rix_dl_tri makes into the chunk
   ring (non-cacheable); the same stores into cacheable memory; and the 40 words copied into the ring
   by 8-register bursts (STM).  Writes go to the last ring slot, whose content no frame uses any
   more (chunk_open rebuilds a slot from its start). */
static u32 mb_cached[40u * 64u];
static void mb_burst40(volatile u32 *dst, const u32 *src)
{
#if defined(__arm__)
    __asm__ volatile(
        "ldmia %1!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "stmia %0!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "ldmia %1!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "stmia %0!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "ldmia %1!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "stmia %0!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "ldmia %1!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "stmia %0!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "ldmia %1!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        "stmia %0!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
        : "+r"(dst), "+r"(src)
        :
        : "r3", "r4", "r5", "r6", "r8", "r9", "r10", "r12", "memory");
#else
    u32 i;
    for (i = 0; i < 40u; i++) dst[i] = src[i];
#endif
}
void zz_rix_microbench(char *out, int cap)
{
    enum { N = 1000 };
    rix_vertex a, b, c;
    u32 d[40], i, k, t0, ns_desc, ns_nc, ns_cached, ns_burst, ok = 0u;
    volatile u32 *nc;
    char n[16];
    out[0] = 0;
    if (!g_open || cap < 512) return;
    nc = (volatile u32 *)rix_ptr(RIXQ2_RING_BASE + (RIXQ2_RING_SLOTS - 1u) * RIXQ2_CHUNK_BYTES);
    memset(&a, 0, sizeof a); memset(&b, 0, sizeof b); memset(&c, 0, sizeof c);
    a.sx = 100.25f; a.sy = 100.5f;  a.z = 0.50f; a.invw = 0.50f; a.u = 0.0f; a.v = 0.0f;
    b.sx = 160.75f; b.sy = 112.25f; b.z = 0.52f; b.invw = 0.48f; b.u = 1.0f; b.v = 0.0f;
    c.sx = 118.5f;  c.sy = 171.0f;  c.z = 0.55f; c.invw = 0.45f; c.u = 0.0f; c.v = 1.0f;
    a.r = b.r = c.r = 1.0f; a.g = b.g = c.g = 0.8f; a.b = b.b = c.b = 0.6f; a.a = b.a = c.a = 1.0f;
    t0 = rix_now();
    for (i = 0; i < (u32)N; i++) { a.sx += 0.001f; ok += (u32)rix_tri_desc(&a, &b, &c, &d[1]); }
    ns_desc = rix_ticks_to_us(rix_now() - t0);              /* us for N = ns per descriptor */
    d[0] = 0x12345678u;
    t0 = rix_now();
    for (i = 0; i < (u32)N; i++) { volatile u32 *p = nc + (i % 400u) * 40u; for (k = 0; k < 40u; k++) p[k] = d[k]; }
    dsb();
    ns_nc = rix_ticks_to_us(rix_now() - t0);
    t0 = rix_now();
    for (i = 0; i < (u32)N; i++) { volatile u32 *p = mb_cached + (i % 64u) * 40u; for (k = 0; k < 40u; k++) p[k] = d[k]; }
    dsb();
    ns_cached = rix_ticks_to_us(rix_now() - t0);
    t0 = rix_now();
    for (i = 0; i < (u32)N; i++) mb_burst40(nc + (i % 400u) * 40u, d);
    dsb();
    ns_burst = rix_ticks_to_us(rix_now() - t0);
    cat(out, "RIX micro-benchmark, ns per descriptor (1000 each):\n");
    cat(out, "  rix_tri_desc (60 px textured triangle)   "); u2s(n, ns_desc); cat(out, n); cat(out, ok == (u32)N ? "\n" : " (some refused)\n");
    cat(out, "  40 word stores to the ring (rix_dl_tri)  "); u2s(n, ns_nc); cat(out, n); cat(out, "\n");
    cat(out, "  40 word stores to cached memory          "); u2s(n, ns_cached); cat(out, n); cat(out, "\n");
    cat(out, "  40 words to the ring by 8-word bursts    "); u2s(n, ns_burst); cat(out, n); cat(out, "\n");
}

/* ---- texel self-test (0.6) ---------------------------------------------------------------------
   Draws, in 2D at 1:1 (the HUD's case), textures whose every texel encodes its own (u, v), reads
   the GPU's pixels back and counts, per case, the pixels that show the expected texel and the
   offsets of the others.  Answers what photos of the screen cannot: which texel the TMU really
   fetches for a given pixel (column order in the 32-bit words, half-texel convention, position
   dependence).  Runs once in GLimp_SetMode (before ref_gl uploads anything), in a frame that is
   never presented; the report goes to the console and to baseq2/rixtest.txt (zzq2rix_video.c).
   Encoding (RGB565, exact through the conversion): R5 = u & 31, B5 = v & 31,
   G6 = 0x20 | (v >> 5) << 2 | (u >> 5)  (0x20 = marker). */
#define TT_TEX_C  (ZZGL_MAX_TEXTURES - 3u)   /* 0.7: 32 x 32 RGBA5551, alpha 0 on a checkerboard */
#define TT_TEX_A  (ZZGL_MAX_TEXTURES - 2u)   /* 32 x 32 */
#define TT_TEX_B  (ZZGL_MAX_TEXTURES - 1u)   /* 128 x 128, the size of conchars */
static unsigned char tt_img[128u * 128u * 4u];
static unsigned char tt_rd[128u * 3u];

static void tt_make(u32 size)
{
    u32 u, v;
    for (v = 0; v < size; v++)
        for (u = 0; u < size; u++) {
            unsigned char *p = &tt_img[(v * size + u) * 4u];
            u32 g6 = 0x20u | ((v >> 5) << 2) | (u >> 5);
            p[0] = (unsigned char)((u & 31u) << 3); p[1] = (unsigned char)(g6 << 2);
            p[2] = (unsigned char)((v & 31u) << 3); p[3] = 255u;
        }
}

/* 0.7: RGBA5551 + alpha test (ref_gl's 2D: GL_GREATER 0.666): texel (u, v) opaque when (u ^ v) & 4 is 0,
   transparent (alpha 0, colour black) otherwise; R5 = u, B5 = v, G5 = 0x14 marker */
static void tt_make_alpha(void)
{
    u32 u, v;
    for (v = 0; v < 32u; v++)
        for (u = 0; u < 32u; u++) {
            unsigned char *p = &tt_img[(v * 32u + u) * 4u];
            int opaque = (((u ^ v) & 4u) == 0u);
            p[0] = opaque ? (unsigned char)(u << 3) : 0u; p[1] = opaque ? (unsigned char)(0x14u << 3) : 0u;
            p[2] = opaque ? (unsigned char)(v << 3) : 0u; p[3] = opaque ? 255u : 0u;
        }
}
#define TT_AX 440u
#define TT_AY 48u
static int tt_check_alpha(char *out)
{
    u32 i, j, ok_op = 0u, ok_tr = 0u, bad_op = 0u, bad_tr = 0u, n_op = 0u, n_tr = 0u;
    char l[160], t[16];
    for (j = 0; j < 32u; j++) {
        s32 gy = 479 - (s32)(TT_AY + j);
        zzglReadPixels((s32)TT_AX, gy, 32, 1, ZGL_RGB, ZGL_UNSIGNED_BYTE, tt_rd);
        for (i = 0; i < 32u; i++) {
            u32 r5 = tt_rd[i * 3u] >> 3, g6 = tt_rd[i * 3u + 1u] >> 2, b5 = tt_rd[i * 3u + 2u] >> 3;
            if (((i ^ j) & 4u) == 0u) { n_op++; if (r5 == i && b5 == j && (g6 >> 1) == 0x14u) ok_op++; else bad_op++; }
            else { n_tr++; if (r5 == 31u && g6 == 63u && b5 == 31u) ok_tr++; else bad_tr++; }
        }
    }
    l[0] = 0; cat(l, "t32 RGBA5551 alpha-test @440,48 opaque ok "); u2s(t, ok_op); cat(l, t); cat(l, "/"); u2s(t, n_op); cat(l, t);
    cat(l, ", transparent kept "); u2s(t, ok_tr); cat(l, t); cat(l, "/"); u2s(t, n_tr); cat(l, t);
    cat(out, l); cat(out, "\n");
    return (bad_op == 0u && bad_tr == 0u);
}
static int g_alpha_ok = -1;   /* 0.7: result of the RGBA5551 case (-1: not run) */
int zz_rix_alpha_ok(void) { return g_alpha_ok; }

/* ZZHalfLife 0.7.8: RGBA4444 + alpha blending (Half-Life's gradient decals).  32 x 32 at (520, 8) on
   the white background, blend SRC_ALPHA / ONE_MINUS_SRC_ALPHA, REPLACE:
     rows 0..15  : black texels, alpha level = column & 15 -> grey 1 - a/15 on screen;
     rows 16..31 : opaque texels, red level = row & 15, green = column & 15, blue 0.
   Checks the nibble order of the format (R G B A from the top) and that the TMU's alpha reaches
   the blender with 16 levels.  Tolerance 2 steps of the 5/6-bit screen channels. */
#define TT_TEX_D  (ZZGL_MAX_TEXTURES - 4u)
#define TT_DX 520u
#define TT_DY 8u
static int g_a4444_ok = -1;
int zz_rix_alpha4444_ok(void) { return g_a4444_ok; }
static void tt_make_4444(void)
{
    u32 u, v;
    for (v = 0; v < 32u; v++)
        for (u = 0; u < 32u; u++) {
            unsigned char *p = &tt_img[(v * 32u + u) * 4u];
            if (v < 16u) { p[0] = 0u; p[1] = 0u; p[2] = 0u; p[3] = (unsigned char)((u & 15u) * 17u); }
            else { p[0] = (unsigned char)((v & 15u) * 17u); p[1] = (unsigned char)((u & 15u) * 17u); p[2] = 0u; p[3] = 255u; }
        }
}
static int near_level(u32 got, u32 maxv, u32 level15)
{
    s32 want = (s32)((level15 * maxv + 7u) / 15u), d = (s32)got - want;
    return d >= -2 && d <= 2;
}
static int tt_check_4444(char *out)
{
    u32 i, j, ok_a = 0u, ok_c = 0u, n_a = 0u, n_c = 0u;
    s32 fi = -1, fj = -1; u32 fr = 0u, fg = 0u, fb = 0u;
    char l[180], t[16];
    for (j = 0; j < 32u; j++) {
        s32 gy = 479 - (s32)(TT_DY + j);
        zzglReadPixels((s32)TT_DX, gy, 32, 1, ZGL_RGB, ZGL_UNSIGNED_BYTE, tt_rd);
        for (i = 0; i < 32u; i++) {
            u32 r5 = tt_rd[i * 3u] >> 3, g6 = tt_rd[i * 3u + 1u] >> 2, b5 = tt_rd[i * 3u + 2u] >> 3;
            int good;
            if (j < 16u) { u32 keep = 15u - (i & 15u); n_a++; good = near_level(r5, 31u, keep) && near_level(g6, 63u, keep) && near_level(b5, 31u, keep); if (good) ok_a++; }
            else { n_c++; good = near_level(r5, 31u, j & 15u) && near_level(g6, 63u, i & 15u) && b5 <= 2u; if (good) ok_c++; }
            if (!good && fi < 0) { fi = (s32)i; fj = (s32)j; fr = r5; fg = g6; fb = b5; }
        }
    }
    l[0] = 0; cat(l, "t32 RGBA4444 blend @520,8 alpha levels ok "); u2s(t, ok_a); cat(l, t); cat(l, "/"); u2s(t, n_a); cat(l, t);
    cat(l, ", colour nibbles ok "); u2s(t, ok_c); cat(l, t); cat(l, "/"); u2s(t, n_c); cat(l, t);
    if (fi >= 0) { cat(l, " first@"); u2s(t, (u32)fi); cat(l, t); cat(l, ","); u2s(t, (u32)fj); cat(l, t); cat(l, "=r"); u2s(t, fr); cat(l, t); cat(l, " g"); u2s(t, fg); cat(l, t); cat(l, " b"); u2s(t, fb); cat(l, t); }
    cat(out, l); cat(out, "\n");
    /* a few misses at most (rounding of the blender at mid levels) */
    return ok_a + 8u >= n_a && ok_c + 8u >= n_c;
}

static void s2s(char *d, s32 v) { if (v < 0) { *d++ = '-'; v = -v; } else *d++ = '+'; u2s(d, (u32)v); }

typedef struct { const char *name; u32 tex, size, x, y, linear; float bias; } tt_case;

/* screen positions in Quake II's 2D coordinates (glOrtho 0..640, 480..0: y down) */
static const tt_case tt_cases[] = {
    { "t32 nearest      @8,8    ", TT_TEX_A,  32u,   8u,   8u, 0u, 0.0f  },
    { "t32 nearest      @300,8  ", TT_TEX_A,  32u, 300u,   8u, 0u, 0.0f  },
    { "t32 nearest+0.25 @8,48   ", TT_TEX_A,  32u,   8u,  48u, 0u, 0.25f },
    { "t32 nearest+0.25 @300,48 ", TT_TEX_A,  32u, 300u,  48u, 0u, 0.25f },
    { "t32 linear       @440,8  ", TT_TEX_A,  32u, 440u,   8u, 1u, 0.0f  },
    { "",                           TT_TEX_C,  32u, TT_AX, TT_AY, 0u, 0.0f },   /* 0.7: RGBA5551 alpha test, checked by tt_check_alpha */
    { "",                           TT_TEX_D,  32u, TT_DX, TT_DY, 0u, 0.0f },   /* 0.7.8: RGBA4444 blend, checked by tt_check_4444 */
    { "t128 nearest     @8,96   ", TT_TEX_B, 128u,   8u,  96u, 0u, 0.0f  },
    { "t128 nearest     @300,96 ", TT_TEX_B, 128u, 300u,  96u, 0u, 0.0f  },
    { "t128 nearest+0.25 @8,240 ", TT_TEX_B, 128u,   8u, 240u, 0u, 0.25f },
    { "t128 nearest+0.25 @300,240", TT_TEX_B, 128u, 300u, 240u, 0u, 0.25f },
};
#define TT_NCASES (sizeof(tt_cases) / sizeof(tt_cases[0]))

static void tt_draw(const tt_case *c)
{
    float x0 = (float)c->x, y0 = (float)c->y, x1 = x0 + (float)c->size, y1 = y0 + (float)c->size;
    if (c->tex == TT_TEX_C) { zzglEnable(ZGL_ALPHA_TEST); zzglAlphaFunc(ZGL_GREATER, 0.666f); }
    else zzglDisable(ZGL_ALPHA_TEST);
    if (c->tex == TT_TEX_D) { zzglEnable(ZGL_BLEND); zzglBlendFunc(ZGL_SRC_ALPHA, ZGL_ONE_MINUS_SRC_ALPHA); }
    else zzglDisable(ZGL_BLEND);
    zzglBindTexture(ZGL_TEXTURE_2D, c->tex);
    zzglTexParameterf(ZGL_TEXTURE_2D, ZGL_TEXTURE_MAG_FILTER, c->linear ? (float)ZGL_LINEAR : (float)ZGL_NEAREST);
    zzgl_set_texel_bias(c->bias);
    zzglBegin(ZGL_QUADS);                            /* as ref_gl's Draw_Pic */
    zzglTexCoord2f(0.0f, 0.0f); zzglVertex2f(x0, y0);
    zzglTexCoord2f(1.0f, 0.0f); zzglVertex2f(x1, y0);
    zzglTexCoord2f(1.0f, 1.0f); zzglVertex2f(x1, y1);
    zzglTexCoord2f(0.0f, 1.0f); zzglVertex2f(x0, y1);
    zzglEnd();
}

/* one case: ok count, the (du, dv) offsets in [-2, 2] and the rest; pairswap = pixels whose texel is
   the other one of its pair of columns (du = +1 on even columns, -1 on odd ones) */
static void tt_check(const tt_case *c, char *out, int cap, int *all_ok)
{
    u32 hist[5][5], ok = 0u, other = 0u, nomark = 0u, pairswap = 0u, n = c->size * c->size, i, j;
    s32 fdu = 0, fdv = 0; u32 fi = 0u, fj = 0u; int first = 1;
    char l[160], t[16];
    for (j = 0; j < 5u; j++) for (i = 0; i < 5u; i++) hist[j][i] = 0u;
    for (j = 0; j < c->size; j++) {
        s32 gy = 479 - (s32)(c->y + j);                   /* OpenGL window row of screen row y + j */
        zzglReadPixels((s32)c->x, gy, (s32)c->size, 1, ZGL_RGB, ZGL_UNSIGNED_BYTE, tt_rd);
        for (i = 0; i < c->size; i++) {
            u32 r5 = tt_rd[i * 3u] >> 3, g6 = tt_rd[i * 3u + 1u] >> 2, b5 = tt_rd[i * 3u + 2u] >> 3;
            s32 du, dv;
            if ((g6 & 0x30u) != 0x20u) { nomark++; if (first) { first = 0; fi = i; fj = j; fdu = 99; fdv = (s32)g6; } continue; }
            du = (s32)(r5 | ((g6 & 3u) << 5)) - (s32)i;
            dv = (s32)(b5 | (((g6 >> 2) & 3u) << 5)) - (s32)j;
            if (du == 0 && dv == 0) { ok++; continue; }
            if (first) { first = 0; fi = i; fj = j; fdu = du; fdv = dv; }
            if (dv == 0 && du == (((i & 1u) == 0u) ? 1 : -1)) pairswap++;
            if (du >= -2 && du <= 2 && dv >= -2 && dv <= 2) hist[dv + 2][du + 2]++; else other++;
        }
    }
    if (ok != n && !c->linear) *all_ok = 0;   /* linear: information only (the encoding wraps 31 -> 0 at column 0) */
    l[0] = 0; cat(l, c->name); cat(l, " ok "); u2s(t, ok); cat(l, t); cat(l, "/"); u2s(t, n); cat(l, t);
    if (ok != n) {
        u32 shown = 0u, k;
        for (k = 0; k < 25u && shown < 4u; k++) {
            u32 best = 0u, bj = 0u, bi = 0u;
            for (j = 0; j < 5u; j++) for (i = 0; i < 5u; i++) if (hist[j][i] > best) { best = hist[j][i]; bj = j; bi = i; }
            if (!best) break;
            cat(l, " d"); s2s(t, (s32)bi - 2); cat(l, t); cat(l, ","); s2s(t, (s32)bj - 2); cat(l, t); cat(l, ":"); u2s(t, best); cat(l, t);
            hist[bj][bi] = 0u; shown++;
        }
        if (other) { cat(l, " far:"); u2s(t, other); cat(l, t); }
        if (nomark) { cat(l, " nomark:"); u2s(t, nomark); cat(l, t); }
        if (pairswap) { cat(l, " pairswap:"); u2s(t, pairswap); cat(l, t); }
        cat(l, " first@"); u2s(t, fi); cat(l, t); cat(l, ","); u2s(t, fj); cat(l, t);
        cat(l, "="); if (fdu == 99) { cat(l, "g"); x2s(t, (u32)fdv, 2); cat(l, t); } else { s2s(t, fdu); cat(l, t); cat(l, ","); s2s(t, fdv); cat(l, t); }
    }
    l[sizeof(l) - 1] = 0;
    if ((int)(sizeof(l)) > cap) l[cap - 1] = 0;
    cat(out, l); cat(out, "\n");
}

/* returns 1 when every case shows the expected texel everywhere; report: lines of at most ~150 chars */
int zz_rix_textest(char *report, int cap)
{
    zzgl_target t;
    u32 k;
    int rc, all_ok = 1;
    report[0] = 0;
    if (!g_open || cap < 2048) return 0;
    g_frame_buf = g_color_bufs[g_cur];
    g_frame_fence = next_fence();
    t.color = g_frame_buf; t.fence = g_frame_fence;
    zzgl_set_target(&t);
    zclear_target(&g_zc, g_cur, 0);                /* a hidden frame never counts on a clean depth buffer */
    zzglViewport(0, 0, 640, 480);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, 640.0, 480.0, 0.0, -99999.0, 99999.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglDisable(ZGL_DEPTH_TEST); zzglDisable(ZGL_CULL_FACE); zzglDisable(ZGL_BLEND); zzglDisable(ZGL_ALPHA_TEST);
    zzglClearColor(1.0f, 1.0f, 1.0f, 1.0f); zzglClear(ZGL_COLOR_BUFFER_BIT);   /* white: the alpha case's background */
    zzglEnable(ZGL_TEXTURE_2D);
    zzglTexEnvf(ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, (float)ZGL_REPLACE);
    zzglColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    tt_make(32u);  zzglBindTexture(ZGL_TEXTURE_2D, TT_TEX_A); zzglTexImage2D(ZGL_TEXTURE_2D, 0, ZGL_RGBA, 32, 32, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, tt_img);
    tt_make(128u); zzglBindTexture(ZGL_TEXTURE_2D, TT_TEX_B); zzglTexImage2D(ZGL_TEXTURE_2D, 0, ZGL_RGBA, 128, 128, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, tt_img);
    tt_make_alpha(); zzgl_set_alpha_textures(1);
    zzglBindTexture(ZGL_TEXTURE_2D, TT_TEX_C); zzglTexImage2D(ZGL_TEXTURE_2D, 0, ZGL_RGBA, 32, 32, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, tt_img);
    zzgl_set_alpha_textures(0);                        /* the caller sets the run's choice afterwards */
    tt_make_4444(); zzgl_set_alpha4444(1);
    zzglBindTexture(ZGL_TEXTURE_2D, TT_TEX_D); zzglTexImage2D(ZGL_TEXTURE_2D, 0, ZGL_RGBA, 32, 32, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, tt_img);
    zzgl_set_alpha4444(0);                             /* idem */
    for (k = 0; k < TT_NCASES; k++) tt_draw(&tt_cases[k]);
    zzglDisable(ZGL_BLEND);
    zzgl_set_texel_bias(0.0f);
    rc = zzgl_swap();
    if (!rc) rc = rix_frame_wait(g_frame_buf, g_frame_fence, 2000000u, 0, 0);
    if (rc) {
        cat(report, "RIX texel test: frame E"); { char n[8]; x2s(n, (u32)rc & 0xFFFFu, 4); cat(report, n); } cat(report, "\n");
        all_ok = 0;
    } else {
        cat(report, "RIX texel test (2D 1:1, RGB565, REPLACE): case ok/pixels, then the commonest (du,dv):count\n");
        for (k = 0; k < TT_NCASES; k++) if (tt_cases[k].tex != TT_TEX_C && tt_cases[k].tex != TT_TEX_D) tt_check(&tt_cases[k], report, cap, &all_ok);
        g_alpha_ok = tt_check_alpha(report);
        g_a4444_ok = tt_check_4444(report);
        cat(report, all_ok ? "RIX texel test: ALL OK (nearest cases; the linear one is for information)\n" : "RIX texel test: MISMATCHES\n");
        cat(report, g_alpha_ok > 0 ? "RIX alpha test: RGBA5551 + alpha test OK\n" : "RIX alpha test: RGBA5551 FAILED (alpha-keyed textures stay RGB565)\n");
        cat(report, g_a4444_ok > 0 ? "RIX alpha test: RGBA4444 + blending OK\n" : "RIX alpha test: RGBA4444 FAILED (gradient alpha stays RGBA5551)\n");
    }
    {   u32 del[4]; del[0] = TT_TEX_A; del[1] = TT_TEX_B; del[2] = TT_TEX_C; del[3] = TT_TEX_D; zzglDeleteTextures(4, del); }
    zzglDisable(ZGL_ALPHA_TEST);
    zzglTexEnvf(ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, (float)ZGL_MODULATE);
    zzglDisable(ZGL_TEXTURE_2D);
    g_cur ^= 1u;                                       /* this buffer is never presented */
    return all_ok;
}

/* ---- the GPU's price list (GPUBENCH=1) ---------------------------------------------------
   What the logs never gave: what RasterIX charges for a pixel according to
   the mode it is drawn in, for a bind according to the texture's size, and for a triangle.  On
   15/11 a frame of 2 065 triangles and 59 binds kept Core1 waiting 107 ms and nothing could say
   whether that was fill.  Run once at start-up, after the texel self-test and before ref_gl
   uploads anything, each case in a frame of its own that is never shown (the texel test's way):
   the frame is drawn, closed, its fence waited, and the time from the first call to the fence is
   the case's cost.  A case is run twice and the shorter time kept.  The first case draws nothing
   but the clears; it is subtracted from the others.
   The 2D projection carries a depth (z = -1 far .. +1 near), so the depth cases are real ones;
   the rejected case reads one pixel back to prove the test rejected. */
#define GB_W ((float)ZZQ2_VID_W)
#define GB_H ((float)ZZQ2_VID_H)
static unsigned char gb_img[256u * 256u * 4u];
static const u32 gb_tex[4] = { TT_TEX_A, TT_TEX_B, TT_TEX_C, TT_TEX_D };   /* 8x8, 64x64 linear, 64x64 nearest, 256x256 */
static const u32 gb_size[4] = { 8u, 64u, 64u, 256u };
static const u32 gb_bind_size[4] = { 8u, 64u, 128u, 256u };                /* the pair of the bind cases, uploaded before each */
#define GB_PAIR0 (ZZGL_MAX_TEXTURES - 5u)
#define GB_PAIR1 (ZZGL_MAX_TEXTURES - 6u)
static void gb_quad(float z, float su, float sv)
{
    zzglBegin(ZGL_QUADS);
    zzglTexCoord2f(0.0f, 0.0f); zzglVertex3f(0.0f, 0.0f, z);
    zzglTexCoord2f(su, 0.0f);   zzglVertex3f(GB_W, 0.0f, z);
    zzglTexCoord2f(su, sv);     zzglVertex3f(GB_W, GB_H, z);
    zzglTexCoord2f(0.0f, sv);   zzglVertex3f(0.0f, GB_H, z);
    zzglEnd();
}
/* n triangles of `side` pixels (half a square each) on a grid, 20 to a Begin/End */
static void gb_tris(u32 n, u32 side, int rebind, u32 texa, u32 texb)
{
    u32 i, cols = (u32)ZZQ2_VID_W / (side + 2u), rows = (u32)ZZQ2_VID_H / (side + 2u), open = 0u;
    if (!cols) cols = 1u;
    if (!rows) rows = 1u;
    for (i = 0; i < n; i++) {
        float x = (float)((i % cols) * (side + 2u)), y = (float)(((i / cols) % rows) * (side + 2u)), s = (float)side;
        if (rebind) { zzglBindTexture(ZGL_TEXTURE_2D, (i & 1u) ? texb : texa); }
        if (rebind || !open) { zzglBegin(ZGL_TRIANGLES); open = 1u; }
        zzglTexCoord2f(0.0f, 0.0f); zzglVertex3f(x, y, 0.0f);
        zzglTexCoord2f(1.0f, 0.0f); zzglVertex3f(x + s, y, 0.0f);
        zzglTexCoord2f(0.0f, 1.0f); zzglVertex3f(x, y + s, 0.0f);
        if (rebind || (i % 20u) == 19u) { zzglEnd(); open = 0u; }
    }
    if (open) zzglEnd();
}
enum { GBC_CLEAR = 0, GBC_OPAQUE_Z, GBC_REJECT, GBC_OPAQUE_NOZ, GBC_NEAREST, GBC_FLAT, GBC_ALPHA, GBC_ADD, GBC_LIGHTMAP,
       GBC_T8, GBC_T256, GBC_T256MIN, GBC_TRI_ONE, GBC_BIND8, GBC_BIND64, GBC_BIND128, GBC_BIND256, GBC_SMALL, GBC_MEDIUM,
       /* build 86 */
       GBC_CLR_Z, GBC_CLR_C,
       GBC_SH_RIGHT, GBC_SH_RIGHT_M, GBC_SH_FLAT, GBC_SH_TALL, GBC_SH_DIAG, GBC_SH_DIAG_M, GBC_COUNT };
/* does the GPU's time follow a triangle's SURFACE or its BOUNDING BOX?  The price list of
   15/11 explains a scene of big polygons and falls 4 to 12 ms short on the real ones; every triangle it drew was a right-angled one, whose box is twice its surface.  Six shapes
   of the SAME surface (1024 px), 500 of each, same state as the two triangle cases above:
     right-angled 32 x 64, the right angle on the left of its lines, then on their right (does the
       GPU walk from the left edge of the box to the triangle?);
     256 x 8 lying flat (8 lines) and 8 x 256 standing (256 lines): the price of a line;
     a sliver along a diagonal, box 264 x 256 = 66 times its surface, leaning one way then the other.
   If the last two cost what the first costs, the GPU pays the surface and the box is no lever. */
#define GB_SH_N    500u
#define GB_SH_AREA 1024u
static const float gb_shape[6][6] = {
    {   0.0f, 0.0f,  32.0f, 0.0f,   0.0f,  64.0f },
    {   0.0f, 0.0f,  32.0f, 0.0f,  32.0f,  64.0f },
    {   0.0f, 0.0f, 256.0f, 0.0f,   0.0f,   8.0f },
    {   0.0f, 0.0f,   8.0f, 0.0f,   0.0f, 256.0f },
    {   0.0f, 0.0f,   8.0f, 0.0f, 264.0f, 256.0f },
    { 256.0f, 0.0f, 264.0f, 0.0f,   0.0f, 256.0f } };
static const u32 gb_shape_box[6][2] = { { 32u, 64u }, { 32u, 64u }, { 256u, 8u }, { 8u, 256u }, { 264u, 256u }, { 264u, 256u } };
static void gb_shapes(u32 s)
{
    const float *o = gb_shape[s];
    u32 i, bw = gb_shape_box[s][0] + 2u, bh = gb_shape_box[s][1] + 2u, cols = (u32)ZZQ2_VID_W / bw, rows = (u32)ZZQ2_VID_H / bh, open = 0u;
    if (!cols) cols = 1u;
    if (!rows) rows = 1u;
    for (i = 0; i < GB_SH_N; i++) {
        float x = (float)((i % cols) * bw), y = (float)(((i / cols) % rows) * bh);
        if (!open) { zzglBegin(ZGL_TRIANGLES); open = 1u; }
        zzglTexCoord2f(0.0f, 0.0f); zzglVertex3f(x + o[0], y + o[1], 0.0f);
        zzglTexCoord2f(1.0f, 0.0f); zzglVertex3f(x + o[2], y + o[3], 0.0f);
        zzglTexCoord2f(0.0f, 1.0f); zzglVertex3f(x + o[4], y + o[5], 0.0f);
        if ((i % 20u) == 19u) { zzglEnd(); open = 0u; }
    }
    if (open) zzglEnd();
}
static const char *const gb_name[GBC_COUNT] = {
    "clears only (colour + depth)              ",
    "opaque 64x64 texture, depth test and write",
    "opaque, REJECTED by the depth test        ",
    "opaque 64x64 texture, no depth (the 2D)   ",
    "same, nearest filter                      ",
    "no texture, flat colour, no depth         ",
    "alpha blend, depth test, no depth write   ",
    "additive (SRC_ALPHA, ONE), idem           ",
    "lightmap pass (ZERO, SRC_COLOR), EQUAL    ",
    "opaque no depth, 8x8 texture stretched    ",
    "opaque no depth, 256x256 at 1 texel/pixel ",
    "opaque no depth, 256x256 at 4 texels/pixel",
    "64 triangles of 8 px, a Begin/End each    ",
    "64 triangles, a bind each, 8x8            ",
    "64 triangles, a bind each, 64x64          ",
    "64 triangles, a bind each, 128x128        ",
    "64 triangles, a bind each, 256x256        ",
    "2000 triangles of 8 px a side (32 px)     ",
    "2000 triangles of 32 px a side (512 px)   ",
    "4 more depth clears                       ",
    "4 more colour clears                      ",
    "500 x 1024 px: right-angled 32x64, left   ",
    "500 x 1024 px: right-angled 32x64, right  ",
    "500 x 1024 px: flat 256x8 (8 lines)       ",
    "500 x 1024 px: standing 8x256 (256 lines) ",
    "500 x 1024 px: diagonal sliver, 264x256   ",
    "500 x 1024 px: the same, leaning back     " };
#define GB_LAYERS 4u
static u32 gb_pixel_ok;
/* draws one case; returns the pixels it asks for (0 when the cost is not a fill) */
static u32 gb_case(u32 c)
{
    u32 k, px = GB_LAYERS * (u32)ZZQ2_VID_W * (u32)ZZQ2_VID_H;
    float rep64x = GB_W / 64.0f, rep64y = GB_H / 64.0f;
    zzglDisable(ZGL_BLEND); zzglDisable(ZGL_ALPHA_TEST); zzglDisable(ZGL_DEPTH_TEST); zzglDepthMask(1u); zzglDepthFunc(ZGL_LEQUAL);
    zzglEnable(ZGL_TEXTURE_2D); zzglTexEnvf(ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, (float)ZGL_MODULATE);
    zzglColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    zzglBindTexture(ZGL_TEXTURE_2D, gb_tex[1]);
    switch (c) {
    case GBC_CLEAR: return 0u;
    case GBC_OPAQUE_Z:                                   /* each layer nearer than the one before: all pass, all write */
        zzglEnable(ZGL_DEPTH_TEST);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.1f + 0.1f * (float)k, rep64x, rep64y);
        return px;
    case GBC_REJECT:                                     /* one near layer, in red, then the layers behind it */
        zzglEnable(ZGL_DEPTH_TEST);
        zzglColor4f(1.0f, 0.0f, 0.0f, 1.0f); gb_quad(0.9f, rep64x, rep64y);
        zzglColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.1f, rep64x, rep64y);
        return px;                                       /* the near layer is taken off with GBC_OPAQUE_Z's price */
    case GBC_OPAQUE_NOZ:
        zzglDepthMask(0u);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.0f, rep64x, rep64y);
        return px;
    case GBC_NEAREST:
        zzglDepthMask(0u);
        zzglBindTexture(ZGL_TEXTURE_2D, gb_tex[2]);      /* the same 64x64, its filter set to nearest at the upload */
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.0f, rep64x, rep64y);
        return px;
    case GBC_FLAT:
        zzglDepthMask(0u); zzglDisable(ZGL_TEXTURE_2D); zzglColor4f(0.3f, 0.5f, 0.7f, 1.0f);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.0f, 1.0f, 1.0f);
        return px;
    case GBC_ALPHA: case GBC_ADD:
        zzglEnable(ZGL_DEPTH_TEST); zzglDepthMask(0u); zzglEnable(ZGL_BLEND);
        zzglBlendFunc(ZGL_SRC_ALPHA, c == GBC_ADD ? ZGL_ONE : ZGL_ONE_MINUS_SRC_ALPHA);
        zzglColor4f(1.0f, 1.0f, 1.0f, 0.25f);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.0f, rep64x, rep64y);
        return px;
    case GBC_LIGHTMAP:                                   /* a base that writes the depth, then the modulation on it */
        zzglEnable(ZGL_DEPTH_TEST);
        gb_quad(0.5f, rep64x, rep64y);
        zzglDepthMask(0u); zzglDepthFunc(ZGL_EQUAL); zzglEnable(ZGL_BLEND); zzglBlendFunc(ZGL_ZERO, ZGL_SRC_COLOR);
        zzglBindTexture(ZGL_TEXTURE_2D, gb_tex[3]);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.5f, GB_W / 256.0f / 16.0f, GB_H / 256.0f / 16.0f);   /* a lightmap is magnified about 16 times */
        return px;                                       /* the base is taken off with GBC_OPAQUE_Z's price */
    case GBC_T8:
        zzglDepthMask(0u); zzglBindTexture(ZGL_TEXTURE_2D, gb_tex[0]);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.0f, 1.0f, 1.0f);
        return px;
    case GBC_T256: case GBC_T256MIN:
        zzglDepthMask(0u); zzglBindTexture(ZGL_TEXTURE_2D, gb_tex[3]);
        for (k = 0; k < GB_LAYERS; k++) gb_quad(0.0f, (c == GBC_T256MIN ? 4.0f : 1.0f) * GB_W / 256.0f, (c == GBC_T256MIN ? 4.0f : 1.0f) * GB_H / 256.0f);
        return px;
    case GBC_TRI_ONE:                                    /* a Begin/End each, as the bind cases, but the texture never changes */
        zzglDepthMask(0u); gb_tris(64u, 4u, 1, gb_tex[1], gb_tex[1]);
        return 0u;
    case GBC_BIND8: case GBC_BIND64: case GBC_BIND128: case GBC_BIND256:
        zzglDepthMask(0u); gb_tris(64u, 4u, 1, GB_PAIR0, GB_PAIR1);   /* two textures of the size alternate (uploaded by the caller) */
        return 0u;
    case GBC_SMALL:
        zzglDepthMask(0u); gb_tris(2000u, 8u, 0, 0u, 0u);
        return 2000u * 32u;
    case GBC_MEDIUM:
        zzglDepthMask(0u); gb_tris(2000u, 32u, 0, 0u, 0u);
        return 2000u * 512u;
    case GBC_CLR_Z:                                      /* the frame's own clears came first; these are extra */
        for (k = 0; k < GB_LAYERS; k++) zzglClear(ZGL_DEPTH_BUFFER_BIT);
        return 0u;
    case GBC_CLR_C:
        for (k = 0; k < GB_LAYERS; k++) zzglClear(ZGL_COLOR_BUFFER_BIT);
        return 0u;
    default:                                             /* the six shapes */
        zzglDepthMask(0u); gb_shapes(c - GBC_SH_RIGHT);
        return GB_SH_N * GB_SH_AREA;
    }
}
static void gb_upload(u32 name, u32 size, int nearest)
{
    u32 i, n = size * size;
    for (i = 0; i < n; i++) {
        u32 x = i % size, y = i / size, v = ((x ^ y) & 8u) ? 200u : 120u;
        gb_img[i * 4u] = (unsigned char)(v + (x & 31u)); gb_img[i * 4u + 1u] = (unsigned char)v; gb_img[i * 4u + 2u] = (unsigned char)(v - (y & 31u)); gb_img[i * 4u + 3u] = 255u;
    }
    zzglBindTexture(ZGL_TEXTURE_2D, name);
    zzglTexImage2D(ZGL_TEXTURE_2D, 0, ZGL_RGBA, (s32)size, (s32)size, 0, ZGL_RGBA, ZGL_UNSIGNED_BYTE, gb_img);
    zzglTexParameterf(ZGL_TEXTURE_2D, ZGL_TEXTURE_MAG_FILTER, nearest ? (float)ZGL_NEAREST : (float)ZGL_LINEAR);
    zzglTexParameterf(ZGL_TEXTURE_2D, ZGL_TEXTURE_MIN_FILTER, nearest ? (float)ZGL_NEAREST : (float)ZGL_LINEAR);
}
/* the next hidden frame's target.  Set before any upload too: ref_gl never uploads without one
   (zz_rix_begin_frame follows every end of frame), and a target set twice with nothing drawn in
   between is what a frame that draws nothing already does. */
static void gb_target(void)
{
    zzgl_target t;
    g_frame_buf = g_color_bufs[g_cur];
    g_frame_fence = next_fence();
    t.color = g_frame_buf; t.fence = g_frame_fence;
    zzgl_set_target(&t);
    zclear_target(&g_zc, g_cur, 0);                /* idem */
}
/* one hidden frame; 0 when it closed.  us_total: first call to fence; us_wait: the fence wait alone */
static int gb_frame(u32 c, u32 *px, u32 *us_total, u32 *us_wait)
{
    u32 t0, t1, t2;
    int rc;
    gb_target();
    zzglViewport(0, 0, (s32)ZZQ2_VID_W, (s32)ZZQ2_VID_H);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, (double)ZZQ2_VID_W, (double)ZZQ2_VID_H, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglDisable(ZGL_CULL_FACE);
    zzglDepthMask(1u);
    t0 = rix_now();
    zzglClearColor(0.0f, 0.0f, 0.0f, 1.0f); zzglClearDepth(1.0); zzglClear(ZGL_COLOR_BUFFER_BIT | ZGL_DEPTH_BUFFER_BIT);
    *px = gb_case(c);
    t1 = rix_now();
    rc = zzgl_swap();
    if (!rc) rc = rix_frame_wait(g_frame_buf, g_frame_fence, 2000000u, 0, 0);
    t2 = rix_now();
    *us_total = rix_ticks_to_us((u32)(t2 - t0)); *us_wait = rix_ticks_to_us((u32)(t2 - t1));
    if (!rc && c == GBC_REJECT) {                        /* the centre pixel must still be the near layer's red */
        unsigned char p3[3];
        zzglReadPixels((s32)ZZQ2_VID_W / 2, (s32)ZZQ2_VID_H / 2, 1, 1, ZGL_RGB, ZGL_UNSIGNED_BYTE, p3);
        gb_pixel_ok = (p3[0] > 80u && p3[1] < 40u && p3[2] < 40u) ? 1u : 2u;
    }
    g_cur ^= 1u;                                         /* never presented */
    return rc;
}
void zz_rix_gpubench(char *out, int cap)
{
    u32 c, r, px, tot[GBC_COUNT], wt[GBC_COUNT], pxs[GBC_COUNT], base, layer_z = 0u;
    char n[16];
    int rc = 0;
    out[0] = 0;
    if (!g_open || cap < 6144) return;
    zzgl_set_origin_stats(0);
    gb_pixel_ok = 0u;
    gb_target();
    for (c = 0; c < 4u; c++) gb_upload(gb_tex[c], gb_size[c], c == 2u);
    gb_upload(GB_PAIR0, 8u, 0); gb_upload(GB_PAIR1, 8u, 0);
    for (c = 0; c < (u32)GBC_COUNT && !rc; c++) {
        tot[c] = 0xFFFFFFFFu; wt[c] = 0u; pxs[c] = 0u;
        if (c > GBC_BIND8 && c <= GBC_BIND256) { gb_target(); gb_upload(GB_PAIR0, gb_bind_size[c - GBC_BIND8], 0); gb_upload(GB_PAIR1, gb_bind_size[c - GBC_BIND8], 0); }
        for (r = 0; r < 2u && !rc; r++) {
            u32 ut, uw;
            rc = gb_frame(c, &px, &ut, &uw);
            if (!rc && ut < tot[c]) { tot[c] = ut; wt[c] = uw; pxs[c] = px; }
        }
    }
    cat(out, "RIX price list (GPUBENCH=1): us from the first call of a frame to its fence, the shorter of two runs;\n"
             "  'wait' = the part spent waiting for the fence once everything was submitted (0 = Core1 was the slower one)\n");
    if (rc) { cat(out, "RIX price list: frame E"); x2s(n, (u32)rc & 0xFFFFu, 4); cat(out, n); cat(out, " at case "); u2s(n, c ? c - 1u : 0u); cat(out, n); cat(out, ", stopped\n"); }
    else {
        base = tot[GBC_CLEAR];
        if (tot[GBC_OPAQUE_Z] > base) layer_z = (tot[GBC_OPAQUE_Z] - base) / GB_LAYERS;   /* one full-screen layer that passes and writes */
        for (c = 0; c < (u32)GBC_COUNT; c++) {
            u32 net = tot[c] > base ? tot[c] - base : 0u;
            char tag[4]; tag[0] = (char)(c < 26u ? 'a' + c : 'A' + (c - 26u)); tag[1] = ' '; tag[2] = 0;
            cat(out, "  "); cat(out, tag); cat(out, gb_name[c]); cat(out, " "); u2s(n, tot[c]); cat(out, n); cat(out, " us, wait "); u2s(n, wt[c]); cat(out, n);
            if (c == GBC_REJECT || c == GBC_LIGHTMAP) net = net > layer_z ? net - layer_z : 0u;   /* their one layer that is not the case */
            if (c == GBC_SMALL || c == GBC_MEDIUM) {
                cat(out, " | "); u2s(n, net * 1000u / 2000u); cat(out, n); cat(out, " ns a triangle all included ("); u2s(n, pxs[c] / 1000u); cat(out, n); cat(out, " kpx in all)");
            } else if (c == GBC_CLR_Z || c == GBC_CLR_C) {
                cat(out, " | "); u2s(n, net / GB_LAYERS); cat(out, n); cat(out, c == GBC_CLR_Z ? " us a depth clear" : " us a colour clear");
            } else if (c >= GBC_SH_RIGHT) {
                const u32 *bx = gb_shape_box[c - GBC_SH_RIGHT];
                cat(out, " | "); u2s(n, (u32)(((unsigned long long)net * 1000ull) / GB_SH_N)); cat(out, n); cat(out, " ns a triangle, box ");
                u2s(n, bx[0] * bx[1]); cat(out, n); cat(out, " px");
            } else if (c != GBC_CLEAR && pxs[c]) {
                /* ns per pixel, two decimals: net us * 1000 / px, in hundredths = net * 100000 / px */
                u32 h = (u32)(((unsigned long long)net * 100000ull) / pxs[c]);
                cat(out, " | "); u2s(n, pxs[c] / 1000u); cat(out, n); cat(out, " kpx, ");
                u2s(n, h / 100u); cat(out, n); cat(out, "."); u2s(n, (h / 10u) % 10u); cat(out, n); u2s(n, h % 10u); cat(out, n);
                cat(out, " ns/px = "); u2s(n, (u32)(((unsigned long long)net * (u32)ZZQ2_VID_W * (u32)ZZQ2_VID_H) / pxs[c])); cat(out, n); cat(out, " us a screen");
            }
            if (c == GBC_REJECT) cat(out, gb_pixel_ok == 1u ? " (read back: rejected)" : gb_pixel_ok == 2u ? " (*** READ BACK: NOT REJECTED, this line is not a rejection price)" : "");
            if (c >= GBC_BIND8 && c <= GBC_BIND256) {
                u32 one = tot[GBC_TRI_ONE], d = tot[c] > one ? tot[c] - one : 0u;
                cat(out, " | "); u2s(n, d / 64u); cat(out, n); cat(out, " us a bind (immediate mode: its wait for the GPU included)");
            }
            cat(out, "\n");
        }
        {   /* the two triangle cases have the same count and 16 times the pixels: time = a per triangle + b per pixel */
            u32 ts = tot[GBC_SMALL] > base ? tot[GBC_SMALL] - base : 0u, tm = tot[GBC_MEDIUM] > base ? tot[GBC_MEDIUM] - base : 0u;
            if (tm > ts) {
                u32 b100 = (u32)(((unsigned long long)(tm - ts) * 100000ull) / (pxs[GBC_MEDIUM] - pxs[GBC_SMALL]));          /* ns per pixel x 100 */
                unsigned long long fill = ((unsigned long long)(tm - ts) * pxs[GBC_SMALL]) / (pxs[GBC_MEDIUM] - pxs[GBC_SMALL]);   /* us of fill in the small case */
                u32 a = ts > (u32)fill ? (u32)(((unsigned long long)(ts - (u32)fill) * 1000ull) / 2000ull) : 0u;
                cat(out, "  = from the last two: about "); u2s(n, a); cat(out, n); cat(out, " ns a triangle + ");
                u2s(n, b100 / 100u); cat(out, n); cat(out, "."); u2s(n, (b100 / 10u) % 10u); cat(out, n); u2s(n, b100 % 10u); cat(out, n);
                cat(out, " ns a pixel (Core1's submission included: see their 'wait')\n");
            } else cat(out, "  = the two triangle cases cost the same: the triangles, not their pixels, set the time\n");
        }
        {   /* surface or box?  The diagonal slivers against the right-angled triangle of the same surface */
            u32 ref = tot[GBC_SH_RIGHT] > base ? tot[GBC_SH_RIGHT] - base : 0u, dg = tot[GBC_SH_DIAG] > base ? tot[GBC_SH_DIAG] - base : 0u;
            u32 dm = tot[GBC_SH_DIAG_M] > base ? tot[GBC_SH_DIAG_M] - base : 0u, worst = dg > dm ? dg : dm;
            if (ref) {
                u32 x10 = (u32)(((unsigned long long)worst * 10ull) / ref);
                cat(out, "  = same surface, box 33 times bigger: the diagonal sliver costs "); u2s(n, x10 / 10u); cat(out, n); cat(out, "."); u2s(n, x10 % 10u); cat(out, n);
                cat(out, x10 >= 15u ? " times the right-angled triangle: the GPU pays for the BOX\n" : " times the right-angled triangle: the GPU pays for the surface, not the box\n");
            }
        }
    }
    {   u32 del[6]; del[0] = TT_TEX_A; del[1] = TT_TEX_B; del[2] = TT_TEX_C; del[3] = TT_TEX_D; del[4] = GB_PAIR0; del[5] = GB_PAIR1; zzglDeleteTextures(6, del); }
    /* back to what the texel test leaves and to ZZGL's initial depth and blend state */
    zzglDisable(ZGL_BLEND); zzglDisable(ZGL_ALPHA_TEST); zzglDisable(ZGL_DEPTH_TEST);
    zzglDepthMask(1u); zzglDepthFunc(ZGL_LESS); zzglBlendFunc(ZGL_ONE, ZGL_ZERO);
    zzglTexEnvf(ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, (float)ZGL_MODULATE);
    zzglColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    zzglDisable(ZGL_TEXTURE_2D);
    zzgl_set_origin_stats(1);
    { zzgl_origin_stat os[ZORG_COUNT]; zzgl_origin_take(os, (u32)ZORG_COUNT); }   /* the bench's own batches are nobody's */
}

/* end of run: numbers for the "last printf" line of the glue */
void zz_rix_stats(u32 *frames, u32 *gpu_us_avg, u32 *gpu_us_max, u32 *present_us_avg, u32 *binds_last, u32 *pool_pages_free)
{
    u32 n = g_frames ? g_frames : 1u;
    const zzgl_stats *st = zzgl_get_stats();
    *frames = g_frames + g_stray_frames * 100000u;   /* stray frames (draws outside Begin/End) in the hundred-thousands */
    *gpu_us_avg = g_t_gpu_us / n;
    *gpu_us_max = g_t_gpu_max_us;
    *present_us_avg = g_t_present_us / n;
    *binds_last = st ? st->binds : 0u;
    *pool_pages_free = g_open ? rix_texpool_free_pages() : 0u;
}

/* zz_alpha (GLimp_SetMode): alpha-keyed textures as RGBA5551 from now on (vid_restart re-uploads) */
void zz_rix_set_alpha_textures(int on) { zzgl_set_alpha_textures(on); }
/* what the init ladder measured for a texture switch (rix_hwcaps) */
void zz_rix_bind_costs(u32 *us64, u32 *us256, u32 *fifo_words)
{
    rix_hwcaps c;
    rix_hw_caps(&c);
    *us64 = c.tex_switch_64_us; *us256 = c.tex_switch_256_us; *fifo_words = c.fifo_words;
}

/* the VDMA registers are mapped (Device) only between zzq2rix_mmu_setup and its
   restore; zzhl_present.c samples the scanout only then */
int zz_rix_is_open(void) { return g_open; }

/* end of run: the GPU idle, the attributes of the release back */
void zz_rix_close(void)
{
    if (!g_open) return;
    pend_wait();                                   /* 0.9.3 */
    rix_shutdown();
    (void)zzq2rix_mmu_restore();
    g_open = 0;
}

/* ---- ZCLEAR=1, the self-test that decides -------------------------------------------------
   The depth buffer may be cleared by the PL330 only if four things hold on THIS machine, and none
   of them can be read in the code: they are facts of the firmware's rasteriser.  Each is checked
   here, once, at start-up (GPU idle, nothing of the game uploaded), on the second depth buffer:
     1. what the GPU's own depth clear leaves in memory is the 16-bit word 0xFFFF in every pixel -
        else a copy of 0xFFFF words is not the same buffer;
     2. the PL330 copies the block of "far" over the whole buffer (read back by Core1);
     3. the GPU tests against the depth that is IN MEMORY when the frame starts: near written by
        Core1 rejects a quad, far written by the PL330 lets it through, and far written by the
        PL330 over a frame's depth lets through a quad that this depth would have rejected (the
        GPU keeps no depth of its own between frames) - with the control that the same quad IS
        rejected when the PL330 has not passed;
     4. at a frame's fence ALL the depth it wrote is in memory and no more arrives: no pixel of the
        picture still reads 0xFFFF, and a copy started at the fence leaves 0xFFFF everywhere, read
        back 5 ms later;
     5. the run's own pattern: a frame writes the second buffer, then the PL330 copies over it
        WHILE the GPU draws a frame on the first buffer; the second buffer must read 0xFFFF
        everywhere once that frame is fenced (nothing of the earlier frame is written late, as a
        cache emptied during the next frame would do), and a quad must then pass it.
   Hidden frames, as the price list's.  One failure and ZCLEAR stays off: the hook is removed and
   the GPU clears at every frame on the first depth buffer, exactly as build 85.
   out: one or two lines, each ended by a newline; also kept for the exit report. */
static void zt_fill(u32 addr, u32 v16)
{
    volatile u32 *p = (volatile u32 *)rix_ptr(addr);
    u32 i, n = RIXQ2_Z_BYTES / 4u, w = (v16 & 0xFFFFu) | ((v16 & 0xFFFFu) << 16);
    for (i = 0; i < n; i++) p[i] = w;
    dsb();
}
/* 16-bit words of the buffer that are not v16; *first: the first one's index */
static u32 zt_count_not(u32 addr, u32 v16, u32 *first)
{
    const volatile u16 *p = (const volatile u16 *)rix_ptr(addr);
    u32 i, n = RIXQ2_Z_BYTES / 2u, bad = 0u;
    dmb();
    for (i = 0; i < n; i++) if (p[i] != (u16)v16) { if (!bad) *first = i; bad++; }
    return bad;
}
/* pixels of the picture, its two border lines and columns left out (the screen clip may leave
   them undrawn), whose depth still reads 0xFFFF */
static u32 zt_count_far_inside(u32 addr)
{
    const volatile u16 *p = (const volatile u16 *)rix_ptr(addr);
    u32 x, y, n = 0u;
    dmb();
    for (y = 2u; y + 2u < RIXQ2_GEO_H; y++) for (x = 2u; x + 2u < RIXQ2_GEO_W; x++) if (p[y * RIXQ2_GEO_W + x] == 0xFFFFu) n++;
    return n;
}
/* one hidden frame on depth buffer zb: the colour cleared to blue, the depth cleared by the GPU when
   asked, then (draw) `layers` flat full-screen quads, the first at depth z (bigger = nearer) and each
   one nearer than the one before, under GL_LESS, depth written, red or green.  copy_rc not NULL: the
   PL330 copies the block of far over the SECOND depth buffer between the frame's submission and its
   fence, i.e. while the GPU draws (*copy_rc = dcopy_run's result).  *shown: 1 the quad shows at the
   five sample points, 0 the blue is left at the five, 2 anything else (zt_rgb then holds the centre
   pixel, for the report). */
static unsigned char zt_rgb[3];
static int zt_frame_ex(u32 zb, int gpu_clear, int draw, float z, int green, u32 layers, int *copy_rc, u32 *shown);
static int zt_frame(u32 zb, int gpu_clear, int draw, float z, int green, u32 *shown) { return zt_frame_ex(zb, gpu_clear, draw, z, green, 1u, 0, shown); }
static int zt_frame_ex(u32 zb, int gpu_clear, int draw, float z, int green, u32 layers, int *copy_rc, u32 *shown)
{
    static const s32 qx[5] = { 2, 1, 3, 1, 3 }, qy[5] = { 2, 1, 1, 3, 3 };   /* in quarters of the screen */
    u32 k, hit = 0u, blue = 0u;
    int rc;
    g_zc_force = zb;
    gb_target();
    zzglViewport(0, 0, (s32)ZZQ2_VID_W, (s32)ZZQ2_VID_H);
    zzglMatrixMode(ZGL_PROJECTION); zzglLoadIdentity(); zzglOrtho(0.0, (double)ZZQ2_VID_W, (double)ZZQ2_VID_H, 0.0, -1.0, 1.0);
    zzglMatrixMode(ZGL_MODELVIEW); zzglLoadIdentity();
    zzglDisable(ZGL_CULL_FACE); zzglDisable(ZGL_BLEND); zzglDisable(ZGL_ALPHA_TEST); zzglDisable(ZGL_TEXTURE_2D); zzglDisable(ZGL_DEPTH_TEST);
    zzglDepthMask(1u);
    zzglClearColor(0.0f, 0.0f, 1.0f, 1.0f); zzglClearDepth(1.0);
    zzglClear(gpu_clear ? (ZGL_COLOR_BUFFER_BIT | ZGL_DEPTH_BUFFER_BIT) : ZGL_COLOR_BUFFER_BIT);
    if (draw) {
        zzglEnable(ZGL_DEPTH_TEST); zzglDepthFunc(ZGL_LESS);
        zzglColor4f(green ? 0.0f : 1.0f, green ? 1.0f : 0.0f, 0.0f, 1.0f);
        for (k = 0; k < layers; k++) gb_quad(z + 0.1f * (float)k, 1.0f, 1.0f);
    }
    rc = zzgl_swap();
    if (!rc && copy_rc) { u32 us; *copy_rc = dcopy_run(RIXQ2_ZFAR, RIXQ2_ZBUF2, RIXQ2_Z_BYTES, &us); }
    if (!rc) rc = rix_frame_wait(g_frame_buf, g_frame_fence, 2000000u, 0, 0);
    if (!rc) for (k = 0; k < 5u; k++) {
        unsigned char p3[3];
        zzglReadPixels(qx[k] * (s32)ZZQ2_VID_W / 4, qy[k] * (s32)ZZQ2_VID_H / 4, 1, 1, ZGL_RGB, ZGL_UNSIGNED_BYTE, p3);
        if (k == 0u) { zt_rgb[0] = p3[0]; zt_rgb[1] = p3[1]; zt_rgb[2] = p3[2]; }
        if (p3[2] > 150u && p3[0] < 80u && p3[1] < 80u) blue++;
        else if (p3[green ? 1 : 0] > 150u && p3[green ? 0 : 1] < 80u && p3[2] < 80u) hit++;
    }
    *shown = hit == 5u ? 1u : blue == 5u ? 0u : 2u;
    zzglDisable(ZGL_DEPTH_TEST);
    g_cur ^= 1u;                                         /* never presented */
    g_zc_force = 0u;
    return rc;
}
int zz_rix_zclear_test(int want, char *out, int cap)
{
    char n[16], why[240];
    u32 us = 0u, us_best = 0xFFFFFFFFu, bad, first = 0u, shown = 0u, step = 0u, last_line = 0u;
    int rc = 0, ok = 0;
    out[0] = 0; why[0] = 0; g_zc_line[0] = 0;
    if (!g_open || cap < 720) return 0;
    if (!want) { cat(out, "RIX: ZCLEAR=0, the GPU clears the depth at every frame (as build 85)\n"); return 0; }
#define ZT_FAIL(text) do { cat(why, text); goto done; } while (0)
/* a picture that is neither the quad everywhere nor the background everywhere proves nothing either way */
#define ZT_ODD() do { if (shown == 2u) { cat(why, "the picture read back is neither the quad nor the background, centre pixel RGB "); u2s(n, zt_rgb[0]); cat(why, n); cat(why, " "); \
                                           u2s(n, zt_rgb[1]); cat(why, n); cat(why, " "); u2s(n, zt_rgb[2]); cat(why, n); goto done; } } while (0)
    if ((RIXQ2_Z_BYTES & 63u) || RIXQ2_Z_BYTES > RIXQ2_ZBUF_BYTES || RIXQ2_BIND_BASE + 1024u > RIXQ2_ZBUF2
        || RIXQ2_ZBUF2 + RIXQ2_Z_BYTES > RIXQ2_ZFAR
#ifndef ZZQ2RIX_HOST
        || RIXQ2_ZFAR + RIXQ2_Z_BYTES > RIXQ2_RESERVE_HI
#endif
        ) ZT_FAIL("the two blocks do not fit this build's buffers");
    if (!rix_dmacopy_available()) ZT_FAIL("no PL330 (see the presentation copy's line)");
    zzgl_set_zbuf_hook(zc_frame_opens);
    /* 1. what the GPU's depth clear leaves in memory */
    step = 1u;
    zt_fill(RIXQ2_ZBUF2, 0x5A5Au);
    rc = zt_frame(RIXQ2_ZBUF2, 1, 0, 0.0f, 0, &shown);
    if (rc) goto done;
    bad = zt_count_not(RIXQ2_ZBUF2, 0xFFFFu, &first);
    if (bad && first >= RIXQ2_GEO_W * RIXQ2_GEO_H) { last_line = bad; bad = 0u; }   /* the 481st line only: no pixel is ever drawn there */
    if (bad) { cat(why, "the GPU's depth clear does not leave 0xFFFF words: "); u2s(n, bad); cat(why, n); cat(why, " differ, the first at word "); u2s(n, first); cat(why, n);
               cat(why, " = "); x2s(n, ((const volatile u16 *)rix_ptr(RIXQ2_ZBUF2))[first], 4); cat(why, n); goto done; }
    /* 2. the block of far, and the PL330 over the whole buffer */
    step = 2u;
    zt_fill(RIXQ2_ZFAR, 0xFFFFu);
    if (zt_count_not(RIXQ2_ZFAR, 0xFFFFu, &first)) ZT_FAIL("the block of far does not hold what Core1 wrote");
    {
        u32 r;
        for (r = 0; r < 2u; r++) {
            zt_fill(RIXQ2_ZBUF2, 0x0000u);
            rc = dcopy_run(RIXQ2_ZFAR, RIXQ2_ZBUF2, RIXQ2_Z_BYTES, &us);
            if (rc) { cat(why, "PL330 copy, step "); u2s(n, (u32)rc); cat(why, n); cat(why, ", FTR "); x2s(n, rix_dmacopy_fault_info(), 8); cat(why, n); rc = 0; goto done; }
            if (us < us_best) us_best = us;
            bad = zt_count_not(RIXQ2_ZBUF2, 0xFFFFu, &first);
            if (bad) { cat(why, "the PL330's copy left "); u2s(n, bad); cat(why, n); cat(why, " words that are not 0xFFFF, the first at "); u2s(n, first); cat(why, n); goto done; }
        }
    }
    /* 3. the GPU tests against the depth in memory */
    step = 3u;
    zt_fill(RIXQ2_ZBUF2, 0x0000u);                                         /* near everywhere, written by Core1 */
    rc = zt_frame(RIXQ2_ZBUF2, 0, 1, 0.5f, 0, &shown);
    if (rc) goto done;
    ZT_ODD();
    if (shown != 0u) ZT_FAIL("a quad passed a depth buffer Core1 had filled with NEAR: the GPU does not test against the memory");
    step = 4u;
    rc = dcopy_run(RIXQ2_ZFAR, RIXQ2_ZBUF2, RIXQ2_Z_BYTES, &us);
    if (rc) { cat(why, "PL330 copy at step 4"); rc = 0; goto done; }
    rc = zt_frame(RIXQ2_ZBUF2, 0, 1, 0.5f, 0, &shown);
    if (rc) goto done;
    ZT_ODD();
    if (shown != 1u) ZT_FAIL("a quad did not pass a depth buffer the PL330 had filled with FAR: the GPU does not see the copy");
    step = 5u;                                                              /* the control: no copy, a quad BEHIND the one just drawn */
    rc = zt_frame(RIXQ2_ZBUF2, 0, 1, 0.2f, 1, &shown);
    if (rc) goto done;
    ZT_ODD();
    if (shown != 0u) ZT_FAIL("control: a quad behind the previous frame's passed without any clear, the depth test rejects nothing here");
    step = 6u;                                                              /* the same quad after the PL330: it must pass */
    rc = dcopy_run(RIXQ2_ZFAR, RIXQ2_ZBUF2, RIXQ2_Z_BYTES, &us);
    if (rc) { cat(why, "PL330 copy at step 6"); rc = 0; goto done; }
    rc = zt_frame(RIXQ2_ZBUF2, 0, 1, 0.2f, 1, &shown);
    if (rc) goto done;
    ZT_ODD();
    if (shown != 1u) ZT_FAIL("a quad was rejected by the depth of the frame BEFORE the PL330's copy: the GPU keeps depth of its own");
    /* 4. at the fence all the frame's depth is in memory, and none arrives later */
    step = 7u;
    bad = zt_count_far_inside(RIXQ2_ZBUF2);
    if (bad) { cat(why, "at its fence the frame's depth is not all in memory: "); u2s(n, bad); cat(why, n); cat(why, " pixels of the picture still read 0xFFFF"); goto done; }
    rc = dcopy_run(RIXQ2_ZFAR, RIXQ2_ZBUF2, RIXQ2_Z_BYTES, &us);
    if (rc) { cat(why, "PL330 copy at step 7"); rc = 0; goto done; }
    { u32 t0 = rix_now(); while (rix_ticks_to_us((u32)(rix_now() - t0)) < 5000u) { } }
    bad = zt_count_not(RIXQ2_ZBUF2, 0xFFFFu, &first);
    if (bad) { cat(why, "depth written by the GPU arrived AFTER its frame's fence: "); u2s(n, bad); cat(why, n); cat(why, " words changed under the PL330's copy"); goto done; }
    /* 5. as the run does it: a frame on the second buffer, then the copy over it while the GPU draws on the first */
    step = 8u;
    rc = zt_frame(RIXQ2_ZBUF2, 0, 1, 0.5f, 0, &shown);                     /* writes the whole second buffer */
    if (rc) goto done;
    ZT_ODD();
    if (shown != 1u) ZT_FAIL("a quad did not pass the buffer the PL330 had just filled with FAR");
    {
        int crc = 0;
        rc = zt_frame_ex(RIXQ2_ZBUF, 1, 1, 0.1f, 0, 4u, &crc, &shown);     /* four layers on the first buffer: the GPU is busy while the PL330 copies */
        if (rc) goto done;
        if (crc) { cat(why, "PL330 copy while the GPU drew, step "); u2s(n, (u32)crc); cat(why, n); goto done; }
        ZT_ODD();
        if (shown != 1u) ZT_FAIL("the frame drawn on the first buffer while the PL330 copied did not come out");
    }
    bad = zt_count_not(RIXQ2_ZBUF2, 0xFFFFu, &first);
    if (bad) { cat(why, "the second depth buffer changed while the GPU drew on the first: "); u2s(n, bad); cat(why, n); cat(why, " words are not 0xFFFF after the PL330's copy"); goto done; }
    step = 9u;
    rc = zt_frame(RIXQ2_ZBUF2, 0, 1, 0.2f, 1, &shown);
    if (rc) goto done;
    ZT_ODD();
    if (shown != 1u) ZT_FAIL("a quad was rejected on the second buffer after a frame on the first and the PL330's copy");
    ok = 1;
done:
#undef ZT_FAIL
#undef ZT_ODD
    if (ok) {
        zclear_enable(&g_zc, 0);                         /* step 9 drew on the second buffer, step 8 on the first */
        g_zc_hooked = 1;
        zzhl_dma_guard = zc_guard;
        cat(out, "RIX: ZCLEAR=1 ON: depth cleared by the PL330 on two buffers (self-test ok: GPU clear = 0xFFFF words");
        if (last_line) cat(out, " but line 481");
        cat(out, ", PL330 "); u2s(n, RIXQ2_Z_BYTES); cat(out, n); cat(out, " bytes in "); u2s(n, us_best); cat(out, n);
        cat(out, " us, GPU tests against memory and keeps no depth, nothing after the fence)\n");
    } else {
        zzgl_set_zbuf_hook(0);
        zclear_init(&g_zc);
        g_zc_hooked = 0; g_zc_force = 0u;
        cat(out, "RIX: ZCLEAR=1 REFUSED, the GPU clears the depth as build 85. Step "); u2s(n, step); cat(out, n); cat(out, ": ");
        if (rc) { cat(out, "frame E"); x2s(n, (u32)rc & 0xFFFFu, 4); cat(out, n); } else cat(out, why);
        cat(out, "\n");
    }
    {   u32 i; for (i = 0; out[i] && i + 1u < sizeof g_zc_line; i++) g_zc_line[i] = out[i]; g_zc_line[i] = 0; }
    /* back to what the texel test leaves */
    zzglDisable(ZGL_BLEND); zzglDisable(ZGL_ALPHA_TEST); zzglDisable(ZGL_DEPTH_TEST);
    zzglDepthMask(1u); zzglDepthFunc(ZGL_LESS); zzglColor4f(1.0f, 1.0f, 1.0f, 1.0f); zzglDisable(ZGL_TEXTURE_2D);
    { zzgl_origin_stat os[ZORG_COUNT]; zzgl_origin_take(os, (u32)ZORG_COUNT); }
    return ok;
}
int zz_rix_zclear_on(void) { return g_zc_hooked && g_zc.on; }
