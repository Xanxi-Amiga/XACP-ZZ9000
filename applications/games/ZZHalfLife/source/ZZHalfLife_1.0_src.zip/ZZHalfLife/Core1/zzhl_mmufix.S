/* Core1 startup MMU wrapper.
 * Preserves the caller's return state across cache invalidation to allow
 * successive launches without a power cycle.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
	.syntax unified
	.arm
	.text
	.global	__wrap_mmu_init_zzquake
	.type	__wrap_mmu_init_zzquake, %function
	.extern	__real_mmu_init_zzquake
__wrap_mmu_init_zzquake:
	str	r4, [sp, #-8]
	str	lr, [sp, #-4]
	dsb	sy
	sub	r2, sp, #8
	bic	r2, r2, #31
	mcr	p15, 0, r2, c7, c10, 1		@ DCCMVAC: that line to the point of coherency
	dsb	sy
	isb	sy
	b	__real_mmu_init_zzquake
	.size	__wrap_mmu_init_zzquake, . - __wrap_mmu_init_zzquake
