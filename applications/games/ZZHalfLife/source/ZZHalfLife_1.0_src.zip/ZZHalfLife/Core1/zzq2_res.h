/* SPDX-License-Identifier: GPL-2.0-or-later */
/* zzq2_res.h - ZZHalfLife: size of the frame, with the macro names of ZZQuake2RIX so that
 * Core1/zzhl_gpu.c (a copy of ZZQuake2's zzq2rix_gpu.c) compiles unchanged.
 *   default         640 x 480   zzhl.bin
 *   ZZHL_RES=320    320 x 240   zzhl_320.bin  (build_arm.sh passes ZZQ2_VID_W/H)
 * ASCII only. */
#ifndef ZZQ2_RES_H
#define ZZQ2_RES_H
#ifndef ZZQ2_VID_W
#define ZZQ2_VID_W      640
#define ZZQ2_VID_H      480
#endif
#define ZZHL_VID_W      ZZQ2_VID_W
#define ZZHL_VID_H      ZZQ2_VID_H
#endif
