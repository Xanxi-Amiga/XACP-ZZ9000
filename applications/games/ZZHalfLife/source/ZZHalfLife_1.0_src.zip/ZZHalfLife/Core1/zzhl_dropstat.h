/* SPDX-License-Identifier: GPL-3.0-or-later */
/* zzhl_dropstat.h - the frames the presentation drops, by the engine's pace.
 *
 * zzq2_present_rgb565 (Core1/zzhl_present.c) drops the frame that finds no display buffer free.
 * A4000, 16/11: 6 108 frames rendered and never shown in 34 minutes, 7 % of them, the same share
 * the day before.  A frame dropped while the engine runs faster than the screen costs nothing:
 * the screen could not have shown it.  A frame dropped while the engine runs SLOWER than the
 * screen (two presentations inside one refresh, then none for two) is a frame the screen had
 * room for.  The launcher's one sample a second cannot tell the two apart:
 * this counts them.
 *
 * The pace is the mean of the last 8 intervals between two calls of the presentation, one call
 * per frame of the engine.  An interval of a second or more (a load, a pause) empties the mean.
 * Pure C, no dependency: tested on the PC (tests/test_dropstat.c). */
#ifndef ZZHL_DROPSTAT_H
#define ZZHL_DROPSTAT_H

#define ZZHL_DROP_SCREEN_US 16667u   /* one refresh of the screen at 60 Hz */
#define ZZHL_DROP_CLASSES   5        /* faster than the screen, 50-60 a second, 40-50, slower, pace not known */

typedef struct
{
	unsigned last_us, have_last;
	unsigned ring[8], n, pos, sum;
	unsigned calls, dropped;
	unsigned by[ZZHL_DROP_CLASSES];
} zzhl_dropstat_t;

/* one call of the presentation at now_us; returns the mean interval (us), 0 when there is none yet */
static inline unsigned zzhl_dropstat_call( zzhl_dropstat_t *d, unsigned now_us )
{
	d->calls++;
	if( d->have_last )
	{
		unsigned iv = now_us - d->last_us;
		if( iv >= 1000000u ) { d->n = 0u; d->pos = 0u; d->sum = 0u; }
		else
		{
			if( d->n == 8u ) d->sum -= d->ring[d->pos]; else d->n++;
			d->ring[d->pos] = iv; d->sum += iv; d->pos = ( d->pos + 1u ) & 7u;
		}
	}
	d->last_us = now_us; d->have_last = 1u;
	return d->n ? d->sum / d->n : 0u;
}
static inline unsigned zzhl_dropstat_class( unsigned mean_us )
{
	return mean_us == 0u ? 4u : mean_us < ZZHL_DROP_SCREEN_US ? 0u : mean_us < 20000u ? 1u : mean_us < 25000u ? 2u : 3u;
}
/* the frame of that call was dropped */
static inline void zzhl_dropstat_drop( zzhl_dropstat_t *d, unsigned mean_us )
{
	d->dropped++;
	d->by[zzhl_dropstat_class( mean_us )]++;
}
#endif
