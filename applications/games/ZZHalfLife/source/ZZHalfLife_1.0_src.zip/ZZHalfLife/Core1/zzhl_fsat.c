/* SPDX-License-Identifier: GPL-3.0-only */
/* ZZ9000 / XACP port contributions: Copyright (C) 2026 Xanxi. */
/* zzhl_fsat.c - ZZHalfLife stage 1: reading a part of a big file of PROGDIR:data/ through the
 * launcher's FS_CMD_READAT (4), the synchronous ol_fs_read_at of ZZOpenLara A2.19 (Core1/ol_fsat.c)
 * copied; the request block, the sequence / acknowledge rule and the 20 s timeout are the
 * release file service's. The launcher keeps the DOS file open between requests and seeks
 * only when the offset changes (ZZQuake2_A0.c, fs_do_read_at). The heartbeat is kept during
 * the wait (SH_HB), so the launcher's watchdog never fires on a long read.
 * ASCII only. */
#include "zzquake_config.h"

typedef unsigned int u32;
typedef unsigned char u8;

extern volatile u32 *shared;
extern u32 zzq_us_now(void);

#define OL_FS_CMD_READAT  4u

static u32 g_req, g_fail, g_us, g_bytes;

/* the request block (0x04B, Normal non-cacheable) is written through the L2
 * controller (PL310), whose store buffer may keep non-cacheable writes after Core1's DSB has
 * completed: a DSB does not make them visible in DDR, only a PL310 Cache Sync does.  The 68k
 * could then find the new SEQ with the previous request's NAME, OFFSET or CHUNK still in DDR and
 * serve the old file or the old offset - wrong bytes without any error.  Seen on the A4000 (build
 * 37, 09/11): the size answered for pak1.pak was pak0.pak's (407817328 bytes), i.e. the launcher
 * kept its open pak0.pak handle (fs_do_read_at reopens only when the name differs).  Same family:
 * the maps of builds 8, 10, 33b and the model of build 35 read with wrong bytes, the launcher's
 * "nom perime" lines.  Here: a Cache Sync once the request is written, before SEQ, and once SEQ
 * is written (Zynq PL310 at 0xF8F02000, register 0x730; section 0xF8F is Device in the release
 * table, the Global Timer of the same section is read all the time). */
#define ZZHL_PL310_SYNC (*(volatile u32 *)0xF8F02730u)
static u32 g_syncs;
static void l2_sync(void)
{
    u32 n;
    __asm__ volatile("dsb sy" ::: "memory");
    ZZHL_PL310_SYNC = 0u;
    for (n = 0; n < 100000u && (ZZHL_PL310_SYNC & 1u); n++) { }
    __asm__ volatile("dsb sy" ::: "memory");
    g_syncs++;
}
u32 zzhl_read_at_syncs(void) { return g_syncs; }

static void publish_name(const char *name)
{
    u8 buf[ZZQ_FNAME_MAX];
    u32 i, k;
    for (i = 0; i < ZZQ_FNAME_MAX; i++) buf[i] = 0;
    for (i = 0; i < ZZQ_FNAME_MAX - 1 && name[i]; i++) buf[i] = (u8)name[i];
    for (i = 0; i < ZZQ_FNAME_MAX / 4; i++) {
        u32 w = 0;
        for (k = 0; k < 4; k++) w |= (u32)buf[i * 4 + k] << (k * 8);
        shared[SH_FS_NAME + i] = w;
    }
}

static int free_slot(void)
{
    u32 m = shared[SH_FS_SLOTMASK];
    int s;
    for (s = ZZQ_FILEBUF_SLOTS - 1; s >= 0; s--)
        if (!(m & (1u << s))) return s;
    return -1;
}

/* Reads len bytes at off of PROGDIR:data/<name> into dst. Returns the number of bytes read (less than
   len at the end of the file), -1 on error. *total (may be 0) = size of the file. */
int zzhl_read_at(const char *name, unsigned off, void *dst, unsigned len, unsigned *total)
{
    u8 *out = (u8 *)dst;
    unsigned done = 0;
    int slot;
    u32 t0;
    slot = free_slot();
    t0 = zzq_us_now();
    if (slot < 0) { g_fail++; return -1; }
    while (done < len) {
        u32 want = len - done, seq, start, got, i;
        const volatile u8 *src;
        if (want > ZZQ_FILEBUF_SIZE) want = ZZQ_FILEBUF_SIZE;
        publish_name(name);
        shared[SH_FS_SIZE]   = 0;
        shared[SH_FS_OFFSET] = off + done;
        shared[SH_FS_CHUNK]  = want;
        shared[SH_FS_ERR]    = 0;
        shared[SH_FS_EXISTS] = 0;
        shared[SH_FS_SLOT]   = (u32)slot;
        shared[SH_FS_CMD]    = OL_FS_CMD_READAT;
        l2_sync();                             /* the request in DDR before SEQ */
        seq = shared[SH_FS_SEQ] + 1u;
        shared[SH_FS_SEQ] = seq;               /* trigger last */
        l2_sync();                             /* and SEQ itself, at once */
        g_req++;
        start = zzq_us_now();
        while (shared[SH_FS_ACK] != seq) {
            volatile u32 k;
            for (k = 0; k < 1000u; k++) { __asm__ volatile("nop"); }
            shared[SH_HB]++;                   /* ZZHalfLife: alive during the wait */
            if ((u32)(zzq_us_now() - start) > 20000000u) { g_fail++; return -1; }
        }
        __asm__ volatile("dmb sy" ::: "memory");
        if (shared[SH_FS_ERR] != 0) { g_fail++; return -1; }
        got = shared[SH_FS_SIZE];
        if (total) *total = shared[SH_FS_EXISTS];
        if (got > want) got = want;
        src = (const volatile u8 *)ZZQ_FILEBUF_AT(slot);
        if ((((u32)(unsigned long)out + done) & 3u) == 0) {
            const volatile u32 *s4 = (const volatile u32 *)src;
            u32 *d4 = (u32 *)(out + done);
            for (i = 0; i < got / 4u; i++) d4[i] = s4[i];
            for (i = got & ~3u; i < got; i++) out[done + i] = src[i];
        } else {
            for (i = 0; i < got; i++) out[done + i] = src[i];
        }
        done += got;
        g_bytes += got;
        if (got < want) break;                 /* end of the file */
    }
    g_us += zzq_us_now() - t0;
    return (int)done;
}

void zzhl_read_at_stats(unsigned *requests, unsigned *failures, unsigned *us, unsigned *bytes)
{
    if (requests) *requests = g_req;
    if (failures) *failures = g_fail;
    if (us) *us = g_us;
    if (bytes) *bytes = g_bytes;
}
