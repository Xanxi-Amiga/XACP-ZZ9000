/* SPDX-License-Identifier: GPL-3.0-or-later */
/* zzhl_stack.S - ZZHalfLife stage 1: call fn(arg) on another stack (the 8 MiB engine stack of
 * the arena, 8-byte aligned), then come back to the release stack. The release's cooperative
 * return (r8/r9 saved by its startup) is untouched: the registers it needs are callee-saved
 * and restored here. ASCII only. */
    .syntax unified
    .arm
    .text
    .global zzhl_call_on_stack
    .type   zzhl_call_on_stack, %function
/* int zzhl_call_on_stack(int (*fn)(const void *), const void *arg, unsigned stack_top) */
zzhl_call_on_stack:
    push    {r4-r11, lr}
    mov     r4, sp
    bic     r2, r2, #15
    mov     sp, r2
    mov     r3, r0
    mov     r0, r1
    blx     r3
    mov     sp, r4
    pop     {r4-r11, pc}
    .size   zzhl_call_on_stack, .-zzhl_call_on_stack
