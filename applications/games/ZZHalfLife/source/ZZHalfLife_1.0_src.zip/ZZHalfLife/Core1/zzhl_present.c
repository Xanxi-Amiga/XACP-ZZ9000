/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * zzhl_present.c - ZZHalfLife: the GPU's RGB565 buffer to the P96 buffer the launcher
 * granted, with the release triple-buffer handshake (launcher unchanged).
 *
 * Derived from ZZQuake2RIX 0.10.3 Core1/zzq2_glue.c (Xanxi), presentation part
 * (present_common, t565_copy_burst, nc_burst_copy, the SH_RENDER_* protocol), the
 * Quake II profiling removed.  The protocol, slot for slot:
 *     SH_RENDER_SEQ new   -> a buffer is granted, else the frame is dropped (never waits)
 *     SH_RENDER_FB        -> the ARM address of that buffer, checked like the release does
 *     SH_FB_USED          <- the buffer written
 *     copy (byte swap to 16-bit big-endian, or 0x00RRGGBB), cache clean
 *     SH_FRAME++, SH_RENDER_DONE <- seq, SH_FRAME_READY <- seq, SH_RENDERS (the launcher's
 *     "CORE1 FIGE" watchdog counts those)
 * Integer registers only: no NEON in the blobs (the release's Core1 stack is not 8-byte
 * aligned; the engine image runs on its own aligned stack but keeps the rule).
 * ASCII only.
 */
#include "zzquake_config.h"
#include "zzq2_res.h"
#include "xacp_rt.h"

typedef unsigned int u32;
typedef unsigned char u8;

extern const zzhl_rt_t *zzhl_rt;
extern void Sys_Error( const char *error, ... );
extern void zz_rix_buffers( unsigned *lo, unsigned *hi );
#define shared ( zzhl_rt->shared )

volatile u32 zzq2_world_count;          /* frames presented (zzhl_gpu.c cuts its timedemo reports on it) */
void (*zzq2_present_hook)( void );      /* called every 4 lines, or while the DMA copies (the GPU queue is pumped meanwhile) */
int zzq2_present_burst = 1;
void zzq_s2_begin( int p ) { (void)p; }
void zzq_s2_end( int p ) { (void)p; }
unsigned zzq2_last_pak_end( void ) { return zzhl_rt->pack0_addr + zzhl_rt->pack0_size; }

static u32 t32_last_seq, t32_pass, t32_block, t32_rejects;
static u32 t32_renders, t32_heavy, t32_work_t0, t32_work_last, t32_work_max;
static u32 t32_fps_peak, t32_last_us;
static u32 t32_hist[ZZQ_HIST_BINS];
static void scanout_sample( void );     /* build 30, after zzhl_frames_presented */
/* what Core1 publishes to the 68k (non-cacheable shared block, PCM ring) passes the L2
   controller's store buffer, where a DSB does not make it visible in DDR - only a PL310 Cache Sync
   does (Zynq PL310 at 0xF8F02000, Cache Sync 0x730; see Core1/zzhl_fsat.c).  Called after
   FRAME_READY here and after the PCM write position (xacp/src/xacp_snd.c). */
static u32 g_l2_syncs;
void zzhl_l2_sync( void )
{
	u32 n;
	__asm__ volatile( "dsb sy" ::: "memory" );
	*(volatile u32 *)0xF8F02730u = 0u;
	for( n = 0; n < 100000u && ( *(volatile u32 *)0xF8F02730u & 1u ); n++ ) { }
	__asm__ volatile( "dsb sy" ::: "memory" );
	g_l2_syncs++;
}
u32 zzhl_l2_sync_count( void ) { return g_l2_syncs; }
/* the copy by the PL330 (librixgpu rix_dmacopy_*, zzhl_gpu.c tests it at open and calls
   zzhl_present_set_dma).  Used for a 16-bit screen when the picture is one block: a GPU colour
   buffer (non-cacheable) to a P96 buffer of the same pitch, both 64-byte aligned.  The P96 buffer is
   then written in DDR by the DMA, never through Core1's caches: the frames the CPU copies (loading
   pictures, the 320 build, a fallback) write whole cache lines and clean them, so no dirty line of
   a P96 buffer is ever left to be evicted over a DMA picture.  Any failure: this frame by the CPU,
   and the CPU for the rest of the run. */
extern int rix_dmacopy_start( u32 src, u32 dst, u32 bytes );
extern int rix_dmacopy_poll( void );
extern void rix_dmacopy_abort( void );
extern u32 rix_dmacopy_fault_info( void );
static int g_pdma;
static u32 g_pdma_frames, g_pdma_us, g_pdma_max_us, g_pdma_cpu_frames, g_pdma_fail, g_pdma_fail_info, g_pdma_pumps;
void zzhl_present_set_dma( int on ) { g_pdma = on ? 1 : 0; }
#include "zzhl_dropstat.h"               /* the frames dropped below, by the engine's pace */
static zzhl_dropstat_t g_drop;
void zzhl_present_drop_stats( unsigned v[2 + ZZHL_DROP_CLASSES] )
{
	int i;
	v[0] = g_drop.calls; v[1] = g_drop.dropped;
	for( i = 0; i < ZZHL_DROP_CLASSES; i++ ) v[2 + i] = g_drop.by[i];
}
int zzhl_present_dma_on( void ) { return g_pdma; }
void zzhl_present_dma_stats( unsigned v[8] )
{
	v[0] = g_pdma; v[1] = g_pdma_frames; v[2] = g_pdma_frames ? g_pdma_us / g_pdma_frames : 0u; v[3] = g_pdma_max_us;
	v[4] = g_pdma_cpu_frames; v[5] = g_pdma_fail; v[6] = g_pdma_fail_info; v[7] = g_pdma_frames ? g_pdma_pumps / g_pdma_frames : 0u;
}
/* the PL330 channel has a second user, the depth clear of ZCLEAR=1 (Core1/zzhl_gpu.c).
   It sets this to a function that waits for its own copy to end; nothing when ZCLEAR is off.
   Without it a picture arriving during a depth clear would find the channel busy, and the
   failure path below would hand the presentation to the CPU for the rest of the run. */
void (*zzhl_dma_guard)( void );
static int dma_present( u32 fb, u32 src, u32 bytes )
{
	u32 t0, dt;
	int r;
	if( zzhl_dma_guard ) zzhl_dma_guard();
	t0 = zzhl_rt->us_now();
	r = rix_dmacopy_start( src, fb, bytes );
	if( r ) { g_pdma = 0; g_pdma_fail = 1u; g_pdma_fail_info = (u32)r; return 0; }
	for( ;; )
	{
		r = rix_dmacopy_poll();
		if( r == 1 ) break;
		if( r == 2 ) { g_pdma = 0; g_pdma_fail = 2u; g_pdma_fail_info = rix_dmacopy_fault_info(); return 0; }
		if(( u32 )( zzhl_rt->us_now() - t0 ) > 30000u ) { rix_dmacopy_abort(); g_pdma = 0; g_pdma_fail = 3u; g_pdma_fail_info = 0u; return 0; }
		if( zzq2_present_hook ) { zzq2_present_hook(); g_pdma_pumps++; }   /* the GPU fed meanwhile */
	}
	dt = zzhl_rt->us_now() - t0;
	g_pdma_frames++; g_pdma_us += dt;
	if( dt > g_pdma_max_us ) g_pdma_max_us = dt;
	return 1;
}
static u32 t565_row[ZZQ2_VID_W / 2] __attribute__((aligned(32)));
static u32 t565_lut_hi[256], t565_lut_lo[256];
static int t565_lut_ok;
static const unsigned short *g_last_pixels;   /* the last image shown, for the keepalive below */
static unsigned g_last_pitch;
/* xacp_loading.c's screen replaces the GPU's picture while the client loads; the last
   picture of the game itself is kept for its background */
const unsigned short *(*zzhl_present_override)( unsigned *pitch_bytes );
static const unsigned short *g_last_game;
static unsigned g_last_game_pitch;
const unsigned short *zzhl_last_game_picture( unsigned *pitch_bytes ) { *pitch_bytes = g_last_game_pitch; return g_last_game; }
int zzhl_present_ready( void ) { return shared[SH_TRIPLE] != 0; }
/* the launcher (ZZQuake2_A0.c, read only) waits after the start of Core1 until the status
   reaches QG_CREATE_OK, at most 3000 x Delay(1), serving only the files meanwhile: no flip, no
   audio process, no keyboard before.  The release runtime sets QG_CREATE_OK when QG_Create
   returns; ZZHalfLife's engine runs INSIDE QG_Create, so the status stayed 0x04 and the launcher
   waited its whole 3000 turns - about two minutes (06/11, first loading picture shown
   at 122.9 s, the launcher's display loop starting at c0a0b; c0a0 and c0a0a ran unseen and
   unheard, "the long black screen without disk access").  Set once the presentation is ready. */
void zzhl_status_create_ok( void )
{
	if( shared[SH_STATUS] < ZZQ_QG_CREATE_OK ) shared[SH_STATUS] = ZZQ_QG_CREATE_OK;
	__asm__ volatile( "dsb sy" ::: "memory" );
}

static void t32_publish( void )
{
	int h;
	shared[SH_WORK_US]       = t32_work_last;
	shared[SH_WORK_MAX]      = t32_work_max;
	shared[SH_FPS_PEAK_X100] = t32_fps_peak;
	shared[SH_GATE_PASS]     = t32_pass;
	shared[SH_GATE_BLOCK]    = t32_block;
	shared[SH_FB_REJECTS]    = t32_rejects;
	shared[SH_HEAVY_FRAMES]  = t32_heavy;
	shared[SH_RENDERS]       = t32_renders;
	for( h = 0; h < ZZQ_HIST_BINS; h++ ) shared[SH_HIST_BASE + h] = t32_hist[h];
}

/* n32 blocks of 32 bytes from the GPU's non-cacheable buffer into cached memory: one LDM of eight
   registers is one AXI burst (ZZQuake2RIX 0.3: 25.7 ms -> a few ms of "show" per frame) */
static void nc_burst_copy( u32 *dst, const u32 *src, u32 n32 )
{
	__asm__ volatile(
		"1:\n\t"
		"ldmia %1!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
		"stmia %0!, {r3, r4, r5, r6, r8, r9, r10, r12}\n\t"
		"subs  %2, %2, #1\n\t"
		"bne   1b\n\t"
		: "+r"(dst), "+r"(src), "+r"(n32)
		:
		: "r3", "r4", "r5", "r6", "r8", "r9", "r10", "r12", "cc", "memory" );
}

static void t565_lut_init( void )
{
	u32 i;
	for( i = 0; i < 256u; i++ )
	{
		u32 r = i >> 3, gh = i & 7u, gl = i >> 5, b = i & 31u;
		t565_lut_hi[i] = ((( r << 3 ) | ( r >> 2 )) << 16 ) | ((( gh << 5 ) | ( gh >> 1 )) << 8 );
		t565_lut_lo[i] = (( gl << 2 ) << 8 ) | (( b << 3 ) | ( b >> 2 ));
	}
	t565_lut_ok = 1;
}

static void t565_copy( u32 fb, u32 pitch, const unsigned short *src, u32 src_pitch, int bpp16 )
{
	int x, y;
	const u32 W = (u32)ZZQ2_VID_W, H = (u32)ZZQ2_VID_H;
	if( !t565_lut_ok ) t565_lut_init();
	for( y = 0; y < (int)H; y++ )
	{
		const u32 *row = (const u32 *)(( const u8 * )src + (u32)y * src_pitch );
		const u32 *r2 = t565_row;
		if( zzq2_present_hook && ( y & 3 ) == 0 ) zzq2_present_hook();   /* every 4 lines (16 before) */
		if( zzq2_present_burst && (( u32 )row & 31u ) == 0u && ( src_pitch & 31u ) == 0u )
			nc_burst_copy( t565_row, row, W * 2u / 32u );
		else
		{
			for( x = 0; x < (int)( W / 2u ); x++ ) t565_row[x] = row[x];
		}
		if( bpp16 )
		{
			u32 *d = (u32 *)( fb + (u32)y * pitch );
			for( x = 0; x < (int)( W / 2u ); x++ )
			{
				u32 v = r2[x];   /* two pixels: byte-swap each halfword (P96 16-bit is big-endian) */
				d[x] = (( v & 0x00FF00FFu ) << 8 ) | (( v >> 8 ) & 0x00FF00FFu );
			}
		}
		else
		{
			u32 *d = (u32 *)( fb + (u32)y * pitch );
			for( x = 0; x < (int)( W / 2u ); x++ )
			{
				u32 v = r2[x];
				d[2 * x]     = t565_lut_hi[( v >> 8 ) & 0xFFu] | t565_lut_lo[v & 0xFFu];
				d[2 * x + 1] = t565_lut_hi[v >> 24]           | t565_lut_lo[( v >> 16 ) & 0xFFu];
			}
		}
	}
}

/* the menu's mouse pointer (xacp_input.c gives its place while the menu has the keys;
   mainui draws none, the OS does it on a PC), drawn over the finished picture in the P96 buffer:
   X black, o white, the rest left as it is.  After the PL330's copy the rows it covers are
   invalidated first (lines a CPU drawing left valid in the cache would be older than the copy),
   then drawn and cleaned; after the CPU copy they are in the cache already, cleaned with the rest. */
static int g_cur_on, g_cur_x, g_cur_y;
void zzhl_present_cursor( int on, int x, int y ) { g_cur_on = on; g_cur_x = x; g_cur_y = y; }
static const char *const g_arrow[19] = {
	"X           ", "XX          ", "XoX         ", "XooX        ", "XoooX       ", "XooooX      ",
	"XoooooX     ", "XooooooX    ", "XoooooooX   ", "XooooooooX  ", "XoooooooooX ", "XooooooXXXXX",
	"XoooXooX    ", "XooX XooX   ", "XoX  XooX   ", "XX    XooX  ", "X     XooX  ", "       XooX ",
	"       XXX  " };
static void cursor_draw( u32 fb, u32 pitch, int bpp16, int after_dma )
{
	int y0 = g_cur_y, rows = 19, r, c;
	if( !g_cur_on || g_cur_x < 0 || g_cur_y < 0 || g_cur_x >= (int)ZZQ2_VID_W || g_cur_y >= (int)ZZQ2_VID_H ) return;
	if( y0 + rows > (int)ZZQ2_VID_H ) rows = (int)ZZQ2_VID_H - y0;
	if( after_dma ) zzhl_rt->dcache_invalidate( fb + (u32)y0 * pitch, (u32)rows * pitch );
	for( r = 0; r < rows; r++ )
	{
		u8 *line = (u8 *)( fb + (u32)( y0 + r ) * pitch );
		for( c = 0; c < 12 && g_cur_x + c < (int)ZZQ2_VID_W; c++ )
		{
			char p = g_arrow[r][c];
			if( p == ' ' ) continue;
			if( bpp16 ) *(unsigned short *)( line + 2u * (u32)( g_cur_x + c )) = p == 'o' ? 0xFFFFu : 0x0000u;
			else *(u32 *)( line + 4u * (u32)( g_cur_x + c )) = p == 'o' ? 0x00FFFFFFu : 0u;
		}
	}
	if( after_dma ) zzhl_rt->dcache_clean( fb + (u32)y0 * pitch, (u32)rows * pitch );
}

/* the GPU's RGB565 buffer after its frame fence, from the top line shown (ZZQ2_VID_W x
   ZZQ2_VID_H; the 320 x 240 picture sits in a 640 x 481 buffer, pitch 1280) */
void zzq2_present_rgb565( const unsigned short *pixels, unsigned pitch_bytes )
{
	u32 fb, pitch, seq, t0, now, wk;
	int bpp16;

	if( !pixels ) return;
	if( zzhl_present_override )
	{
		const unsigned short *o = zzhl_present_override( &pitch_bytes );
		if( o ) pixels = o;
		else { g_last_game = pixels; g_last_game_pitch = pitch_bytes; }
	}
	g_last_pixels = pixels; g_last_pitch = pitch_bytes;
	if( !shared[SH_TRIPLE] )
		Sys_Error( "ZZHalfLife: the launcher did not obtain 3 buffers" );
	t0 = zzhl_rt->us_now();
	if( !t32_work_t0 ) t32_work_t0 = t0;

	seq = shared[SH_RENDER_SEQ];
	{
		unsigned pace = zzhl_dropstat_call( &g_drop, t0 );   /* build 91 */
		if( seq == t32_last_seq ) { t32_block++; zzhl_dropstat_drop( &g_drop, pace ); return; }   /* no buffer free: dropped */
	}
	t32_last_seq = seq;
	t32_pass++;
	fb = shared[SH_RENDER_FB];
	if( fb < 0x00200000u || fb > 0x08000000u )
	{
		shared[SH_FB_LAST_BAD] = fb;
		t32_rejects++;
		return;
	}
	shared[SH_FB_USED] = fb;
	bpp16 = ( shared[SH_FB_BPP] == 2u );
	pitch = shared[SH_FB_PITCH];
	if( pitch == 0 ) pitch = (u32)ZZQ2_VID_W * ( bpp16 ? 2u : 4u );
	{   /* P96 places the screen buffers where it wants in the board memory; one of them on the GPU's
	       colour buffers would be drawn by both sides (ZZQuake2RIX 0.10 check) */
		unsigned lo, hi;
		zz_rix_buffers( &lo, &hi );
		if( fb < hi && fb + (u32)ZZQ2_VID_H * pitch > lo )
			Sys_Error( "RIX: P96 buffer %08x over GPU buffers %08x-%08x", fb, lo, hi );
	}

	{
		unsigned lo, hi;
		u32 src = (u32)pixels, bytes = (u32)ZZQ2_VID_H * pitch;
		int done = 0;
		zz_rix_buffers( &lo, &hi );
		if( g_pdma && bpp16 && pitch == (u32)ZZQ2_VID_W * 2u && pitch_bytes == pitch && src >= lo && src + bytes <= hi
		    && (( src | fb | bytes ) & 63u ) == 0u )
			done = dma_present( fb, src, bytes );   /* build 35, above */
		if( !done )
		{
			t565_copy( fb, pitch, pixels, pitch_bytes, bpp16 );
			g_pdma_cpu_frames++;
		}
		cursor_draw( fb, pitch, bpp16, done );   /* the menu's pointer */
		shared[SH_CONVERT_US] = zzhl_rt->us_now() - t0;
		if( !done ) zzhl_rt->dcache_clean( fb, (u32)ZZQ2_VID_H * pitch );
	}
	shared[SH_FRAME]++;

	now = zzhl_rt->us_now();
	if( t32_last_us )
	{
		u32 d = now - t32_last_us;
		if( d > 0 && d < 1000000u )
		{
			u32 fps100 = 100000000u / d;
			if( fps100 > t32_fps_peak ) t32_fps_peak = fps100;
		}
	}
	t32_last_us = now;
	wk = now - t32_work_t0;
	t32_work_last = wk;
	if( wk > t32_work_max ) t32_work_max = wk;
	t32_renders++;
	zzq2_world_count++;
	if( wk > 16810u ) t32_heavy++;
	{
		u32 bin = wk / 2000u;
		if( bin >= ZZQ_HIST_BINS ) bin = ZZQ_HIST_BINS - 1u;
		t32_hist[bin]++;
	}
	t32_publish();
	shared[SH_RENDER_DONE] = seq;
	__asm__ volatile( "dsb sy" ::: "memory" );
	shared[SH_FRAME_READY] = seq;
	zzhl_l2_sync();                        /* FRAME_READY in DDR now, not when the store buffer drains */
	if(( t32_renders & 31u ) == 8u ) scanout_sample();   /* build 30, above */
	t32_work_t0 = zzhl_rt->us_now();
}

u32 zzhl_frames_presented( void ) { return t32_renders; }

/* the scanout as the firmware programmed it, sampled every 32 frames (three reads).
   The release launcher flips with PAN_HI/PAN_LO only; the firmware (XX19d-RIX main.c,
   REG_ZZ_PAN_LO) takes the pan width from its blitter register X2, adds X1/Y1, as last written
   by any program, and sets the stride from that width at every vblank (video.c init_vdma).
   A stale X2 = 640 on the 320 x 240 screen gives a 1280-byte stride: every second line of two
   buffers, the picture twice, one above the other (08/11, after a 640 run).  The wrapper
   (launcher/ZZHalfLife.c) now writes X1 = Y1 = 0 and X2 = the width; this checks it. */
/* AXI VDMA MM2S, read only, as librixgpu's rix_vdma_sa (librixgpu stays the vendored tree):
   Core0 rewrites these at every vblank (video.c isr_video -> init_vdma) */
#define ZZHL_VDMA( off ) ( *(volatile u32 *)( 0x83000000u + ( off )))
extern int zz_rix_is_open( void );      /* the section 0x830 may be unmapped before (zzq2rix_mmu.c) */
static u32 g_sc_samples, g_sc_bad, g_sc_first[3], g_sc_badv[3];
static void scanout_sample( void )
{
	u32 v[3], pitch = shared[SH_FB_PITCH];
	if( !zz_rix_is_open( )) return;
	v[0] = ZZHL_VDMA( 0x54u ) & 0xFFFFu;     /* MM2S_HSIZE: bytes per line */
	v[1] = ZZHL_VDMA( 0x50u ) & 0x1FFFu;     /* MM2S_VSIZE: lines */
	v[2] = ZZHL_VDMA( 0x58u ) & 0xFFFFu;     /* MM2S_FRMDLY_STRIDE: stride */
	if( !g_sc_samples ) { g_sc_first[0] = v[0]; g_sc_first[1] = v[1]; g_sc_first[2] = v[2]; }
	g_sc_samples++;
	if( pitch && ( v[2] != pitch || v[0] != pitch || v[1] != (u32)ZZQ2_VID_H ))
	{
		if( !g_sc_bad ) { g_sc_badv[0] = v[0]; g_sc_badv[1] = v[1]; g_sc_badv[2] = v[2]; }
		g_sc_bad++;
	}
}
void zzhl_scanout_status( unsigned *samples, unsigned *bad, unsigned first[3], unsigned badv[3], unsigned *pitch )
{
	int i;
	*samples = g_sc_samples; *bad = g_sc_bad; *pitch = shared[SH_FB_PITCH];
	for( i = 0; i < 3; i++ ) { first[i] = g_sc_first[i]; badv[i] = g_sc_badv[i]; }
}

/* keepalive: the launcher stops a run after ZZQ_FREEZE_AFTER_S (30 s) without a new image once
   the first one is out; a level load can take longer (READAT at about 1.3 MB/s). The file layer
   calls this after each request: if the last image is older than 5 s, it is shown again. */
void zzhl_present_keepalive( void )
{
	u32 now = zzhl_rt->us_now();
	if( !g_last_pixels || !t32_last_us || (u32)( now - t32_last_us ) < 5000000u ) return;
	zzq2_present_rgb565( g_last_pixels, g_last_pitch );
}
