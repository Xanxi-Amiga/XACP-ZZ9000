#!/usr/bin/env python3
# hl_saveunits.py - ZZHalfLife (build 48): how big Half-Life's saves can grow, from your own pak.
#   python3 tools/hl_saveunits.py data/pak0.pak
# Half-Life keeps the state of every level visited (save/<map>.HL1/.HL2/.HL3) and packs all of
# them into each save (sv_save.c, DirectoryCopy); they are dropped only when a map whose worldspawn
# has "newunit" "1" opens (sv_newunit, ClearSaveDir after the changelevel).  On the ZZ9000 those
# files and the saves (autosave, autosave01, autosave02, quick, quick01, quick02: 2 aged copies,
# SAVE_AGED_COUNT) live in Core1's heap.  This prints, in game order, the maps that start a new
# unit and the longest run of maps a save can carry, with the size measured on the A4000 (build 46,
# We've Got Hostiles: 144 KiB with 1 map, 644 KiB with 5) as the rate: an estimate, not a measure.
# Reads the pak only, writes nothing.  Code by the ZZHalfLife port, 0BSD.  ASCII only.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hl_chapters import Pak, CHAPTERS, bsp_info

FIRST_KIB, PER_MAP_KIB = 144, 125      # build 46 on the A4000: 144 KiB, then +125 KiB a map (644 at 5)

def main():
    if len(sys.argv) < 2: raise SystemExit('usage: hl_saveunits.py data/pak0.pak [data/pak1.pak]')
    pak = Pak(sys.argv[1:])
    order = [(c, m) for c, (t, ms) in enumerate(CHAPTERS) if c > 0 for m in ms.split()]
    order += [(0, m) for m in CHAPTERS[0][1].split()]          # the Hazard Course: a game of its own
    run, longest, where, missing, units = 0, 0, None, [], []
    for c, m in order:
        if not pak.has('maps/%s.bsp' % m): missing.append(m); continue
        _, ents, _ = bsp_info(pak, m)
        ws = next((e for e in ents if e.get('classname') == 'worldspawn'), {})
        nu = ws.get('newunit', '0').strip() not in ('', '0')
        if c == 0 and m == CHAPTERS[0][1].split()[0]: run = 0   # a new game
        if nu or (c == 1 and m == 'c0a0'): run = 0
        run += 1
        if nu: units.append('%s (%s)' % (m, CHAPTERS[c][0]))
        if run > longest: longest, where = run, '%s (%s)' % (m, CHAPTERS[c][0])
        print('%-7s %-24s newunit %s  maps in the save here: %d' % (m, CHAPTERS[c][0], 'yes' if nu else 'no ', run))
    print()
    print('maps that start a new unit (the older levels leave the saves): %d' % len(units))
    for u in units: print('  ' + u)
    est = FIRST_KIB + PER_MAP_KIB * (longest - 1) if longest else 0
    print('longest run of maps in one save: %d, up to %s' % (longest, where))
    print('estimated size of one save there: %.1f MiB (rate of We\'ve Got Hostiles, build 46)' % (est / 1024.0))
    print('in Core1 memory then, levels + 3 autosaves (+ 3 quick saves if F6 is used): %.1f MiB (%.1f MiB)' % (4 * est / 1024.0, 7 * est / 1024.0))
    if missing: print('maps not in this pak: ' + ' '.join(missing))

if __name__ == '__main__':
    main()
