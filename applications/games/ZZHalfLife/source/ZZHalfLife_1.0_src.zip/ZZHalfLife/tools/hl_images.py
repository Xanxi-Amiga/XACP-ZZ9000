#!/usr/bin/env python3
# hl_images.py - ZZHalfLife: look through a Half-Life install for full-screen pictures (a loading
# screen, a menu background) and say which ones are not black. Reads the user's own files on his PC,
# writes nothing, sends nothing.
#   python3 hl_images.py <Half-Life folder or valve folder>
# For each .tga / .bmp / .png at least 256 pixels wide, loose or inside a .pak: its size and, for
# TGA (uncompressed or RLE) and BMP (8/24/32 bits), the brightest channel and the mean brightness
# (0-255; 0 = black). Pictures that share a name prefix (the tiles 800_1_a..800_3_d) are grouped.
# Standard library only. ASCII only.
import os, struct, sys, zlib

def tga_pixels(d):
    idl, cmt, it = d[0], d[1], d[2]
    w, h, bpp = struct.unpack('<HH', d[12:16]) + (d[16],)
    pos = 18 + idl + (struct.unpack('<H', d[5:7])[0] * ((d[7] + 7) // 8) if cmt else 0)
    n = bpp // 8
    if it == 2:
        return w, h, n, d[pos:pos + w * h * n]
    if it == 10:
        out = bytearray(); total = w * h * n
        while len(out) < total and pos < len(d):
            c = d[pos]; pos += 1
            if c & 0x80:
                px = d[pos:pos + n]; pos += n; out += px * ((c & 0x7f) + 1)
            else:
                k = ((c & 0x7f) + 1) * n; out += d[pos:pos + k]; pos += k
        return w, h, n, bytes(out[:total])
    return w, h, 0, None

def bmp_pixels(d):
    off = struct.unpack('<I', d[10:14])[0]
    w, h = struct.unpack('<ii', d[18:26]); bpp = struct.unpack('<H', d[28:30])[0]
    h = abs(h)
    if bpp == 8:
        pal = d[54:54 + 1024]
        row = (w + 3) & ~3
        px = bytearray()
        for y in range(h):
            for x in range(w):
                i = d[off + y * row + x]; px += pal[i * 4:i * 4 + 3]
        return w, h, 3, bytes(px)
    if bpp in (24, 32):
        n = bpp // 8; row = (w * n + 3) & ~3
        return w, h, n, b''.join(d[off + y * row: off + y * row + w * n] for y in range(h))
    return w, h, 0, None

def png_size(d):
    return struct.unpack('>II', d[16:24])

def stats(n, px):
    mx = 0; tot = 0; cnt = 0
    for i in range(0, len(px), n * 7):      # every 7th pixel is plenty
        r, g, b = px[i], px[i + 1], px[i + 2]
        m = max(r, g, b); mx = max(mx, m); tot += (r + g + b) // 3; cnt += 1
    return mx, (tot // cnt if cnt else 0)

def look(name, d, out):
    low = name.lower()
    try:
        if low.endswith('.tga'):
            w, h, n, px = tga_pixels(d)
        elif low.endswith('.bmp') and d[:2] == b'BM':
            w, h, n, px = bmp_pixels(d)
        elif low.endswith('.png') and d[:8] == b'\x89PNG\r\n\x1a\n':
            w, h = png_size(d); n, px = 0, None
        else:
            return
    except Exception:
        return
    if w < 256 and not ('background' in low):
        return
    mx, mean = stats(n, px) if px else (-1, -1)
    out.append((name, w, h, mx, mean))

def read_pak(path, out):
    with open(path, 'rb') as f:
        hdr = f.read(12)
        if hdr[:4] != b'PACK': return
        dofs, dlen = struct.unpack('<II', hdr[4:12])
        f.seek(dofs); dirs = f.read(dlen)
        for i in range(0, dlen, 64):
            name = dirs[i:i + 56].split(b'\0', 1)[0].decode('latin-1')
            ofs, size = struct.unpack('<II', dirs[i + 56:i + 64])
            if name.lower().endswith(('.tga', '.bmp', '.png')):
                f.seek(ofs); look(os.path.basename(path) + ':' + name, f.read(size), out)

def main():
    if len(sys.argv) < 2:
        print(open(__file__).read().split('import os')[0]); return 2
    top = sys.argv[1]; out = []
    for root, dirs, files in os.walk(top):
        for fn in files:
            full = os.path.join(root, fn); rel = os.path.relpath(full, top).replace('\\', '/')
            low = fn.lower()
            if low.endswith('.pak'):
                read_pak(full, out)
            elif low.endswith(('.tga', '.bmp', '.png')):
                with open(full, 'rb') as f: look(rel, f.read(), out)
    groups = {}
    for name, w, h, mx, mean in out:
        base = name.rsplit('/', 1)[-1]
        key = ( name.rsplit('/', 1)[0] + '/' if '/' in name else '' ) + (base.split('_', 1)[0] + '_*' + ('_loading' if '_loading' in base else '') if base[:1].isdigit() else base)
        g = groups.setdefault(key, [0, 0, -1, 0, set()])
        g[0] += 1; g[1] = max(g[1], w * h); g[2] = max(g[2], mx); g[3] = max(g[3], mean); g[4].add('%dx%d' % (w, h))
    print('%-58s %5s %-16s %s' % ('picture (tiles grouped)', 'files', 'sizes', 'brightest / mean (0 = black)'))
    for k in sorted(groups):
        n, a, mx, mean, sz = groups[k]
        sizes = ','.join(sorted(sz))[:16]
        print('%-58s %5d %-16s %s' % (k[:58], n, sizes, 'png, not measured' if mx < 0 else '%d / %d%s' % (mx, mean, '  BLACK' if mx < 24 else '')))
    return 0

if __name__ == '__main__':
    sys.exit(main())
