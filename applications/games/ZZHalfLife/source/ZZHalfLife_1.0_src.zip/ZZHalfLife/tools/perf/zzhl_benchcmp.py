#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""zzhl_benchcmp.py - ZZHalfLife build 84: compare bench runs (BENCH=) from their logs.

    python3 tools/perf/zzhl_benchcmp.py b84_ref.log b84_early.log b84_f2b.log ...

Each argument is the output of `ZZSlots ALL` after a run started with BENCH=...  The first log is
the reference; the others are compared to it window by window (a window = a scene, live or
frozen).  Printed:
  1. the options each run was started with (the BENCH SUMMARY line);
  2. the average frame period of every window, and the difference to the reference;
  3. for every window of every run, where the frame goes (engine, ref_gl, binds, triangles, GPU
     waits, presentation) and what it sends (pixels, binds), by origin when --origins is given;
  4. when a log holds the GPU's price list (GPUBENCH=1): the list, and for each window what the
     pixels and binds it submits would cost at that price - to be set against the GPU waits.
Nothing here is specific to a machine: standard library only, reads text, writes text.
ASCII only.
"""
import re
import sys

ROW = re.compile(r'BENCH = (\w) (.+?)\s*:\s*(\d+) frames,\s*(\d+) us,\s*([\d.]+) img/s, longest\s*(\d+) us, over 45 ms\s*(\d+) \|\s*(\d+) tris,\s*(\d+) binds,\s*(\d+) kpx opaque,\s*(\d+) kpx blended')
SUMMARY = re.compile(r'BENCH SUMMARY, (\d+) s windows, (.*)')
WINDOW = re.compile(r'BENCH (.+?): frames (\d+)(?: \(and \d+ without the world, left out\))?, period (\d+) us')
PERIOD = re.compile(r'bench\s+frames (\d+) \| period (\d+) = engine (\d+) \+ ref_gl (\d+) \+ begin/binds (\d+) \+ triangles (\d+) \+ uploads (\d+) \(GPU waits in these (\d+)\) \+ present (\d+) \+ swap (\d+)')
IDLE = re.compile(r'GPU idle, work waiting <= (\d+) in (\d+), nothing queued <= (\d+)')
# build 84 printed "tris N"; build 85 prints "tris in N sent M" and "us U of which GPU waits W"
# build 86 adds " box N" (BOXPX=1): thousands of pixels of the triangles' bounding boxes
ORIGIN = re.compile(r'^\s*B (.{10}) batches ([\d.]+) tris (?:in (\d+) sent )?(\d+) kpx opaque ([\d.]+) blended ([\d.]+) binds ([\d.]+) pages (\d+) us (\d+)(?: of which GPU waits (\d+))?(?: box ([\d.]+))?(?: rej (\d+))?')
# build 87, WALKSTAT=1: the rasteriser's clocks by origin, by its model (thousands), and the frame's time by that model
WALK = re.compile(r'^\s*B walk (.{10}) desc (\d+) kclocks ([\d.]+) far ([\d.]+) ends ([\d.]+) lines (\d+) empty (\d+)')
WALKSUM = re.compile(r'B rasteriser, by its model: (\d+) us a frame .*?; (\d+) us on lines that ran to the end of their box, (\d+) us on lines before')
BOXFIT = re.compile(r'B box fit \(BOXFIT=(\d)\): lines without a pixel taken off the boxes (\d+) a frame, triangles not sent because their box held no pixel (\d+) a frame')
# build 86: the frame's depth clears, by the GPU or skipped because the PL330 had cleared the buffer (ZCLEAR=1)
DEPTHCLR = re.compile(r'B depth clears x1000: by the GPU (\d+), skipped \(the PL330 had cleared the buffer\) (\d+); PL330 clears made late x1000 (\d+), Core1 waited for the PL330 (\d+) us')
ZCLINE = re.compile(r'RIX: ZCLEAR=\d.*')
# what the engine and ZZSlots put in front of a console line: a colour reset (its ESC shown as a dot) and a time stamp
PREFIX = re.compile(r'^(?:.?\[0m)?(?:\[\d\d:\d\d:\d\d\] )?')
ENGINE = re.compile(r'B binds asked by ref_gl ([\d.]+), distinct textures ([\d.]+), GL queue replays (\d+) us \| engine: server (\d+) us, client up to the 3D scene (\d+) us, sound mix (\d+) us')
SPRITES = re.compile(r'B sprite quads ([\d.]+), with an empty margin the drawing mode cannot show ([\d.]+)(?:: (\d+) % of their quad can show)?')
PRICE = re.compile(r'^\s*([a-zA-Z]) (.{42}) (\d+) us, wait (\d+)(.*)$')   # build 86: 27 cases, the 27th under A
PRICE_EXTRA = re.compile(r'\| (\d+ (?:us a depth clear|us a colour clear|ns a triangle, box \d+ px|ns a triangle all included))')
PRICE_SAYS = re.compile(r'^\s*= (.*)$')
NSPX = re.compile(r'([\d.]+) ns/px')
USBIND = re.compile(r'(\d+) us a bind')


class Window:
    def __init__(self, label):
        self.label = label
        self.frames = 0
        self.period = 0
        self.parts = None       # engine, ref_gl, binds, triangles, uploads, gpu waits, present, swap
        self.idle = None        # work waiting, spells, nothing queued
        self.origins = {}       # name -> (batches, tris sent, kpx opaque, kpx blended, binds, pages, us, tris in or None, GPU waits or None)
        self.engine = None      # binds asked, distinct, replay us, server, client, sound
        self.sprites = None
        self.depthclr = None    # per 1000 frames: by the GPU, skipped; late PL330 clears; us waited for the PL330
        self.walk = {}          # origin -> (desc, kclocks, far, ends, lines, empty)
        self.walksum = None     # us a frame by the model, us on far lines, us on end lines
        self.boxfit = None      # mode, lines taken off a frame, triangles not sent a frame


class Run:
    def __init__(self, path):
        self.path = path
        self.options = '(no BENCH SUMMARY line: the run did not reach its end?)'
        self.seconds = 0
        self.rows = {}          # label -> (frames, period us, fps, longest, over45, tris, binds, kpx opaque, kpx blended)
        self.order = []
        self.windows = {}
        self.prices = {}        # letter -> (name, us, wait, ns/px or None, us a bind or None, other text or None)
        self.price_says = []    # the list's own conclusions (its lines that start with "=")
        self.zclear = None      # the self-test's line

    def parse(self):
        cur = None
        with open(self.path, encoding='latin-1', errors='replace') as f:
            for raw in f:
                line = PREFIX.sub('', raw.rstrip('\r\n'))
                m = SUMMARY.search(line)
                if m:
                    self.seconds = int(m.group(1)); self.options = m.group(2).strip(); cur = None
                    continue
                m = ROW.search(line)
                if m:
                    label = m.group(2).strip()
                    self.rows[label] = (int(m.group(3)), int(m.group(4)), float(m.group(5)), int(m.group(6)), int(m.group(7)),
                                        int(m.group(8)), int(m.group(9)), int(m.group(10)), int(m.group(11)))
                    if label not in self.order:
                        self.order.append(label)
                    continue
                m = WINDOW.search(line)
                if m and 'BENCH = ' not in line:
                    cur = Window(m.group(1).strip()); cur.frames = int(m.group(2)); cur.period = int(m.group(3))
                    self.windows[cur.label] = cur
                    continue
                m = PRICE.match(line)
                if m and ' us, wait ' in line:
                    rest = m.group(5)
                    ns = NSPX.search(rest); ub = USBIND.search(rest)
                    ex = PRICE_EXTRA.search(rest)
                    self.prices[m.group(1)] = (m.group(2).strip(), int(m.group(3)), int(m.group(4)),
                                               float(ns.group(1)) if ns else None, int(ub.group(1)) if ub else None, ex.group(1) if ex else None)
                    continue
                m = PRICE_SAYS.match(line)
                if m and self.prices and m.group(1) not in self.price_says:
                    self.price_says.append(m.group(1)); continue
                m = ZCLINE.search(line)
                if m and self.zclear is None:
                    self.zclear = m.group(0); continue
                if cur is None:
                    continue
                m = PERIOD.search(line)
                if m:
                    cur.parts = tuple(int(m.group(i)) for i in range(3, 11)); continue
                m = IDLE.search(line)
                if m and cur.idle is None:
                    cur.idle = (int(m.group(1)), int(m.group(2)), int(m.group(3))); continue
                m = ORIGIN.match(line)
                if m:
                    cur.origins[m.group(1).strip()] = (float(m.group(2)), int(m.group(4)), float(m.group(5)), float(m.group(6)),
                                                       float(m.group(7)), int(m.group(8)), int(m.group(9)),
                                                       int(m.group(3)) if m.group(3) else None, int(m.group(10)) if m.group(10) else None,
                                                       float(m.group(11)) if m.group(11) else None, int(m.group(12)) if m.group(12) else None)
                    continue
                m = WALK.match(line)
                if m:
                    cur.walk[m.group(1).strip()] = (int(m.group(2)), float(m.group(3)), float(m.group(4)), float(m.group(5)), int(m.group(6)), int(m.group(7)))
                    continue
                m = WALKSUM.search(line)
                if m:
                    cur.walksum = tuple(int(m.group(i)) for i in range(1, 4)); continue
                m = BOXFIT.search(line)
                if m:
                    cur.boxfit = tuple(int(m.group(i)) for i in range(1, 4)); continue
                m = DEPTHCLR.search(line)
                if m:
                    cur.depthclr = tuple(int(m.group(i)) for i in range(1, 5)); continue
                m = ENGINE.search(line)
                if m:
                    cur.engine = (float(m.group(1)), float(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)), int(m.group(6))); continue
                m = SPRITES.search(line)
                if m:
                    cur.sprites = (float(m.group(1)), float(m.group(2)), int(m.group(3)) if m.group(3) else None); continue
        return self


def ms(us):
    return '%6.2f' % (us / 1000.0)


def main(argv):
    show_origins = '--origins' in argv
    paths = [a for a in argv[1:] if not a.startswith('--')]
    if not paths:
        print(__doc__)
        return 2
    runs = [Run(p).parse() for p in paths]
    ref = runs[0]

    print('RUNS')
    for i, r in enumerate(runs):
        print('  %s  %-28s %s' % (chr(ord('A') + i), r.path.split('/')[-1][:28], r.options))
        if r.zclear:
            print('     %s' % r.zclear)
    print()

    labels = list(ref.order)
    for r in runs[1:]:
        for l in r.order:
            if l not in labels:
                labels.append(l)
    if not labels:
        print('No "BENCH = " line found: these are not logs of a run started with BENCH=, or the run did not finish.')
        return 1

    print('AVERAGE PERIOD, ms per frame (img/s); difference to run A in ms')
    head = '  %-24s' % 'window' + ''.join('  %s: ms  img/s   diff' % chr(ord('A') + i) for i in range(len(runs)))
    print(head)
    for l in labels:
        out = '  %-24s' % l[:24]
        base = ref.rows.get(l)
        for r in runs:
            row = r.rows.get(l)
            if not row or not row[0]:
                out += '        -      -      -'
                continue
            d = (row[1] - base[1]) / 1000.0 if base and base[0] else 0.0
            out += '  %7.2f  %5.1f %+6.2f' % (row[1] / 1000.0, row[2], d)
        print(out)
    print()

    print('WHERE THE FRAME GOES, ms per frame: period = engine + ref_gl + binds + triangles + uploads + present + swap')
    print('  (GPU waits are inside binds and triangles; kpx = thousands of pixels submitted)')
    for l in labels:
        print('  %s' % l)
        for i, r in enumerate(runs):
            w = r.windows.get(l); row = r.rows.get(l)
            if not w or not w.parts:
                print('    %s  (no detail in this log)' % chr(ord('A') + i))
                continue
            e, g, b, t, u, wt, pr, sw = w.parts
            idle = ' | GPU idle: work waiting <= %s, nothing queued <= %s' % (ms(w.idle[0]).strip(), ms(w.idle[2]).strip()) if w.idle else ''
            px = ' | %d kpx opaque, %d blended, %d binds, longest frame %s' % (row[7], row[8], row[6], ms(row[3]).strip()) if row else ''
            print('    %s  period %s = engine %s + ref_gl %s + binds %s + tris %s + upl %s + present %s  (GPU waits %s)%s%s' % (
                chr(ord('A') + i), ms(w.period), ms(e), ms(g), ms(b), ms(t), ms(u), ms(pr), ms(wt).strip(), idle, px))
            if w.engine:
                print('       engine: server %s, client %s, sound mix %s; GL queue replays %s; binds asked %.0f for %.0f textures' % (
                    ms(w.engine[3]).strip(), ms(w.engine[4]).strip(), ms(w.engine[5]).strip(), ms(w.engine[2]).strip(), w.engine[0], w.engine[1]))
            if w.walksum:
                print('       rasteriser by its model: %s a frame, of which %s on lines that ran to the end of their box, %s before the first / after the last line with a pixel' % (
                    ms(w.walksum[0]).strip(), ms(w.walksum[1]).strip(), ms(w.walksum[2]).strip()))
            if w.boxfit:
                print('       BOXFIT=%d: %d lines without a pixel taken off the boxes a frame, %d triangles not sent a frame' % w.boxfit)
            if w.depthclr:
                print('       depth clears per 1000 frames: %d by the GPU, %d skipped (PL330); late PL330 clears %d; Core1 waited for the PL330 %s a frame' % (
                    w.depthclr[0], w.depthclr[1], w.depthclr[2], ms(w.depthclr[3]).strip()))
            if w.sprites and w.sprites[0]:
                print('       sprites: %.1f quads, %.1f with an empty margin%s' % (
                    w.sprites[0], w.sprites[1], ' (%d %% of their quad can show)' % w.sprites[2] if w.sprites[2] is not None else ''))
            if show_origins:
                for name, o in w.origins.items():
                    tin = '%6d' % o[7] if o[7] is not None else '     -'
                    own = '%6d' % (o[6] - o[8]) if o[8] is not None else '     -'
                    box = '  box kpx %7.1f = %4.1f x the surface' % (o[9], o[9] / (o[2] + o[3])) if o[9] is not None and (o[2] + o[3]) > 0 else ''
                    rej = '  rej %5d' % o[10] if o[10] is not None else ''
                    print('         %-10s batches %7.1f  tris in %s sent %5d%s  kpx opaque %7.1f  blended %7.1f  binds %5.1f  pages %5d  Core1 us %6d, without its GPU waits %s%s' % (
                        name, o[0], tin, o[1], rej, o[2], o[3], o[4], o[5], o[6], own, box))
                for name, k in w.walk.items():
                    if k:
                        print('         walk %-10s desc %5d  kclocks %8.1f = %6.2f ms  far %7.1f  ends %7.1f  lines %6d  empty %5d' % (name, k[0], k[1], k[1] * 0.01004, k[2], k[3], k[4], k[5]))
    print()

    priced = next((r for r in runs if r.prices), None)
    if priced is None:
        print('No price list in these logs (GPUBENCH=1 was not given): nothing to set the pixels against.')
        return 0
    p = priced.prices
    print('GPU PRICE LIST (from %s)' % priced.path.split('/')[-1])
    for k in sorted(p, key=lambda c: (c.isupper(), c)):
        name, us, wait, ns, ub, other = p[k]
        extra = ''
        if ns is not None:
            extra += '  %6.2f ns/px' % ns
        if ub is not None:
            extra += '  %4d us a bind' % ub
        if other is not None:
            extra += '  ' + other
        print('  %s %-42s %7d us (wait %7d)%s' % (k, name, us, wait, extra))
    for s in priced.price_says:
        print('  = %s' % s)

    def price(letter):
        return p[letter][3] if letter in p and p[letter][3] is not None else None
    opaque, blend_lm, blend_add, blend_alpha, flat2d = price('b'), price('i'), price('h'), price('g'), price('d')
    binds = [p[k][4] for k in 'nopq' if k in p and p[k][4] is not None]
    if opaque is None or blend_add is None:
        print('  (the list is incomplete: no estimate)')
        return 0
    bind_us = sum(binds) / len(binds) if binds else 0.0
    print()
    print('WHAT THE SUBMITTED LOAD WOULD COST AT THAT PRICE, ms per frame')
    print('  opaque pixels at line b, lightmap pass at line i, other blended pixels at line h (2D: line g), binds at the mean of n..q (%.0f us).' % bind_us)
    print('  An ESTIMATE: every submitted pixel is charged in full, the ones the depth test rejects included (line c is their real price).')
    for l in labels:
        for i, r in enumerate(runs):
            w = r.windows.get(l)
            if not w or not w.origins:
                continue
            t_op = t_bl = t_bind = 0.0
            for name, o in w.origins.items():
                if name == 'TOTAL':
                    continue
                t_op += o[2] * 1000.0 * (flat2d if name == '2D/HUD' and flat2d is not None else opaque) / 1e6
                bp = blend_lm if name == 'lightmaps' and blend_lm is not None else blend_alpha if name == '2D/HUD' and blend_alpha is not None else blend_add
                t_bl += o[3] * 1000.0 * bp / 1e6
                t_bind += o[4] * bind_us / 1000.0
            gw = w.parts[5] / 1000.0 if w.parts else 0.0
            print('  %s %-24s opaque %6.2f + blended %6.2f + binds %6.2f = %6.2f   | period %s, GPU waits %6.2f' % (
                chr(ord('A') + i), l[:24], t_op, t_bl, t_bind, t_op + t_bl + t_bind, ms(w.period), gw))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
