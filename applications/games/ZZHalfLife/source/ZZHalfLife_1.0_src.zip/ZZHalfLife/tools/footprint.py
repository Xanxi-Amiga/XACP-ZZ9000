#!/usr/bin/env python3
# footprint.py - ZZHalfLife: memory footprint of the engine image (zzhl_core.elf) by component,
# from the linker map and nm: text/rodata/data (in the file) and bss (cleared at load), plus the
# fixed areas of the arena. Written to the build log and docs/MEMOIRE.md reads from it. ASCII only.
import re, subprocess, sys
elf, mapf, nm_bin = sys.argv[1], sys.argv[2], sys.argv[3]
groups = {
    'engine (Xash3D common/client/server/public)': 'engine_', 'filesystem_stdio': 'filesystem_stdio.o',
    'ref_gl (+ref_common)': 'ref_gl.o', 'hlsdk server (hl.so)': 'server.o', 'hlsdk client (+FreeVGUI)': 'client.o',
    'xacp platform (fs, libc, video, input, gl table)': 'xacp_', 'librixgpu + ZZGL + GPU adapter + present': 'rix_',
    'newlib libc / libm / libgcc / libstdc++': '/lib/',
}
tot = {k: [0, 0, 0] for k in groups}   # text+rodata, data, bss
other = [0, 0, 0]
cur = None
sec_re = re.compile(r'^ (\.\w[\w.$]*)\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+(\S+)')
cont_re = re.compile(r'^\s+0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+(\S+)')
pending = None
for line in open(mapf, errors='replace'):
    m = sec_re.match(line)
    if m:
        name, addr, size, obj = m.group(1), int(m.group(2), 16), int(m.group(3), 16), m.group(4)
    else:
        m2 = re.match(r'^ (\.\w[\w.$]*)\s*$', line)
        if m2:
            pending = m2.group(1); continue
        m3 = cont_re.match(line)
        if m3 and pending:
            name, addr, size, obj = pending, int(m3.group(1), 16), int(m3.group(2), 16), m3.group(3); pending = None
        else:
            continue
    if size == 0 or addr == 0:
        continue
    if name.startswith('.text') or name.startswith('.rodata') or name.startswith('.ARM') or name.startswith('.init') or name.startswith('.zzhlhdr'):
        col = 0
    elif name.startswith('.data'):
        col = 1
    elif name.startswith('.bss') or name == 'COMMON' or name.startswith('COMMON'):
        col = 2
    else:
        continue
    hit = False
    for g, key in groups.items():
        if key == 'rix_' and ('/rix_' in obj or 'zzgl.o' in obj or 'zzhl_gpu' in obj or 'zzq2rix_mmu' in obj or 'zzhl_present' in obj):
            tot[g][col] += size; hit = True; break
        if key == 'xacp_' and ('xacp/' in obj and 'rix_' not in obj and 'zzgl' not in obj and 'zzhl_gpu' not in obj and 'zzq2rix' not in obj and 'zzhl_present' not in obj):
            tot[g][col] += size; hit = True; break
        if key not in ('rix_', 'xacp_') and key in obj:
            tot[g][col] += size; hit = True; break
    if not hit:
        other[col] += size
print("component                                              text+ro     data      bss")
for g in groups:
    t = tot[g]
    print("%-52s %9d %8d %9d" % (g, t[0], t[1], t[2]))
print("%-52s %9d %8d %9d" % ('other', other[0], other[1], other[2]))
T = [sum(tot[g][i] for g in groups) + other[i] for i in range(3)]
print("%-52s %9d %8d %9d" % ('TOTAL', T[0], T[1], T[2]))
syms = subprocess.run([nm_bin, '-S', '--size-sort', '-r', elf], capture_output=True, text=True).stdout.splitlines()
print("\nlargest bss objects:")
n = 0
for l in syms:
    p = l.split()
    if len(p) == 4 and p[2] in ('b', 'B'):
        print("  %9d  %s" % (int(p[1], 16), p[3])); n += 1
        if n >= 14: break
