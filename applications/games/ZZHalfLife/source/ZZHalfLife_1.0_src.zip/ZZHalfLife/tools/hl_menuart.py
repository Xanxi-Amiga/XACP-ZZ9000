#!/usr/bin/env python3
# hl_menuart.py - ZZHalfLife (build 52): draws the small pictures of the menu that Half-Life does not
# have and the FWGS menu (mainui) asks for in gfx/shell/: check boxes (cb_*), the arrows of the
# spin controls and of the lists (larrow*, rarrow*, uparrow*, dnarrow*) and the slider's knob.
# Xash3D's own set (xash-extras) comes from the WON Half-Life menu, Valve's: not shipped.  These
# are drawn here, plain shapes in the menu's colours (mainui's uiPromptTextColor 240 180 24), and
# are the port's own work: 0BSD, as this script.  Without them mainui draws nothing (invisible
# check boxes); its minimize/close buttons are left out of the menu instead (xacp/menu/Main.cpp).
#   python3 tools/hl_menuart.py [out dir]      (default: tools/menu, read by hl_pak.py --menu)
# Writes gfx/shell/<name>.tga, 24-bit, bottom line first.  Standard library only.  ASCII only.
import os, struct, sys

ORANGE = (240, 180, 24)
DARK = (20, 20, 20)

def tga(w, h, px):
    """px: rows top first, (r, g, b) tuples -> 24-bit TGA, bottom line first"""
    out = bytearray(struct.pack('<BBBHHBHHHHBB', 0, 0, 2, 0, 0, 0, 0, 0, w, h, 24, 0))
    for y in range(h - 1, -1, -1):
        for r, g, b in px[y * w:(y + 1) * w]:
            out += bytes((b, g, r))
    return bytes(out)

def canvas(w, h, c):
    return [c] * (w * h)

def mix(a, b, t):
    return tuple(int(round(x + (y - x) * t)) for x, y in zip(a, b))

def box(px, w, h, fill, border, bw):
    for y in range(h):
        for x in range(w):
            edge = x < bw or y < bw or x >= w - bw or y >= h - bw
            px[y * w + x] = border if edge else fill

def shape(px, w, h, inside, colour, ss=4):
    """paints colour where inside(x, y) holds, antialiased by ss x ss samples a pixel"""
    for y in range(h):
        for x in range(w):
            n = sum(1 for i in range(ss) for j in range(ss) if inside(x + (i + 0.5) / ss, y + (j + 0.5) / ss))
            if n:
                px[y * w + x] = mix(px[y * w + x], colour, n / float(ss * ss))

def triangle(a, b, c):
    def side(p, q, r): return (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])
    def inside(x, y):
        p = (x, y); d1, d2, d3 = side(a, b, p), side(b, c, p), side(c, a, p)
        return not ((d1 < 0 or d2 < 0 or d3 < 0) and (d1 > 0 or d2 > 0 or d3 > 0))
    return inside

def thick_line(points, r):
    def dist2(p, a, b):
        ax, ay = a; bx, by = b; px_, py = p
        dx, dy = bx - ax, by - ay
        t = max(0.0, min(1.0, ((px_ - ax) * dx + (py - ay) * dy) / float(dx * dx + dy * dy)))
        cx, cy = ax + t * dx, ay + t * dy
        return (px_ - cx) ** 2 + (py - cy) ** 2
    segs = list(zip(points, points[1:]))
    return lambda x, y: any(dist2((x, y), a, b) <= r * r for a, b in segs)

def checkbox(state):
    w = h = 32
    px = canvas(w, h, DARK)
    border = {'empty': (150, 150, 150), 'over': ORANGE, 'down': ORANGE, 'checked': (150, 150, 150), 'disabled': (70, 70, 70)}[state]
    fill = (60, 45, 10) if state == 'down' else DARK
    box(px, w, h, fill, border, 2)
    if state == 'checked':
        shape(px, w, h, thick_line([(8, 16.5), (13.5, 22), (24, 9.5)], 2.4), ORANGE)
    return w, h, px

def arrow(direction, state):
    w = h = 32
    px = canvas(w, h, DARK)
    box(px, w, h, DARK, (110, 110, 110) if state == 'd' else (200, 200, 200), 1)
    col = {'d': (190, 190, 190), 'f': (255, 255, 255), 'p': ORANGE}[state]
    tri = {'left': ((21, 8), (21, 24), (10, 16)), 'right': ((11, 8), (11, 24), (22, 16)),
           'up': ((8, 21), (24, 21), (16, 10)), 'down': ((8, 11), (24, 11), (16, 22))}[direction]
    shape(px, w, h, triangle(*tri), col)
    return w, h, px

def slider():
    w, h = 32, 16
    px = canvas(w, h, ORANGE)
    box(px, w, h, ORANGE, (120, 90, 12), 2)
    return w, h, px

def pictures():
    out = {}
    for s in ('empty', 'over', 'down', 'checked', 'disabled'):
        out['cb_' + s] = checkbox(s)
    for name, d in (('larrow', 'left'), ('rarrow', 'right')):
        for suffix, st in (('default', 'd'), ('flyover', 'f'), ('pressed', 'p')):
            out[name + suffix] = arrow(d, st)
    for name, d in (('uparrow', 'up'), ('dnarrow', 'down')):
        for st in ('d', 'f', 'p'):
            out[name + st] = arrow(d, st)
    out['slider'] = slider()
    return out

def main():
    top = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), 'menu')
    d = os.path.join(top, 'gfx', 'shell')
    os.makedirs(d, exist_ok=True)
    for name, (w, h, px) in sorted(pictures().items()):
        with open(os.path.join(d, name + '.tga'), 'wb') as f:
            f.write(tga(w, h, px))
    print('%d pictures in %s' % (len(pictures()), d))

if __name__ == '__main__':
    main()
