#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# gl_audit.py - ZZHalfLife: the OpenGL functions Half-Life's renderer uses, and what ZZGL does
# with each.  Writes docs/GL_COUVERTURE.md.
#
#   python3 tools/gl_audit.py <xash3d-fwgs> [<build/gen>] [-o docs/GL_COUVERTURE.md]
#
# Read from the sources, nothing is run:
#   - ref/gl/gl_opengl.c: the tables of the functions ref_gl asks for by name (GL 1.1 core, then
#     one table per extension);
#   - ref/gl/*.c and *.h: every call of a pglXxx function (the patched copies of build/gen are
#     read instead of the originals when they exist), and the modes given to the calls that
#     have several (glBegin, glBlendFunc, glEnable...);
#   - xacp/src/xacp_gl.c: the table that answers those names, and which answers are empty.
# What each function really does (complete, partial, empty) is the hand-kept table STATUS below:
# change it when xacp_gl.c, xacp_glq.c or zzgl.c change.  The script stops if a function of
# ref_gl's table has no entry in ours, or the other way round.
# ASCII only.
import collections, glob, os, re, sys

C, P, V, F = 'complet', 'partiel', 'vide', 'reponse fixe'
STATUS = {
 'glClearColor': (C, ''),
 'glClear': (C, 'couleur et profondeur ; la profondeur est sautee quand ZCLEAR a rendu le tampon propre ; le bit stencil est ignore'),
 'glAlphaFunc': (C, 'les 8 comparaisons ; ref_gl n\'utilise que GL_GREATER'),
 'glBlendFunc': (C, 'les 11 facteurs de GL 1.1 ont leur numero RasterIX ; ref_gl utilise 7 paires (section 4)'),
 'glCullFace': (C, 'fait dans ZZGL, par le signe de l\'aire du triangle'),
 'glFrontFace': (C, ''),
 'glDrawBuffer': (V, 'sans objet : un seul tampon de dessin'),
 'glReadBuffer': (V, 'sans objet'),
 'glAccum': (V, ''),
 'glEnable': (P, 'TEXTURE_2D (TEXTURE_1D traite comme 2D), DEPTH_TEST, BLEND, ALPHA_TEST, CULL_FACE, SCISSOR_TEST ; POLYGON_OFFSET_FILL emule ; FOG et STENCIL_TEST acceptes et ignores ; tout autre : GL_INVALID_ENUM compte et affiche a la sortie'),
 'glDisable': (P, 'comme glEnable'),
 'glEnableClientState': (P, 'VERTEX_ARRAY, COLOR_ARRAY, TEXTURE_COORD_ARRAY ; NORMAL_ARRAY ignore (pas d\'eclairage GL)'),
 'glDisableClientState': (P, 'comme glEnableClientState'),
 'glGetBooleanv': (F, '0, sauf ce que glGetIntegerv connait'),
 'glGetDoublev': (F, ''),
 'glGetFloatv': (P, 'MODELVIEW_MATRIX et PROJECTION_MATRIX ; autre : erreur comptee (GL_FOG_COLOR n\'est demande que par un chemin de mods)'),
 'glGetIntegerv': (F, 'MAX_TEXTURE_SIZE = 256 ; unites de texture = 1 ; tout le reste 0'),
 'glGetError': (C, ''),
 'glGetString': (C, 'version "1.1", aucune extension annoncee'),
 'glFinish': (C, 'vide la file de dessin du port ; la presentation attend le GPU de son cote'),
 'glFlush': (C, 'comme glFinish'),
 'glClearDepth': (C, ''),
 'glDepthFunc': (C, ''),
 'glDepthMask': (C, ''),
 'glDepthRange': (C, 'sert a l\'arme tenue en main'),
 'glDrawElements': (C, 'rejoue en mode immediat (tous les personnages passent par la)'),
 'glDrawArrays': (C, 'rejoue en mode immediat'),
 'glArrayElement': (C, ''),
 'glColorMask': (P, 'tout ou rien ; ref_gl ne demande que tout ou rien'),
 'glIndexPointer': (V, ''),
 'glNormalPointer': (V, 'pas d\'eclairage GL'),
 'glVertexPointer': (C, 'flottants'),
 'glColorPointer': (C, 'flottants ou octets'),
 'glTexCoordPointer': (C, 'flottants'),
 'glTexGenf': (V, ''), 'glTexGenfv': (V, ''),
 'glTexGeni': (V, 'offert aux mods par l\'API du rendu ; le rendu de Half-Life ne l\'appelle pas'),
 'glNormal3f': (V, ''),
 'glNormal3fv': (V, 'pas d\'eclairage GL ; les faisceaux en donnent, sans effet'),
 'glBegin': (P, 'TRIANGLES, TRIANGLE_STRIP, TRIANGLE_FAN, QUADS, QUAD_STRIP, POLYGON dessines ; POINTS, LINES, LINE_STRIP, LINE_LOOP acceptes et NON dessines'),
 'glEnd': (P, 'comme glBegin'),
 'glLineWidth': (V, 'les lignes ne sont pas dessinees'),
 'glPointSize': (V, 'les points ne sont pas dessines'),
 'glMatrixMode': (P, 'MODELVIEW et PROJECTION ; TEXTURE accepte mais la matrice de texture est ignoree'),
 'glRasterPos2f': (V, ''), 'glPushAttrib': (V, ''), 'glPopAttrib': (V, ''), 'glDrawPixels': (V, ''),
 'glReadPixels': (C, 'RGB et RGBA en octets (captures d\'ecran, vignettes de sauvegarde), lus dans la derniere image presentee'),
 'glStencilFunc': (V, 'le port annonce 0 bit de stencil : ref_gl ne prend pas ces chemins'),
 'glStencilMask': (V, ''), 'glStencilOp': (V, 'comme glStencilFunc'), 'glClearStencil': (V, ''),
 'glIsEnabled': (F, 'repond toujours 0 ; ses 3 appels portent sur GL_FOG'),
 'glIsList': (F, '0'),
 'glIsTexture': (F, 'vrai pour tout nom non nul'),
 'glTexEnvf': (P, 'MODULATE et REPLACE ; DECAL, ADD et COMBINE sont rendus en MODULATE'),
 'glTexEnvfv': (P, 'comme glTexEnvf'), 'glTexEnvi': (P, 'comme glTexEnvf'),
 'glTexParameterf': (P, 'MAG_FILTER (plus proche ou bilineaire), WRAP_S et WRAP_T (repetition ou bord) ; MIN_FILTER ignore : un seul niveau, pas de mipmaps ; les autres ignores'),
 'glTexParameterfv': (P, 'comme glTexParameterf'), 'glTexParameteri': (P, 'comme glTexParameterf'),
 'glHint': (V, 'sans objet'),
 'glPixelStoref': (V, ''), 'glPixelStorei': (V, ''),
 'glGenTextures': (C, '2 304 noms, les noms rendus sont reutilises'),
 'glDeleteTextures': (C, ''),
 'glBindTexture': (C, ''),
 'glTexImage1D': (P, 'traite comme une texture 2D d\'une ligne'),
 'glTexImage2D': (P, 'RGB et RGBA en octets, cotes en puissances de 2 de 8 a 256, niveau 0 seul (les niveaux de mipmap fournis sont jetes) ; stockee en 16 bits : RGB565, RGBA5551 ou RGBA4444'),
 'glTexSubImage1D': (C, ''),
 'glTexSubImage2D': (C, 'lightmaps dynamiques'),
 'glCopyTexImage1D': (V, ''), 'glCopyTexImage2D': (V, ''), 'glCopyTexSubImage1D': (V, ''), 'glCopyTexSubImage2D': (V, ''),
 'glScissor': (C, ''),
 'glViewport': (C, ''),
 'glGetTexImage': (V, ''),
 'glGetTexEnviv': (F, '0'), 'glGetTexLevelParameteriv': (F, '0'), 'glGetTexLevelParameterfv': (F, '0'), 'glGetClipPlane': (F, '0'),
 'glPolygonOffset': (P, 'emule dans la file de dessin : les sommets des decals sont rapproches de l\'oeil d\'un nombre constant de pas de profondeur ; le terme de pente n\'est pas modelise'),
 'glPolygonMode': (P, 'FILL ; en LINE ou POINT rien n\'est dessine (fil de fer de debug)'),
 'glPolygonStipple': (V, ''),
 'glClipPlane': (V, ''),
 'glShadeModel': (C, 'FLAT et SMOOTH'),
 'glFogfv': (V, 'brouillard non rendu (section 2)'), 'glFogf': (V, 'brouillard non rendu'), 'glFogi': (V, 'brouillard non rendu'),
}
for n in ('glColor3f glColor3fv glColor4f glColor4fv glColor3ub glColor4ub glColor4ubv glVertex2f glVertex3f glVertex3fv '
          'glTexCoord1f glTexCoord2f glTexCoord1fv glTexCoord2fv glOrtho glFrustum glPushMatrix glPopMatrix glLoadIdentity '
          'glLoadMatrixd glLoadMatrixf glMultMatrixd glMultMatrixf glRotated glRotatef glScaled glScalef glTranslated glTranslatef').split():
    STATUS.setdefault(n, (C, ''))
for n in 'glTexCoord3f glTexCoord4f glTexCoord3fv glTexCoord4fv'.split():
    STATUS.setdefault(n, (P, 's et t ; r et q ignores'))

EXT = collections.OrderedDict([
 ('multitexturefuncs', 'multitexture (deux textures a la fois) : lightmaps en deux passes a la place'),
 ('vbofuncs', 'tampons de sommets (VBO) : mode immediat et tableaux de sommets a la place'),
 ('mapbufferrangefuncs', 'VBO'), ('bufferstoragefuncs', 'VBO'), ('vaofuncs', 'VBO'),
 ('drawrangeelementsfuncs', 'glDrawRangeElements : glDrawElements a la place'), ('drawrangeelementsextfuncs', 'idem'),
 ('drawrangeelementsbasevertexfuncs', 'idem'),
 ('texture3dextfuncs', 'textures 3D : inutilisees par Half-Life'),
 ('texturecompressionfuncs', 'textures compressees : chargees non compressees'),
 ('multisampletexfuncs', 'anticrenelage multi-echantillons'),
 ('framebufferobjectfuncs', 'rendu dans une texture (FBO)'), ('framebufferblitfuncs', 'FBO'),
 ('framebuffermultisamplefuncs', 'FBO'), ('framebufferarbfuncs', 'FBO'),
 ('shaderobjectsfuncs', 'shaders : chemin GL 1.1 fixe a la place'), ('shaderobjectsfuncs_gles', 'shaders (GLES)'),
 ('multitexturefuncs_es', 'multitexture (GLES)'), ('multitexturefuncs_es2', 'multitexture (GLES2)'),
 ('debugoutputfuncs', 'messages de debug du pilote'),
])


def main():
    args = sys.argv[1:]
    out = 'docs/GL_COUVERTURE.md'
    if '-o' in args:
        i = args.index('-o'); out = args[i + 1]; del args[i:i + 2]
    if not args: sys.exit(__doc__ or 'usage: gl_audit.py <xash3d-fwgs> [<build/gen>] [-o file]')
    X = args[0]; GEN = args[1] if len(args) > 1 else 'build/gen'
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = open(os.path.join(X, 'ref/gl/gl_opengl.c'), encoding='utf-8', errors='replace').read()
    tables = collections.OrderedDict()
    for m in re.finditer(r'static (?:const )?dllfunc_t (\w+)\[\][^=]*=\s*\{(.*?)\n\};', src, re.S):
        tables[m.group(1)] = [a or b for a, b in re.findall(r'\{\s*GL_CALL\(\s*(\w+)\s*\)\s*\}|\{\s*"(\w+)"', m.group(2))]
    core = tables['opengl_110funcs']
    uses = collections.defaultdict(collections.Counter)
    text = {}
    patched = []
    for f in sorted(glob.glob(os.path.join(X, 'ref/gl/*.[ch]'))):
        name = os.path.basename(f)
        g = os.path.join(GEN, name)
        if os.path.exists(g): f = g; patched.append(name)
        t = open(f, encoding='utf-8', errors='replace').read()
        t = re.sub(r'/\*.*?\*/', '', t, flags=re.S); t = re.sub(r'//[^\n]*', '', t)
        text[name] = t
        if name in ('gl_opengl.c', 'gl_export.h'): continue
        for m in re.finditer(r'\bpgl([A-Z]\w+)\s*\(', t): uses['gl' + m.group(1)][name] += 1
    x = open(os.path.join(here, 'xacp/src/xacp_gl.c'), encoding='utf-8').read()
    bound = dict((n, k) for k, n in re.findall(r'\b([ZA])\( (\w+) \)', x[x.index('static const glent_t g_gl[]'):]))
    missing = [n for n in core if n not in bound]; extra = [n for n in bound if n not in core]; nostat = [n for n in core if n not in STATUS]
    if missing or extra or nostat:
        sys.exit('gl_audit: tables differ. Asked by ref_gl and not answered: %s; answered and not asked: %s; without a status here: %s' % (missing, extra, nostat))
    zz = open(os.path.join(here, 'zzgl/zzgl.c'), encoding='utf-8').read()
    ver = re.search(r'ZZGL (\d+\.\d+\.\d+)', open(os.path.join(here, 'xacp/src/xacp_video.c'), encoding='utf-8').read())

    def modes(rx):
        c = collections.Counter()
        for name, t in text.items():
            if name in ('gl_opengl.c', 'gl_export.h'): continue
            for m in re.finditer(rx, t): c[re.sub(r'\s+', ' ', m.group(1).strip())] += 1
        return c

    n_called = sum(1 for n in core if n in uses)
    cnt = collections.Counter(STATUS[n][0] for n in core)
    cnt_called = collections.Counter(STATUS[n][0] for n in core if n in uses)
    ext_fn = sum(len(tables[k]) for k in tables if k != 'opengl_110funcs')
    L = []
    w = L.append
    w('# ZZHalfLife - les fonctions OpenGL de Half-Life et ce que ZZGL en fait')
    w('')
    w('Fichier ecrit par `tools/gl_audit.py` a partir des sources (rien n\'est execute) :')
    w('`ref/gl` de Xash3D-FWGS 27092af%s, `xacp/src/xacp_gl.c`, `xacp/src/xacp_glq.c`, `zzgl/zzgl.c`%s.'
      % (' (avec les copies corrigees du build : %s)' % ', '.join(patched) if patched else '', ' (ZZGL %s)' % ver.group(1) if ver else ''))
    w('Tout le dessin de Half-Life passe par `ref/gl` : le code du jeu, le HUD, le menu et VGUI')
    w('n\'appellent jamais OpenGL eux-memes.')
    w('')
    w('## 1. En bref')
    w('')
    w('- Le rendu demande **%d fonctions OpenGL 1.1** par leur nom ; **les %d ont une reponse** dans' % (len(core), len(core)))
    w('  `xacp_gl.c`. Il en appelle %d dans son code ; les %d autres ne sont que demandees.' % (n_called, len(core) - n_called))
    w('- Des %d appelees : **%d completes, %d partielles, %d a reponse fixe, %d vides** (acceptees, sans effet).'
      % (n_called, cnt_called[C], cnt_called[P], cnt_called[F], cnt_called[V]))
    w('- Il demande aussi %d fonctions d\'extensions (%d groupes) : **aucune n\'est fournie**, volontairement. ref_gl' % (ext_fn, len(tables) - 1))
    w('  prend alors ses chemins OpenGL 1.1 : une texture a la fois, lightmaps en deux passes.')
    w('- Constat sur l\'A4000 : ZZGL compte tout mode qu\'il ne connait pas et l\'affiche a la sortie')
    w('  (`GL_INVALID_ENUM: ...`). Session de jeu du 15/11 (35 189 images, neuf cartes de c0a0 a c1a0d,')
    w('  puis c2a5f par un chargement rapide) : **aucun**. Ce que ce compteur avait trouve avant')
    w('  (les textures 1D, le 13/11) est corrige.')
    w('- **Donc : rien de ce que Half-Life appelle n\'est refuse, mais tout n\'est pas rendu.** Trois')
    w('  manques peuvent se voir dans le jeu (section 2) ; les autres ne touchent que des affichages')
    w('  de debug, des options eteintes par defaut ou les mods.')
    w('')
    w('## 2. Ce qui manque, par ordre d\'effet sur l\'image de Half-Life')
    w('')
    w('| manque | ou ref_gl s\'en sert | effet dans Half-Life | le GPU sait-il le faire ? |')
    w('|---|---|---|---|')
    w('| **Brouillard** (`glFog*`, `GL_FOG`) : %d appels, vides | sous l\'eau, ref_gl allume un brouillard de la couleur de la texture d\'eau (`R_CheckFog`, `gl_fog` vaut 1 par defaut) ; le ciel et les surfaces d\'eau l\'ajustent | **sous l\'eau, le brouillard colore n\'est pas dessine. Ce que cela donne a l\'ecran n\'a pas ete regarde : A VOIR sur l\'A4000 a un endroit ou l\'on nage** | le coeur RasterIX de XX19d-RIX est configure avec `ENABLE_FOG = 1` (lu dans le `.xci`, firmware non modifie) et `rix_hw.h` a les registres (`RIX_FEAT_FOG`, `RIX_OP_FOG_LUT`, `RIX_REG_FOG_COLOR`) ; ni librixgpu ni ZZGL ne s\'en servent, rien n\'a ete essaye sur l\'A4000 |'
      % sum(sum(uses[n].values()) for n in ('glFogf', 'glFogfv', 'glFogi')))
    w('| **Mipmaps** : ZZGL garde le niveau 0, `MIN_FILTER` ignore | ref_gl fournit tous les niveaux des textures du monde, des modeles, des sprites et des decals | les textures vues de loin ou en biais fourmillent quand on bouge (pas de filtrage en reduction) ; de pres, rien | `ENABLE_MIPMAPPING = 1` dans la meme configuration ; jamais valide (`rix_hw.h` : "min filter (mipmap) OFF") ; un tiers de texels en plus a envoyer a chaque changement de texture |')
    w('| **Textures en 16 bits** (RGB565, RGBA5551, RGBA4444), 256 de cote au plus | toutes les textures | degrades en paliers sur les sprites a transparence progressive (4 bits par canal en RGBA4444) : fumees, explosions, halos ; Half-Life n\'a pas de texture de plus de 256 | formats du GPU ; pas d\'autre choix a une TMU de cette taille |')
    w('| Lignes et points (`GL_LINES`, `GL_POINTS`, `glPolygonMode` en `LINE`) : non dessines | os et boites de collision des modeles (`r_drawentities` 2 a 7), fil de fer (`gl_wireframe`), modeles Quake (`gl_alias.c`), `TRI_LINES` / `TRI_POINTS` de l\'API offerte au code client | aucun en jeu : ce sont des affichages de debug ; le code client de Half-Life n\'utilise ni `TRI_LINES` ni `TRI_POINTS` | pas de primitive ligne ; il faudrait les dessiner en quads fins |')
    w('| Stencil (`glStencil*`) | ombres portees des modeles (`r_shadows`, 0 par defaut), decals sur les surfaces a trous | aucun : le port annonce 0 bit de stencil et ref_gl ne prend pas ces chemins, comme sur toute carte sans stencil | `ENABLE_STENCIL_BUFFER = 1` dans la configuration ; non utilise |')
    w('| Matrice de texture, `glTexGen`, `glTexEnv` en `DECAL` / `ADD` / `COMBINE` | textures de detail (il faut un fichier `maps/<carte>_detail.txt` : Half-Life n\'en a pas), chemin VBO (extension absente), modeles Quake, API des mods | aucun dans Half-Life | - |')
    w('| `glColorMask` par canal, `glIsEnabled` | ref_gl ne demande que tout ou rien ; `glIsEnabled` n\'est appele que sur `GL_FOG` | aucun | - |')
    w('')
    w('Les extensions absentes ne retirent rien a l\'image : elles coutent du temps (lightmaps en')
    w('deux passes, pas de VBO), pas des pixels.')
    w('')
    w('## 3. Les %d fonctions OpenGL 1.1' % len(core))
    w('')
    w('`appels` = nombre d\'endroits du code de ref_gl qui l\'appellent (0 = seulement demandee).')
    w('`complet` = fait ce qu\'OpenGL demande dans tout ce que ref_gl en utilise ; `partiel` = avec')
    w('les limites dites ; `reponse fixe` = une interrogation qui rend une constante ; `vide` =')
    w('acceptee, sans effet.')
    w('')
    w('| fonction | appels | reponse | remarque |')
    w('|---|---|---|---|')
    for n in core:
        st, rem = STATUS[n]
        w('| `%s` | %d | %s | %s |' % (n, sum(uses[n].values()) if n in uses else 0, '**%s**' % st if st == V and n in uses else st, rem))
    w('')
    w('Total : %d completes, %d partielles, %d a reponse fixe, %d vides.' % (cnt[C], cnt[P], cnt[F], cnt[V]))
    w('Vides ET appelees : %s.' % ', '.join('`%s` (%d)' % (n, sum(uses[n].values())) for n in core if STATUS[n][0] == V and n in uses))
    w('')
    w('## 4. Les modes que ref_gl donne a ces fonctions')
    w('')

    def table(title, rx, verdict):
        c = modes(rx)
        w('**%s**' % title); w('')
        w('| valeur | appels | ZZGL |'); w('|---|---|---|')
        for k, v in c.most_common():
            if not re.match(r'^[A-Z_0-9 ,x]+$', k): continue          # a variable: not a literal mode
            w('| `%s` | %d | %s |' % (k, v, verdict(k)))
        w('')
    table('`glBegin`', r'pglBegin\s*\(\s*([^)]*)\)',
          lambda k: 'NON dessine (debug)' if k in ('GL_LINES', 'GL_POINTS', 'GL_LINE_STRIP', 'GL_LINE_LOOP') else 'dessine')
    table('`glBlendFunc` (source, destination)', r'pglBlendFunc\s*\(\s*([^)]*)\)', lambda k: 'rendu')
    table('`glDepthFunc`', r'pglDepthFunc\s*\(\s*([^)]*)\)', lambda k: 'rendu')
    table('`glAlphaFunc`', r'pglAlphaFunc\s*\(\s*([^,]*),', lambda k: 'rendu')
    table('`glEnable`', r'pglEnable\s*\(\s*([^)]*)\)',
          lambda k: {'GL_FOG': 'ignore', 'GL_STENCIL_TEST': 'ignore', 'GL_POLYGON_OFFSET_FILL': 'emule'}.get(k, 'rendu' if k in ('GL_BLEND', 'GL_TEXTURE_2D', 'GL_ALPHA_TEST', 'GL_DEPTH_TEST', 'GL_CULL_FACE', 'GL_SCISSOR_TEST') else 'jamais atteint (extension absente)'))
    table('`glTexEnv`, mode', r'pglTexEnv[fi]\s*\(\s*GL_TEXTURE_ENV\s*,\s*GL_TEXTURE_ENV_MODE\s*,\s*([^)]*)\)',
          lambda k: 'rendu' if k in ('GL_MODULATE', 'GL_REPLACE') else 'rendu en MODULATE (detail, modeles Quake, multitexture)')
    table('`glTexParameter`, parametre', r'pglTexParameter[fi]v?\s*\(\s*[^,]*,\s*([^,]*),',
          lambda k: 'rendu' if k in ('GL_TEXTURE_MAG_FILTER', 'GL_TEXTURE_WRAP_S', 'GL_TEXTURE_WRAP_T') else 'ignore')
    table('`glMatrixMode`', r'pglMatrixMode\s*\(\s*([^)]*)\)', lambda k: 'ignoree' if k == 'GL_TEXTURE' else 'rendu')
    table('`glShadeModel`', r'pglShadeModel\s*\(\s*([^)]*)\)', lambda k: 'rendu')
    table('`glPolygonMode`', r'pglPolygonMode\s*\(\s*([^)]*)\)', lambda k: 'rendu' if 'FILL' in k else 'rien n\'est dessine (debug)')
    w('## 5. Les extensions, toutes absentes')
    w('')
    w('| groupe (table de `gl_opengl.c`) | fonctions | ce que ref_gl fait sans |')
    w('|---|---|---|')
    for k in tables:
        if k == 'opengl_110funcs': continue
        w('| `%s` | %d | %s |' % (k, len(tables[k]), EXT.get(k, '-')))
    w('')
    w('Le firmware a deux TMU (apres la v1.0) ouvrirait `multitexturefuncs` : une seule passe pour')
    w('le monde et ses lightmaps.')
    w('')
    w('## 6. Refaire ce fichier')
    w('')
    w('    python3 tools/gl_audit.py <xash3d-fwgs> build/gen')
    w('')
    w('Les colonnes `appels` et les tables de la section 4 sont comptees dans les sources. La colonne')
    w('`reponse` et les remarques sont la table `STATUS` du script, tenue a la main d\'apres')
    w('`xacp_gl.c`, `xacp_glq.c` et `zzgl.c` ; le script s\'arrete si une fonction demandee par ref_gl')
    w('n\'a pas de reponse chez nous, ou l\'inverse.')
    txt = '\n'.join(L) + '\n'
    bad = [c for c in txt if ord(c) > 127]
    if bad: sys.exit('gl_audit: non-ASCII characters in the output: %r' % sorted(set(bad)))
    with open(out, 'w', newline='\n') as f: f.write(txt)
    print('%s: %d functions, %d called (%d complete, %d partial, %d fixed, %d empty), %d extension functions in %d groups'
          % (out, len(core), n_called, cnt_called[C], cnt_called[P], cnt_called[F], cnt_called[V], ext_fn, len(tables) - 1))


if __name__ == '__main__':
    main()
