#!/usr/bin/env python3
# hl_pakcrc.py - ZZHalfLife build 37: the CRC-32 of every 64 KiB block of a pak, in <pak>.crc next to
# it.  Copied into PROGDIR:data/ with the pak, it lets the Core1 file layer (xacp/src/xacp_fs.c) check
# every block it reads from the pak and read again a block that arrived wrong.  Works on your own pak,
# on your PC (MSYS2 Python 3, standard library only); nothing is downloaded or sent anywhere.
#   python3 hl_pakcrc.py data/pak0.pak [data/pak1.pak ...]
# Format (little-endian): "ZZCRC1\0\0", block size (65536), pak size, block count, then one CRC-32
# (zlib.crc32) per block, the last block as long as what is left of the pak.
# Run it again whenever the pak is made again (hl_pak.py does it itself since build 37).
# ASCII only.
import os, struct, sys, zlib

BLOCK = 65536

def write_crc(pak):
    out = os.path.splitext(pak)[0] + '.crc'
    size = os.path.getsize(pak)
    crcs = []
    with open(pak, 'rb') as f:
        while True:
            b = f.read(BLOCK)
            if not b:
                break
            crcs.append(zlib.crc32(b) & 0xFFFFFFFF)
    with open(out, 'wb') as o:
        o.write(b'ZZCRC1\0\0' + struct.pack('<III', BLOCK, size, len(crcs)))
        o.write(struct.pack('<%dI' % len(crcs), *crcs))
    print('written %s: %d blocks of 64 KiB for %s (%d bytes)' % (out, len(crcs), pak, size))
    return out

def main():
    if len(sys.argv) < 2:
        print(__doc__ if __doc__ else 'usage: python3 hl_pakcrc.py <pak> [<pak> ...]')
        print('usage: python3 hl_pakcrc.py data/pak0.pak [data/pak1.pak ...]')
        return 1
    for pak in sys.argv[1:]:
        if not os.path.isfile(pak):
            print('no such file: %s' % pak)
            return 1
        with open(pak, 'rb') as f:
            if f.read(4) != b'PACK':
                print('%s: not a PACK file' % pak)
                return 1
        write_crc(pak)
    return 0

if __name__ == '__main__':
    sys.exit(main())
