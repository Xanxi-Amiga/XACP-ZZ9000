#!/usr/bin/env python3
# hl_loading.py - ZZHalfLife: make the loading screen picture from YOUR Half-Life files, on your
# PC (build 25). Nothing is downloaded, nothing is redistributed, nothing of Valve ships with
# ZZHalfLife: the picture is made from your own install and stays with you.
#   python3 hl_loading.py [-p preview.bmp] [--gain G] <Half-Life or valve dir> <out .tga>
# Recommended:  python3 hl_loading.py -p preview.bmp <valve dir> data/zzhl_loadscreen.tga
# What it does (Steam install with the 25th anniversary update):
#  - background: the tiles of resource/background/ - the set a resource/*BackgroundLoadingLayout.txt
#    names, else each <prefix>_<row>_<col>_loading.tga set by name; a set that is black to the last
#    pixel is skipped (Steam's 800_ set is); the tiles are put together, the middle 4:3 part is kept
#    and averaged down to 640 x 480 (grey);
#  - over it resource/logo.tga (HALF-LIFE, white, its shape in the alpha), 560 pixels wide, with a
#    soft glow made from its own shape. Its letters end at 42 % of the height: ZZHalfLife draws
#    LOADING, its bar and the console line under them (xacp/src/xacp_loading.c, LS_LOGO_BOTTOM).
#  - written as an 8-bit grey TGA (about 300 KiB, under the 512 KiB of the launcher's file
#    service), for PROGDIR:data/zzhl_loadscreen.tga, where ZZHalfLife looks for it.
# -p FILE: the same picture as a 24-bit BMP, to look at on the PC. --gain G: background brightness
# (1.0 = as Valve made it, dark; 1.5 = half again as bright). The logo is left as it is.
# Standard library only. ASCII only.
import os, struct, sys

OW, OH = 640, 480          # the picture; ZZHalfLife scales it to 320 x 240 itself
LOGO_W = 560               # the logo's width on the picture
LOGO_BOTTOM = 42           # percent of the height where the logo's letters end (xacp_loading.c)
LOGO_GREY = 235            # the logo's white
GLOW_R = 6                 # glow: two box blurs of this radius, at GLOW_K
GLOW_K = 1.1
ID = b'ZZHalfLife loadscreen 1: hl_loading.py, logo letters end at 42% of the height'

class Install:
    """The files of a valve/ folder, loose (they win, as in hl_pak.py) or in its .pak files."""
    def __init__(self, top):
        self.loose, self.pak = {}, {}
        for root, dirs, files in os.walk(top):
            for fn in files:
                full = os.path.join(root, fn)
                self.loose[os.path.relpath(full, top).replace('\\', '/').lower()] = full
        for fn in sorted(os.listdir(top)):
            if not fn.lower().endswith('.pak'):
                continue
            path = os.path.join(top, fn)
            with open(path, 'rb') as f:
                hdr = f.read(12)
                if hdr[:4] != b'PACK':
                    continue
                dofs, dlen = struct.unpack('<II', hdr[4:12])
                f.seek(dofs); d = f.read(dlen)
            for i in range(0, dlen - 63, 64):
                name = d[i:i + 56].split(b'\0', 1)[0].decode('latin-1').replace('\\', '/').lower()
                ofs, size = struct.unpack('<II', d[i + 56:i + 64])
                self.pak.setdefault(name, (path, ofs, size))
    def names(self):
        return set(self.loose) | set(self.pak)
    def has(self, name):
        n = name.lower()
        return n in self.loose or n in self.pak
    def read(self, name):
        n = name.lower()
        if n in self.loose:
            with open(self.loose[n], 'rb') as f:
                return f.read()
        path, ofs, size = self.pak[n]
        with open(path, 'rb') as f:
            f.seek(ofs); return f.read(size)

def tga_decode(d):
    """-> w, h, bytes per pixel, pixels top line first (B G R [A] or grey)"""
    if len(d) < 18:
        raise ValueError('not a TGA')
    idl, cmt, it = d[0], d[1], d[2]
    cml, cms = struct.unpack('<H', d[5:7])[0], d[7]
    w, h = struct.unpack('<HH', d[12:16])
    bpp, desc = d[16], d[17]
    n = bpp // 8
    if it in (2, 10) and n not in (3, 4) or it in (3, 11) and n != 1 or it not in (2, 3, 10, 11) or not w or not h:
        raise ValueError('TGA type %d, %d bits: not handled' % (it, bpp))
    pos = 18 + idl + (cml * ((cms + 7) // 8) if cmt else 0)
    total = w * h * n
    if it in (2, 3):
        px = d[pos:pos + total]
    else:
        out = bytearray()
        while len(out) < total and pos < len(d):
            c = d[pos]; pos += 1
            if c & 0x80:
                out += d[pos:pos + n] * ((c & 0x7f) + 1); pos += n
            else:
                k = ((c & 0x7f) + 1) * n; out += d[pos:pos + k]; pos += k
        px = bytes(out[:total])
    if len(px) < total:
        raise ValueError('TGA cut short')
    if not desc & 0x20:                       # stored bottom line first
        row = w * n
        px = b''.join(px[(h - 1 - y) * row:(h - y) * row] for y in range(h))
    return w, h, n, px

def grey_of(n, px):
    if n == 1:
        return bytes(px)
    b, g, r = px[0::n], px[1::n], px[2::n]
    if b == g == r:
        return bytes(b)
    return bytes((77 * rr + 150 * gg + 29 * bb) >> 8 for bb, gg, rr in zip(b, g, r))

def tokens(line):
    out, cur, q = [], '', False
    for ch in line:
        if ch == '"':
            q = not q
            if not q: out.append(cur); cur = ''
        elif ch in ' \t\r' and not q:
            if cur: out.append(cur); cur = ''
        else:
            cur += ch
    if cur: out.append(cur)
    return out

def tile_name(n):
    n = n.replace('\\', '/')
    return n if n.lower().endswith(('.tga', '.bmp')) else n + '.tga'

def sets_from_layouts(inst):
    """[(label, W, H, [(name, x, y)])] from every resource/*backgroundloadinglayout.txt, HD first"""
    out = []
    lays = sorted((n for n in inst.names() if n.startswith('resource/') and n.endswith('backgroundloadinglayout.txt')),
                  key=lambda n: (not os.path.basename(n).startswith('hd_'), n))
    for lay in lays:
        W = H = 0; tiles = []
        for line in inst.read(lay).decode('latin-1').split('\n'):
            t = tokens(line)
            if not t or t[0].startswith('//'):
                continue
            if t[0].lower() == 'resolution' and len(t) >= 3:
                W, H = int(t[1]), int(t[2])
            elif len(t) >= 4:
                try:
                    tiles.append((tile_name(t[0]), int(t[2]), int(t[3])))
                except ValueError:
                    pass
        if W > 0 and H > 0 and tiles:
            out.append((lay, W, H, tiles))
    return out

def sets_from_names(inst):
    """each resource/background/<prefix>_<row>_<col>_loading.tga set, the largest first"""
    groups = {}
    for n in inst.names():
        if not (n.startswith('resource/background/') and n.endswith('_loading.tga')):
            continue
        p = os.path.basename(n)[:-len('_loading.tga')].split('_')
        if len(p) < 3 or not p[-2].isdigit() or len(p[-1]) != 1 or not p[-1].isalpha():
            continue
        groups.setdefault('_'.join(p[:-2]), {})[(int(p[-2]), p[-1])] = n
    out = []
    for prefix, g in groups.items():
        rows = sorted({r for r, c in g}); cols = sorted({c for r, c in g})
        hgt, wid = {}, {}
        for (r, c), n in g.items():          # sizes from the headers: column widths, row heights
            d = inst.read(n)[:18]
            if len(d) == 18:
                w, h = struct.unpack('<HH', d[12:16])
                wid[c] = max(wid.get(c, 0), w); hgt[r] = max(hgt.get(r, 0), h)
        xs, x = {}, 0
        for c in cols: xs[c] = x; x += wid.get(c, 256)
        ys, y = {}, 0
        for r in rows: ys[r] = y; y += hgt.get(r, 256)
        out.append(('resource/background/%s_*_loading.tga' % prefix, x, y,
                    [(n, xs[c], ys[r]) for (r, c), n in sorted(g.items())]))
    return sorted(out, key=lambda s: -s[1] * s[2])

def compose(inst, W, H, tiles):
    """-> canvas, tiles placed, W, H; the canvas grows to the tiles if they go past the layout's
    resolution (a layout file whose numbers do not match its tiles still gives the whole picture)"""
    got = []
    for name, x0, y0 in tiles:
        if not inst.has(name) or not name.lower().endswith('.tga') or x0 < 0 or y0 < 0:
            continue
        try:
            w, h, n, px = tga_decode(inst.read(name))
        except ValueError as e:
            print('  %s: %s, skipped' % (name, e)); continue
        got.append((x0, y0, w, h, grey_of(n, px)))
    if got:
        ew, eh = max(x0 + w for x0, y0, w, h, g in got), max(y0 + h for x0, y0, w, h, g in got)
        if ew > W or eh > H:
            print('  the tiles go to %d x %d, past the %d x %d given: %d x %d used' % (ew, eh, W, H, max(W, ew), max(H, eh)))
            W, H = max(W, ew), max(H, eh)
    if W > 8192 or H > 8192:
        raise ValueError('canvas %d x %d too large' % (W, H))
    cv = bytearray(W * H)
    for x0, y0, w, h, g in got:
        for y in range(h):
            cv[(y0 + y) * W + x0:(y0 + y) * W + x0 + w] = g[y * w:(y + 1) * w]
    return cv, len(got), W, H

def taps(sn, dn):
    """area average from sn samples to dn: for each output, [(source index, weight)]"""
    s = sn / dn; out = []
    for i in range(dn):
        a, b = i * s, (i + 1) * s
        t, j = [], int(a)
        while j < b and j < sn:
            lo, hi = max(a, j), min(b, j + 1)
            if hi > lo: t.append((j, (hi - lo) / s))
            j += 1
        out.append(t)
    return out

def resample(src, sw, sh, dw, dh):
    tx, ty = taps(sw, dw), taps(sh, dh)
    rows = {}
    need = sorted({j for t in ty for j, w in t})
    for y in need:
        r = src[y * sw:(y + 1) * sw]
        rows[y] = [sum(r[j] * w for j, w in t) for t in tx]
    out = bytearray(dw * dh)
    for y, t in enumerate(ty):
        acc = [0.0] * dw
        for j, w in t:
            acc = [a + v * w for a, v in zip(acc, rows[j])]
        out[y * dw:(y + 1) * dw] = bytes(min(255, int(v + 0.5)) for v in acc)
    return out

def box_blur(m, w, h, r):
    """one box blur of radius r, horizontal then vertical, values as floats"""
    k = 2 * r + 1
    tmp = [0.0] * (w * h)
    for y in range(h):
        row = m[y * w:(y + 1) * w]; s = 0.0
        pre = [0.0]
        for v in row: s += v; pre.append(s)
        for x in range(w):
            a, b = max(0, x - r), min(w, x + r + 1)
            tmp[y * w + x] = (pre[b] - pre[a]) / k
    out = [0.0] * (w * h)
    for x in range(w):
        s = 0.0; pre = [0.0]
        for y in range(h): s += tmp[y * w + x]; pre.append(s)
        for y in range(h):
            a, b = max(0, y - r), min(h, y + r + 1)
            out[y * w + x] = (pre[b] - pre[a]) / k
    return out

def put_logo(pic, inst):
    """resource/logo.tga with its glow over pic (OW x OH grey); -> text for the report, or None"""
    if not inst.has('resource/logo.tga'):
        return None
    w, h, n, px = tga_decode(inst.read('resource/logo.tga'))
    if n != 4:
        print('  resource/logo.tga has no alpha, not used'); return None
    lh = max(1, round(h * LOGO_W / w))
    a = resample(px[3::4], w, h, LOGO_W, lh)
    rows = [y for y in range(lh) if max(a[y * LOGO_W:(y + 1) * LOGO_W]) > 64]
    cols = [x for x in range(LOGO_W) if max(a[x::LOGO_W]) > 64]
    if not rows:
        print('  resource/logo.tga is empty, not used'); return None
    lx = (OW - (cols[-1] - cols[0] + 1)) // 2 - cols[0]
    ly = OH * LOGO_BOTTOM // 100 - rows[-1]
    pad = 3 * GLOW_R; gw, gh = LOGO_W + 2 * pad, lh + 2 * pad
    m = [0.0] * (gw * gh)
    for y in range(lh):
        m[(y + pad) * gw + pad:(y + pad) * gw + pad + LOGO_W] = [float(v) for v in a[y * LOGO_W:(y + 1) * LOGO_W]]
    g = box_blur(box_blur(m, gw, gh, GLOW_R), gw, gh, GLOW_R)
    for y in range(gh):
        py = ly - pad + y
        if py < 0 or py >= OH: continue
        for x in range(gw):
            px_ = lx - pad + x
            if px_ < 0 or px_ >= OW: continue
            k = min(1.0, g[y * gw + x] * GLOW_K / 255.0)
            v = pic[py * OW + px_]
            v = v + (255 - v) * k                     # the glow, towards white
            if pad <= y < pad + lh and pad <= x < pad + LOGO_W:
                al = a[(y - pad) * LOGO_W + x - pad] / 255.0
                v = v * (1 - al) + LOGO_GREY * al     # the letters
            pic[py * OW + px_] = min(255, int(v + 0.5))
    return 'resource/logo.tga, letters %d..%d of %d' % (ly + rows[0], ly + rows[-1], OH)

def write_tga(path, pic):
    hdr = struct.pack('<BBBHHBHHHHBB', len(ID), 0, 3, 0, 0, 0, 0, 0, OW, OH, 8, 0x20)
    with open(path, 'wb') as f:
        f.write(hdr + ID + bytes(pic))

def write_bmp(path, pic):
    row = OW * 3
    body = b''.join(bytes(v for p in pic[(OH - 1 - y) * OW:(OH - y) * OW] for v in (p, p, p)) for y in range(OH))
    hdr = b'BM' + struct.pack('<IHHI', 54 + len(body), 0, 0, 54) + struct.pack('<IiiHHIIiiII', 40, OW, OH, 1, 24, 0, len(body), 2835, 2835, 0, 0)
    with open(path, 'wb') as f:
        f.write(hdr + body)

def main(argv):
    preview, gain, args = None, 1.0, []
    i = 0
    while i < len(argv):
        if argv[i] == '-p' and i + 1 < len(argv): preview = argv[i + 1]; i += 2
        elif argv[i] == '--gain' and i + 1 < len(argv): gain = float(argv[i + 1]); i += 2
        else: args.append(argv[i]); i += 1
    if len(args) != 2:
        print(open(__file__).read().split('import os')[0]); return 2
    top, outp = args
    if not os.path.isdir(os.path.join(top, 'resource')) and os.path.isdir(os.path.join(top, 'valve')):
        top = os.path.join(top, 'valve')
    if not os.path.isdir(top):
        print('%s: no such folder' % top); return 1
    inst = Install(top)
    pic, used = None, None
    for label, W, H, tiles in sets_from_layouts(inst) + sets_from_names(inst):
        try:
            cv, placed, W, H = compose(inst, W, H, tiles)
        except ValueError as e:
            print('%s: %s - skipped' % (label, e)); continue
        if not placed:
            print('%s: no tile found' % label); continue
        if max(cv) < 24:
            print('%s: %d tiles, %d x %d, black - skipped' % (label, placed, W, H)); continue
        if W * 3 > H * 4:                      # wider than 4:3: the middle part
            cw = round(H * 4 / 3); x0 = (W - cw) // 2
            cv = b''.join(cv[y * W + x0:y * W + x0 + cw] for y in range(H)); W = cw
        elif W * 3 < H * 4:
            ch = round(W * 3 / 4); y0 = (H - ch) // 2
            cv = cv[y0 * W:(y0 + ch) * W]; H = ch
        print('%s: %d tiles, middle %d x %d -> %d x %d' % (label, placed, W, H, OW, OH))
        pic = resample(cv, W, H, OW, OH); used = label
        break
    if pic is None:
        print('no loading picture in this install: the logo on black')
        pic = bytearray(OW * OH)
    elif gain != 1.0:
        pic = bytearray(min(255, int(v * gain + 0.5)) for v in pic)
    logo = put_logo(pic, inst)
    print('logo: %s' % (logo or 'none (no resource/logo.tga with alpha) - LOADING still goes under 42 %'))
    if used is None and logo is None:
        print('nothing to make: neither loading tiles nor resource/logo.tga (not a Steam install with'
              ' the 25th anniversary update?). ZZHalfLife shows the game title instead.')
        return 1
    write_tga(outp, pic)
    print('%s written: %d x %d grey, %d bytes - copy it to PROGDIR:data/zzhl_loadscreen.tga' % (outp, OW, OH, os.path.getsize(outp)))
    if preview:
        write_bmp(preview, pic); print('%s written (to look at on the PC)' % preview)
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
