#!/usr/bin/env python3
# hl_menubg.py - ZZHalfLife (build 52): the background of the menu, made from YOUR Half-Life files on
# your PC, for tools/hl_pak.py --menu.  Nothing is downloaded, nothing of Valve ships with ZZHalfLife.
#   python3 hl_menubg.py <Half-Life or valve dir> <out dir>      (hl_pak.py --menu calls build())
# Why: the menu (FWGS mainui) draws the background of the 25th anniversary update from
# resource/HD_BackgroundLayout.txt, dozens of 21:9 tiles that stay in the RasterIX texture memory
# (16 MiB) while the game runs: 13.7 MiB of it on the A4000 (12/11), and the map's sky, HUD and
# walls no longer fitted.  Here: the picture that layout gives, its middle 4:3 part (what mainui
# shows of a wide background on a 640x480 screen), averaged down to 512 x 384, in four tiles
# (256x256 twice, 256x128 twice: 384 KiB of texture memory), named by our own
# resource/BackgroundLayout.txt ("resolution 512 384": mainui scales it to the screen).  The engine
# side (xacp/dll/zzhl_menu_wrap.cpp) clears the menu's HD background flag, so that file is the one
# read.  Without an HD layout, the classic resource/BackgroundLayout.txt set is used the same way;
# a set black to the last pixel (Steam's 800_ tiles since that update) is skipped.
# Writes <out dir>/resource/BackgroundLayout.txt and <out dir>/resource/background/zzhl_menu_*.tga
# (24-bit TGA, bottom line first, as mainui loads the tiles: PIC_NOFLIP_TGA).
# Code by the ZZHalfLife port, 0BSD.  Standard library only.  ASCII only.
import os, struct, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hl_loading import Install, tga_decode, tokens, tile_name, taps

OUT_W, OUT_H = 512, 384
TILES = [('zzhl_menu_1_a', 0, 0, 256, 256), ('zzhl_menu_1_b', 256, 0, 256, 256),
         ('zzhl_menu_2_a', 0, 256, 256, 128), ('zzhl_menu_2_b', 256, 256, 256, 128)]
LAYOUTS = ['resource/hd_backgroundlayout.txt', 'resource/backgroundlayout.txt']

def read_layout(inst, name):
    """-> W, H, [(tile, x, y)] of a mainui background layout ("resolution W H", then "<tga> scaled x y")"""
    W = H = 0; tiles = []
    for line in inst.read(name).decode('latin-1').split('\n'):
        t = tokens(line)
        if not t or t[0].startswith('//'):
            continue
        if t[0].lower() == 'resolution' and len(t) >= 3:
            W, H = int(t[1]), int(t[2])
        elif len(t) >= 4:
            try:
                tiles.append((tile_name(t[0]), int(t[2]), int(t[3])))
            except ValueError:
                pass
    return W, H, tiles

def compose_rgb(inst, W, H, tiles):
    """-> the layout's picture, W x H, 3 bytes a pixel (R G B), and the number of tiles found"""
    cv = bytearray(W * H * 3); got = 0
    for name, x0, y0 in tiles:
        if not inst.has(name) or x0 < 0 or y0 < 0:
            continue
        try:
            w, h, n, px = tga_decode(inst.read(name))
        except ValueError as e:
            print('  %s: %s, skipped' % (name, e)); continue
        got += 1
        for y in range(min(h, H - y0)):
            row = px[y * w * n:(y + 1) * w * n]
            ww = min(w, W - x0)
            d = (y0 + y) * W * 3 + x0 * 3
            if n == 1:
                g = row[:ww]
                cv[d:d + ww * 3:3] = g; cv[d + 1:d + ww * 3:3] = g; cv[d + 2:d + ww * 3:3] = g
            else:
                cv[d:d + ww * 3:3] = row[2:ww * n:n]          # R
                cv[d + 1:d + ww * 3:3] = row[1:ww * n:n]      # G
                cv[d + 2:d + ww * 3:3] = row[0:ww * n:n]      # B
    return cv, got

def resample_rgb(src, sw, sh, x0, y0, cw, ch, dw, dh):
    """area average of the cw x ch part at x0, y0 of src (sw wide, RGB) to dw x dh"""
    tx, ty = taps(cw, dw), taps(ch, dh)
    rows = {}
    for y in sorted({j for t in ty for j, w in t}):
        base = ((y0 + y) * sw + x0) * 3
        r = src[base:base + cw * 3]
        rows[y] = [tuple(sum(r[j * 3 + c] * w for j, w in t) for c in range(3)) for t in tx]
    out = bytearray(dw * dh * 3)
    for y, t in enumerate(ty):
        acc = [[0.0, 0.0, 0.0] for _ in range(dw)]
        for j, w in t:
            for x, v in enumerate(rows[j]):
                a = acc[x]; a[0] += v[0] * w; a[1] += v[1] * w; a[2] += v[2] * w
        o = y * dw * 3
        out[o:o + dw * 3] = bytes(min(255, int(c + 0.5)) for a in acc for c in a)
    return out

def tga24(w, h, rgb_top_first, x0, y0, W):
    """a 24-bit TGA of the w x h part at x0, y0 of an RGB picture W wide, bottom line first"""
    hdr = struct.pack('<BBBHHBHHHHBB', 0, 0, 2, 0, 0, 0, 0, 0, w, h, 24, 0)
    body = bytearray()
    for y in range(h - 1, -1, -1):
        o = ((y0 + y) * W + x0) * 3
        row = rgb_top_first[o:o + w * 3]
        bgr = bytearray(w * 3)
        bgr[0::3] = row[2::3]; bgr[1::3] = row[1::3]; bgr[2::3] = row[0::3]
        body += bgr
    return hdr + bytes(body)

def build(top):
    """-> {name in the pak: bytes} (the layout and the four tiles), or {} when the install has none"""
    inst = Install(top)
    for lay in LAYOUTS:
        if not inst.has(lay):
            continue
        W, H, tiles = read_layout(inst, lay)
        if W <= 0 or H <= 0 or not tiles:
            print('menu background: %s has no tiles, skipped' % lay); continue
        cv, got = compose_rgb(inst, W, H, tiles)
        if not got or not any(cv):
            print('menu background: %s: %d tiles found, all black, skipped' % (lay, got)); continue
        if W * 3 > H * 4:      # wider than 4:3: the middle part, as mainui centres it
            cw, ch = H * 4 // 3, H; x0, y0 = (W - cw) // 2, 0
        else:
            cw, ch = W, W * 3 // 4; x0, y0 = 0, (H - ch) // 2
        pic = resample_rgb(cv, W, H, x0, y0, cw, ch, OUT_W, OUT_H)
        files = {}
        layout = ['// ZZHalfLife: made by tools/hl_menubg.py from %s (%d x %d, %d tiles), its middle %d x %d' % (lay, W, H, got, cw, ch),
                  'resolution %d %d' % (OUT_W, OUT_H)]
        for name, tx, ty, tw, th in TILES:
            files['resource/background/%s.tga' % name] = tga24(tw, th, pic, tx, ty, OUT_W)
            layout.append('resource/background/%s.tga scaled %d %d' % (name, tx, ty))
        files['resource/BackgroundLayout.txt'] = ('\n'.join(layout) + '\n').encode('latin-1')
        print('menu background: %s, %d x %d, %d tiles -> 512 x 384 in 4 tiles' % (lay, W, H, got))
        return files
    print('menu background: no background layout with pictures in this install (the menu draws a plain colour)')
    return {}

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(open(__file__).read().split('import os')[0]); sys.exit(2)
    for n, d in build(sys.argv[1]).items():
        p = os.path.join(sys.argv[2], n); os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, 'wb').write(d)
