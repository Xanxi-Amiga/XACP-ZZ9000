#!/bin/sh
# cc_one.sh <engine source> : compile one engine unit with the build_arm.sh engine flags (debug aid)
cd "$(dirname "$0")/.."
X="${XASH3D:-../../../../xash3d-fwgs}"; H="${HLSDK:-../../../../hlsdk-portable}"; B=build
eval "$(sed -n '/^ARCH=/,/^CLFLAGS=/p' build_arm.sh | grep -v '^#')"
arm-none-eabi-gcc $ENGFLAGS -c "$1" -o /tmp/one.o
