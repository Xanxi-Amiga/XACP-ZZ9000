#!/bin/sh
# triage_arm.sh - ZZHalfLife: compile every Xash3D-FWGS / HLSDK unit for the Core1 target,
# never stop on an error, keep one log per unit.  Audit tool, not the production build.
# XASH3D=<xash3d-fwgs tree>  HLSDK=<hlsdk-portable tree>  OUT=<build dir>
set -u
cd "$(dirname "$0")/.."
X="${XASH3D:-../../../../xash3d-fwgs}"
H="${HLSDK:-../../../../hlsdk-portable}"
B="${OUT:-build_triage}"
AGCC=${AGCC:-arm-none-eabi-gcc}
AGXX=${AGXX:-arm-none-eabi-g++}
ARCH="-mcpu=cortex-a9 -marm -mfpu=vfpv3-d16 -mfloat-abi=hard -mno-unaligned-access -fno-short-enums"
COMMON="$ARCH -O2 -ffunction-sections -fdata-sections -fno-strict-aliasing -fwrapv -fno-tree-vectorize \
 -Wno-error -w -DXASH_NO_NETWORK=1 -DXASH_STATIC_LIBS=1 -DXASH_LOW_MEMORY=0 -DXASH_NO_LIBDL=1"
INC_ENGINE="-Ixacp/include -I$X/engine -I$X/engine/common -I$X/engine/common/imagelib -I$X/engine/server \
 -I$X/engine/client -I$X/engine/client/vgui -I$X/engine/common/soundlib -I$X/engine/platform -I$X/public \
 -I$X/common -I$X/filesystem -I$X/pm_shared -I$X/3rdparty/library_suffix/include -I$X/3rdparty/miniz \
 -I$X/3rdparty/MultiEmulator/include -I$X/3rdparty/mbedtls/mbedtls/include"
rm -rf "$B"; mkdir -p "$B/log"
ok=0; bad=0; BADLIST=""
cc1() { # cc1 <compiler> <flags> <src> <objname>
    if $1 $2 -c "$3" -o "$B/$4.o" > "$B/log/$4.log" 2>&1; then ok=$((ok+1)); rm -f "$B/log/$4.log"
    else bad=$((bad+1)); BADLIST="$BADLIST $4"; fi
}
objname() { echo "$1" | sed "s#^$X/##; s#^$H/##" | tr '/.' '__'; }

echo "== engine (common, imagelib, soundlib, server, http, client) =="
for f in $X/engine/common/*.c $X/engine/common/imagelib/*.c $X/engine/common/soundlib/*.c \
         $X/engine/server/*.c $X/engine/common/http/*.c $X/engine/client/*.c $X/engine/client/*/*.c \
         $X/engine/platform/misc/lib_static.c; do
    case "$f" in */avi_ffmpeg.c|*/net_http_tls.c) continue;; esac
    cc1 "$AGCC" "$COMMON -DENGINE_DLL=1 $INC_ENGINE" "$f" "$(objname $f)"
done
echo "== public =="
for f in $X/public/*.c; do cc1 "$AGCC" "$COMMON $INC_ENGINE" "$f" "$(objname $f)"; done
echo "== filesystem =="
for f in $X/filesystem/*.c; do cc1 "$AGCC" "$COMMON $INC_ENGINE" "$f" "$(objname $f)"; done
echo "== miniz =="
for f in $X/3rdparty/miniz/*.c; do cc1 "$AGCC" "$COMMON $INC_ENGINE" "$f" "$(objname $f)"; done
echo "== ref/common, ref/gl =="
for f in $X/ref/common/*.c $X/ref/gl/*.c; do
    cc1 "$AGCC" "$COMMON -DREF_DLL=1 $INC_ENGINE -I$X/ref/common -I$X/ref/gl" "$f" "$(objname $f)"
done
echo "== hlsdk: dlls (server), cl_dll (client), pm_shared, game_shared =="
HINC="-Ixacp/include -I$H/common -I$H/engine -I$H/public -I$H/pm_shared -I$H/game_shared -I$H/dlls -I$H/cl_dll -I$H/utils/false_vgui/include"
CXXF="$COMMON -std=gnu++11 -fno-exceptions -fno-rtti -fpermissive -DCLIENT_WEAPONS -DNO_VOICEGAMEMGR"
for f in $H/dlls/*.cpp $H/dlls/wpn_shared/*.cpp $H/pm_shared/*.c $H/game_shared/*.cpp; do
    cc1 "$AGXX" "$CXXF $HINC -DNDEBUG" "$f" "sv_$(objname $f)"
done
for f in $H/cl_dll/*.cpp $H/cl_dll/hl/*.cpp $H/pm_shared/*.c $H/game_shared/*.cpp; do
    cc1 "$AGXX" "$CXXF $HINC -DCLIENT_DLL -I$H/cl_dll/hl" "$f" "cl_$(objname $f)"
done
echo; echo "compiled OK: $ok   failed: $bad"
echo "$BADLIST" | tr ' ' '\n' | sed '/^$/d' > "$B/failed.txt"
cat "$B/failed.txt"
