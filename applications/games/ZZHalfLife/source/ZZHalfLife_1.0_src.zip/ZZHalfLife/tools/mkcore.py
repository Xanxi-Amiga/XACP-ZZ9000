#!/usr/bin/env python3
# mkcore.py - ZZHalfLife: fills the header of the engine image (zzhl_core.bin, stage 2) after the
# link: image size, bss bounds, entry, CRC-32 of the image after the header. The loader
# (Core1/zzhl_glue.c) checks all of them before it jumps. ASCII only.
import struct, sys, zlib
bin_path, map_path, nm_path, out_path = sys.argv[1:5]
ENTRY = sys.argv[5] if len(sys.argv) > 5 else 'zzhl_core_entry'   # build 103: zzhl_game_entry for zzhl_game.bin
syms = {}
for line in open(nm_path):
    parts = line.split()
    if len(parts) >= 3:
        syms[parts[2]] = int(parts[0], 16)
img = bytearray(open(bin_path, 'rb').read())
HDR = 64
m0, m1, ver, hsz, load = struct.unpack('<5I', img[0:20])
assert m0 == 0x4C48525A and m1 in (0x45524F43, 0x454D4147) and hsz == HDR, "not a ZZHalfLife core or game image header"
while len(img) % 16:
    img.append(0)
size = len(img)
bss_start, bss_end, entry = syms['_bss_start'], syms['_bss_end'], syms[ENTRY]
assert load + size <= bss_start + 32, "image overlaps its own bss"
crc = zlib.crc32(bytes(img[HDR:])) & 0xFFFFFFFF
img[20:40] = struct.pack('<5I', size, bss_start, bss_end, entry, crc)
open(out_path, 'wb').write(img)
print("mkcore: %s: %u bytes, load %08x..%08x, bss %08x..%08x (%u KiB), entry %08x, crc %08x" % (
    out_path, size, load, load + size, bss_start, bss_end, (bss_end - bss_start) // 1024, entry, crc))
