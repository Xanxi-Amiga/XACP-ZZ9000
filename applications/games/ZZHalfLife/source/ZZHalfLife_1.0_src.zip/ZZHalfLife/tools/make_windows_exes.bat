@echo off
rem ZZHalfLife - publisher PC only: makes ZZHalfLife-Data.exe from zzhl_data.py.
rem Needs the native Windows Python (not MSYS2's) with, once:
rem     python -m pip install pyinstaller lameenc miniaudio
rem End users need nothing: the .exe holds Python, the tools, the chapter lists, the menu files
rem and the MP3 encoder (LAME, through lameenc) and decoder (miniaudio).
setlocal
pushd "%~dp0"
python -c "import sys; assert sys.platform == 'win32'" >nul 2>nul
if errorlevel 1 (
 echo ERROR: native Windows Python not found.
 popd
 exit /b 1
)
python -c "import PyInstaller, lameenc, miniaudio" >nul 2>nul
if errorlevel 1 (
 echo ERROR: missing packages. Run: python -m pip install pyinstaller lameenc miniaudio
 popd
 exit /b 1
)
rem 16/11: an .exe made in a folder without hl_precache_table.py failed on the user's PC, not here.
for %%F in (zzhl_data.py zzhl_ref.py hl_pak.py hl_chlayout.py hl_chapters.py hl_precache_table.py hl_pakcrc.py hl_menubg.py hl_loading.py hl_paklist.py) do (
 if not exist "%~dp0%%F" (
  echo ERROR: %%F is missing from this folder.
  popd
  exit /b 1
 )
)
python -m PyInstaller --onefile --clean --noconfirm --name ZZHalfLife-Data --distpath . --workpath _WIN_build\data --specpath _WIN_build ^
 --paths "%~dp0." --add-data "%~dp0chapters;chapters" --add-data "%~dp0menu;menu" --add-data "%~dp0zzhl_data.py;." ^
 --hidden-import hl_pak --hidden-import hl_chlayout --hidden-import hl_chapters --hidden-import hl_precache_table --hidden-import hl_pakcrc ^
 --hidden-import hl_menubg --hidden-import hl_loading --hidden-import hl_paklist --hidden-import zzhl_ref --hidden-import _cffi_backend zzhl_data.py
if errorlevel 1 goto :failed
echo ZZHalfLife-Data.exe ready.
popd
exit /b 0
:failed
echo ERROR: Windows EXE build failed.
popd
exit /b 1
