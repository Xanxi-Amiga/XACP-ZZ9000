#!/usr/bin/env python3
# hl_chlayout.py - ZZHalfLife (build 45): pak0.pak laid out by chapter, for hl_pak.py --chapters.
# The reference lists (tools/chapters/zzhl_chNN.lst, made once on the A4000 by SURVEY=1: names and
# sizes of what each chapter's maps load, no data of the game) say what each chapter needs; to them
# this adds, by rule, what Half-Life reads only while it is played:
#   - the texture model and the animation files of every model (xT.mdl, x01.mdl ...);
#   - the words of the sentences the chapter's characters can say (sentences.txt, the sentence
#     groups of each entity class of its maps - tools/hl_precache_table.py - and the sentences its
#     maps name), the HEV suit's voice;
#   - decals.wad whole, the HUD's sprites and lists.
# Layout: what every chapter needs first, then each chapter's files in the order of the game, then
# the rest; a .wad is written again with its textures in the same order (the engine reads a .wad
# through its directory: the order of the textures is free).  Next to the pak, <pak>.chp: for each
# chapter the ranges of the pak to read when it opens (xacp/src/xacp_fs.c).  The same install gives
# the same bytes: every order is sorted, nothing depends on the time or the machine.
# Format of .chp (little-endian): "ZZCHP1\0\0", pak size, chapter count; per chapter: number,
# range count, bytes, then (offset, length) per range.  Build 46: number 255 is the common part
# (what every chapter needs, the HEV voice, HUD, decals), read once, at the first chapter opened;
# a chapter's ranges leave it out - the engine keeps most of it in its own memory once loaded.
# Code by the ZZHalfLife port, 0BSD.  ASCII only.
import os, re, struct, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hl_chapters as hc

GAME_ORDER = list(range(1, 20)) + [0, 20]      # the campaign, the Hazard Course, then Uplink
# build 78: a chapter absent from GAME_ORDER is dropped WITHOUT A WORD further down
# (chs = [c for c in GAME_ORDER if c in lists]), so Uplink has to be named here too.
HUD_LISTS = re.compile(r'^sprites/.*\.txt$')

class Source:
    """the entries of hl_pak.py (name -> (name, file, offset, size)) as hl_chapters' Pak"""
    def __init__(self, entries): self.idx = {k: (v[1], v[2], v[3]) for k, v in entries.items()}; self.e = entries
    def has(self, n): return n.lower() in self.idx
    def size(self, n): return self.idx[n.lower()][2]
    def read(self, n, start=0, length=None):
        p, ofs, size = self.idx[n.lower()]
        if length is None: length = size - start
        with open(p, 'rb') as f:
            f.seek(ofs + start); return f.read(max(0, min(length, size - start)))

def load_lists(d):
    out = {}
    for fn in sorted(os.listdir(d)):
        m = re.match(r'zzhl_ch(\d\d)\.lst$', fn)
        if not m: continue
        c = int(m.group(1))
        ch = {'f': {}, 'w': {}, 'd': {}, 'maps': []}
        for line in open(os.path.join(d, fn), encoding='latin-1'):
            line = line.rstrip('\n')
            if line.startswith('#'):
                mm = re.search(r'- maps (.*)$', line)
                if mm: ch['maps'] = mm.group(1).split()
                continue
            t = line.split(' ')
            if len(t) < 3 or not t[-1].isdigit(): continue
            size = int(t[-1])                       # a name can hold spaces: the size is the last word
            if t[0] == 'f': ch['f'][' '.join(t[1:-1]).lower()] = size
            elif t[0] == 'd': ch['d'][' '.join(t[1:-1]).lower()] = size
            elif t[0] == 'w' and len(t) >= 4: ch['w'].setdefault(t[1].lower(), {})[' '.join(t[2:-1]).lower()] = size
        out[c] = ch
    return out

def parse_wad(data):
    if data[:4] not in (b'WAD3', b'WAD2'): return None
    n, io = struct.unpack('<ii', data[4:12])
    lumps = []
    for i in range(n):
        e = data[io + 32 * i: io + 32 * i + 32]
        fp, ds, sz = struct.unpack('<iii', e[:12])
        lumps.append({'name': e[16:32].split(b'\0', 1)[0].decode('latin-1').lower(), 'raw': e, 'data': data[fp:fp + ds]})
    return data[:4], lumps

def write_wad(magic, lumps):
    """the lumps in this order; returns the bytes and each lump's (offset, length) in the file"""
    body, pos, where = [], 12, {}
    for l in lumps:
        where[l['name']] = (pos, len(l['data']))
        body.append(l['data']); pos += len(l['data'])
        while pos % 4: body.append(b'\0'); pos += 1
    dir_ = []
    for l in lumps:
        r = l['raw']
        dir_.append(struct.pack('<i', where[l['name']][0]) + r[4:])
    return magic + struct.pack('<ii', len(lumps), pos) + b''.join(body) + b''.join(dir_), where, (pos, 32 * len(lumps))

def rules(src, lists, report):
    """what each chapter reads while played, added to its lists"""
    sent = hc.sentences(src)
    common_f = set()
    for n in src.idx:
        if n.startswith('sound/fvox/') or HUD_LISTS.match(n) or n.startswith('sprites/640'): common_f.add(n)
        if HUD_LISTS.match(n):
            for line in src.read(n).decode('latin-1', 'replace').splitlines():
                t = line.split()
                if len(t) >= 3 and src.has('sprites/%s.spr' % t[2].lower()): common_f.add('sprites/%s.spr' % t[2].lower())
    for c, ch in lists.items():
        add = set()
        for f in list(ch['f']):
            if f.endswith('.mdl'):
                base = f[:-4]
                if src.has(base + 't.mdl'): add.add(base + 't.mdl')
                for i in range(1, 32):
                    if src.has('%s%02d.mdl' % (base, i)): add.add('%s%02d.mdl' % (base, i))
                    else: break
        groups = set()
        for m in ch['maps']:
            if not src.has('maps/%s.bsp' % m): continue
            ver, ents, tex = hc.bsp_info(src, m)
            for e in ents:
                cl = e.get('classname', '')
                if cl in hc.PRECACHE: groups |= hc.class_closure(cl)[1]
                for k, v in e.items():
                    if v.startswith('!') or (k == 'sentence' and v): groups.add(v)
        for g in groups:
            add |= {w for w in hc.group_words(sent, g) if src.has(w)}
        new = {f for f in add if f not in ch['f']}
        for f in new: ch['f'][f] = src.size(f)
        report.append('chapter %02d: %d files added by rule (animations, sentences\' words), %.1f MiB' % (c, len(new), sum(src.size(f) for f in new) / 1048576.0))
    return {f: src.size(f) for f in common_f}

# build 48: read when a chapter opens but placed as before (pak0.pak keeps build 45's bytes):
# what the run of 11/11 (build 46) still read while played -
#  - the engine's client sounds (engine/common/sounds.c, the default sound list: shells,
#    debris, ricochets, explosions, water) and the client library's event sounds (cl_dll/ev_hldm.cpp);
#  - the words of the Black Mesa announcer: a "speaker" entity plays sentences at random from a
#    group named by its "message" ("C1A3_"...) or its "preset" (hlsdk dlls/sound.cpp, CSpeaker).
ENGINE_SOUNDS = [('player/pl_shell%d.wav', 1, 3), ('weapons/sshell%d.wav', 1, 3), ('debris/concrete%d.wav', 1, 3),
                 ('debris/glass%d.wav', 1, 4), ('debris/metal%d.wav', 1, 6), ('debris/flesh%d.wav', 1, 7),
                 ('debris/wood%d.wav', 1, 4), ('weapons/ric%d.wav', 1, 5), ('weapons/explode%d.wav', 3, 5),
                 ('player/pl_wade%d.wav', 1, 4)]
EVENT_SOUNDS = ('agrunt/ag_fire1.wav agrunt/ag_fire2.wav agrunt/ag_fire3.wav ambience/pulsemachine.wav '
    'weapons/357_shot1.wav weapons/357_shot2.wav weapons/bullet_hit1.wav weapons/bullet_hit2.wav '
    'weapons/cbar_miss1.wav weapons/dbarrel1.wav weapons/egon_off1.wav weapons/egon_run3.wav '
    'weapons/egon_windup2.wav weapons/gauss2.wav weapons/glauncher.wav weapons/glauncher2.wav weapons/hks1.wav '
    'weapons/hks2.wav weapons/pl_gun3.wav weapons/sbarrel1.wav weapons/xbow_fire1.wav weapons/rocketfire1.wav '
    'weapons/electro4.wav weapons/electro5.wav weapons/electro6.wav').split()
SPEAKER_PRESETS = {1: 'C1A0_', 2: 'C1A1_', 3: 'C1A2_', 4: 'C1A3_', 5: 'C1A4_', 6: 'C2A1_', 7: 'C2A2_', 8: 'C2A3_',
                   9: 'C2A4_', 10: 'C2A5_', 11: 'C3A1_', 12: 'C3A2_'}

def extras(src, lists, report):
    """what a chapter (and the common part) reads ahead without moving a file of the pak"""
    sent = hc.sentences(src)
    common = set()
    for pat, a, b in ENGINE_SOUNDS:
        for i in range(a, b + 1):
            n = 'sound/' + pat % i
            if src.has(n): common.add(n)
    common |= {'sound/' + n for n in EVENT_SOUNDS if src.has('sound/' + n)}
    per = {}
    for c, ch in lists.items():
        add = set()
        for m in ch['maps']:
            if not src.has('maps/%s.bsp' % m): continue
            ver, ents, tex = hc.bsp_info(src, m)
            for e in ents:
                if e.get('classname', '') != 'speaker': continue
                g = e.get('message', '')
                try: pr = int(e.get('preset', '0') or 0)
                except ValueError: pr = 0
                if pr in SPEAKER_PRESETS: g = SPEAKER_PRESETS[pr]
                if not g: continue
                if g.startswith('!'):
                    add |= {w for w in hc.group_words(sent, g) if src.has(w)}
                else:
                    for name, words in sent.items():
                        if name.startswith(g.upper()): add |= {w for w in words if src.has(w)}
        per[c] = {f for f in add if f not in ch['f']}
        report.append('chapter %02d: %d files read ahead without moving (announcer\'s words), %.1f MiB' % (c, len(per[c]), sum(src.size(f) for f in per[c]) / 1048576.0))
    report.append('common part: %d client sounds read ahead without moving, %.1f MiB' % (len(common), sum(src.size(f) for f in common) / 1048576.0))
    return per, common

def plan(entries, lists):
    """the order of the pak's files, the .wad files written again, and what to report"""
    src = Source(entries)
    report = []
    common_rule = rules(src, lists, report)
    ex_per, ex_common = extras(src, lists, report)          # build 48: ranges only
    # check the lists against this install
    missing, differ = set(), set()
    for c, ch in lists.items():
        for f, sz in ch['f'].items():
            if not src.has(f): missing.add(f)
            elif src.size(f) != sz: differ.add(f)
    chs = [c for c in GAME_ORDER if c in lists]
    allf = [set(lists[c]['f']) for c in chs]
    common = set.intersection(*allf) if allf else set()
    common |= set(common_rule)
    order, placed = [], set()
    def put(names):
        for n in sorted(names):
            if n in placed or n not in entries or n.endswith('.wad'): continue
            order.append(n); placed.add(n)
    put(common)
    wads = sorted({n for n in entries if n.endswith('.wad')})
    order_wads_after_common = list(wads)
    for c in chs: put(lists[c]['f'])
    put(entries.keys())
    # the .wad files: textures common to every chapter (and decals.wad whole), then by chapter
    wad_new, common_wad = {}, {}
    for w in wads:
        parsed = parse_wad(src.read(w))
        if not parsed: continue
        magic, lumps = parsed
        byname = {}
        for l in lumps: byname.setdefault(l['name'], l)
        rank = {}
        used = [set(lists[c]['w'].get(w, {})) for c in chs]
        allw = set.intersection(*used) if used and all(used) else set()
        for n in byname:
            if w == 'decals.wad' or n in allw: rank[n] = (0, n)
        for i, c in enumerate(chs):
            for n in lists[c]['w'].get(w, {}):
                if n in byname and n not in rank: rank[n] = (1 + i, n)
        for n in byname:
            if n not in rank: rank[n] = (99, n)
        common_wad[w] = {n for n, r in rank.items() if r[0] == 0}
        seen, new = set(), []
        for l in sorted(lumps, key=lambda l: rank[l['name']]):
            if l['name'] in seen: continue           # a name twice: the engine finds the first
            seen.add(l['name']); new.append(l)
        wad_new[w] = write_wad(magic, new)
        for c in chs:
            for n in lists[c]['w'].get(w, {}):
                if n not in byname: missing.add('%s:%s' % (w, n))
    # the .wad files go right after the common part
    k = len([n for n in order if n in common])
    order = order[:k] + [w for w in order_wads_after_common] + order[k:]
    return order, wad_new, (common, common_wad, ex_per, ex_common), report, missing, differ

def ranges_for(chapter, lists, common, offsets, wad_new):
    """the ranges of the pak a chapter reads when it opens (255: the common part), merged when
    under a block apart; a chapter's own leave the common part out"""
    r = []
    cf, cw, ex_per, ex_common = common
    if chapter == 255:
        files, wadneed = set(cf) | ex_common, {w: set(cw.get(w, ())) for w in wad_new}
    else:
        ch = lists[chapter]
        files = ( set(ch['f']) | ex_per.get(chapter, set())) - cf - ex_common
        wadneed = {w: set(ch['w'].get(w, {})) - cw.get(w, set()) for w in wad_new}
    for f in files:
        if f in offsets: r.append(offsets[f])
    for w, (data, where, dirpos) in wad_new.items():
        if w not in offsets: continue
        base = offsets[w][0]
        need = wadneed.get(w, set())
        if not need: continue
        r.append((base, 12))
        r.append((base + dirpos[0], dirpos[1]))
        for n in need:
            if n in where: r.append((base + where[n][0], where[n][1]))
    r = sorted(x for x in r if x[1] > 0)
    out = []
    for o, l in r:
        if out and o <= out[-1][0] + out[-1][1] + 65536:
            a, b = out[-1]
            out[-1] = (a, max(a + b, o + l) - a)
        else: out.append((o, l))
    return out

def write_chp(path, paksize, per):
    with open(path, 'wb') as o:
        o.write(b'ZZCHP1\0\0' + struct.pack('<II', paksize, len(per)))
        for c in sorted(per):
            rs = per[c]
            o.write(struct.pack('<III', c, len(rs), sum(l for _, l in rs)))
            for a, l in rs: o.write(struct.pack('<II', a, l))
