#!/usr/bin/env python3
# hl_pak.py - ZZHalfLife: merge a Half-Life valve/ folder (pak0.pak + loose files of a Steam
# install) into ONE Quake-format PAK for PROGDIR:data/pak0.pak, and report the sizes. Nothing
# is downloaded, nothing is redistributed: it works on your own install, on your PC.
#   python3 hl_pak.py [-x PATTERN]... <valve dir> [<out pak0.pak>]
# Without an output file: report only. -x PATTERN (repeatable) leaves out every entry whose
# path matches (fnmatch, case-insensitive): "SAVE/*", "media/*.mp3", "resource/background/*"...
# Loose files of a Steam install take precedence over same-name pak entries (they are the
# updated ones).
# Recommended for the ZZ9000 (nothing the Core1 engine reads is left out, 395 MiB instead of 521):
#   python3 hl_pak.py -x "SAVE/*" -x "dlls/*" -x "cl_dlls/*" -x "hw/*" -x "logos/*" \
#       -x "controller_configs/*" -x "overviews/*" -x "resource/background/*" -x "media/*" \
#       <valve dir> data/pak0.pak
#   (media/: the Valve logo AVI and the Steam soundtrack MP3s; neither is read from the pak
#    by the Core1 build, they go to data/ as separate files when video and music come.)
# -i PATTERN (repeatable, build 23): keep ONLY the entries matching one of the patterns; the
# names kept are listed when there are 80 or fewer.  Half-Life's own loading picture for the
# loading screen (Steam: resource/background/, left out of pak0.pak by the command above) as a
# small second pak that the engine mounts next to pak0.pak:
#   python3 hl_pak.py -i "resource/background*layout.txt" -i "resource/background/*loading*" \
#       <valve dir> data/pak1.pak
#   (without the output file: only the list, to see what your install has)
# Since build 37 the pak written gets its <pak>.crc next to it (tools/hl_pakcrc.py): copy both to data/.
# --chapters DIR (build 45): the pak laid out by chapter from the reference lists of DIR
# (tools/chapters/zzhl_chNN.lst, see tools/hl_chlayout.py), and <pak>.chp next to it: what each
# chapter reads when it opens.  Copy the three files (pak, .crc, .chp) to data/.  For the release:
#   python3 hl_pak.py --chapters chapters -x "SAVE/*" ... <valve dir> data/pak0.pak
# --extra DIR (build 50): the files under DIR are added as they are (their path under DIR is the
# name in the pak).  --menu is the small second pak of the menu: the background of the menu made
# from your install by tools/hl_menubg.py (build 52: four tiles, 512 x 384, instead of the Steam
# tiles themselves, which filled the texture memory) and --extra tools/menu (two free fonts and
# the port's own check boxes, arrows and slider, see tools/menu/README.txt):
#   python3 hl_pak.py --menu <valve dir> data/pak1.pak
# ASCII only.
import fnmatch, os, struct, sys

def read_pak(path):
    out = {}
    with open(path, 'rb') as f:
        hdr = f.read(12)
        if hdr[:4] != b'PACK':
            raise SystemExit('%s: not a PACK file' % path)
        dofs, dlen = struct.unpack('<II', hdr[4:12])
        f.seek(dofs)
        d = f.read(dlen)
        for i in range(0, dlen, 64):
            name = d[i:i+56].split(b'\0', 1)[0].decode('latin-1').replace('\\', '/')
            ofs, size = struct.unpack('<II', d[i+56:i+64])
            out[name.lower()] = (name, path, ofs, size)
    return out

def excluded(name, patterns):
    low = name.lower()
    return any(fnmatch.fnmatchcase(low, pat.lower()) for pat in patterns)

def main():
    args = sys.argv[1:]
    patterns = []
    includes = []
    chapters = None
    extras = []
    menu = False
    while args and args[0] == '--menu' or len(args) >= 2 and args[0] in ('-x', '-i', '--chapters', '--extra'):
        if args[0] == '--menu':
            menu = True              # build 52: nothing of the install as it is, see below
            extras.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'menu'))
            args = args[1:]; continue
        if args[0] == '--chapters': chapters = args[1]
        elif args[0] == '--extra': extras.append(args[1])
        else: (patterns if args[0] == '-x' else includes).append(args[1])
        args = args[2:]
    if not args:
        print(open(__file__).read().split('import fnmatch')[0]); return 2
    vdir = args[0]
    out = args[1] if len(args) > 1 else None
    entries = {}
    paks = sorted(p for p in os.listdir(vdir) if p.lower().endswith('.pak'))
    total_pak = 0
    for p in paks:
        full = os.path.join(vdir, p)
        e = read_pak(full)
        total_pak += os.path.getsize(full)
        entries.update(e)
        print('%-14s %10d bytes, %5d files' % (p, os.path.getsize(full), len(e)))
    loose = 0; nloose = 0
    for root, dirs, files in os.walk(vdir):
        for fn in files:
            full = os.path.join(root, fn)
            rel = os.path.relpath(full, vdir).replace('\\', '/')
            if rel.lower().endswith('.pak') and '/' not in rel:
                continue
            size = os.path.getsize(full)
            loose += size; nloose += 1
            entries[rel.lower()] = (rel, full, 0, size)
    if menu:                                       # build 52: the menu background, made from the install
        import tempfile
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_menubg
        entries = {}
        made = hl_menubg.build(vdir)
        if made:
            tmp = tempfile.mkdtemp(prefix='zzhl_menubg_')
            import atexit, shutil
            atexit.register(shutil.rmtree, tmp, True)      # 17/11: it stayed in the system's temporary folder
            for n, d in made.items():
                p = os.path.join(tmp, n); os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p, 'wb') as f: f.write(d)
            extras.insert(0, tmp)
    if includes:
        entries = {k: v for k, v in entries.items() if excluded(v[0], includes)}
        print('kept by -i: %d files' % len(entries))
        if len(entries) <= 80:
            for k in sorted(entries):
                print('  %-56s %9d bytes' % (entries[k][0], entries[k][3]))
    if patterns:
        dropped = {k: v for k, v in entries.items() if excluded(v[0], patterns)}
        entries = {k: v for k, v in entries.items() if k not in dropped}
        print('excluded by -x: %d files, %d bytes (%.1f MiB)' % (len(dropped), sum(v[3] for v in dropped.values()), sum(v[3] for v in dropped.values()) / 1048576.0))
    for xd in extras:                              # build 50: --extra / --menu
        nx = 0
        for root, dirs, files in os.walk(xd):
            for fn in sorted(files):
                full = os.path.join(root, fn)
                rel = os.path.relpath(full, xd).replace('\\', '/')
                if '/' not in rel: continue            # README.txt of the folder itself
                entries[rel.lower()] = (rel, full, 0, os.path.getsize(full)); nx += 1
        print('added from %s: %d files' % (xd, nx))
    by_dir = {}
    for k, (name, src, ofs, size) in entries.items():
        d = name.split('/')[0] if '/' in name else '(root)'
        by_dir[d] = by_dir.get(d, 0) + size
    print('loose files: %d, %d bytes; paks: %d bytes' % (nloose, loose, total_pak))
    print('content by directory (the pak the engine will read):')
    for d, s in sorted(by_dir.items(), key=lambda x: -x[1]):
        print('  %-12s %10d bytes (%.1f MiB)' % (d, s, s / 1048576.0))
    tot = sum(e[3] for e in entries.values())
    print('total %d files, %d bytes (%.1f MiB)' % (len(entries), tot, tot / 1048576.0))
    if not out:
        return 0
    names = sorted(entries)
    for n in names:
        if len(entries[n][0].encode('latin-1')) > 55:
            print('WARNING: name too long for a PAK entry, skipped: %s' % entries[n][0])
    names = [n for n in names if len(entries[n][0].encode('latin-1')) <= 55]
    wad_new, lists, common = {}, None, set()
    if chapters:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_chlayout
        lists = hl_chlayout.load_lists(chapters)
        if not lists: raise SystemExit('--chapters %s: no zzhl_chNN.lst there' % chapters)
        keep = set(names)
        order, wad_new, common, report, missing, differ = hl_chlayout.plan({k: entries[k] for k in names}, lists)
        missing = {m for m in missing if not excluded(m, patterns)}   # left out on purpose by -x (pak1.pak, ...)
        names = [n for n in order if n in keep]
        print('chapters: %d reference lists from %s' % (len(lists), chapters))
        for r in report: print('  ' + r)
        print('  in the lists but not in this install: %d%s' % (len(missing), (': ' + ', '.join(sorted(missing)[:20]) + (' ...' if len(missing) > 20 else '')) if missing else ''))
        print('  in the lists with another size here: %d%s' % (len(differ), (': ' + ', '.join(sorted(differ)[:20]) + (' ...' if len(differ) > 20 else '')) if differ else ''))
    offsets = {}
    with open(out, 'wb') as o:
        o.write(b'PACK' + b'\0' * 8)
        pos = 12
        dirents = []
        for n in names:
            name, src, ofs, size = entries[n]
            if n in wad_new:                       # build 45: a .wad with its textures in chapter order
                data = wad_new[n][0]
                o.write(data); size = len(data)
            else:
                with open(src, 'rb') as f:
                    f.seek(ofs)
                    left = size
                    while left:
                        chunk = f.read(min(left, 1 << 20))
                        if not chunk: break
                        o.write(chunk); left -= len(chunk)
            dirents.append((name, pos, size))
            offsets[n] = (pos, size)
            pos += size
            while pos % 4:
                o.write(b'\0'); pos += 1
        dofs = pos
        for name, ofs, size in dirents:
            o.write(name.encode('latin-1').ljust(56, b'\0') + struct.pack('<II', ofs, size))
        o.seek(4); o.write(struct.pack('<II', dofs, len(dirents) * 64))
    print('written %s: %d files, %d bytes' % (out, len(dirents), os.path.getsize(out)))
    if lists:
        per = {c: hl_chlayout.ranges_for(c, lists, common, offsets, wad_new) for c in list(lists) + [255]}
        chp = os.path.splitext(out)[0] + '.chp'
        hl_chlayout.write_chp(chp, os.path.getsize(out), per)
        print('written %s: what each chapter reads when it opens' % chp)
        for c in sorted(per):
            print('  %s: %4d ranges, %6.1f MiB' % ('common part (read once)' if c == 255 else 'chapter %02d' % c, len(per[c]), sum(l for _, l in per[c]) / 1048576.0))
    # build 37: the block CRCs the Core1 file layer checks reads against (hl_pakcrc.py), copy both
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import hl_pakcrc
        hl_pakcrc.write_crc(out)
    except ImportError:
        print('hl_pakcrc.py not found next to hl_pak.py: run it on %s yourself' % out)
    return 0

if __name__ == '__main__':
    sys.exit(main())
