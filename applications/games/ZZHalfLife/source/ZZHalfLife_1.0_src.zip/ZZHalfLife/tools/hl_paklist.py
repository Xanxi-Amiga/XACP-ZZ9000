#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# hl_paklist.py - ZZHalfLife: what is inside a .pak - MD5, size and name of every file.
#
#   python3 tools/hl_paklist.py <file.pak> [<file.pak> ...]  > list.txt
#
# Names, sizes and fingerprints only: nothing of the files themselves is written.  Used to see
# which files of a Steam install went into pak0.pak (the personal ones - configuration, spray,
# screenshots - make two people's paks differ) and to compare two installs file by file.
# ASCII only.
import hashlib, os, struct, sys


def members(path):
    """(name, size, md5) of every file of a .pak, by name; zzhl_data.py checks its pak0.pak with it"""
    out = []
    with open(path, 'rb') as f:
        hdr = f.read(12)
        if hdr[:4] != b'PACK': raise SystemExit('%s: not a PACK file' % path)
        dofs, dlen = struct.unpack('<II', hdr[4:12])
        f.seek(dofs); d = f.read(dlen)
        ents = []
        for i in range(0, dlen, 64):
            name = d[i:i + 56].split(b'\0', 1)[0].decode('latin-1').replace('\\', '/')
            ofs, size = struct.unpack('<II', d[i + 56:i + 64])
            ents.append((name, ofs, size))
        for name, ofs, size in sorted(ents, key=lambda e: e[0].lower()):
            f.seek(ofs); h = hashlib.md5(); left = size
            while left > 0:
                b = f.read(min(left, 1 << 20))
                if not b: raise SystemExit('%s: %s runs past the end of the file' % (path, name))
                h.update(b); left -= len(b)
            out.append((name, size, h.hexdigest()))
    return out


def main():
    if len(sys.argv) < 2: sys.exit('usage: hl_paklist.py <file.pak> [...]')
    for path in sys.argv[1:]:
        m = members(path)
        print('# %s: %d files, %d bytes' % (os.path.basename(path), len(m), os.path.getsize(path)))
        for name, size, md5 in m:
            print('%s %10d %s' % (md5, size, name))


if __name__ == '__main__':
    main()
