#!/usr/bin/env python3
# hl_chapters.py - ZZHalfLife (build 43): how much of pak0.pak each chapter of Half-Life needs,
# to decide whether a whole chapter can be read into the ZZ9000's memory when it opens.
#   python3 hl_chapters.py data/pak0.pak [data/pak1.pak] [-v]
# Works on your own pak (made by tools/hl_pak.py from your install), on your PC: nothing is
# downloaded, nothing is written.  For each map of a chapter it reads the map itself (.bsp): its
# entities (monsters, doors, sounds, sprites, sentences), its textures (found in the .wad files
# the map names), its sky; for each entity class, the files hlsdk precaches for it
# (tools/hl_precache_table.py, made from hlsdk-portable by tools/gen_hl_precache.py); for each
# model its texture model (xT.mdl) and its animation files (x01.mdl ...); for each character the
# words of its sentences (sound/sentences.txt).  It counts large: in doubt, in.
# "common" is what every map loads (the world, the player, the weapons, the HUD, the decals, the
# HEV voice): read once, kept for the whole game.  Sizes in MiB.  -v: the 15 largest files of
# each chapter and what was referenced but not found.
# Code by the ZZHalfLife port, 0BSD.  ASCII only.
import os, re, struct, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hl_precache_table import PRECACHE

CHAPTERS = [
    ("Hazard Course", "t0a0 t0a0a t0a0b t0a0b1 t0a0b2 t0a0c t0a0d"),
    ("Black Mesa Inbound", "c0a0 c0a0a c0a0b c0a0c c0a0d c0a0e"),
    ("Anomalous Materials", "c1a0 c1a0d c1a0a c1a0b c1a0c c1a0e"),
    ("Unforeseen Consequences", "c1a1 c1a1a c1a1f c1a1b c1a1c c1a1d"),
    ("Office Complex", "c1a2 c1a2a c1a2b c1a2c c1a2d"),
    ("We've Got Hostiles", "c1a3 c1a3a c1a3b c1a3c c1a3d"),
    ("Blast Pit", "c1a4 c1a4k c1a4b c1a4f c1a4d c1a4e c1a4i c1a4g c1a4j"),
    ("Power Up", "c2a1 c2a1a c2a1b"),
    ("On A Rail", "c2a2 c2a2a c2a2b1 c2a2b2 c2a2c c2a2d c2a2e c2a2f c2a2g c2a2h"),
    ("Apprehension", "c2a3 c2a3a c2a3b c2a3c c2a3d c2a3e"),
    ("Residue Processing", "c2a4 c2a4a c2a4b c2a4c"),
    ("Questionable Ethics", "c2a4d c2a4e c2a4f c2a4g"),
    ("Surface Tension", "c2a5 c2a5w c2a5x c2a5a c2a5b c2a5c c2a5d c2a5e c2a5f c2a5g"),
    ("Forget About Freeman", "c3a1 c3a1a c3a1b"),
    ("Lambda Core", "c3a2e c3a2 c3a2a c3a2b c3a2c c3a2d c3a2f"),
    ("Xen", "c4a1"),
    ("Gonarch's Lair", "c4a2 c4a2a c4a2b"),
    ("Interloper", "c4a1a c4a1b c4a1c c4a1d c4a1e c4a1f"),
    ("Nihilanth", "c4a3"),
    ("Endgame", "c5a1"),
    # build 78: Uplink, the 1999 demo.  Not part of the campaign - the engine starts it from
    # the New Game checkbox on its own - but without an entry here it plays with no preload.
    # MUST stay identical to g_ch[] in xacp/src/xacp_chapters.c; tests/test_chapters_sync.py
    # checks it.
    ("Uplink", "hldemo1 hldemo2 hldemo3"),
]
# what the engine and the client load besides the game library's precaches (counted large)
COMMON_PREFIX = ["sound/fvox/", "sound/common/", "sound/player/", "sprites/"]
COMMON_FILES = ["decals.wad", "gfx.wad", "fonts.wad", "cached.wad", "sound/sentences.txt", "sound/materials.txt",
                "titles.txt", "liblist.gam", "gfx/palette.lmp"]
SKY_SIDES = ["up", "dn", "lf", "rt", "ft", "bk"]

class Pak:
    def __init__(self, paths):
        self.idx = {}
        for p in paths:
            with open(p, 'rb') as f:
                h = f.read(12)
                if h[:4] != b'PACK': raise SystemExit('%s: not a PACK file' % p)
                dofs, dlen = struct.unpack('<II', h[4:12])
                f.seek(dofs); d = f.read(dlen)
            for i in range(0, dlen, 64):
                name = d[i:i + 56].split(b'\0', 1)[0].decode('latin-1').replace('\\', '/').lower()
                ofs, size = struct.unpack('<II', d[i + 56:i + 64])
                self.idx[name] = (p, ofs, size)
    def has(self, n): return n.lower() in self.idx
    def size(self, n): return self.idx[n.lower()][2]
    def read(self, n, start=0, length=None):
        p, ofs, size = self.idx[n.lower()]
        if length is None: length = size - start
        with open(p, 'rb') as f:
            f.seek(ofs + start); return f.read(max(0, min(length, size - start)))

def parse_entities(text):
    ents = []
    for block in re.findall(r'\{(.*?)\}', text, flags=re.S):
        e = {}
        for k, v in re.findall(r'"([^"]*)"\s*"([^"]*)"', block): e[k.lower()] = v
        ents.append(e)
    return ents

def bsp_info(pak, mapname):
    b = pak.read('maps/%s.bsp' % mapname)
    ver = struct.unpack('<i', b[:4])[0]
    lumps = [struct.unpack('<ii', b[4 + 8 * i:12 + 8 * i]) for i in range(15)]
    eo, el = lumps[0]
    ents = parse_entities(b[eo:eo + el].decode('latin-1', 'replace'))
    to, tl = lumps[2]
    tex = []
    if tl >= 4:
        n = struct.unpack('<i', b[to:to + 4])[0]
        for i in range(max(0, min(n, 4096))):
            o = struct.unpack('<i', b[to + 4 + 4 * i:to + 8 + 4 * i])[0]
            if o < 0: continue
            m = b[to + o:to + o + 40]
            name = m[:16].split(b'\0', 1)[0].decode('latin-1').lower()
            if struct.unpack('<I', m[24:28])[0] == 0: tex.append(name)   # offsets[0] == 0: in a .wad
    return ver, ents, tex

_wads = {}
def wad_lumps(pak, wad):
    if wad not in _wads:
        d = {}
        if pak.has(wad):
            h = pak.read(wad, 0, 12)
            if h[:4] in (b'WAD3', b'WAD2'):
                n, io = struct.unpack('<ii', h[4:12])
                t = pak.read(wad, io, 32 * n)
                for i in range(n):
                    e = t[32 * i:32 * i + 32]
                    if len(e) < 32: break
                    fp, ds = struct.unpack('<ii', e[:8])
                    d[e[16:32].split(b'\0', 1)[0].decode('latin-1').lower()] = ds
        _wads[wad] = d
    return _wads[wad]

def sentences(pak):
    out = {}
    if not pak.has('sound/sentences.txt'): return out
    for line in pak.read('sound/sentences.txt').decode('latin-1', 'replace').splitlines():
        line = line.split('//', 1)[0].strip()
        if not line: continue
        tok = line.split()
        name, words, d = tok[0].upper(), [], 'vox'
        for w in tok[1:]:
            w = re.sub(r'\([^)]*\)', '', w).strip(',.')
            if not w: continue
            if '/' in w: d, w = w.rsplit('/', 1)
            if w: words.append('sound/%s/%s.wav' % (d.lower(), w.lower()))
        out[name] = words
    return out

def group_words(sent, g):
    g = g.lstrip('!').upper()
    if g in sent: return set(sent[g])
    out = set()
    for n, w in sent.items():
        if re.sub(r'\d+$', '', n) == g: out |= set(w)
    return out

def class_closure(cls, seen=None):
    seen = set() if seen is None else seen
    files, groups = set(), set()
    if cls in seen or cls not in PRECACHE: return files, groups
    seen.add(cls)
    f, others, g = PRECACHE[cls]
    files |= set(f); groups |= set(g)
    for o in others:
        f2, g2 = class_closure(o, seen); files |= f2; groups |= g2
    return files, groups

def with_models(pak, files):
    """a model brings its texture model and its animation files"""
    out = set(files)
    for f in files:
        if f.endswith('.mdl'):
            base = f[:-4]
            if pak.has(base + 't.mdl'): out.add(base + 't.mdl')
            for i in range(1, 32):
                n = '%s%02d.mdl' % (base, i)
                if pak.has(n): out.add(n)
                else: break
    return out

def real(f):
    return f.split(':', 1)[1] if f.startswith('voice:') else f

def kind(f):
    if f.startswith('maps/'): return 'maps'
    if f.startswith('wad:'): return 'textures'
    if f.startswith('gfx/env/'): return 'sky'
    if f.endswith('.mdl'): return 'models'
    if f.endswith('.spr'): return 'sprites'
    if f.startswith('voice:'): return 'voices'
    if f.endswith('.wav'): return 'sounds'
    return 'other'

def main():
    args = [a for a in sys.argv[1:] if not a.startswith('-')]
    verbose = '-v' in sys.argv
    if not args: raise SystemExit(__doc__ if __doc__ else 'usage: hl_chapters.py data/pak0.pak [data/pak1.pak] [-v]')
    pak = Pak(args)
    sent = sentences(pak)
    missing, unknown = set(), set()
    def size_of(f):
        if f.startswith('wad:'):
            _, wad, name = f.split(':', 2); return wad_lumps(pak, wad).get(name, 0)
        n = f.split(':', 1)[1] if f.startswith('voice:') else f
        return pak.size(n) if pak.has(n) else 0
    def present(f):
        if f.startswith('wad:'): return True
        n = f.split(':', 1)[1] if f.startswith('voice:') else f
        if pak.has(n): return True
        missing.add(n); return False
    # common
    cf, cg = set(), set()
    for c in ('worldspawn', 'player'):
        f, g = class_closure(c); cf |= f; cg |= g
    cf = with_models(pak, cf)
    for n in pak.idx:
        if any(n.startswith(p) for p in COMMON_PREFIX): cf.add(n)
    cf |= {f for f in COMMON_FILES if pak.has(f)}
    cf |= {'voice:' + w for g in cg for w in group_words(sent, g)}
    common, cnames = set(), set()
    for f in sorted(cf, key=lambda x: x.startswith('voice:')):
        if present(f) and real(f) not in cnames: common.add(f); cnames.add(real(f))
    rows = []
    for title, maps in CHAPTERS:
        files, nmaps, found = set(), 0, 0
        for m in maps.split():
            nmaps += 1
            if not pak.has('maps/%s.bsp' % m): missing.add('maps/%s.bsp' % m); continue
            found += 1
            files.add('maps/%s.bsp' % m)
            ver, ents, tex = bsp_info(pak, m)
            world = ents[0] if ents else {}
            wads = [os.path.basename(w.replace('\\', '/')).lower() for w in world.get('wad', '').split(';') if w.strip()]
            wads = [w for w in wads if pak.has(w)] or [n for n in pak.idx if n.endswith('.wad')]
            for t in tex:
                for w in wads:
                    if t in wad_lumps(pak, w): files.add('wad:%s:%s' % (w, t)); break
                else: missing.add('texture %s' % t)
            sky = world.get('skyname', 'desert').lower()
            for s in SKY_SIDES:
                for ext in ('.tga', '.bmp'):
                    if pak.has('gfx/env/%s%s%s' % (sky, s, ext)): files.add('gfx/env/%s%s%s' % (sky, s, ext)); break
            groups = set()
            for e in ents:
                c = e.get('classname', '')
                if c in PRECACHE:
                    f, g = class_closure(c); files |= f; groups |= g
                elif c and not c.startswith(('func_', 'trigger_', 'info_', 'path_', 'light', 'env_', 'multi_', 'game_', 'momentary_', 'button_', 'player_', 'worldspawn', 'scripted_', 'aiscripted_', 'monstermaker', 'xen_', 'target_', 'ambient_', 'speaker', 'infodecal')):
                    unknown.add(c)
                for k, v in e.items():
                    lv = v.strip().replace('\\', '/').lower()
                    if lv.endswith('.mdl') or lv.endswith('.spr'): files.add(lv)
                    elif lv.endswith('.wav'): files.add(lv if lv.startswith('sound/') else 'sound/' + lv.lstrip('*!'))
                    elif v.startswith('!') or (k == 'sentence' and v): groups.add(v)
            files = with_models(pak, files)
            files |= {'voice:' + w for g in groups for w in group_words(sent, g)}
        files = {f for f in files if present(f)}
        own, seen_names = set(), set(real(f) for f in common)
        for f in sorted(files, key=lambda x: x.startswith('voice:')):   # a file precached counts as a sound, not twice
            if real(f) not in seen_names: own.add(f); seen_names.add(real(f))
        by = {}
        for f in own: by[kind(f)] = by.get(kind(f), 0) + size_of(f)
        rows.append((title, nmaps, found, by, sum(by.values()), own))
    M = 1048576.0
    cby = {}
    for f in common: cby[kind(f)] = cby.get(kind(f), 0) + size_of(f)
    ctot = sum(cby.values())
    print('Half-Life chapters in %s (MiB; a file counted once per chapter, the common part apart)' % ', '.join(args))
    print('common (world, player, weapons, HUD, decals, HEV voice): %.1f MiB, %d files: %s' % (ctot / M, len(common), ', '.join('%s %.1f' % (k, v / M) for k, v in sorted(cby.items(), key=lambda x: -x[1]))))
    cols = ['maps', 'textures', 'models', 'sounds', 'voices', 'sprites', 'sky', 'other']
    print('%-24s %5s ' % ('chapter', 'n') + ' '.join('%8s' % c for c in cols) + ' %8s %9s' % ('chapter', '+common'))
    for title, nmaps, found, by, tot, own in rows:
        mtxt = '%d' % found if found == nmaps else '%d/%d' % (found, nmaps)
        print('%-24s %5s ' % (title[:24], mtxt) + ' '.join('%8.1f' % (by.get(c, 0) / M) for c in cols) + ' %8.1f %9.1f' % (tot / M, (tot + ctot) / M))
    big = max(rows, key=lambda r: r[4])
    print('largest chapter: %s, %.1f MiB with the common part (the ZZ9000 has about 100 MiB for it)' % (big[0], (big[4] + ctot) / M))
    allf = set(common)
    for r in rows: allf |= r[5]
    print('the whole game by these rules: %.1f MiB of %.1f MiB in the pak' % (sum(size_of(f) for f in allf) / M, sum(v[2] for v in pak.idx.values()) / M))
    print('referenced but not in the pak: %d (maps, textures, sounds...); entity classes not in the table: %d' % (len(missing), len(unknown)))
    if verbose:
        for title, nmaps, found, by, tot, own in rows:
            print('-- %s: the 15 largest' % title)
            for f in sorted(own, key=size_of, reverse=True)[:15]: print('   %8.1f KiB  %s' % (size_of(f) / 1024.0, f))
        print('-- not found:', ', '.join(sorted(missing)[:200]))
        print('-- classes not in the table:', ', '.join(sorted(unknown)))

if __name__ == '__main__':
    main()
