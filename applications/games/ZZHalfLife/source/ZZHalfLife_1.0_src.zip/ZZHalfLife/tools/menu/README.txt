tools/menu - what tools/hl_pak.py --menu adds to data/pak1.pak next to the background of the menu
that tools/hl_menubg.py makes from the player's own Half-Life (build 52):
  gfx/fonts/FiraSans-Regular.ttf  "Trebuchet MS" in mainui: Fira Sans, (c) 2012-2015 The Mozilla
                                  Foundation and Telefonica S.A., SIL Open Font License 1.1
                                  (FiraSans-OFL.txt); as in FWGS's xash-extras
                                  (3rdparty/extras/xash-extras/gfx/fonts, Xash3D-FWGS 27092af)
  gfx/fonts/tahoma.ttf            "Tahoma" in mainui: the Wine project's Tahoma, (c) 1993-2024 the
                                  Wine project authors, GNU LGPL 2.1 or later (tahoma-LICENSE.txt,
                                  LGPL-2.1.txt); source: https://gitlab.winehq.org/wine/wine
  gfx/shell/*.tga (build 52)      check boxes, arrows and the slider's knob that the menu asks for
                                  and Half-Life does not have: drawn by tools/hl_menuart.py, the
                                  port's own work, 0BSD (Xash3D's set comes from the WON menu).
Nothing of Valve here.  ASCII only.
