#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# zzhl_data.py - ZZHalfLife: builds the game data for the Amiga from YOUR Half-Life (Steam).
#
#   Windows: double-click ZZHalfLife-Data.exe (made from this file by make_windows_exes.bat),
#            or drop your Half-Life (or Half-Life\valve) folder on it.
#   macOS / Linux:  python3 zzhl_data.py [<Half-Life or valve folder>] [--out <folder>]
#                   (needs:  python3 -m pip install lameenc miniaudio)
#
# Without a folder, the Steam install is looked for where Steam puts it (the registry on
# Windows, ~/Library/Application Support/Steam on macOS, ~/.steam and ~/.local/share/Steam on
# Linux), in every Steam library listed in libraryfolders.vdf.
#
# It writes <out>/data/, to copy as it is into the ZZHalfLife drawer on the Amiga:
#   pak0.pak pak0.crc pak0.chp   the game, laid out by chapter       (tools/hl_pak.py --chapters)
#   pak1.pak pak1.crc            the menu's pictures and fonts       (tools/hl_pak.py --menu)
#   zzhl_loadscreen.tga          the loading screen                  (tools/hl_loading.py)
#   liblist.gam                  original valve/liblist.gam
#   music/track02..28.mp3        the 27 tracks of the soundtrack, in the order of the CD
#                                (launcher/InstallerMusique), re-encoded to 128 kbit/s CBR
#                                (Steam ships them at a higher rate)
# and next to it:
#   ZZHalfLife_data_MD5.txt      the MD5 of every file written
#   ZZHalfLife_data_report.txt   your game files against the reference install (tools/zzhl_ref.py):
#                                the same, or which ones differ, are missing, are yours only.
# pak0.pak itself differs from one person to the next - your own config.cfg (your keys) is in it,
# on purpose - so its MD5 says nothing: the report is what tells whether two installs are the same.
#
# Nothing is downloaded, nothing is sent anywhere, nothing in your Steam folder is changed.
# The result is made from your copy of the game: do not give it away.
# ASCII only.
import hashlib, os, re, shutil, sys, time
import base64, fnmatch, zlib

MUSIC = [   # CD track -> Steam file (launcher/InstallerMusique, Xash3D's own playlist order)
    (2, 'Half-Life01'), (3, 'Prospero01'), (4, 'Half-Life12'), (5, 'Half-Life07'), (6, 'Half-Life10'),
    (7, 'Suspense01'), (8, 'Suspense03'), (9, 'Half-Life09'), (10, 'Half-Life02'), (11, 'Half-Life13'),
    (12, 'Half-Life04'), (13, 'Half-Life15'), (14, 'Half-Life14'), (15, 'Half-Life16'), (16, 'Suspense02'),
    (17, 'Half-Life03'), (18, 'Half-Life08'), (19, 'Prospero02'), (20, 'Half-Life05'), (21, 'Prospero04'),
    (22, 'Half-Life11'), (23, 'Half-Life06'), (24, 'Prospero03'), (25, 'Half-Life17'), (26, 'Prospero05'),
    (27, 'Suspense05'), (28, 'Suspense07')]
MP3_KBPS = 128
# what the release pak0 leaves out: nothing the Core1 engine reads (tools/hl_pak.py, header)
PAK0_EXCLUDE = ['SAVE/*', 'dlls/*', 'cl_dlls/*', 'hw/*', 'logos/*', 'controller_configs/*',
                'overviews/*', 'resource/background/*', 'media/*']
NEED_MIB = 700          # pak0 ~395 MiB + music + room
# What differs from one person to the next - keys, spray, what the game wrote while it ran.  Packed
# as before (the Amiga starts with your keys), never compared with the reference, and never part of
# it (tools/make_zzhl_ref.py).
PERSONAL = ['config.cfg', 'userconfig.cfg', 'autoexec.cfg', 'custom.hpk', 'tempdecal.wad', 'voice_ban.dt',
            'banned.cfg', 'listip.cfg', 'models/player/remapped.bmp', 'maps/graphs/*.nrp',
            # 17/11, the first report from another PC (same steam.inf, 3 873 game files the same): the
            # multiplayer server's files and the options the game rewrites differed, Steam's cloud
            # marker was absent.  None is read by the single-player game on the Amiga.
            'mapcycle.txt', 'server.cfg', 'listenserver.cfg', 'user.scr', 'settings.scr', 'steam_autocloud.vdf']
# The node graphs (the monsters' paths).  Valve ships them for the campaign; the game writes the
# others on the PC the first time a map runs (Uplink: hldemo1..3), and writes one again when it
# finds it older than its map.  Compared apart: a graph of your own is as good as the reference's.
GRAPHS = 'maps/graphs/*.nod'
UPLINK = ('hldemo1', 'hldemo2', 'hldemo3')
# every module of this folder the work needs (make_windows_exes.bat names the same ones)
TOOLS = ('hl_pak', 'hl_chlayout', 'hl_chapters', 'hl_precache_table', 'hl_pakcrc', 'hl_menubg', 'hl_loading', 'hl_paklist')

FROZEN = getattr(sys, 'frozen', False)
HERE = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)


def say(msg=''):
    print(msg); sys.stdout.flush()


def fail(msg):
    say(''); say('ERROR: ' + msg)
    finish(1)


def finish(rc):
    if FROZEN and os.name == 'nt':
        try: input('\nPress Enter to close this window.')
        except EOFError: pass
    sys.exit(rc)


# ---- where is Half-Life? ----
def steam_roots():
    roots = []
    home = os.path.expanduser('~')
    if os.name == 'nt':
        try:
            import winreg
            for hive, key, val in ((winreg.HKEY_CURRENT_USER, r'Software\Valve\Steam', 'SteamPath'),
                                   (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\WOW6432Node\Valve\Steam', 'InstallPath'),
                                   (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Valve\Steam', 'InstallPath')):
                try:
                    with winreg.OpenKey(hive, key) as k:
                        roots.append(winreg.QueryValueEx(k, val)[0])
                except OSError:
                    pass
        except ImportError:
            pass
        for env in ('ProgramFiles(x86)', 'ProgramFiles'):
            if os.environ.get(env): roots.append(os.path.join(os.environ[env], 'Steam'))
    elif sys.platform == 'darwin':
        roots.append(os.path.join(home, 'Library', 'Application Support', 'Steam'))
    else:
        roots += [os.path.join(home, '.steam', 'steam'), os.path.join(home, '.local', 'share', 'Steam'),
                  os.path.join(home, '.var', 'app', 'com.valvesoftware.Steam', '.local', 'share', 'Steam')]
    out = []
    for r in roots:
        r = os.path.normpath(r)
        if os.path.isdir(r) and r not in out: out.append(r)
    return out


def steam_libraries(root):
    libs = [root]
    for vdf in (os.path.join(root, 'steamapps', 'libraryfolders.vdf'), os.path.join(root, 'config', 'libraryfolders.vdf')):
        try:
            with open(vdf, 'r', encoding='utf-8', errors='replace') as f:
                for m in re.finditer(r'"path"\s+"([^"]+)"', f.read()):
                    p = os.path.normpath(m.group(1).replace('\\\\', '\\'))
                    if p not in libs: libs.append(p)
        except OSError:
            pass
    return libs


def valve_of(path):
    """the valve folder of a Half-Life folder, of a valve folder, or None"""
    if not path: return None
    path = os.path.normpath(os.path.expanduser(path.strip().strip('"')))
    for cand in (path, os.path.join(path, 'valve')):
        if os.path.isfile(os.path.join(cand, 'liblist.gam')) and os.path.isdir(os.path.join(cand, 'maps')):
            return cand
    return None


def find_valve():
    for root in steam_roots():
        for lib in steam_libraries(root):
            v = valve_of(os.path.join(lib, 'steamapps', 'common', 'Half-Life'))
            if v: return v
    return None


def ask_folder():
    if not FROZEN: return None
    try:
        import tkinter, tkinter.filedialog
        w = tkinter.Tk(); w.withdraw()
        p = tkinter.filedialog.askdirectory(title='ZZHalfLife: choose your Half-Life folder (the one that holds "valve")')
        w.destroy()
        return p or None
    except Exception:
        return None


def inside(child, parent, P=os.path):
    """is the folder child inside the folder parent?  17/11: os.path.commonpath RAISES on Windows when
       the two are on different drives - the tool on C:, Half-Life in a Steam library on F: - and the
       first tester's run stopped there with a traceback.  Another drive is simply 'not inside'."""
    try:
        c, q = P.normcase(P.abspath(child)), P.normcase(P.abspath(parent))
        return P.commonpath([c, q]) == q
    except ValueError:
        return False


# ---- what the install must hold ----
def check_install(valve):
    missing = []
    def has(rel):
        if os.path.isfile(os.path.join(valve, *rel.split('/'))): return True
        try:
            import hl_pak
            for p in os.listdir(valve):
                if p.lower().endswith('.pak') and rel.lower() in hl_pak.read_pak(os.path.join(valve, p)):
                    return True
        except Exception:
            pass
        return False
    for rel in ('maps/c0a0.bsp', 'maps/c1a0.bsp', 'maps/c5a1.bsp', 'halflife.wad', 'models/scientist.mdl', 'sound/sentences.txt'):
        if not has(rel): missing.append(rel)
    media = os.path.join(valve, 'media')
    names = {n.lower(): n for n in os.listdir(media)} if os.path.isdir(media) else {}
    for _, n in MUSIC:
        if (n + '.mp3').lower() not in names: missing.append('media/%s.mp3' % n)
    return missing, names


# ---- your install against the reference ----
def kind_of(name):
    low = name.lower()
    if any(fnmatch.fnmatchcase(low, p) for p in PERSONAL): return 'personal'
    return 'graph' if fnmatch.fnmatchcase(low, GRAPHS) else 'game'


def load_reference():
    """(module, {lower name: (name, size, md5)}) or (None, None) without tools/zzhl_ref.py"""
    try:
        import zzhl_ref
    except ImportError:
        return None, None
    ref = {}
    for line in zlib.decompress(base64.b64decode(''.join(zzhl_ref.REF_PAK0))).decode('latin-1').split('\n'):
        md5, size, name = line.split(None, 2)
        ref[name.lower()] = (name, int(size), md5)
    return zzhl_ref, ref


def compare(members, ref):
    """members: (name, size, md5) of the pak0.pak just written; ref: load_reference()'s.
       -> {'game': {...}, 'graph': {...}, 'personal': [names]}, each {...} holding the lists
       same / different / missing / extra (different: (name, size, md5, ref size, ref md5))"""
    res = {k: {'same': [], 'different': [], 'missing': [], 'extra': []} for k in ('game', 'graph')}
    res['personal'] = []
    seen = set()
    for name, size, md5 in members:
        k = kind_of(name)
        if k == 'personal': res['personal'].append(name); continue
        low = name.lower(); seen.add(low)
        r = ref.get(low)
        if r is None: res[k]['extra'].append((name, size, md5))
        elif (r[1], r[2]) == (size, md5): res[k]['same'].append(name)
        else: res[k]['different'].append((name, size, md5, r[1], r[2]))
    for low, (name, size, md5) in ref.items():
        if low not in seen: res[kind_of(name)]['missing'].append((name, size, md5))
    return res


def file_md5(p):
    h = hashlib.md5()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''): h.update(chunk)
    return h.hexdigest()


def check_reference(valve, data, out):
    """writes ZZHalfLife_data_report.txt and says the verdict; returns the report's path or None"""
    mod, ref = load_reference()
    if not ref:
        say('(no reference in this copy of the tool - tools/zzhl_ref.py - nothing to compare with)')
        return None
    import hl_paklist
    members = hl_paklist.members(os.path.join(data, 'pak0.pak'))
    res = compare(members, ref)
    g, n = res['game'], res['graph']
    others = {}                                  # 'same' / 'different' / 'not made'
    for name, (md5, size) in sorted(mod.REF_FILES.items()):
        p = os.path.join(data, *name.split('/'))
        others[name] = 'not made' if not os.path.isfile(p) else 'same' if (os.path.getsize(p), file_md5(p)) == (size, md5) else 'different'
    art = [k for k in others if not k.startswith('music/')]
    music = [k for k in others if k.startswith('music/')]
    art_bad = [k for k in art if others[k] != 'same']
    music_bad = [k for k in music if others[k] != 'same']
    names = {m[0].lower() for m in members}
    uplink = [u for u in UPLINK if 'maps/%s.bsp' % u in names and 'maps/graphs/%s.nod' % u not in names]
    same_game = not g['different'] and not g['missing'] and not art_bad
    L = []
    L.append('ZZHalfLife data report - made by zzhl_data.py')
    L.append('This file holds file names, sizes and MD5 fingerprints only: nothing of the game itself.')
    L.append('Reference: %s (%s), %d files.' % (mod.REF_NOTE, mod.REF_DATE, mod.REF_COUNT))
    try:
        with open(os.path.join(valve, 'steam.inf'), 'r', encoding='latin-1') as f:
            L.append('Your steam.inf: ' + ' '.join(f.read().split()))
    except OSError:
        L.append('Your steam.inf: none')
    L.append('')
    L.append('VERDICT: ' + ('SAME GAME FILES as the reference.' if same_game else
             'DIFFERENT from the reference (%d different, %d missing).' % (len(g['different']) + len(art_bad), len(g['missing']))))
    L.append('')
    L.append('game files      : %d the same, %d different, %d missing, %d of yours that the reference lacks'
             % (len(g['same']), len(g['different']), len(g['missing']), len(g['extra'])))
    L.append('node graphs     : %d the same, %d different, %d absent, %d of yours that the reference lacks'
             % (len(n['same']), len(n['different']), len(n['missing']), len(n['extra'])))
    L.append('personal files  : %d (keys, spray, server settings...: they differ from one person to the next and are not compared)' % len(res['personal']))
    L.append('menu, loading screen: ' + ('the same' if not art_bad else ', '.join('%s %s' % (k, others[k]) for k in art_bad)))
    L.append('music           : ' + ('the same %d files' % len(music) if not music_bad else
             '%d of %d files differ (another version of the MP3 encoder, or other music files); this does not matter to the game' % (len(music_bad), len(music))))
    if uplink:
        L.append('')
        L.append('NOTE: no node graph for the Uplink map(s) %s. The Amiga will work them out each time such a map' % ', '.join(uplink))
        L.append('      loads (longer loading). To have them: play Uplink once in Half-Life on this PC, then run this tool again.')
    summary = list(L)
    def block(title, rows, fmt):
        if not rows: return
        L.append(''); L.append('%s (%d):' % (title, len(rows)))
        for r in sorted(rows, key=lambda r: (r if isinstance(r, str) else r[0]).lower()): L.append('  ' + fmt(r))
    block('game files that differ (yours, then the reference)', g['different'], lambda r: '%s  %d %s  /  %d %s' % (r[0], r[1], r[2], r[3], r[4]))
    block('game files of the reference that you lack', g['missing'], lambda r: '%s  %d' % (r[0], r[1]))
    block('game files of yours that the reference lacks', g['extra'], lambda r: '%s  %d %s' % r)
    block('node graphs that differ (yours, then the reference)', n['different'], lambda r: '%s  %d %s  /  %d %s' % (r[0], r[1], r[2], r[3], r[4]))
    block('node graphs of the reference that you lack', n['missing'], lambda r: '%s  %d' % (r[0], r[1]))
    block('node graphs of yours that the reference lacks', n['extra'], lambda r: '%s  %d %s' % r)
    block('personal files (packed, not compared)', res['personal'], lambda r: r)
    block('other files that differ', [k for k in others if others[k] != 'same'], lambda r: '%s: %s' % (r, others[r]))
    rep = os.path.join(out, 'ZZHalfLife_data_report.txt')
    with open(rep, 'w', newline='\n') as f: f.write('\n'.join(L) + '\n')
    say(''); say('Your game files against the reference install:')
    for l in summary[7:]: say('  ' + l if l else '')
    say('  ' + summary[5])
    if not same_game:
        say('  The data is made all the same. If the game misbehaves on the Amiga, send ' + os.path.basename(rep) + '.')
    return rep


# ---- the steps ----
def run_tool(module, argv, needed=True):
    """a tool of this folder, with its own arguments, as if run from the command line"""
    import importlib
    mod = importlib.import_module(module)
    old = sys.argv
    sys.argv = [module + '.py'] + argv
    try:
        rc = mod.main(argv) if module == 'hl_loading' else mod.main()
    except SystemExit as e:
        rc = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        if not isinstance(e.code, int) and e.code: say(str(e.code))
    except Exception as e:                       # a damaged file of the install, a full disk...
        import traceback
        traceback.print_exc()
        rc = 'Python error %s' % type(e).__name__
    finally:
        sys.argv = old
    if rc and needed: fail('%s stopped (code %s): see above.' % (module, rc))
    if rc: say('(not made: the game will show its title instead; nothing else is affected)')


def encode_music(valve, names, mdir):
    try:
        import miniaudio, lameenc
    except ImportError:
        fail('the MP3 encoder is missing. On macOS / Linux:  python3 -m pip install lameenc miniaudio')
    os.makedirs(mdir, exist_ok=True)
    total_in = total_out = 0
    for track, n in MUSIC:
        src = os.path.join(valve, 'media', names[(n + '.mp3').lower()])
        dst = os.path.join(mdir, 'track%02d.mp3' % track)
        t0 = time.time()
        pcm = miniaudio.mp3_read_file_s16(src)
        enc = lameenc.Encoder()
        enc.set_bit_rate(MP3_KBPS)
        enc.set_in_sample_rate(pcm.sample_rate)
        enc.set_channels(pcm.nchannels)
        enc.set_quality(2)
        data = enc.encode(pcm.samples.tobytes()) + enc.flush()
        with open(dst, 'wb') as f: f.write(data)
        total_in += os.path.getsize(src); total_out += len(data)
        say('  track%02d.mp3  <- %-16s %5.1f s of music, %d Hz %s, %6d -> %6d KiB, %.1f s'
            % (track, n + '.mp3', pcm.num_frames / float(pcm.sample_rate), pcm.sample_rate,
               'stereo' if pcm.nchannels == 2 else 'mono', os.path.getsize(src) // 1024, len(data) // 1024, time.time() - t0))
    say('  27 tracks: %.1f MiB -> %.1f MiB' % (total_in / 1048576.0, total_out / 1048576.0))


def md5_report(out, data):
    lines = []
    for root, dirs, files in os.walk(data):
        dirs.sort()
        for fn in sorted(files):
            p = os.path.join(root, fn)
            h = hashlib.md5()
            with open(p, 'rb') as f:
                for chunk in iter(lambda: f.read(1 << 20), b''): h.update(chunk)
            lines.append('%s  %10d  %s' % (h.hexdigest(), os.path.getsize(p), os.path.relpath(p, out).replace('\\', '/')))
    rep = os.path.join(out, 'ZZHalfLife_data_MD5.txt')
    with open(rep, 'w', newline='\n') as f:
        f.write('# ZZHalfLife data made by zzhl_data.py from a Steam install: MD5, size, file\n')
        f.write('\n'.join(lines) + '\n')
    return rep, lines


def main():
    args = sys.argv[1:]
    out = None
    if '--out' in args:
        i = args.index('--out')
        if i + 1 >= len(args): fail('--out needs a folder')
        out = args[i + 1]; del args[i:i + 2]
    if args and args[0] in ('-h', '--help'):
        say(open(os.path.join(HERE, 'zzhl_data.py')).read().split('import hashlib')[0] if not FROZEN else
            'ZZHalfLife-Data [<Half-Life folder>] [--out <folder>]'); return 0
    say('ZZHalfLife data builder - makes the Amiga data from your own Half-Life (Steam)')
    say('')
    # 16/11: an .exe made in a folder that lacked hl_precache_table.py stopped after the first minute
    for m in TOOLS:
        try:
            __import__(m)
        except ImportError as e:
            fail('this copy of the tool is incomplete (%s). The folder it was made from must hold: %s'
                 % (e, ', '.join(t + '.py' for t in TOOLS)))
    valve = valve_of(args[0]) if args else None
    if args and not valve: fail('%s is not a Half-Life folder (no valve\\liblist.gam and valve\\maps)' % args[0])
    if not valve: valve = find_valve()
    if not valve: valve = valve_of(ask_folder())
    if not valve:
        fail('Half-Life was not found. Give its folder:  zzhl_data.py "<...>/steamapps/common/Half-Life"')
    say('Half-Life: ' + valve)
    missing, names = check_install(valve)
    if missing:
        fail('your install lacks %d file(s) the game needs: %s%s\n       In Steam: Half-Life > Properties > Installed Files > Verify integrity.'
             % (len(missing), ', '.join(missing[:8]), ' ...' if len(missing) > 8 else ''))
    if out is None:   # next to the .exe, or in the current folder
        out = os.path.join(os.path.dirname(os.path.abspath(sys.executable)) if FROZEN else os.getcwd(), 'ZZHalfLife_data')
    out = os.path.abspath(out)
    if inside(out, valve): fail('the output folder cannot be inside the Half-Life folder')
    data = os.path.join(out, 'data')
    os.makedirs(data, exist_ok=True)
    free = shutil.disk_usage(out).free // 1048576
    if free < NEED_MIB: fail('%s: %d MiB free, %d needed' % (out, free, NEED_MIB))
    say('Output:    ' + data)
    t0 = time.time()

    say(''); say('1/4  pak0.pak: the game, laid out by chapter (a few minutes)')
    argv = ['--chapters', os.path.join(HERE, 'chapters')]
    for x in PAK0_EXCLUDE: argv += ['-x', x]
    run_tool('hl_pak', argv + [valve, os.path.join(data, 'pak0.pak')])
    say(''); say('2/4  pak1.pak: the menu')
    run_tool('hl_pak', ['--menu', valve, os.path.join(data, 'pak1.pak')])
    say(''); say('3/4  zzhl_loadscreen.tga: the loading screen')
    run_tool('hl_loading', [valve, os.path.join(data, 'zzhl_loadscreen.tga')], needed=False)
    # Xash3D requires liblist.gam outside the game PAKs.
    shutil.copyfile(os.path.join(valve, 'liblist.gam'), os.path.join(data, 'liblist.gam'))
    say('     liblist.gam copied')
    say(''); say('4/4  music: 27 tracks at %d kbit/s' % MP3_KBPS)
    encode_music(valve, names, os.path.join(data, 'music'))

    rep, lines = md5_report(out, data)
    say(''); say('Done in %.0f s. Files written (MD5, size, name), also in %s:' % (time.time() - t0, rep))
    for l in lines: say('  ' + l)
    rep2 = check_reference(valve, data, out)
    say('')
    if rep2: say('The full list is in ' + rep2)
    say('Copy the folder "data" into your ZZHalfLife drawer on the Amiga (with zzhl_core.bin already in it).')
    say('It is made from your copy of Half-Life: do not give it away.')
    return 0


if __name__ == '__main__':
    try:
        rc = main()
    except KeyboardInterrupt:
        rc = 1
    except SystemExit:
        raise
    except Exception:                    # 17/11: a bug of the tool must not close the window on a raw traceback
        import traceback
        traceback.print_exc()
        say(''); say('ERROR: this is a fault of the tool, not of your Half-Life. Nothing was changed in your Steam folder.')
        say('       Please send the text above to whoever gave you this program.')
        rc = 1
    finish(rc or 0)
