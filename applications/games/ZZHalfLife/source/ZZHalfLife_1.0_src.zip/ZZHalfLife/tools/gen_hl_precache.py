#!/usr/bin/env python3
# gen_hl_precache.py - ZZHalfLife (build 43): from the hlsdk-portable sources (dlls/), the files
# each entity class precaches, for tools/hl_chapters.py.  Run on the development machine only:
#   python3 tools/gen_hl_precache.py <hlsdk-portable>/dlls > tools/hl_precache_table.py
# For each LINK_ENTITY_TO_CLASS( name, CClass ): the body of CClass::Precache (and of the
# functions it calls by name that the sources define: W_Precache, ClientPrecache, a base
# class's Precache...), its string literals ending in .mdl / .spr / .wav, the arrays it walks
# (PRECACHE_SOUND_ARRAY, ARRAYSIZE, X[i]) and UTIL_PrecacheOther( "class" ); the sentence groups
# named anywhere in the class's file ("SC_IDLE", "!SC_CUREA").  It counts large: a doubt is a
# file in.  Output: a Python module, PRECACHE = { class: (files, other classes, groups) }.
# Code by the ZZHalfLife port, 0BSD; the table it writes is file names read from hlsdk-portable
# (Half-Life 1 SDK licence, see its LICENSE).  ASCII only.
import os, re, sys

src_dir = sys.argv[1]
texts = {}
for root, _, files in os.walk(src_dir):
    for f in files:
        if f.endswith('.cpp') or f.endswith('.h'):
            p = os.path.join(root, f)
            texts[p] = open(p, encoding='latin-1').read()

def strip_comments(t):
    t = re.sub(r'/\*.*?\*/', ' ', t, flags=re.S)
    return re.sub(r'//[^\n]*', ' ', t)
texts = {p: strip_comments(t) for p, t in texts.items()}

def body_at(t, i):
    """the {...} block starting at the first '{' from i"""
    j = t.find('{', i)
    if j < 0: return ''
    d = 0
    for k in range(j, len(t)):
        if t[k] == '{': d += 1
        elif t[k] == '}':
            d -= 1
            if d == 0: return t[j:k + 1]
    return t[j:]

def find_function(name):
    """bodies of 'Class :: Func(' or 'void Func(' definitions"""
    out = []
    if '::' in name:
        cl, fn = name.split('::')
        pat = re.compile(r'\b' + re.escape(cl) + r'\s*::\s*' + re.escape(fn) + r'\s*\([^;{]*\)\s*\{')
    else:
        pat = re.compile(r'^\s*(?:void|static void)\s+' + re.escape(name) + r'\s*\([^;{]*\)\s*\{', re.M)
    for p, t in texts.items():
        for m in pat.finditer(t):
            out.append((p, body_at(t, m.start())))
    return out

def arrays_in(t):
    """'CClass::X' or 'X' -> literals of 'CClass::X[] = { "a", "b" }' / 'X[] = {...}' of a file"""
    out = {}
    for m in re.finditer(r'(?:(\w+)\s*::\s*)?(\w+)\s*\[\s*\w*\s*\]\s*=\s*\{', t):
        b = body_at(t, m.start())
        lits = re.findall(r'"([^"\n]*)"', b)
        key = (m.group(1) + '::' + m.group(2)) if m.group(1) else m.group(2)
        if lits: out.setdefault(key, []).extend(lits)
    return out

all_arrays = {}            # qualified names, and the unqualified ones of each file
file_arrays = {}
for p, t in texts.items():
    a = arrays_in(t)
    file_arrays[p] = a
    for k, v in a.items():
        if '::' in k: all_arrays.setdefault(k, []).extend(v)

def array_lits(cname, a, path):
    """an array walked by CClass::Precache: CClass::a, else one of the same file, else none"""
    if cname + '::' + a in all_arrays: return all_arrays[cname + '::' + a]
    if a in file_arrays.get(path, {}): return file_arrays[path][a]
    return []

classes = {}
for p, t in texts.items():
    for m in re.finditer(r'LINK_ENTITY_TO_CLASS\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', t):
        classes.setdefault(m.group(1), (m.group(2), p))

def media(lits):
    out = set()
    for s in lits:
        s = s.strip().replace('\\', '/')
        lo = s.lower()
        if lo.endswith('.mdl') or lo.endswith('.spr'): out.add(lo)
        elif lo.endswith('.wav'):
            out.add(lo if lo.startswith('sound/') else 'sound/' + lo.lstrip('*'))
    return out

def precache_of(cname, seen):
    files, others = set(), set()
    todo = [cname + '::Precache']
    while todo:
        fn = todo.pop()
        if fn in seen: continue
        seen.add(fn)
        owner = fn.split('::')[0] if '::' in fn else cname
        for p, b in find_function(fn):
            files |= media(re.findall(r'"([^"\n]*)"', b))
            for a in re.findall(r'PRECACHE_SOUND_ARRAY\s*\(\s*(\w+)\s*\)', b) + re.findall(r'ARRAYSIZE\s*\(\s*(\w+)\s*\)', b) + re.findall(r'\(\s*char\s*\*\s*\)\s*(\w+)\s*\[', b):
                files |= media(array_lits(owner, a, p))
            for g in re.findall(r'PRECACHE_MODEL\s*\(\s*(\w+)\s*\(\s*\)\s*\)', b):
                for p2, b2 in find_function(owner + '::' + g) or find_function(g):   # PRECACHE_MODEL( GetScientistModel() )
                    files |= media(re.findall(r'"([^"\n]*)"', b2))
            others |= set(re.findall(r'UTIL_PrecacheOther\s*\(\s*"(\w+)"', b))
            for base in re.findall(r'\b(C\w+)\s*::\s*Precache\s*\(', b):
                todo.append(base + '::Precache')
            for f2 in re.findall(r'\b(W_Precache|ClientPrecache|TalkInit|PrecacheSounds?)\s*\(', b):
                todo.append(f2 if f2 in ('W_Precache', 'ClientPrecache') else cname + '::' + f2)
    return files, others

table = {}
for name, (cname, path) in sorted(classes.items()):
    files, others = precache_of(cname, set())
    groups = set(re.findall(r'"(!?[A-Z][A-Z0-9]*_[A-Z0-9_]+)"', texts[path]))
    table[name] = (sorted(files), sorted(others), sorted(groups))
# the world: CWorld::Precache, with W_Precache and ClientPrecache it calls
files, others = precache_of('CWorld', set())
table['worldspawn'] = (sorted(files), sorted(others), sorted(set(re.findall(r'"(!?[A-Z][A-Z0-9]*_[A-Z0-9_]+)"', texts[classes['worldspawn'][1]])) if 'worldspawn' in classes else []))

print('# generated by tools/gen_hl_precache.py from hlsdk-portable/dlls - do not edit by hand')
print('# PRECACHE[class] = (files precached, classes precached with it, sentence groups named in its file)')
print('PRECACHE = {')
for k in sorted(table):
    f, o, g = table[k]
    print('    %r: (%r, %r, %r),' % (k, f, o, g))
print('}')
