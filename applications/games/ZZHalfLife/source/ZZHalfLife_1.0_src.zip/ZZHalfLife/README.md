# ZZHalfLife 1.0 - ARM source code (build 107)

This archive contains the engine, game module and platform integration
sources for ZZHalfLife on the ZZ9000 ARM Core1. The original Half-Life
game data and the private AmigaOS 68k launcher source are not included.

## Source layout

- `ZZHalfLife/Core1/`, `ZZHalfLife/xacp/`: ARM runtime and platform integration.
- `ZZHalfLife/zzgl/`, `ZZHalfLife/librixgpu/`: RasterIX rendering interfaces.
- `ZZHalfLife/tools/`: data preparation tools, including `zzhl_data.py`.
- `ZZHalfLife/tests/`: host-side tests.
- `ZZHalfLife/out/`: reference build-107 ARM images and checksum manifests.
- `upstream/xash3d-fwgs/`: Xash3D FWGS source at the documented revision.
- `upstream/hlsdk-portable/`: Half-Life SDK port at the documented revision.
- `runtime/ZZQuake640_Core1/`: Core1 startup/runtime code.

## Build

From the `ZZHalfLife` directory in MSYS, with a local ARM GNU Toolchain
13.2.1 installation and the included source trees:

```sh
XASH3D=../upstream/xash3d-fwgs HLSDK=../upstream/hlsdk-portable ZZQUAKE_RELEASE=../runtime/ZZQuake640_Core1 sh build_arm.sh
```

For the optional resolutions, prefix the command with `ZZHL_RES=320`
or `ZZHL_RES=800`. The build is designed to run offline with local
sources; no automatic downloads are required.

The engine (`zzhl_core.bin`) and HLSDK game module (`zzhl_game.bin`) are
separate ARM images. The stage-1 loader is `zzhl.bin` (with 320 and 800
variants). The Amiga 68k launcher is a separate executable, not built here.

## Licenses

See `ZZHalfLife/release/LICENSES.txt`, the accompanying GPL and HLSDK
license files, and the individual source notices. Xash3D FWGS uses
GPLv3-or-later; the game code uses the Valve Half-Life 1 SDK license.
FreeVGUI uses the BSD 3-Clause license. Individual components of ZZGL
and librixgpu retain their own license notices, including the GPL
notice on `rix_walk_model.h`.
