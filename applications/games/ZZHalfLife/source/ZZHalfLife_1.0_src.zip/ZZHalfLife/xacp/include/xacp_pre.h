/* xacp_pre.h - ZZHalfLife: forced include (-include) for every Xash3D-FWGS engine unit built
 * for Core1.  newlib/arm-none-eabi differences the engine does not expect on a "non-POSIX"
 * platform:
 *   - PRIx64 & co. (engine prints 64-bit ids): with the Debian/Ubuntu arm-none-eabi packages
 *     GCC's own stdint.h is used and newlib's <inttypes.h> then leaves the 64-bit macros out
 *     (__int64_t_defined unset); they are defined here when missing (int64_t is long long);
 *   - STDOUT_FILENO (sys_con.c writes the log with write(2)): <unistd.h>;
 *   - SIGINT (system.c, Sys_DebugBreak, never reached: no debugger): <signal.h>.
 * ASCII only. */
#ifndef ZZHL_XACP_PRE_H
#define ZZHL_XACP_PRE_H
#include <stdint.h>
#include <inttypes.h>
#include <unistd.h>
#include <signal.h>
#ifndef PRIx64
#define PRId64 "lld"
#define PRIi64 "lli"
#define PRIu64 "llu"
#define PRIx64 "llx"
#define PRIX64 "llX"
#endif
#endif
