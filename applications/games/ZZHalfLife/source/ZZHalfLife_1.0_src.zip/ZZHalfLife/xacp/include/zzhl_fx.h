/* Frame counters used by the Core1 performance report.
 * Counters retain the origin of deferred GL work and are aggregated
 * by frame-time bucket.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef ZZHL_FX_H
#define ZZHL_FX_H

/* where a draw comes from (the index ZZGL counts under, zzgl_origin_set: at most ZZGL_ORIGINS) */
enum {
	ZORG_OTHER = 0,      /* no marker: loading plaque, tests, what ref_gl draws between the phases */
	ZORG_WORLD,          /* R_DrawWorld: the level's own surfaces, first pass */
	ZORG_LIGHTMAP,       /* the modulation pass (GL queue group 1), whoever owns the surface */
	ZORG_BRUSH,          /* brush entities: doors, lifts, glass, func_wall */
	ZORG_STUDIO,         /* studio models */
	ZORG_VIEWMODEL,      /* the weapon in the player's hands */
	ZORG_SPRITE,         /* sprite entities */
	ZORG_EFX,            /* CL_DrawEFX (temp entities, beams, particles, tracers), the client's triangles */
	ZORG_DECAL,          /* depth-biased overlays (GL queue group 2) */
	ZORG_SKY,            /* the sky box */
	ZORG_WATER,          /* R_DrawWaterSurfaces */
	ZORG_2D,             /* orthographic projection: HUD, menu, console, the fps counter */
	ZORG_COUNT
};
/* per origin */
enum {
	ZFXO_BATCHES = 0,    /* Begin/End pairs that reached ZZGL */
	ZFXO_TRIS,           /* triangles sent to the GPU (after culling and clipping) */
	ZFXO_PX_OPAQUE,      /* pixels they cover on the screen, blending off */
	ZFXO_PX_BLEND,       /* idem, blending on */
	ZFXO_BINDS,          /* binds really sent */
	ZFXO_PAGES,          /* 2 KiB pages those binds stream into the TMU */
	ZFXO_US,             /* Core1's time inside the draws (ZZGL, GPU waits included) */
	ZFXO_TRIS_IN,        /* triangles handed to ZZGL, before culling and clipping */
	ZFXO_WAIT_US,        /* of ZFXO_US, the part spent waiting for the GPU (queue full, ring slot, bind fence) */
	ZFXO_PX_BOX,         /* build 86, BOXPX=1 only: pixels of the bounding boxes of the triangles sent */
	ZFXO_WK_DESC,        /* build 87, WALKSTAT=1 only: descriptors sent to the GPU (a triangle cut by the screen clip makes several) */
	ZFXO_WK_CLOCKS,      /*   the clocks the rasteriser's edge walker spends on them, by its model (librixgpu/rix_walk_model.h) */
	ZFXO_WK_FAR,         /*   of which on lines where it ran to the end of the box */
	ZFXO_WK_END,         /*   of which on the lines before the first and after the last line with a pixel */
	ZFXO_WK_LINES,       /*   lines walked */
	ZFXO_WK_EMPTY,       /*   of which hold no pixel */
	ZFXO_TRIS_REJ,       /* build 87, REJECT=1: of ZFXO_TRIS_IN, the triangles of batches dropped whole because nothing of them was in view */
	ZFXO_COUNT
};

enum {
	ZFX_FLUSH_FRAME = 0, ZFX_FLUSH_STATE, ZFX_FLUSH_TEXTURE, ZFX_FLUSH_CLEAR, ZFX_FLUSH_FULL, ZFX_FLUSH_EARLY,   /* = GLQ_WHY_* */
	ZFX_MID_BATCHES,     /* batches replayed by the flushes that are not the end of the frame */
	ZFX_BINDS_REQ,       /* binds as ref_gl issued them */
	ZFX_TEX_DISTINCT,    /* distinct textures among them */
	ZFX_REPLAY_US,       /* the GL queue's replays, wherever they happened */
	ZFX_SV_US,           /* Host_ServerFrame */
	ZFX_CL_US,           /* from Host_ClientFrame to the start of the 3D scene */
	ZFX_SND_US,          /* the sound mix (SNDDMA_BeginPainting .. SNDDMA_Submit), wherever it runs */
	ZFX_SND_MIXES,       /* how many times a frame it runs */
	ZFX_SPR_QUADS,       /* sprite quads drawn (R_DrawSpriteQuad) */
	ZFX_SPR_TRIMMABLE,   /* of which: the texture has an empty margin the drawing mode cannot show */
	ZFX_SPR_KEPT1000,    /* for those: the part of the quad that can show, per thousand, summed */
	ZFX_ZC_SKIPPED,      /* depth clears not sent to the GPU (ZCLEAR=1: the buffer came clean from the PL330) */
	ZFX_ZC_GPU,          /* depth clears the GPU made */
	ZFX_ZC_WAIT_US,      /* Core1 waiting for the PL330's copy as a frame opened */
	ZFX_ZC_LATE,         /* of the PL330 clears, those made as the frame opened (the buffer had not been cleared in advance) */
	ZFX_BF_LINES,        /* build 87, BOXFIT: lines without a pixel taken off the triangles' boxes */
	ZFX_BF_DROPPED,      /* build 87, BOXFIT: triangles not sent because their box held no pixel at all */
	ZFX_FLUSHBY0,        /* ZORG_COUNT counters: order-dependent flushes, by the origin of the draw that forced them */
	ZFX_ORG0 = ZFX_FLUSHBY0 + ZORG_COUNT,   /* then ZORG_COUNT blocks of ZFXO_COUNT */
	ZFX_COUNT = ZFX_ORG0 + ZORG_COUNT * ZFXO_COUNT
};
#define ZFX_ORG( org, what ) ( ZFX_ORG0 + ( org ) * ZFXO_COUNT + ( what ))

extern unsigned zzhl_fx[ZFX_COUNT];
/* the origin the engine is drawing for right now (set by the markers of the generated ref_gl
   patches through zzhl_refphase / zzhl_entphase and the two flags below) */
unsigned zzhl_origin_now( void );
void zzhl_org_sky( int on );
void zzhl_org_viewmodel( int on );
/* the entity-phase clock, for a caller that does somebody else's work inside the current phase
   (the GL queue's replay): returns the slot that was current.  Outside the entity loop it does
   nothing and returns 0, and handing 0 back does nothing either. */
unsigned zzhl_entphase_swap( unsigned slot );
#define ZZ_ENTPH_REPLAY 17u
/* what Core1 has waited for the GPU since the frame under way opened, in us.  Read
   before and after a draw to know how much of its time was a wait.  The counter restarts when a
   frame opens: a reading smaller than the one before means that happened in between. */
unsigned zzhl_gpu_wait_us( void );

#endif
