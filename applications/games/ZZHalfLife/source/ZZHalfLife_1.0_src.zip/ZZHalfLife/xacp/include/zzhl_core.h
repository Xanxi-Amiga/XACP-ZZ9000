/* zzhl_core.h - ZZHalfLife: the engine image file (zzhl_core.bin, stage 2) as the stage-1
 * loader reads it: a 64-byte header, then the image (text, rodata, data), loaded at
 * ZZHL_CORE_LOAD; its bss follows and is cleared by the loader.
 * tools/mkcore.py fills the header after the link. ASCII only. */
#ifndef ZZHL_CORE_H
#define ZZHL_CORE_H
#define ZZHL_CORE_MAGIC0   0x4C48525Au   /* "ZRHL" */
#define ZZHL_CORE_MAGIC1   0x45524F43u   /* "CORE" */
#define ZZHL_CORE_VERSION  1u
#define ZZHL_CORE_LOAD     0x3A800000u   /* link address of the image */
#define ZZHL_CORE_LIMIT    0x3D800000u   /* image + bss must end below the GPU reservation */
#define ZZHL_STACK_LO      0x3A000000u   /* engine stack, 8 MiB, grows down from ZZHL_STACK_HI */
#define ZZHL_STACK_HI      0x3A800000u
#define ZZHL_HEAP_LO       0x30000000u   /* engine heap: from the end of the boot container */
#define ZZHL_HEAP_HI       0x3A000000u
typedef struct {
	unsigned magic0, magic1;   /* ZRHL CORE */
	unsigned version;          /* ZZHL_CORE_VERSION */
	unsigned hdr_size;         /* 64 */
	unsigned load;             /* ZZHL_CORE_LOAD */
	unsigned image_size;       /* bytes of the file, header included */
	unsigned bss_start, bss_end;
	unsigned entry;            /* zzhl_core_entry address */
	unsigned crc32;            /* of the file after the header */
	unsigned vid_w, vid_h;     /* the screen the image was built for */
	unsigned reserved[4];
} zzhl_core_hdr_t;
#endif
