/* xacp_glq.h - ZZHalfLife: the draw queue between ref_gl's GL calls (xacp_gl.c) and ZZGL.
 *
 * Why: RasterIX (XX19d-RIX, G4B configuration) has ONE texture unit and no texture cache: every
 * texture change streams the texture's pages into the TMU and drains the pipeline (librixgpu
 * rule 11: the bind travels outside the frame chunks and the next chunk waits for its fence).
 * Measured on the A4000 (31/10, c0a0): 66 to 129 binds a frame at about 144 us each, 9.6 ms of a
 * 20.5 ms frame.  ref_gl draws the world by texture chains, but then every brush model (doors,
 * the tram, platforms) re-binds its textures surface by surface, the lightmap pass re-binds its
 * pages after each entity, and studio models bind per mesh: the same texture is loaded several
 * times a frame.
 *
 * What GLQ does: the batches whose result does not depend on the drawing order are recorded
 * instead of drawn, and replayed sorted by texture at the next point where order matters.
 * Recordable:
 *   group 0, opaque: depth test on, depth write on, blending off, polygon fill, colour mask on,
 *     no scissor, perspective projection (alpha test on or off: a per-fragment kill is order
 *     independent).  With a depth test, the final pixel of two opaque fragments is the nearest
 *     one whatever the order (equal depths excepted: coplanar polygons z-fight in any order).
 *   group 1, the lightmap pass of ref_gl (R_BlendLightmaps): depth func EQUAL, depth write off,
 *     blend (ZERO, SRC_COLOR) or (DST_COLOR, SRC_COLOR).  Such a fragment only modulates the
 *     pixel whose depth is exactly its own, i.e. the base fragment of the same polygon, drawn
 *     from the same vertices through the same arithmetic.  Moving all of group 1 after all of
 *     group 0 is therefore exact: an opaque fragment drawn later in front of a modulated pixel
 *     replaces it (and gets its own lightmap pass later), one drawn behind is rejected.
 * Everything else (blended entities, sprites, particles, decals, 2D, clears, scissors) is a
 * flush point: the queue is replayed in sorted order, then the call goes through.  A texture
 * update (TexImage2D / TexSubImage2D / delete / filter) of a texture the queue references is a
 * flush point too: the dynamic-lightmap sequence of ref_gl (upload a block, draw it, upload the
 * next surface into the SAME block, draw it) keeps its order.
 *
 * The replay re-issues the GL state of every batch (the "key": enables, depth/blend/alpha funcs,
 * cull, shade model, texture env), its texture, and the exact modelview/projection matrices it
 * was recorded with (ZZGL transforms at glVertex time, so the matrices must be the batch's own:
 * identical inputs give identical descriptors, which is what the EQUAL pass needs).  After the
 * replay the engine's current state is restored, so pass-through draws see what ref_gl set.
 *
 * Off (SORT=0) every call goes straight to ZZGL, as in builds 1-9; the shadow state is kept
 * either way for the bind statistics.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#ifndef XACP_GLQ_H
#define XACP_GLQ_H

void glq_set_sort( int on );
void glq_set_decal_bias( int scale );         /* glPolygonOffset emulation for overlays (decals), 0 = off; see xacp_glq.c */
void glq_set_lm_depth( int mode );            /* LMDEPTH: the depth test of a modulation pass (lightmaps):
                                                 1 = GL_EQUAL as the engine asks (default),
                                                 0 = GL_LEQUAL, tolerant of a rounding difference,
                                                 2 = GL_ALWAYS, a probe (does the pass cover the pixel at all?) */
void glq_set_decal_group( int mode );         /* DECALQ: 0 = a biased overlay flushes the queue (build 53),
                                                 1 = third group replayed last in the recorded order (build 54),
                                                 2 = third group replayed last and sorted by texture (build 55) */
void glq_polygon_offset( float factor, float units );
unsigned glq_biased( void );                  /* batches drawn with the bias since the start */
void glq_set_bindtest( int mode );            /* 1: every 3D draw uses one tiny texture (no binds at all); 2: two tiny textures alternate (binds kept, 1 page each) */
int  glq_sort_on( void );
void glq_set_early( int on );                 /* build 84, EARLY: 1 = the world replayed when R_DrawWorld returns; 0 (default) at the first order-dependent draw */
int  glq_early( void );
void glq_set_recfast( int on );            /* build 92, RECFAST=1: a recorded vertex's colour kept in bytes, nothing told to ZZGL meanwhile */
int  glq_recfast( void );
unsigned glq_recfast_check( void );        /* the 256 byte values through the division and back: how many change (must be 0) */
/* build 94, DECALCULL=1 (off by default): an overlay wholly out of view is dropped at its glEnd
   instead of being recorded and replayed (xacp_glq.c).  Does nothing without REJECT=1. */
void glq_set_emit_prof( int on );             /* build 95, EMITPROF=1: a measure of the recorded calls and of the gaps between them (xacp_glq.c) */
int  glq_emit_prof( void );
unsigned glq_emit_prof_empty( void );          /* ticks (3 ns) of two timer reads with nothing between */
unsigned glq_emit_prof_get( int cls, int what, unsigned long long *ticks );   /* cls 0 models, 1 the rest; what 0..9; returns the calls */
void glq_end_indexed( const unsigned char *idx, unsigned n );   /* ends a glq_begin( ZGL_TRIANGLES ) whose vertices were given once each (60 at most); n indices, three a triangle */
unsigned glq_indexed_stats( unsigned *tris );                  /* indexed batches recorded since the start, and their triangles */
void glq_set_decal_frust( int mode );          /* build 96, DECALFRUST=1|2 (off by default): ref_gl does not emit a decal out of its frustum; 2 = a check */
int  glq_decal_frust( void );
void glq_decal_frust_stats( unsigned v[5] );   /* looked at, called out of view, marked ones met, the clip test disagrees, not checked */
#define GLQ_OV_SRC 5                           /* 0 water, 1 decals, 2 brush entity at rest, 3 moved brush entity, 4 the rest */
void glq_overlay_src_stats( unsigned drop[GLQ_OV_SRC], unsigned dropv[GLQ_OV_SRC], unsigned keep[GLQ_OV_SRC], unsigned keepv[GLQ_OV_SRC] );   /* overlays dropped out of view and recorded, by source: batches and vertices */
void glq_set_water_cull( int mode );           /* build 98, WATERCULL=1|2 (off by default): ref_gl does not emit a water polygon out of its frustum; 2 = a check */
int  glq_water_cull( void );
void glq_water_stats( unsigned v[8] );         /* water polygons looked at, called out of view, tested; highest wave x1000; surfaces drawn by the world, an entity at rest, moved, rotated */
void glq_set_decal_cull( int on );
void glq_decal_cull_reject_is( int on );
int  glq_decal_cull( void );
unsigned glq_decal_culled( unsigned *verts );             /* batches (and their vertices) dropped since the start */
unsigned glq_decal_cull_check( unsigned *batches, unsigned *dropped, unsigned *plain );   /* batches it drops that the plain comparisons keep: must be 0 */
void glq_color4ub( unsigned r, unsigned g, unsigned b, unsigned a );
void glq_early_feed( unsigned starved_us );   /* build 89, EARLY=2: the GPU's idle time with nothing queued, last frame (us) */
int  glq_early_now( void );                   /* 1 = the world is replayed early on this frame */
void glq_set_f2b( int on );                   /* build 84, F2B: 1 = the opaque textures replayed from the nearest to the farthest; 0 (default) in texture order */
int  glq_f2b( void );
void zzhl_world_done( void );                 /* called by ref_gl (generated patch of gl_rmain.c) after R_DrawWorld */
void glq_set_fxtime( int on );                /* build 84, FXTIME: 0 = no clock reading for the time by origin (default 1) */
int  glq_trim_kind( void );                   /* build 84, SPRTRIM: bit 0 = alpha-0 texels, bit 1 = black texels cannot show in the current state; 0 = none */

/* state: shadowed, then forwarded to ZZGL */
void glq_enable( unsigned cap, int on );
void glq_depth_func( unsigned f );
void glq_depth_mask( int on );
void glq_blend_func( unsigned s, unsigned d );
void glq_alpha_func( unsigned f, float ref );
void glq_cull_face( unsigned m );
void glq_front_face( unsigned m );
void glq_shade_model( unsigned m );
void glq_polygon_mode( unsigned m );
void glq_tex_env( unsigned mode );
void glq_color_mask( int on );
void glq_scissor( int x, int y, int w, int h );
void glq_viewport( int x, int y, int w, int h );
void glq_depth_range( double n, double f );
void glq_bind( unsigned tex );                /* the engine's bind: shadow + ZZGL (uploads follow it) */
void glq_color( float r, float g, float b, float a );
void glq_texcoord( float s, float t );

/* draws (immediate mode and the vertex-array replay of xacp_gl.c both come here) */
void glq_begin( unsigned mode );
void glq_vertex( float x, float y, float z );
void glq_end( void );

/* flush points */
void glq_flush( int why );                    /* replay everything recorded (GLQ_WHY_*) */
void glq_texture_touched( unsigned tex );     /* before an upload / delete / filter change of tex */
unsigned glq_bound( void );                   /* the engine's bound texture */
unsigned glq_splits( void );                  /* runs cut at 60 vertices since the start (build 15) */
void glq_texture_size( unsigned tex, unsigned w, unsigned h );   /* for the bind byte statistics */
void glq_matrix_mode( unsigned m );
void glq_frame_end( void );                   /* GL_SwapBuffers: flush, per-frame statistics */

#define GLQ_WHY_FRAME    0
#define GLQ_WHY_STATE    1   /* a non-recordable draw */
#define GLQ_WHY_TEXTURE  2   /* a texture the queue uses changes */
#define GLQ_WHY_CLEAR    3   /* clear, scissor, viewport, depth range, read pixels, finish */
#define GLQ_WHY_FULL     4
#define GLQ_WHY_EARLY    5   /* the world replayed at the end of its walk (EARLY=1) */
#define GLQ_WHY_COUNT    6

/* statistics, whole run (per-frame averages are the caller's division) */
typedef struct {
	unsigned frames;
	unsigned binds_req;        /* texture changes between consecutive draws, as ref_gl issued them */
	unsigned binds_done;       /* texture changes actually sent to ZZGL (after sorting, before ZZGL's own skip) */
	unsigned binds_3d, binds_2d;
	unsigned distinct;         /* distinct textures drawn with, summed over frames */
	unsigned rebinds;          /* binds of a texture already used earlier in the same frame (before sorting) */
	unsigned bind_kib;         /* texels streamed by the binds done, KiB (w*h*2) */
	unsigned batches, batches_recorded, verts_recorded;
	unsigned flushes[GLQ_WHY_COUNT];
	unsigned replay_us;        /* Core1 time inside the replays (ZZGL work included) */
	unsigned max_batches, max_verts;
	/* the replay split by group - 0 opaque, 1 the lightmap pass, 2 the biased overlays
	   (decals, marks).  Answers "what do the overlays cost" without a per-batch timer: the replay is
	   already ordered by group, so one timestamp per group boundary is enough. */
	unsigned grp_batches[3], grp_binds[3], grp_verts[3], grp_us[3];
} glq_stats_t;
const glq_stats_t *glq_stats( void );

#endif
