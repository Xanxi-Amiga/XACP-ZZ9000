/* zzhl_benchload.h - when has the scene a bench command asked for loaded?
 *
 * Kept apart from xacp_bench.c so that the PC can test it (tests/test_benchload.c): build 84 got
 * this wrong on the A4000 and only a real disk showed it.  Its rule was "the client must leave the
 * scene before within 15 s".  A load that begins by reading a chapter from the disk blocks inside
 * the command for longer than that (19 s on 15/11), and on the first engine frame afterwards the
 * client is still "active": two scenes were called failed while they loaded, and one was measured
 * under the next one's name.
 *
 * The rule now, one call per engine frame after the command:
 *   1. the engine has spawned a server since the command (svs.spawncount moved: that happens
 *      inside the command, however long it blocks);
 *   2. the client has been seen out of the game since - it reconnects to the new server - or was
 *      not in a game when the command was given (the menu);
 *   3. client and server are both active again.
 * A command that loaded nothing (no such save) leaves the spawn count alone while engine frames
 * keep coming: BENCHLOAD_NOTHING after 90 such frames and 6 s.  No engine frame runs while a load
 * blocks, so a slow disk cannot look like that.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#ifndef ZZHL_BENCHLOAD_H
#define ZZHL_BENCHLOAD_H

enum { BENCHLOAD_WAIT = 0, BENCHLOAD_IN_GAME, BENCHLOAD_NOTHING, BENCHLOAD_NEVER_SHOWN };

typedef struct {
	int    spawn0;         /* svs.spawncount when the command was given */
	int    frames0;        /* the bench's engine-frame count then */
	double t0;             /* the time then, seconds */
	int    left;           /* 1: the client has been seen out of the game since (or was not in one) */
} benchload_t;

static inline void benchload_begin( benchload_t *b, int spawncount, int frames, double now, int client_active )
{
	b->spawn0 = spawncount; b->frames0 = frames; b->t0 = now; b->left = client_active ? 0 : 1;
}

static inline int benchload_step( benchload_t *b, int spawncount, int frames, double now, int client_active, int server_active )
{
	if( spawncount == b->spawn0 )
		return ( frames - b->frames0 > 90 && now - b->t0 > 6.0 ) ? BENCHLOAD_NOTHING : BENCHLOAD_WAIT;
	if( !client_active ) b->left = 1;
	if( b->left && client_active && server_active ) return BENCHLOAD_IN_GAME;
	return ( now - b->t0 > 600.0 ) ? BENCHLOAD_NEVER_SHOWN : BENCHLOAD_WAIT;
}

#endif
