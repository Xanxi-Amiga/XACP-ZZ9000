/* bzlib.h - ZZHalfLife stub: engine/common/net_chan.c compresses network fragments
 * with bzip2 (HL25 protocol).  No network on Core1 (XASH_NO_NETWORK): the three entry
 * points exist and fail (xacp/src/xacp_stubs.c), the engine takes its uncompressed path.
 * ASCII only. */
#ifndef ZZHL_BZLIB_H
#define ZZHL_BZLIB_H
#define BZ_OK 0
#define BZ_RUN 0
#define BZ_OUTBUFF_FULL (-8)
int BZ2_bzBuffToBuffCompress(char *dest, unsigned int *destLen, char *source, unsigned int sourceLen, int blockSize100k, int verbosity, int workFactor);
int BZ2_bzBuffToBuffDecompress(char *dest, unsigned int *destLen, char *source, unsigned int sourceLen, int small, int verbosity);
const char *BZ2_bzlibVersion(void);
#endif
