/* ABI between the Xash3D engine image and the separately loaded HLSDK image.
 * Defines module header, import functions and client/server export tables.
 * The game image is linked at a fixed address and loaded at startup.
 * SPDX-License-Identifier: 0BSD
 */
#ifndef ZZHL_GAME_H
#define ZZHL_GAME_H
#include <stddef.h>

#define ZZHL_GAME_MAGIC0   0x4C48525Au   /* "ZRHL" */
#define ZZHL_GAME_MAGIC1   0x454D4147u   /* "GAME" */
#define ZZHL_GAME_VERSION  1u
#define ZZHL_GAME_LOAD     0x3D400000u   /* link address of the game image */
#define ZZHL_GAME_LIMIT    0x3D800000u   /* = ZZHL_CORE_LIMIT: the RasterIX reservation above */
#define ZZHL_GAME_FILE     "zzhl_game.bin"
#define ZZHL_GAME_ABI      1u            /* both tables below; the engine refuses another one */

/* same layout as zzhl_core_hdr_t (tools/mkcore.py fills both) */
typedef struct {
	unsigned magic0, magic1;   /* ZRHL GAME */
	unsigned version;          /* ZZHL_GAME_VERSION */
	unsigned hdr_size;         /* 64 */
	unsigned load;             /* ZZHL_GAME_LOAD */
	unsigned image_size;       /* bytes of the file, header included */
	unsigned bss_start, bss_end;
	unsigned entry;            /* zzhl_game_entry */
	unsigned crc32;            /* of the file after the header */
	unsigned abi;              /* ZZHL_GAME_ABI */
	unsigned reserved[5];
} zzhl_game_hdr_t;

struct stat;
struct timeval;
typedef struct {
	unsigned abi, size;
	/* the C library's system calls (newlib), as the engine implements them (xacp_fs.c, xacp_libc.c) */
	int    (*open_)( const char *path, int flags, int mode );
	int    (*close_)( int fd );
	int    (*read_)( int fd, void *buf, size_t n );
	int    (*write_)( int fd, const void *buf, size_t n );
	long   (*lseek_)( int fd, long off, int whence );
	int    (*fstat_)( int fd, struct stat *st );
	int    (*stat_)( const char *path, struct stat *st );
	int    (*isatty_)( int fd );
	int    (*unlink_)( const char *path );
	int    (*link_)( const char *o, const char *n );
	int    (*mkdir_)( const char *path, unsigned mode );
	int    (*gettimeofday_)( struct timeval *tv, void *tz );
	int    (*getpid_)( void );
	int    (*kill_)( int pid, int sig );
	void   (*exit_)( int code );
	void  *(*sbrk_)( ptrdiff_t incr );
	/* one heap for both images: the engine's */
	void  *(*malloc_)( size_t n );
	void   (*free_)( void *p );
	void  *(*calloc_)( size_t n, size_t s );
	void  *(*realloc_)( void *p, size_t n );
	void  *(*memalign_)( size_t align, size_t n );
	/* the port: GPU pumps during the game logic, the microsecond clock */
	void   (*pump_soon)( void );
	unsigned long long (*us64)( void );
} zzhl_game_imports_t;

typedef struct { const char *name; void *pointer; } zzhl_game_table_t;
typedef struct {
	unsigned abi, size;
	zzhl_game_table_t *client;   /* lib_client_exports: Initialize, HUD_*, F, ... */
	zzhl_game_table_t *server;   /* lib_server_exports: GiveFnptrsToDll, GetEntityAPI2, the entity classes */
} zzhl_game_exports_t;

typedef int ( *zzhl_game_entry_t )( const zzhl_game_imports_t *imp, zzhl_game_exports_t *exp );
#endif
