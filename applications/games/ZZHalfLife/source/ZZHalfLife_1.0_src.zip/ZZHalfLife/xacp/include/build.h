/* build.h - ZZHalfLife replacement of library_suffix/include/build.h for the
 * XACP / ZZ9000 Core1 bare-metal target (arm-none-eabi, Cortex-A9, VFPv3 hard float).
 *
 * The upstream header (public domain, FWGS) reaches "#error" on a toolchain that
 * defines none of _WIN32 / __linux__ / __vita__ ...  This file is found first on
 * the include path and defines the same macro set for the XACP target:
 *   XASH_XACP 1, XASH_ARM 7, XASH_ARMv7 1, XASH_ARM_HARDFP 1, XASH_LITTLE_ENDIAN 1
 *   (XASH_BIG_ENDIAN 0 for the engine only, see below)
 * and no XASH_POSIX / XASH_WIN32: the engine then takes its "other platform"
 * branches (as for XASH_DOS4GW and XASH_PSP), and ZZHalfLife/xacp/ provides what
 * those branches need.
 * ASCII only.
 */
#pragma once
#ifndef BUILD_H
#define BUILD_H

#undef XASH_64BIT
#undef XASH_AMD64
#undef XASH_ANDROID
#undef XASH_APPLE
#undef XASH_ARM
#undef XASH_ARM_HARDFP
#undef XASH_ARM_SOFTFP
#undef XASH_ARMv4
#undef XASH_ARMv5
#undef XASH_ARMv6
#undef XASH_ARMv7
#undef XASH_ARMv8
#undef XASH_BIG_ENDIAN
#undef XASH_DOS4GW
#undef XASH_E2K
#undef XASH_FREEBSD
#undef XASH_HAIKU
#undef XASH_HURD
#undef XASH_IOS
#undef XASH_IRIX
#undef XASH_LINUX
#undef XASH_LITTLE_ENDIAN
#undef XASH_MIPS
#undef XASH_MOBILE_PLATFORM
#undef XASH_NETBSD
#undef XASH_NSWITCH
#undef XASH_OPENBSD
#undef XASH_OSX
#undef XASH_POSIX
#undef XASH_PPC
#undef XASH_PS4
#undef XASH_PSP
#undef XASH_PSVITA
#undef XASH_RISCV
#undef XASH_SERENITY
#undef XASH_SPARC
#undef XASH_SUNOS
#undef XASH_TERMUX
#undef XASH_WASI
#undef XASH_WASM
#undef XASH_WIN32
#undef XASH_X86
#undef XASH_XACP

#if !defined __arm__
	#error "ZZHalfLife build.h: this header is for the arm-none-eabi Core1 target only"
#endif

#define XASH_XACP 1
#define XASH_LITTLE_ENDIAN 1
/* The engine's build.h always defines both byte-order macros (0 or 1) and tests them with #if;
   hlsdk-portable's own build.h defines only the true one, and its common/byteswap.h tests
   "#ifdef XASH_BIG_ENDIAN".  This single header serves both: defined to 0 for the HLSDK, the
   game code believed it ran big-endian (builds 1-16) - every save/restore field byte-swapped
   (symmetrically, so it went unseen) and the retail node graphs (maps/graphs/*.nod) rejected
   ("Graph version is 268435456, expected 16") and rebuilt at every new map ("Node Graph out of
   Date. Rebuilding...").  build_arm.sh passes XACP_HLSDK=1 for the HLSDK and FreeVGUI. */
#if !defined XACP_HLSDK
#define XASH_BIG_ENDIAN 0
#endif
#define XASH_ARM 7
#define XASH_ARMv7 1
#if defined __SOFTFP__ || __ARM_PCS_VFP == 0
	#error "ZZHalfLife: the Core1 blob is hard float (-mfloat-abi=hard)"
#endif
#define XASH_ARM_HARDFP 1

#endif /* BUILD_H */
