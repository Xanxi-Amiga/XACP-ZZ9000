/* dirent.h - ZZHalfLife: newlib for arm-none-eabi has no <dirent.h>.  The engine's
 * filesystem lists directories through opendir/readdir (filesystem/sys.c, dir.c);
 * on Core1 there is no directory service yet, so the functions exist and report
 * an empty directory (xacp/src/xacp_libc.c).  ASCII only. */
#ifndef ZZHL_DIRENT_H
#define ZZHL_DIRENT_H
#include <sys/types.h>
struct dirent {
	unsigned char d_type;
	char d_name[260];
};
#define DT_UNKNOWN 0
#define DT_DIR 4
#define DT_REG 8
typedef struct { int dummy; } DIR;
DIR *opendir(const char *name);
struct dirent *readdir(DIR *d);
int closedir(DIR *d);
#endif
