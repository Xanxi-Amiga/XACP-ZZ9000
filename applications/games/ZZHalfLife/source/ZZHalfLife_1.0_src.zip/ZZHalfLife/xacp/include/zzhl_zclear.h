/* Depth-buffer state for asynchronous PL330 clears.
 * Each colour buffer has a corresponding depth buffer. A clear must complete
 * before that depth buffer is reused. Testable without RasterIX hardware.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#ifndef ZZHL_ZCLEAR_H
#define ZZHL_ZCLEAR_H

enum { ZC_DIRTY = 0, ZC_CLEARING, ZC_CLEAN };
enum { ZCA_NONE = 0, ZCA_WAIT, ZCA_START };     /* what zclear_open_need asks of the caller */

typedef struct {
	int on;                  /* asked for, self-test passed, no failure since */
	unsigned char st[2];     /* ZC_* of each buffer */
	unsigned char busy[2];   /* a frame opened on it and was not reported finished */
	int run;                 /* the buffer the PL330 is clearing, -1 = none */
	unsigned cur;            /* the buffer of the target last set */
	int game;                /* that target is a frame of the game, and no frame opened on it yet */
} zclear_t;

static void zclear_init( zclear_t *z )
{
	z->on = 0; z->st[0] = z->st[1] = ZC_DIRTY; z->busy[0] = z->busy[1] = 0; z->run = -1; z->cur = 0u; z->game = 0;
}
/* the self-test passed; clean1: buffer 1 was left full of "far" by it */
static void zclear_enable( zclear_t *z, int clean1 )
{
	z->on = 1; z->st[0] = ZC_DIRTY; z->st[1] = clean1 ? ZC_CLEAN : ZC_DIRTY; z->busy[0] = z->busy[1] = 0; z->run = -1;
}
/* the PL330 failed (the caller has stopped it): the GPU clears from now on */
static void zclear_fail( zclear_t *z )
{
	z->on = 0; z->st[0] = z->st[1] = ZC_DIRTY; z->run = -1;
}
/* the next frame's target: colour buffer i (0 or 1).  game = 1 for a frame of the game, 0 for a
   hidden frame (tests, price list), which never counts on a clean buffer */
static void zclear_target( zclear_t *z, unsigned i, int game )
{
	z->cur = i & 1u; z->game = game ? 1 : 0;
}
/* a frame is about to open on the current target: what must be done first.  Call again after
   each action until ZCA_NONE.
     ZCA_WAIT   wait for the end of the running copy, then zclear_done (or zclear_fail)
     ZCA_START  start the copy over buffer cur, then zclear_started( cur ) (or zclear_fail) */
static int zclear_open_need( const zclear_t *z )
{
	unsigned i = z->cur;
	if( z->run == (int)i ) return ZCA_WAIT;                 /* never a frame on a buffer being copied over */
	if( z->on && z->game && z->st[i] == ZC_DIRTY && !z->busy[i] ) return z->run >= 0 ? ZCA_WAIT : ZCA_START;
	return ZCA_NONE;
}
/* the frame opens (after zclear_open_need said ZCA_NONE): 1 = its depth buffer holds "far"
   everywhere, the frame's depth clear can be skipped until something writes the depth */
static int zclear_open( zclear_t *z )
{
	unsigned i = z->cur;
	int clean = ( z->on && z->game && z->st[i] == ZC_CLEAN && z->run != (int)i ) ? 1 : 0;
	z->st[i] = ZC_DIRTY; z->busy[i] = 1; z->game = 0;
	return clean;
}
static void zclear_started( zclear_t *z, unsigned i ) { z->run = (int)( i & 1u ); z->st[i & 1u] = ZC_CLEARING; }
static void zclear_done( zclear_t *z )
{
	if( z->run >= 0 ) { if( z->st[z->run] == ZC_CLEARING ) z->st[z->run] = ZC_CLEAN; z->run = -1; }
}
/* every frame drawn on buffer i has passed its fence (and was shown or dropped): 1 = start the
   copy over it now, then zclear_started( i ).  The caller polls the running copy first
   (zclear_done), so that one copy a frame always finds the channel free. */
static int zclear_release( zclear_t *z, unsigned i )
{
	i &= 1u;
	z->busy[i] = 0;
	return ( z->on && z->st[i] == ZC_DIRTY && z->run < 0 ) ? 1 : 0;
}

#endif
