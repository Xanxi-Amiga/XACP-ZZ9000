/* xacp_rt.h - ZZHalfLife: the runtime services the engine image (stage 2, zzhl_core.bin) gets
 * from the Core1 runtime blob (stage 1, zzhl.bin = ZZQuake640 release runtime + loader).
 *
 * The two are linked separately (the launcher copies at most 2 MiB to 0x04900000; the
 * engine is 4 to 6 MiB and lives in the Core1 arena). Stage 1 fills this structure and
 * calls zzhl_core_entry(rt); nothing else is shared by address. Every function is one of
 * the release runtime's (zzquake_*.c of the ZZQuake640 Core1 tree, unmodified) or of the
 * stage-1 glue (Core1/zzhl_glue.c).
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#ifndef ZZHL_XACP_RT_H
#define ZZHL_XACP_RT_H
#include <stddef.h>
#include <stdio.h>

#define ZZHL_RT_MAGIC    0x5A5A484Cu   /* "ZZHL" */
#define ZZHL_RT_VERSION  1u

typedef struct zzhl_rt_s {
	unsigned magic;             /* ZZHL_RT_MAGIC */
	unsigned version;           /* ZZHL_RT_VERSION: stage 2 refuses any other value */
	unsigned size;              /* sizeof( zzhl_rt_t ) as stage 1 built it */

	/* release shared block (ZZQ_SHARED_ARM, non-cacheable) */
	volatile unsigned *shared;

	/* time: microseconds since Core1 start (zzq_us_now, global timer) */
	unsigned (*us_now)( void );

	/* diagnostics: zzq_printf (SH_LAST_PRINTF), zzq_fatal_end (SH_ERROR + parked blob) */
	int  (*printf)( const char *fmt, ... );
	void (*fatal)( unsigned code );

	/* release file service (zzquake_fs_mem.c): PROGDIR:data/<flat name>, 512 KiB at most */
	FILE  *(*fopen)( const char *path, const char *mode );
	int    (*fclose)( FILE *f );
	size_t (*fread)( void *dst, size_t sz, size_t n, FILE *f );
	size_t (*fwrite)( const void *src, size_t sz, size_t n, FILE *f );
	int    (*fseek)( FILE *f, long off, int whence );
	long   (*ftell)( FILE *f );
	int    (*file_time)( const char *path );   /* release Sys_FileTime: 1 = exists (FS_CMD_STAT), -1 = not */

	/* partial read of a big file of PROGDIR:data/ (FS_CMD_READAT of the ZZOpenLara launcher,
	   Core1 side ported from ZZOpenLara's ol_fsat.c): len bytes at off into dst, 512 KiB per
	   request, returns the bytes read (short at the end of the file) or -1; *total = size of
	   the whole file. Flat names only (the launcher refuses separators). */
	int    (*read_at)( const char *name, unsigned off, void *dst, unsigned len, unsigned *total );

	/* input (release key queue and mouse accumulators) */
	int  (*get_key)( int *down, int *key );
	void (*get_mouse_move)( int *dx, int *dy );

	/* caches (release zzquake_mmu.c) */
	void (*dcache_clean)( unsigned start, unsigned len );
	void (*dcache_invalidate)( unsigned start, unsigned len );

	/* memory map decided by stage 1 (see docs/MEMOIRE.md) */
	unsigned pack0_addr, pack0_size;    /* the boot container the launcher preloaded (options file, 0 = none) */
	unsigned heap_lo, heap_hi;          /* engine heap (newlib malloc of stage 2 via _sbrk) */
	unsigned image_lo, image_hi;        /* stage-2 image + bss, informative */

	/* screen the launcher opened: width, height, 16 = RGB565 big-endian / 32 = 0x00RRGGBB */
	unsigned vid_w, vid_h, vid_bpp;

	/* pump: stage 1 heartbeat + launcher command check, call often during long work;
	   returns 1 when the launcher asked to stop */
	int (*pump)( void );
} zzhl_rt_t;

/* stage-2 entry: returns the engine exit code (0 = clean quit) */
typedef int (*zzhl_core_entry_t)( const zzhl_rt_t *rt );

#endif
