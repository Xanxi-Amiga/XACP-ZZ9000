/* zzhl_conlog.h - ZZHalfLife: post-mortem console mirror, readable from the 68k.
 *
 * The ZZOpenLara launcher only keeps the LAST Core1 printf line (LAST_PRINTF slot); the
 * engine's console (Xash3D's Con_Printf / Sys_Error text, the stage-1 loader messages) would
 * otherwise be lost when Core1 stops.  Both stages therefore also append every line to a
 * ring in a window the 68k can read through the frame-buffer aperture:
 *
 *   ARM 0x048C0000 .. 0x04900000 (256 KiB) = fb + 0x046C0000
 *
 * It is the top of the launcher's staging area (ZZQ_STAGING_ARM 0x04500000, 4 MiB), which the
 * launcher uses only during PRELOAD, i.e. before QG_Create; stage 1 initialises the header at
 * QG_Create and nothing else maps there (MP3 stream 0x04200000-0x04500000, blob 0x04900000,
 * shared/PCM 0x04B00000, Core1 stack 0x05F00000, file service 0x06E00000).  The release MMU
 * table maps sections 0x045-0x048 Normal non-cacheable, so the writes reach DDR without any
 * cache maintenance and tools/amiga/ZZSlots.c prints the tail after a run.
 *
 * Layout: 64-byte header (magic, version, ring size, total bytes written) then the ring.
 * ASCII only. */
#ifndef ZZHL_CONLOG_H
#define ZZHL_CONLOG_H

#define ZZHL_CONLOG_ARM     0x048C0000u
#define ZZHL_CONLOG_FB      0x046C0000u          /* 68k: fb + this */
#define ZZHL_CONLOG_WINDOW  0x00040000u
#define ZZHL_CONLOG_HDR     64u
#define ZZHL_CONLOG_RING    (ZZHL_CONLOG_WINDOW - ZZHL_CONLOG_HDR)
#define ZZHL_CONLOG_MAGIC   0x434C485Au          /* "ZHLC" little-endian */
#define ZZHL_CONLOG_VERSION 1u

typedef struct {
	volatile unsigned magic;
	volatile unsigned version;
	volatile unsigned ring_size;
	volatile unsigned wr;          /* total bytes ever written; ring index = wr % ring_size */
	volatile unsigned reserved[12];
	volatile unsigned char ring[ZZHL_CONLOG_RING];
} zzhl_conlog_t;

#define ZZHL_CONLOG ((zzhl_conlog_t *)ZZHL_CONLOG_ARM)

/* stage 1, once, at QG_Create (the staging area is idle from then on) */
static inline void zzhl_conlog_init( void )
{
	zzhl_conlog_t *c = ZZHL_CONLOG;
	unsigned i;
	c->magic = 0;
	c->version = ZZHL_CONLOG_VERSION;
	c->ring_size = ZZHL_CONLOG_RING;
	c->wr = 0;
	for( i = 0; i < 12; i++ ) c->reserved[i] = 0;
	__asm__ volatile( "dsb" ::: "memory" );
	c->magic = ZZHL_CONLOG_MAGIC;
	__asm__ volatile( "dsb" ::: "memory" );
}

/* append n bytes (any stage); a trailing '\n' is the caller's business */
static inline void zzhl_conlog_write( const char *s, unsigned n )
{
	zzhl_conlog_t *c = ZZHL_CONLOG;
	unsigned wr, i;
	if( c->magic != ZZHL_CONLOG_MAGIC || c->ring_size != ZZHL_CONLOG_RING ) return;
	wr = c->wr;
	for( i = 0; i < n; i++ ) c->ring[( wr + i ) % ZZHL_CONLOG_RING] = (unsigned char)s[i];
	__asm__ volatile( "dsb" ::: "memory" );
	c->wr = wr + n;
	__asm__ volatile( "dsb" ::: "memory" );
}

static inline void zzhl_conlog_line( const char *s )
{
	unsigned n = 0;
	while( s[n] ) n++;
	zzhl_conlog_write( s, n );
	zzhl_conlog_write( "\n", 1 );
}

#endif
