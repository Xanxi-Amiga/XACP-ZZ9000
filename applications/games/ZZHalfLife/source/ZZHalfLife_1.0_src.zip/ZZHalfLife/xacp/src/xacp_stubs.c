/* xacp_stubs.c - ZZHalfLife: engine entry points of components that are not built for
 * Core1 (first renders): music/voice codecs (mpg123, vorbis, opus), bzip2, whereami.
 * Each stub fails cleanly; the engine falls back (WAV sounds only, no voice, no bz2).
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include "common.h"
#include "soundlib.h"
#include "client.h"
#include "voice.h"
#include "bzlib.h"

/* ---- soundlib: mp3 / ogg vorbis / ogg opus (engine/client/soundlib/snd_*.c not built) ---- */
qboolean Sound_LoadMPG( const char *name, const byte *buffer, fs_offset_t filesize ) { return false; }
qboolean Sound_LoadOggVorbis( const char *name, const byte *buffer, fs_offset_t filesize ) { return false; }
qboolean Sound_LoadOggOpus( const char *name, const byte *buffer, fs_offset_t filesize ) { return false; }
stream_t *Stream_OpenMPG( const char *filename ) { return NULL; }
int Stream_ReadMPG( stream_t *stream, int bytes, void *buffer ) { return 0; }
int Stream_SetPosMPG( stream_t *stream, int newpos ) { return 0; }
int Stream_GetPosMPG( stream_t *stream ) { return 0; }
void Stream_FreeMPG( stream_t *stream ) { }
stream_t *Stream_OpenOggVorbis( const char *filename ) { return NULL; }
int Stream_ReadOggVorbis( stream_t *stream, int bytes, void *buffer ) { return 0; }
int Stream_SetPosOggVorbis( stream_t *stream, int newpos ) { return 0; }
int Stream_GetPosOggVorbis( stream_t *stream ) { return 0; }
void Stream_FreeOggVorbis( stream_t *stream ) { }
stream_t *Stream_OpenOggOpus( const char *filename ) { return NULL; }
int Stream_ReadOggOpus( stream_t *stream, int bytes, void *buffer ) { return 0; }
int Stream_SetPosOggOpus( stream_t *stream, int newpos ) { return 0; }
int Stream_GetPosOggOpus( stream_t *stream ) { return 0; }
void Stream_FreeOggOpus( stream_t *stream ) { }

/* ---- voice chat (engine/client/sound/voice.c not built: it needs opus) ---- */
voice_state_t voice;
CVAR_DEFINE_AUTO( voice_loopback, "0", 0, "no voice on Core1" );
void Voice_RegisterCvars( void ) { }
qboolean Voice_Init( const char *pszCodecName, int quality, qboolean preinit ) { return false; }
void Voice_Idle( double frametime ) { }
qboolean Voice_IsRecording( void ) { return false; }
void Voice_RecordStop( void ) { }
void Voice_RecordStart( void ) { }
void Voice_Disconnect( void ) { }
void Voice_AddIncomingData( int ent, const byte *data, uint size, uint frames ) { }
void Voice_StopChannel( int entnum ) { }
void Voice_LoopbackAck( void ) { }
voice_audio_info_t Voice_GetAudioInfo( void ) { voice_audio_info_t i; memset( &i, 0, sizeof( i )); return i; }

/* ---- bzip2 (net_chan.c) ---- */
int BZ2_bzBuffToBuffCompress( char *dest, unsigned int *destLen, char *source, unsigned int sourceLen, int blockSize100k, int verbosity, int workFactor ) { return BZ_OUTBUFF_FULL; }
int BZ2_bzBuffToBuffDecompress( char *dest, unsigned int *destLen, char *source, unsigned int sourceLen, int small, int verbosity ) { return BZ_OUTBUFF_FULL; }
const char *BZ2_bzlibVersion( void ) { return "none"; }

/* ---- whereami (engine/common/whereami.c has no Core1 branch) ---- */
int wai_getExecutablePath( char *out, int capacity, int *dirname_length )
{
	static const char exe[] = "PROGDIR:zzhl.bin";
	int n = (int)sizeof( exe ) - 1;
	if( out && capacity > 0 )
	{
		int k = n < capacity ? n : capacity;
		memcpy( out, exe, k );
		if( k < capacity ) out[k] = 0;
	}
	if( dirname_length ) *dirname_length = 8;
	return n;
}
