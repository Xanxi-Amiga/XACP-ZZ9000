/* Load the HLSDK game image and register its client/server exports.
 * Engine and game are separate images communicating through zzhl_game.h.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include "xacp_rt.h"
#include "zzhl_core.h"
#include "zzhl_game.h"

extern const zzhl_rt_t *zzhl_rt;
extern void zzhl_log( const char *s );
extern unsigned long long zzhl_us64( void );
extern void zzhl_pump_soon( void );
/* the engine's system calls (xacp_fs.c, xacp_libc.c) */
extern int _open( const char *path, int flags, int mode );
extern int _close( int fd );
extern int _read( int fd, void *buf, size_t n );
extern int _write( int fd, const void *buf, size_t n );
extern off_t _lseek( int fd, off_t off, int whence );
extern int _fstat( int fd, struct stat *st );
extern int _stat( const char *path, struct stat *st );
extern int _isatty( int fd );
extern int _unlink( const char *path );
extern int _link( const char *o, const char *n );
extern int mkdir( const char *path, mode_t mode );
extern int _gettimeofday( struct timeval *tv, void *tz );
extern int _getpid( void );
extern int _kill( int pid, int sig );
extern void _exit( int code );
extern void *_sbrk( ptrdiff_t incr );
/* lib_static.c's list of libraries (build_arm.sh, generated_library_tables.h) */
extern void zzhl_game_libs_set( void *client, void *server );

static long g_lseek( int fd, long off, int whence ) { return (long)_lseek( fd, (off_t)off, whence ); }
static int g_mkdir( const char *path, unsigned mode ) { return mkdir( path, (mode_t)mode ); }

static zzhl_game_imports_t g_imp;
static zzhl_game_exports_t g_exp;

static unsigned crc32_of( const unsigned char *p, unsigned n )
{
	static unsigned t[256];
	unsigned c, i, k;
	if( !t[1] )
		for( i = 0; i < 256u; i++ ) { c = i; for( k = 0; k < 8u; k++ ) c = ( c & 1u ) ? 0xEDB88320u ^ ( c >> 1 ) : c >> 1; t[i] = c; }
	c = 0xFFFFFFFFu;
	while( n-- ) c = t[( c ^ *p++ ) & 0xFFu] ^ ( c >> 8 );
	return c ^ 0xFFFFFFFFu;
}

/* 0 = loaded; else the step that failed (said in the message) */
static int read_image( zzhl_game_hdr_t *h )
{
	unsigned total = 0, done, size;
	unsigned char *dst;
	int n;
	if( !zzhl_rt->read_at ) return 1;
	n = zzhl_rt->read_at( ZZHL_GAME_FILE, 0, h, sizeof( *h ), &total );
	if( n != (int)sizeof( *h )) return 1;                                       /* absent or short */
	if( h->magic0 != ZZHL_GAME_MAGIC0 || h->magic1 != ZZHL_GAME_MAGIC1 ) return 2;
	if( h->version != ZZHL_GAME_VERSION || h->hdr_size != sizeof( *h ) || h->abi != ZZHL_GAME_ABI ) return 3;
	if( h->load != ZZHL_GAME_LOAD || h->image_size != total || h->image_size < sizeof( *h )) return 4;
	if( h->bss_end > ZZHL_GAME_LIMIT || h->bss_start < h->load + h->image_size - sizeof( *h ) || h->bss_end < h->bss_start ) return 5;
	if( h->entry < h->load || h->entry >= h->load + h->image_size ) return 6;
	size = h->image_size;
	dst = (unsigned char *)h->load;
	done = 0;
	while( done < size )
	{
		unsigned want = size - done;
		if( want > 1024u * 1024u ) want = 1024u * 1024u;
		n = zzhl_rt->read_at( ZZHL_GAME_FILE, done, dst + done, want, NULL );
		if( n <= 0 ) return 7;
		done += (unsigned)n;
		if( zzhl_rt->pump ) zzhl_rt->pump();
		if( (unsigned)n < want ) break;
	}
	if( done != size || memcmp( dst, h, sizeof( *h ))) return 8;
	if( crc32_of( dst + sizeof( *h ), size - sizeof( *h )) != h->crc32 ) return 9;
	return 0;
}

int zzhl_game_load( void )
{
	static zzhl_game_hdr_t h;
	char line[160];
	unsigned long long t0 = zzhl_us64();
	int rc, tries;
	extern char _end[];
	if( (unsigned)_end > ZZHL_GAME_LOAD )
	{
		zzhl_log( "ZZHalfLife: the engine image reaches the game image's address: wrong build" );
		return 10;
	}
	for( tries = 0; tries < 2; tries++ )      /* a wrong answer of the file service is read again once */
		if(( rc = read_image( &h )) == 0 || rc < 7 ) break;
	if( rc )
	{
		static const char *const why[10] = { "", "not found (copy out/zzhl_game.bin into PROGDIR:data/)", "not a game image",
			"another version", "wrong size or address", "too big", "bad entry", "read failed", "read short", "CRC wrong" };
		snprintf( line, sizeof( line ), "ZZHalfLife: data/" ZZHL_GAME_FILE ": %s (step %d)", rc < 10 ? why[rc] : "?", rc );
		zzhl_log( line );
		if( zzhl_rt->printf ) zzhl_rt->printf( "%s", line );     /* the launcher's last line */
		return rc;
	}
	memset( (void *)h.bss_start, 0, h.bss_end - h.bss_start );
	/* the image was written through the data side: clean it, then forget the instruction side */
	zzhl_rt->dcache_clean( h.load, h.bss_end - h.load );
	__asm__ volatile( "dsb sy" ::: "memory" );
	__asm__ volatile( "mcr p15, 0, %0, c7, c5, 0" :: "r"( 0 ));   /* ICIALLU */
	__asm__ volatile( "mcr p15, 0, %0, c7, c5, 6" :: "r"( 0 ));   /* BPIALL */
	__asm__ volatile( "dsb sy\n\tisb" ::: "memory" );

	memset( &g_imp, 0, sizeof( g_imp ));
	g_imp.abi = ZZHL_GAME_ABI; g_imp.size = sizeof( g_imp );
	g_imp.open_ = _open; g_imp.close_ = _close; g_imp.read_ = _read; g_imp.write_ = _write;
	g_imp.lseek_ = g_lseek; g_imp.fstat_ = _fstat; g_imp.stat_ = _stat; g_imp.isatty_ = _isatty;
	g_imp.unlink_ = _unlink; g_imp.link_ = _link; g_imp.mkdir_ = g_mkdir;
	g_imp.gettimeofday_ = _gettimeofday; g_imp.getpid_ = _getpid; g_imp.kill_ = _kill;
	g_imp.exit_ = _exit; g_imp.sbrk_ = _sbrk;
	g_imp.malloc_ = malloc; g_imp.free_ = free; g_imp.calloc_ = calloc; g_imp.realloc_ = realloc; g_imp.memalign_ = memalign;
	g_imp.pump_soon = zzhl_pump_soon; g_imp.us64 = zzhl_us64;
	memset( &g_exp, 0, sizeof( g_exp ));
	g_exp.size = sizeof( g_exp );
	rc = (( zzhl_game_entry_t )h.entry )( &g_imp, &g_exp );
	if( rc || g_exp.abi != ZZHL_GAME_ABI || !g_exp.client || !g_exp.server )
	{
		snprintf( line, sizeof( line ), "ZZHalfLife: data/" ZZHL_GAME_FILE " refused its entry (%d)", rc );
		zzhl_log( line );
		if( zzhl_rt->printf ) zzhl_rt->printf( "%s", line );
		return 11;
	}
	zzhl_game_libs_set( g_exp.client, g_exp.server );
	snprintf( line, sizeof( line ), "ZZHalfLife: game image %u KiB at %08x (bss to %08x), loaded in %u ms",
		h.image_size / 1024u, h.load, h.bss_end, (unsigned)(( zzhl_us64() - t0 ) / 1000ull ));
	zzhl_log( line );
	return 0;
}
