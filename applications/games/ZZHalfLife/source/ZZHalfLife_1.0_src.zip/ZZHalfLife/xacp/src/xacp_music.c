/* Half-Life CD music requests forwarded to the Amiga audio backend.
 * Core1 queues track and volume changes; playback uses CD, MP3 or MHI.
 */

#include "zzquake_config.h"
#include "xacp_rt.h"

typedef unsigned int u32;
/* stage 2 reaches the release shared block through the runtime block, not through the stage-1
   `shared` symbol, which does not exist on this side of the link. */
extern const zzhl_rt_t *zzhl_rt;
#define shared ( zzhl_rt->shared )

/* counters, for the report and for telling a silent backend from a silent game */
u32 zzhl_mus_play, zzhl_mus_stop, zzhl_mus_pause, zzhl_mus_resume, zzhl_mus_dropped;

static void mus_push( u32 cmd, u32 arg )
{
	u32 w, r, nxt;
	if( !shared[SH_MUSIC_ENABLE] ) return;          /* the launcher plays nothing: MUSIC=NONE */
	w = shared[SH_MUSQ_WR];
	r = shared[SH_MUSQ_RD];
	nxt = ( w + 1u ) & ( ZZQ_MUSQ_SIZE - 1u );
	if( nxt == r ) { zzhl_mus_dropped++; return; }  /* queue full: dropped, never blocking */
	shared[SH_MUSQ_BASE + w * 2u + 0u] = cmd;
	shared[SH_MUSQ_BASE + w * 2u + 1u] = arg;
	__asm__ volatile( "dsb sy" ::: "memory" );
	shared[SH_MUSQ_WR] = nxt;
}

void zzhl_music_play( int track, int looping )
{
	if( track < 1 ) { zzhl_music_stop(); return; }
	zzhl_mus_play++;
	shared[SH_CD_PLAY]++;
	shared[SH_CD_TRACK] = (u32)track;
	shared[SH_CD_LOOP]  = looping ? 1u : 0u;
	if( track >= 1 && track <= 31 ) shared[SH_CD_TRACKMASK] |= ( 1u << track );
	mus_push( ZZQ_MUS_PLAY, ((u32)track & 0xFFu ) | ( looping ? 0x100u : 0u ));
}

/* Forward the music volume to the launcher so the game audio menu controls MP3 playback. */
u32 zzhl_mus_vol = 0x10000u, zzhl_mus_volsent;
void zzhl_music_volume( int vol )
{
	if( vol < 0 ) vol = 0;
	if( vol > 0x10000 ) vol = 0x10000;
	zzhl_mus_vol = (u32)vol;
	zzhl_mus_volsent++;
	mus_push( ZZQ_MUS_VOLUME, (u32)vol );
}

void zzhl_music_stop( void )
{
	zzhl_mus_stop++;
	shared[SH_CD_STOP]++;
	mus_push( ZZQ_MUS_STOP, 0u );
}

void zzhl_music_pause( void )
{
	zzhl_mus_pause++;
	shared[SH_CD_PAUSE]++;
	mus_push( ZZQ_MUS_PAUSE, 0u );
}

void zzhl_music_resume( void )
{
	zzhl_mus_resume++;
	shared[SH_CD_RESUME]++;
	mus_push( ZZQ_MUS_RESUME, 0u );
}
