/* xacp_avi.c - ZZHalfLife: no movie playback on Core1 (engine/client/avi/avi_ffmpeg.c needs
 * ffmpeg).  The AVI_* entry points exist and report "no video". GPL-3.0-or-later. ASCII only. */
#include "common.h"
#include "client.h"
#include "avi/avi.h"
int AVI_GetVideoFrameNumber( movie_state_t *Avi, float time ) { return 0; }
byte *AVI_GetVideoFrame( movie_state_t *Avi, int frame ) { return NULL; }
qboolean AVI_GetVideoInfo( movie_state_t *Avi, int *xres, int *yres, float *duration ) { return false; }
qboolean AVI_HaveAudioTrack( const movie_state_t *Avi ) { return false; }
void AVI_OpenVideo( movie_state_t *Avi, const char *filename, qboolean load_audio, int quiet ) { }
movie_state_t *AVI_LoadVideo( const char *filename, qboolean load_audio ) { return NULL; }
void AVI_CloseVideo( movie_state_t *Avi ) { }
qboolean AVI_IsActive( movie_state_t *Avi ) { return false; }
void AVI_FreeVideo( movie_state_t *Avi ) { }
movie_state_t *AVI_GetState( int num ) { return NULL; }
qboolean AVI_Initailize( void ) { return false; }
void AVI_Shutdown( void ) { }
qboolean AVI_SetParm( movie_state_t *Avi, enum movie_parms_e parm, ... ) { return false; }
qboolean AVI_Think( movie_state_t *Avi ) { return false; }
