/* Half-Life campaign chapter and map ordering for loading and traversal. */
#include <string.h>

static const struct { const char *title, *maps; } g_ch[] = {
	{ "Hazard Course", "t0a0 t0a0a t0a0b t0a0b1 t0a0b2 t0a0c t0a0d" },
	{ "Black Mesa Inbound", "c0a0 c0a0a c0a0b c0a0c c0a0d c0a0e" },
	{ "Anomalous Materials", "c1a0 c1a0d c1a0a c1a0b c1a0c c1a0e" },
	{ "Unforeseen Consequences", "c1a1 c1a1a c1a1f c1a1b c1a1c c1a1d" },
	{ "Office Complex", "c1a2 c1a2a c1a2b c1a2c c1a2d" },
	{ "We've Got Hostiles", "c1a3 c1a3a c1a3b c1a3c c1a3d" },
	{ "Blast Pit", "c1a4 c1a4k c1a4b c1a4f c1a4d c1a4e c1a4i c1a4g c1a4j" },
	{ "Power Up", "c2a1 c2a1a c2a1b" },
	{ "On A Rail", "c2a2 c2a2a c2a2b1 c2a2b2 c2a2c c2a2d c2a2e c2a2f c2a2g c2a2h" },
	{ "Apprehension", "c2a3 c2a3a c2a3b c2a3c c2a3d c2a3e" },
	{ "Residue Processing", "c2a4 c2a4a c2a4b c2a4c" },
	{ "Questionable Ethics", "c2a4d c2a4e c2a4f c2a4g" },
	{ "Surface Tension", "c2a5 c2a5w c2a5x c2a5a c2a5b c2a5c c2a5d c2a5e c2a5f c2a5g" },
	{ "Forget About Freeman", "c3a1 c3a1a c3a1b" },
	{ "Lambda Core", "c3a2e c3a2 c3a2a c3a2b c3a2c c3a2d c3a2f" },
	{ "Xen", "c4a1" },
	{ "Gonarch's Lair", "c4a2 c4a2a c4a2b" },
	{ "Interloper", "c4a1a c4a1b c4a1c c4a1d c4a1e c4a1f" },
	{ "Nihilanth", "c4a3" },
	{ "Endgame", "c5a1" },
	/* Uplink is a separate scenario, not a chapter of the main campaign. */
	{ "Uplink", "hldemo1 hldemo2 hldemo3" },
};
#define N_CH ( (int)( sizeof( g_ch ) / sizeof( g_ch[0] )))

int xacp_chapter_count( void ) { return N_CH; }
const char *xacp_chapter_title( int c ) { return c >= 0 && c < N_CH ? g_ch[c].title : "(no chapter)"; }

static int lower_eq( const char *a, unsigned la, const char *b )
{
	unsigned i;
	for( i = 0; i < la; i++ )
	{
		char x = a[i], y = b[i];
		if( x >= 'A' && x <= 'Z' ) x = (char)( x + 32 );
		if( y >= 'A' && y <= 'Z' ) y = (char)( y + 32 );
		if( x != y || !y ) return 0;
	}
	return b[la] == 0;
}
/* the chapter of a map ("c1a3", any case), -1 when none */
int xacp_chapter_of( const char *map )
{
	int c;
	for( c = 0; c < N_CH && map; c++ )
	{
		const char *p = g_ch[c].maps;
		while( *p )
		{
			unsigned l = 0;
			while( p[l] && p[l] != ' ' ) l++;
			if( lower_eq( p, l, map )) return c;
			p += l;
			while( *p == ' ' ) p++;
		}
	}
	return -1;
}
/* the number of maps of a chapter */
int xacp_chapter_maps( int c )
{
	const char *p;
	int n = 0;
	if( c < 0 || c >= N_CH ) return 0;
	for( p = g_ch[c].maps; *p; )
	{
		while( *p == ' ' ) p++;
		if( !*p ) break;
		n++;
		while( *p && *p != ' ' ) p++;
	}
	return n;
}
/* a chapter's maps, space separated, in the order the game goes through them (TRAVERSE=1) */
const char *xacp_chapter_maplist( int c ) { return c >= 0 && c < N_CH ? g_ch[c].maps : ""; }
