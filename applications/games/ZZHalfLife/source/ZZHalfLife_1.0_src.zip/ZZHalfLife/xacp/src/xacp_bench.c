/* Repeatable scene benchmarks (BENCH=, BENCHSETTLE, BENCHTIME, BENCHFREEZE).
 * Each scene is loaded, allowed to settle and measured in live and optional
 * frozen windows. No benchmarking logic runs unless BENCH is requested.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include "common.h"
#include "server.h"
#include "client.h"
#include <stdlib.h>
#include "zzhl_benchload.h"                /* when a scene has loaded (tested on the PC) */

extern const char *zzhl_option( const char *key );
extern int  zzhl_option_int( const char *key, int def );
extern void zz_rix_bench_begin( void );
extern void zz_rix_bench_end( void );
extern void zz_rix_bench_numbers( unsigned v[8] );
extern void zz_rix_bench_report( const char *name, char *out, int cap );
extern int  zz_rix_zclear_on( void );
extern int  zz_rix_boxfit( void );
extern int  zz_rix_reject( void );
extern int  zzhl_fpsmax( void );               /* FPSMAX (xacp_main.c) */
extern int  zz_rix_cull_early( void );         /* CULLEARLY (Core1/zzhl_gpu.c) */
extern int  glq_recfast( void ); extern int glq_decal_cull( void ); extern int glq_decal_frust( void ); extern int xacp_gl_meshidx( void );               /* RECFAST (xacp_glq.c) */

#define BN_MAX   12
#define BN_NAME  40
enum { BS_START = 0, BS_ISSUE, BS_LOADING, BS_SETTLE, BS_LIVE, BS_FREEZING, BS_FROZEN };

typedef struct { char label[BN_NAME + 40]; unsigned v[8]; } bn_row_t;

static int      g_on = -1;                 /* -1 not decided yet, 0 off, 1 running */
static char     g_item[BN_MAX][BN_NAME];
static int      g_nitems, g_cur = -1, g_state, g_settle, g_time, g_freeze, g_frames;
static double   g_t0, g_t_issue, g_t_mark;
static benchload_t g_load;                 /* zzhl_benchload.h */
static bn_row_t g_rows[BN_MAX * 2];
static int      g_nrows;
static char     g_rep[8192];

static int in_game( void ) { return CL_Active() && sv.state == ss_active; }

static void bench_init( void )
{
	const char *list = zzhl_option( "BENCH" );
	g_on = 0;
	if( !list || !list[0] ) return;
	while( *list && g_nitems < BN_MAX )
	{
		int k = 0;
		while( *list == ',' ) list++;
		while( *list && *list != ',' ) { if( k < BN_NAME - 1 ) g_item[g_nitems][k++] = *list; list++; }
		g_item[g_nitems][k] = 0;
		if( k ) g_nitems++;
	}
	if( !g_nitems ) return;
	g_settle = zzhl_option_int( "BENCHSETTLE", 4 ); if( g_settle < 1 ) g_settle = 1;
	g_time   = zzhl_option_int( "BENCHTIME", 6 );   if( g_time < 1 ) g_time = 1;
	g_freeze = zzhl_option_int( "BENCHFREEZE", 1 ) ? 1 : 0;
	g_on = 1; g_state = BS_START; g_t0 = Sys_DoubleTime();
	Con_Printf( "BENCH: %d scene%s, %d s to settle, %d s measured live%s; nobody plays, then quit\n",
		g_nitems, g_nitems == 1 ? "" : "s", g_settle, g_time, g_freeze ? ", then as long with the game paused" : "" );
}

/* Benchmark player state is normalized without changing unrelated state. */
static void untouchable( void )
{
	edict_t *pl = SV_EdictNum( 1 );
	if( !pl || pl->free ) return;
	pl->v.flags |= FL_GODMODE | FL_NOTARGET;
}

static void print_lines( char *text )
{
	char *l = text, *e;
	while( *l )
	{
		e = strchr( l, '\n' );
		if( e ) *e = 0;
		Con_Printf( "%s\n", l );
		if( !e ) break;
		l = e + 1;
	}
}

static void window_close( const char *kind )
{
	bn_row_t *r;
	char label[BN_NAME + 40];
	zz_rix_bench_end();
	/* the map the engine is really on goes into the label: build 84 once measured a scene under
	   the next one's name, and nothing in its table could show it */
	Q_snprintf( label, sizeof( label ), "%s %s %s", g_item[g_cur], kind, sv.name );
	zz_rix_bench_report( label, g_rep, (int)sizeof( g_rep ));
	print_lines( g_rep );
	if( g_nrows >= BN_MAX * 2 ) return;
	r = &g_rows[g_nrows++];
	Q_strncpy( r->label, label, sizeof( r->label ));
	zz_rix_bench_numbers( r->v );
}

static void row_failed( const char *why )
{
	bn_row_t *r;
	Con_Printf( "BENCH %s: %s - skipped\n", g_item[g_cur], why );
	if( g_nrows >= BN_MAX * 2 ) return;
	r = &g_rows[g_nrows++];
	Q_snprintf( r->label, sizeof( r->label ), "%s FAILED", g_item[g_cur] );
	memset( r->v, 0, sizeof( r->v ));
}

static void summary( void )
{
	int i;
	/* two lines: the mirror keeps 239 characters of a line */
	/* ZCLEAR is what the self-test decided, not what was asked; BOXPX and DEV as asked */
	Con_Printf( "BENCH SUMMARY, %d s windows, EARLY=%d F2B=%d SPRTRIM=%d SORT=%d DECALQ=%d RING=%d PUMP=%d PIPE=%d ZCLEAR=%d BOXFIT=%d REJECT=%d BOXPX=%d WALKSTAT=%d DEV=%d FPSMAX=%d CULLEARLY=%d RECFAST=%d DECALCULL=%d DECALFRUST=%d MESHIDX=%d WATERCULL=%d\n",
		g_time, zzhl_option_int( "EARLY", 2 ), zzhl_option_int( "F2B", 0 ), zzhl_option_int( "SPRTRIM", 0 ), zzhl_option_int( "SORT", 1 ), zzhl_option_int( "DECALQ", 2 ),
		zzhl_option_int( "RING", 1 ), zzhl_option_int( "PUMP", 32 ), zzhl_option_int( "PIPE", 1 ), zz_rix_zclear_on(), zz_rix_boxfit(), zz_rix_reject(), zzhl_option_int( "BOXPX", 0 ),
		zzhl_option_int( "WALKSTAT", 0 ), zzhl_option_int( "DEV", 0 ), zzhl_fpsmax(), zz_rix_cull_early(), glq_recfast(), glq_decal_cull(), glq_decal_frust(), xacp_gl_meshidx(), glq_water_cull());
	Con_Printf( "BENCH columns: average period, img/s, longest frame, frames over 45 ms | per frame: triangles sent, binds sent, thousands of pixels submitted opaque and blended\n" );
	for( i = 0; i < g_nrows; i++ )
	{
		const unsigned *v = g_rows[i].v;
		unsigned fps10 = v[1] ? 10000000u / v[1] : 0u;
		/* a letter each: the console mirror folds consecutive lines that differ only by digits */
		Con_Printf( "BENCH = %c %-28s: %4u frames, %6u us, %2u.%u img/s, longest %6u us, over 45 ms %3u | %5u tris, %3u binds, %5u kpx opaque, %5u kpx blended\n",
			'a' + i, g_rows[i].label, v[0], v[1], fps10 / 10u, fps10 % 10u, v[2], v[3], v[4], v[5], v[6], v[7] );
	}
	Con_Printf( "BENCH done: %d window%s in %.0f s\n", g_nrows, g_nrows == 1 ? "" : "s", Sys_DoubleTime() - g_t0 );
}

static void issue_next( double now )
{
	const char *it;
	if( sv.paused ) SV_TogglePause( "" );
	if( ++g_cur >= g_nitems )
	{
		summary();
		Cbuf_AddText( "quit\n" );
		g_on = 0;
		return;
	}
	it = g_item[g_cur];
	if( !Q_strnicmp( it, "map:", 4 ))
	{
		Con_Printf( "BENCH %d/%d %s: a new game on this map\n", g_cur + 1, g_nitems, it );
		Cbuf_AddText( va( "map %s\n", it + 4 ));
	}
	else
	{
		if( !FS_FileExists( va( "save/%s.sav", it ), true )) Con_Printf( "BENCH %d/%d %s: save/%s.sav is not on the disk, trying anyway\n", g_cur + 1, g_nitems, it, it );
		else Con_Printf( "BENCH %d/%d %s: loading the save\n", g_cur + 1, g_nitems, it );
		Cbuf_AddText( va( "load %s\n", it ));
	}
	g_t_issue = now;
	benchload_begin( &g_load, svs.spawncount, g_frames, now, CL_Active());
	g_state = BS_LOADING;
}

void xacp_bench_frame( void )
{
	double now;
	if( g_on < 0 ) bench_init();
	if( !g_on ) return;
	now = Sys_DoubleTime();
	g_frames++;
	switch( g_state )
	{
	case BS_START:                            /* the engine up and the menu drawn before the first command */
		if( !cls.initialized || g_frames < 40 || now - g_t0 < 3.0 ) return;
		g_state = BS_ISSUE;
		/* fall through */
	case BS_ISSUE:
		issue_next( now );
		return;
	case BS_LOADING:                          /* the rule and its history: zzhl_benchload.h */
		switch( benchload_step( &g_load, svs.spawncount, g_frames, now, CL_Active(), sv.state == ss_active ))
		{
		case BENCHLOAD_IN_GAME:
			Con_Printf( "BENCH %d/%d %s: in the game on %s after %.1f s\n", g_cur + 1, g_nitems, g_item[g_cur], sv.name, now - g_t_issue );
			g_t_mark = now; g_state = BS_SETTLE;
			break;
		case BENCHLOAD_NOTHING:
			row_failed( "nothing was loaded (the save is not there, or was refused)" ); g_state = BS_ISSUE;
			break;
		case BENCHLOAD_NEVER_SHOWN:
			row_failed( "its server started but the game never showed" ); g_state = BS_ISSUE;
			break;
		default: break;
		}
		return;
	case BS_SETTLE:
		if( !in_game()) { row_failed( "left the game while settling" ); g_state = BS_ISSUE; return; }
		untouchable();
		if( now - g_t_mark < (double)g_settle ) return;
		zz_rix_bench_begin();
		g_t_mark = now; g_state = BS_LIVE;
		return;
	case BS_LIVE:
		if( !in_game()) { zz_rix_bench_end(); row_failed( "left the game while measured" ); g_state = BS_ISSUE; return; }
		untouchable();
		if( now - g_t_mark < (double)g_time ) return;
		window_close( "live" );
		if( !g_freeze ) { g_state = BS_ISSUE; return; }
		if( !sv.paused ) SV_TogglePause( "" );
		g_t_mark = now; g_state = BS_FREEZING;
		return;
	case BS_FREEZING:                         /* one second for the pause to reach the client and the picture to stand still */
		if( now - g_t_mark < 1.0 ) return;
		if( !sv.paused ) { row_failed( "the game would not pause" ); g_state = BS_ISSUE; return; }
		zz_rix_bench_begin();
		g_t_mark = now; g_state = BS_FROZEN;
		return;
	default:                                  /* BS_FROZEN */
		if( now - g_t_mark < (double)g_time ) return;
		window_close( "frozen" );
		g_state = BS_ISSUE;
		return;
	}
}
