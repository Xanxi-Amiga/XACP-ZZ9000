/* xacp_input.c - ZZHalfLife: keyboard and mouse from the release key queue and mouse
 * accumulators (zzquake_platform.c of the ZZQuake640 runtime, through the stage-1 API):
 * Platform_RunEvents drains the queue into Key_Event, Platform_MouseMove gives the relative
 * motion the engine asks for (m_rawinput). Key codes: the release sends Quake key numbers,
 * which Half-Life inherited (same table from 9 to 152, 255 = pause); the three mouse buttons
 * are 200..202 in the queue and 241..243 for Xash3D.
 * with the menu (mainui), its pointer from the relative motion, Escape left to the engine.
 * the menu again when a game ends (menu_after_game).
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include "common.h"
#include "client.h"
#include "input.h"
#include "platform/platform.h"
#include "xacp_rt.h"

extern const zzhl_rt_t *zzhl_rt;
extern const char *zzhl_option( const char *key );
static unsigned g_key_events;

/* Map keyboard input by physical key position so configured controls work on different keymaps. */
static int g_layout = -1;          /* 0 QWERTY (as sent), 1 AZERTY, 2 QWERTZ */
static int layout( void )
{
	if( g_layout < 0 )
	{
		const char *v = zzhl_option( "KEYS" );
		g_layout = 0;
		if( v && ( !Q_stricmp( v, "AZERTY" ) || !Q_stricmp( v, "FR" ) || !Q_stricmp( v, "BE" ))) g_layout = 1;
		else if( v && ( !Q_stricmp( v, "QWERTZ" ) || !Q_stricmp( v, "DE" ) || !Q_stricmp( v, "CH" ))) g_layout = 2;
		Con_Printf( "ZZHalfLife: KEYS=%s (%s)\n", g_layout == 1 ? "AZERTY" : g_layout == 2 ? "QWERTZ" : "QWERTY",
			g_layout ? "keys by position: the game sees the QWERTY key at the same place" : "keys as the keymap gives them" );
		Cbuf_AddText( "bindlist\n" );             /* the bindings in force, into the log (ZZSlots) */
	}
	return g_layout;
}
/* the character from the keymap -> the QWERTY key at the same place; *digit set for the number row */
static int by_position( int c, int *digit )
{
	*digit = ( c >= '0' && c <= '9' );
	if( layout() == 1 )
	{
		switch( c )
		{
		case 'a': return 'q';
		case 'z': return 'w';
		case 'q': return 'a';
		case 'w': return 'z';
		case 'm': return ';';
		case '&': *digit = 1; return '1';
		case '"': *digit = 1; return '3';
		case '\'': *digit = 1; return '4';
		case '(': *digit = 1; return '5';
		default: break;
		}
	}
	else if( layout() == 2 )
	{
		if( c == 'z' ) return 'y';
		if( c == 'y' ) return 'z';
	}
	return c;
}

/* Ignore keyboard qualifier transformations that turn gameplay letters into control codes. */
static int unctrl( int k )
{
	if( k >= 1 && k <= 26 && k != 9 && k != 13 ) return 'a' + k - 1;
	return k;
}
static int map_key( int k )
{
	if( k >= 200 && k <= 202 ) return K_MOUSE1 + ( k - 200 );
	if( k == 255 ) return K_PAUSE;
	k = unctrl( k );
	if( k >= 'A' && k <= 'Z' ) return k + 32;
	return k;
}

/* the menu (FWGS mainui) and its pointer.  The engine moves the menu's cursor with the
   absolute position Platform_GetMousePos gives, which this platform (no SDL) does not have: the
   relative motion of the release mouse accumulates here, clamped to the screen, and goes to
   UI_MouseMove while the menu has the keys.  mainui draws no pointer (the OS does it on a PC): the
   presentation draws one over the finished picture (Core1/zzhl_present.c). */
extern void zzhl_present_cursor( int on, int x, int y );
static int g_mx = -1, g_my = -1;
static int menu_loaded( void ) { return gameui.hInstance != NULL; }
static void menu_pointer( void )
{
	int on = menu_loaded() && cls.key_dest == key_menu && UI_IsVisible();
	if( on && zzhl_rt->get_mouse_move )
	{
		int dx = 0, dy = 0, w = gameui.globals ? gameui.globals->scrWidth : 640, h = gameui.globals ? gameui.globals->scrHeight : 480;
		if( g_mx < 0 ) { g_mx = w / 2; g_my = h / 2; }
		zzhl_rt->get_mouse_move( &dx, &dy );   /* the game takes the relative motion only in key_game */
		g_mx += dx; g_my += dy;
		if( g_mx < 0 ) g_mx = 0;
		if( g_my < 0 ) g_my = 0;
		if( g_mx > w - 1 ) g_mx = w - 1;
		if( g_my > h - 1 ) g_my = h - 1;
		UI_MouseMove( g_mx, g_my );
	}
	zzhl_present_cursor( on, g_mx, g_my );
}

/* back to the menu when a game ends.  CL_Disconnect opens the menu only outside the developer
   mode (cl_main.c, "back to menu in non-developer mode"), and this port runs with -dev 2 for its logs:
   at the end of the Hazard Course (disconnect) the console showed instead of the menu (A4000, 12/11;
   Escape brought the menu back).  Here: after a game (client active), the client disconnected with no
   local server for half a second - not a change of level nor a load, the server stays up through those
   - and the menu comes back, once. */
static void menu_after_game( void )
{
	static int in_game;
	static double t_off;
	if( !menu_loaded()) return;
	if( cls.state == ca_active ) { in_game = 1; t_off = 0.0; return; }
	if( !in_game || cls.state != ca_disconnected || SV_Active()) { t_off = 0.0; return; }
	if( t_off == 0.0 ) { t_off = Sys_DoubleTime(); return; }
	if( Sys_DoubleTime() - t_off < 0.5 ) return;
	in_game = 0; t_off = 0.0;
	if( !UI_IsVisible()) UI_SetActiveMenu( true );
}

extern void xacp_soak_frame( void );
extern void xacp_loading_frame( void );   /* Half-Life's loading picture, read at a frame start */
void Platform_RunEvents( void )
{
	/* Service pending GPU and launcher work while the engine waits for its next frame. */
	{ extern void zzhl_pump_soon( void ); zzhl_pump_soon(); }
	xacp_soak_frame();                 /* SOAK=1, a no-op otherwise */
	{ extern void xacp_traverse_frame( void ); xacp_traverse_frame(); }   /* TRAVERSE=1; no older save copies */
	{ extern void xacp_bench_frame( void ); xacp_bench_frame(); }         /* BENCH=, a no-op otherwise */
	xacp_loading_frame();              /* reads Half-Life's loading picture once */
	{ extern void xacp_disk_frame( void ); xacp_disk_frame(); }   /* a load's line when the game shows again */
	int down, key;
	if( !zzhl_rt->get_key ) return;
	(void)layout();                    /* said once, with the bindings */
	while( zzhl_rt->get_key( &down, &key ))
	{
		int k = map_key( key ), digit = 0, ch = unctrl( key );   /* ch: the character as typed, for the console */
		g_key_events++;
		if( k >= 32 && k < 127 ) k = by_position( k, &digit );   /* build 39 */
		if( digit && !down ) continue;                 /* its release was sent with the press */
		if( digit )
		{   /* the keyboard's auto-repeat comes back as presses: one taken per 150 ms of a run */
			static double last[10];
			double now = Sys_DoubleTime();
			int d = k - '0';
			int rep = ( now - last[d] < 0.15 );
			last[d] = now;
			if( rep ) continue;
		}
		/* no menu in A0 (console build): Escape would normally open it, so a RELEASED Escape
		   pressed twice within two seconds quits instead (single Esc still clears the console
		   / cancels, as usual).  The launcher's Ctrl-C keeps working as before. */
		if( k == K_ESCAPE && !down && !menu_loaded())   /* with the menu, Escape opens it */
		{
			static double last;
			double now = Sys_DoubleTime();
			if( now - last < 2.0 ) { extern void xacp_loading_quit( void ); xacp_loading_quit(); Cbuf_AddText( "quit\n" ); last = 0.0; }
			else last = now;
		}
		if( k >= K_MOUSE1 && k <= K_MOUSE3 && down ) menu_pointer();   /* the click where the pointer is */
		Key_Event( k, down ? true : false );
		if( digit && down ) Key_Event( k, false );     /* pressed and released at once */
		if( down && ch >= 32 && ch < 127 ) CL_CharEvent( ch );
	}
	menu_after_game();                 /* build 53 */
	menu_pointer();                    /* build 50 */
}

void Platform_MouseMove( float *x, float *y )
{
	int dx = 0, dy = 0;
	if( zzhl_rt->get_mouse_move ) zzhl_rt->get_mouse_move( &dx, &dy );
	if( x ) *x = (float)dx;
	if( y ) *y = (float)dy;
}

void Platform_EnableTextInput( qboolean enable, int x, int y, int w, int h ) { }

unsigned zzhl_key_events( void ) { return g_key_events; }
