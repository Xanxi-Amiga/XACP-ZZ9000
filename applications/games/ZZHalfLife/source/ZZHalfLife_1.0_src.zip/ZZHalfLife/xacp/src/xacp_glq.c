/* xacp_glq.c - ZZHalfLife: the draw queue between ref_gl's GL calls and ZZGL (xacp_glq.h).
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <string.h>
#include "zzgl.h"
#include "xacp_glq.h"
#include "zzhl_fx.h"                       /* the frame's counters, by origin */

extern unsigned long long zzhl_us64( void );

/* ---- limits ---- */
#define GLQ_MAX_BATCH   4096u
#define GLQ_MAX_VERT    32768u
#define GLQ_MAX_KEYS    64u
#define GLQ_MAX_MATS    192u
#define GLQ_BATCH_ROOM  512u      /* vertices kept free when a batch opens (ref_gl's largest polygons are far under) */
#define GLQ_TEX_NONE    0xFFFFu
#define GLQ_NTEX        ZZGL_MAX_TEXTURES

/* ---- the sortable state (the key) ---- */
typedef struct {
	unsigned char en_tex, en_depth, en_blend, en_alpha, en_cull;
	unsigned char depth_mask, shade_flat, group;
	unsigned short depth_func, blend_s, blend_d, alpha_func, cull_mode, front_face, tex_env;
	float alpha_ref;
} glq_key_t;

typedef struct { float x, y, z, s, t; unsigned char rgba[4]; } glq_vert_t;
typedef struct { unsigned first, count; unsigned short tex, key; unsigned char mode, mat, group, org; unsigned idx_first; unsigned short idx_count, pad; } glq_batch_t;   /* org: build 84, ZORG_* */
typedef struct { float mv[16], pr[16]; } glq_mat_t;

/* ---- shadow of the engine's state (what ref_gl set last) ---- */
static glq_key_t  S;                       /* sortable part */
static unsigned char S_color_mask = 1, S_fill = 1, S_scissor, S_polyofs;
static float     S_po_factor, S_po_units;
static unsigned   S_matrix_mode = ZGL_MODELVIEW;
static unsigned   g_tex;                   /* bound texture (engine's) */
static float      g_col[4] = { 1.0f, 1.0f, 1.0f, 1.0f }, g_st[2];

/* ---- the queue ---- */
static glq_vert_t  g_v[GLQ_MAX_VERT];
static glq_batch_t g_b[GLQ_MAX_BATCH];
#define GLQ_MAX_IDX 131072u        /* the indices of the indexed batches of a flush (three a triangle, one byte each) */
#define GLQ_IDX_ROOM 1024u
static unsigned char g_idx[GLQ_MAX_IDX];
static unsigned g_nidx;
static unsigned short g_order[GLQ_MAX_BATCH];
static glq_key_t   g_keys[GLQ_MAX_KEYS];
static glq_mat_t   g_mats[GLQ_MAX_MATS];
static unsigned g_nv, g_nb, g_nkeys, g_nmats;
static unsigned short g_tex_gen[GLQ_NTEX];     /* flush generation in which the texture was last queued */
static unsigned short g_gen = 1;
/* the origin of the batch in progress, the clock of a pass-through batch, and for F2B
   the sum of the view distances of each recorded batch's vertices */
static unsigned g_org;
static unsigned long long g_pt_t0;
static unsigned g_pt_w0;                       /* the GPU waits when the pass-through batch began */
/* the waits since `before`, which may predate the frame's opening (the counter restarts there) */
static unsigned waits_since( unsigned before ) { unsigned now = zzhl_gpu_wait_us(); return now >= before ? now - before : now; }
static float g_bsum[GLQ_MAX_BATCH];
static const float *g_rec_mv;
static int g_early, g_f2b;
/* FXTIME=0 drops the clock readings that give Core1's time by origin (two a pass-through batch,
   one at each change of origin in a replay: a few hundred a frame, a fraction of a millisecond).
   Everything else that is counted costs no reading. */
static int g_fxtime = 1;
void glq_set_fxtime( int on ) { g_fxtime = on ? 1 : 0; }

/* ---- recording state ---- */
static int g_sort, g_bindtest;
static int g_in_begin, g_rec;
static unsigned g_mode, g_count;           /* pass-through: mode and vertices since the last Begin (60-split) */
static unsigned g_tiny[2], g_tiny_k, g_tiny_ready;

/* ---- statistics ---- */
static glq_stats_t st;
static unsigned short g_tex_frame[GLQ_NTEX], g_tex_w[GLQ_NTEX], g_tex_h[GLQ_NTEX];
static unsigned short g_frame = 1;
static unsigned g_last_req = GLQ_TEX_NONE, g_last_done = GLQ_TEX_NONE;
static unsigned g_frame_batches, g_frame_verts;

/* ---- glPolygonOffset emulation (build 18) ----
 * RasterIX has no depth bias and ZZGL ignored GL_POLYGON_OFFSET_FILL: Half-Life's decals (blood,
 * scorch marks, bullet holes), drawn coplanar with their surface after it, fought with it in the
 * 16-bit depth buffer: streaks and dotted patterns through the marks (A4000, 06/11).  For an
 * overlay batch (polygon offset on, depth test on, depth writes off, depth func not EQUAL - so
 * never the lightmap pass, which must meet its base pass exactly) every vertex is moved towards
 * the eye along its own view ray: it stays on the same pixel and comes nearer by a constant number
 * of depth-buffer steps, which is what OpenGL's "units" term does:
 *   eye-space e, distance d = -e.z, near plane n (from the projection),
 *   one 16-bit step at distance d is about d^2 / (n * 65536),
 *   e *= 1 - k with k = steps * d / (n * 65536), steps = scale * |units|  (ref_gl: units -2),
 *   k limited to 8 %.
 * The batch is then drawn with an identity modelview (the vertices are already in eye space);
 * the engine's modelview is restored at glEnd.  The slope term of glPolygonOffset is not
 * modelled.  DECALBIAS=0 turns it off, DECALBIAS=n sets the scale (default 4: 8 steps). */
static int   g_bias_scale = 4;
static int   g_po;                 /* the batch in progress is biased */
static float g_po_mv[16], g_po_c;
static unsigned g_biased;
void glq_set_decal_bias( int scale ) { g_bias_scale = scale < 0 ? 0 : scale; }
void glq_polygon_offset( float factor, float units ) { S_po_factor = factor; S_po_units = units; }
unsigned glq_biased( void ) { return g_biased; }
/* ---- build 94, DECALCULL=1 (off by default): an overlay that is wholly out of view is dropped
 * when its glEnd comes, instead of being recorded, sorted, replayed, transformed by ZZGL and
 * dropped there by REJECT.  A4000, 17/11, save007 (c1a1b), frozen window: 577 overlay batches a
 * frame, 4 120 triangles handed to ZZGL, 303 sent, 3 756 thrown away whole at zzglEnd, 4 010 us of
 * Core1 a frame inside those draws with no wait for the GPU.
 * A biased batch is recorded in eye space under an identity modelview (above), so its clip
 * coordinates are the projection's alone.  For ref_gl's projection (a frustum: w = -z, x from
 * P0 and P8, y from P5 and P9, checked on the matrix itself; anything else: no early test) each
 * vertex gives four numbers, negative when it is outside the left, right, bottom or top side BY A
 * MARGIN of 1/256 of |w|.  The four sign bits are ANDed over the batch: one left set = every
 * vertex is beyond that side, by more than any rounding between this arithmetic and ZZGL's, so
 * ZZGL's batch_outside (x < -w, x > w, y < -w, y > w on every vertex) says the same and nothing of
 * the batch could have reached the GPU.  The dropped batches are a subset of REJECT's, which is why
 * the option does nothing without REJECT=1.  The near plane is left to ZZGL.
 * No float comparison per vertex (each one is a trip from the FPU to the core on a Cortex-A9):
 * the signs are read in the stored bits.  A NaN or an infinity anywhere keeps the batch. */
#define GLQ_DC_MARGIN 0.00390625f
static int   g_dcull, g_dcull_reject = 1;
static int   g_dc_on;              /* the batch in progress is biased and its projection is a frustum */
static float g_dc_pr[16], g_dc_p0, g_dc_p8, g_dc_p5, g_dc_p9;
static int   g_dc_frustum;         /* g_dc_pr is ref_gl's kind of projection */
static unsigned g_dc_and[4], g_dc_bad;
static unsigned g_dc_batches, g_dc_verts;
void glq_set_decal_cull( int on ) { g_dcull = on ? 1 : 0; }
void glq_decal_cull_reject_is( int on ) { g_dcull_reject = on ? 1 : 0; }   /* REJECT= as xacp_video.c set it */
int  glq_decal_cull( void ) { return g_dcull && g_dcull_reject; }
unsigned glq_decal_culled( unsigned *verts ) { if( verts ) *verts = g_dc_verts; return g_dc_batches; }
/* build 96, DECALFRUST (build_arm.sh 0d2, ref_gl's gl_decals.c): 1 = a decal whose polygon is wholly
   beyond one plane of ref_gl's frustum is not emitted; 2 = a CHECK: everything is emitted, ref_gl
   only marks the decals its test would leave out (zzhl_decal_mark, set before their glBegin), and
   the queue compares: a marked decal must have every vertex outside one and the same side of the
   view by the plain comparisons on its clip coordinates (ZZGL's batch_outside).  One that has not
   is counted wrong: must stay 0. */
int zzhl_decalfrust;
unsigned zzhl_decal_seen, zzhl_decal_culled, zzhl_decal_mark;
static unsigned g_dv_on, g_dv_and, g_dv_marked, g_dv_wrong, g_dv_unchecked;
void glq_set_decal_frust( int mode ) { zzhl_decalfrust = mode == 2 ? 2 : mode ? 1 : 0; }
int  glq_decal_frust( void ) { return zzhl_decalfrust; }
/* v[0] decals ref_gl looked at, [1] those its test calls out of view, [2] marked ones the queue met,
   [3] of which the clip test disagrees, [4] of which it could not check */
void glq_decal_frust_stats( unsigned v[5] ) { v[0] = zzhl_decal_seen; v[1] = zzhl_decal_culled; v[2] = g_dv_marked; v[3] = g_dv_wrong; v[4] = g_dv_unchecked; }
/* what the biased overlays are.  ref_gl says it (build_arm.sh 0d2 and 0d3): zzhl_emit_decal
   is set before a decal's glBegin (cleared here at its glEnd), zzhl_emit_water while EmitWaterPolys
   runs, zzhl_emit_bmodel while R_DrawBrushModel draws under its polygon offset (1 an entity at rest,
   2 a moved one).  Sources: 0 water, 1 decals, 2 brush entity at rest, 3 moved brush entity, 4 the rest.
   WATERCULL=1|2 (off by default): see build_arm.sh 0d3; 2 is a check through zzhl_decal_mark. */
int zzhl_emit_water, zzhl_emit_bmodel, zzhl_watercull;
unsigned zzhl_emit_decal, zzhl_water_seen, zzhl_water_culled;
unsigned zzhl_water_kind[4], zzhl_water_tested, zzhl_water_hmax;   /* calls by what draws the water, polygons the test looked at, highest wave x1000 */
static unsigned g_ov_drop[GLQ_OV_SRC], g_ov_dropv[GLQ_OV_SRC], g_ov_keep[GLQ_OV_SRC], g_ov_keepv[GLQ_OV_SRC];
void glq_set_water_cull( int mode ) { zzhl_watercull = mode == 2 ? 2 : mode ? 1 : 0; }
int  glq_water_cull( void ) { return zzhl_watercull; }
void glq_water_stats( unsigned v[8] )
{
	v[0] = zzhl_water_seen; v[1] = zzhl_water_culled; v[2] = zzhl_water_tested; v[3] = zzhl_water_hmax;
	v[4] = zzhl_water_kind[0]; v[5] = zzhl_water_kind[1]; v[6] = zzhl_water_kind[2]; v[7] = zzhl_water_kind[3];
}
void glq_overlay_src_stats( unsigned drop[GLQ_OV_SRC], unsigned dropv[GLQ_OV_SRC], unsigned keep[GLQ_OV_SRC], unsigned keepv[GLQ_OV_SRC] )
{
	unsigned i;
	for( i = 0; i < GLQ_OV_SRC; i++ ) { drop[i] = g_ov_drop[i]; dropv[i] = g_ov_dropv[i]; keep[i] = g_ov_keep[i]; keepv[i] = g_ov_keepv[i]; }
}
static int dc_frustum( const float *pr )
{
	return pr[1] == 0.0f && pr[2] == 0.0f && pr[3] == 0.0f && pr[4] == 0.0f && pr[6] == 0.0f && pr[7] == 0.0f
		&& pr[12] == 0.0f && pr[13] == 0.0f && pr[15] == 0.0f && pr[11] == -1.0f;
}
static void dc_begin( const float *pr )
{
	g_dc_on = 0; g_dv_on = 0u;
	if( !( g_dcull && g_dcull_reject ) && zzhl_decalfrust != 2 && zzhl_watercull != 2 ) return;
	if( memcmp( pr, g_dc_pr, sizeof( g_dc_pr )))
	{
		memcpy( g_dc_pr, pr, sizeof( g_dc_pr ));
		g_dc_frustum = dc_frustum( pr );
		g_dc_p0 = pr[0]; g_dc_p8 = pr[8]; g_dc_p5 = pr[5]; g_dc_p9 = pr[9];
	}
	if( !g_dc_frustum ) return;
	if( zzhl_decalfrust == 2 || zzhl_watercull == 2 ) { g_dv_on = 1u; g_dv_and = 15u; }
	if( !( g_dcull && g_dcull_reject )) return;
	g_dc_and[0] = g_dc_and[1] = g_dc_and[2] = g_dc_and[3] = 0xFFFFFFFFu; g_dc_bad = 0u;
	g_dc_on = 1;
}
/* DECALFRUST=2 only: the plain comparisons, as ZZGL's batch_outside makes them */
/* the same check for a batch that is not a biased overlay (the water of the world, at
   the dam of c2a5: "could not check 2053604", A4000, 17/11 12 h 20).  The mark is known at the
   glBegin; the clip coordinates come from projection x modelview as ZZGL holds them then. */
static float g_dv_m[3][4];
static void dv_begin_plain( void )
{
	float mv[16], pr[16];
	int r, c;
	static const int row[3] = { 0, 1, 3 };
	zzglGetFloatv( ZGL_MODELVIEW_MATRIX, mv );
	zzglGetFloatv( ZGL_PROJECTION_MATRIX, pr );
	for( r = 0; r < 3; r++ )
		for( c = 0; c < 4; c++ )
			g_dv_m[r][c] = pr[row[r]] * mv[4 * c] + pr[row[r] + 4] * mv[4 * c + 1] + pr[row[r] + 8] * mv[4 * c + 2] + pr[row[r] + 12] * mv[4 * c + 3];
	g_dv_on = 2u; g_dv_and = 15u;
}
static void dv_vertex_plain( float x, float y, float z )
{
	const float cx = g_dv_m[0][0] * x + g_dv_m[0][1] * y + g_dv_m[0][2] * z + g_dv_m[0][3];
	const float cy = g_dv_m[1][0] * x + g_dv_m[1][1] * y + g_dv_m[1][2] * z + g_dv_m[1][3];
	const float cw = g_dv_m[2][0] * x + g_dv_m[2][1] * y + g_dv_m[2][2] * z + g_dv_m[2][3];
	unsigned o = 0u;
	if( cx < -cw ) o |= 1u;
	if( cx > cw ) o |= 2u;
	if( cy < -cw ) o |= 4u;
	if( cy > cw ) o |= 8u;
	g_dv_and &= o;
}
static void dv_vertex( float ex, float ey, float ez )
{
	const float cx = g_dc_p0 * ex + g_dc_p8 * ez, cy = g_dc_p5 * ey + g_dc_p9 * ez, cw = -ez;
	unsigned o = 0u;
	if( cx < -cw ) o |= 1u;
	if( cx > cw ) o |= 2u;
	if( cy < -cw ) o |= 4u;
	if( cy > cw ) o |= 8u;
	g_dv_and &= o;
}
static inline void dc_vertex( float ex, float ey, float ez )
{
	union { float f[4]; unsigned u[4]; } d;
	const float w = -ez;
	const float wm = w + __builtin_fabsf( w ) * GLQ_DC_MARGIN;
	const float cx = g_dc_p0 * ex + g_dc_p8 * ez, cy = g_dc_p5 * ey + g_dc_p9 * ez;
	d.f[0] = cx + wm;        /* below 0: x < -w - margin */
	d.f[1] = wm - cx;        /* below 0: x >  w + margin */
	d.f[2] = cy + wm;
	d.f[3] = wm - cy;
	g_dc_and[0] &= d.u[0]; g_dc_and[1] &= d.u[1]; g_dc_and[2] &= d.u[2]; g_dc_and[3] &= d.u[3];
	/* an exponent of all ones = NaN or infinity: the batch is kept */
	g_dc_bad |= (((( d.u[0] >> 23 ) & 0xFFu ) + 1u ) | ((( d.u[1] >> 23 ) & 0xFFu ) + 1u )
	           | ((( d.u[2] >> 23 ) & 0xFFu ) + 1u ) | ((( d.u[3] >> 23 ) & 0xFFu ) + 1u )) & 0x100u;
}
static inline int dc_outside( void )
{
	return !g_dc_bad && (( g_dc_and[0] | g_dc_and[1] | g_dc_and[2] | g_dc_and[3] ) >> 31 );
}
/* the test checked where it runs: batches of 3 to 12 eye-space vertices under a frustum like
   ref_gl's - wholly beyond one side, the same with one vertex put back inside, vertices on a side
   exactly, behind the eye, a NaN, an infinity, anything at all.  A batch this test drops while the
   plain comparisons on its clip coordinates (ZZGL's batch_outside) keep it is an error: returns
   how many, must be 0.  *dropped: batches dropped; *plain: batches the plain test drops. */
unsigned glq_decal_cull_check( unsigned *batches, unsigned *dropped, unsigned *plain )
{
	static const float pr[16] = { 1.299038f, 0, 0, 0,  0, 1.732051f, 0, 0,  0, 0, -1.000244f, -1.0f,  0, 0, -8.000977f, 0 };
	const int keep_on = g_dcull, keep_rej = g_dcull_reject;
	unsigned seed = 88172645u, t, k, bad = 0u, nd = 0u, np = 0u;
#define DCR() ( seed ^= seed << 13, seed ^= seed >> 17, seed ^= seed << 5, seed )
#define DCF() ((float)( DCR() & 0xFFFFFFu ) / 16777215.0f )
	g_dcull = 1; g_dcull_reject = 1; memset( g_dc_pr, 0, sizeof( g_dc_pr ));
	for( t = 0; t < 4000u; t++ )
	{
		const unsigned kind = t % 8u, n = 3u + DCR() % 10u, side = DCR() % 4u;
		unsigned all = 15u;
		int mine;
		dc_begin( pr );
		for( k = 0; k < n; k++ )
		{
			float d = 4.0f + 2000.0f * DCF(), fx = 3.0f * DCF() - 1.5f, fy = 3.0f * DCF() - 1.5f, ex, ey, ez, cx, cy, cw;
			unsigned o = 0u;
			if( kind == 1u || kind == 2u || kind == 3u )
			{   /* wholly beyond one side, from far beyond to a hair beyond */
				const float out = ( kind == 1u ) ? 1.0f + 4.0f * DCF() : ( kind == 2u ) ? 1.0f + 0.02f * DCF() : 1.0f + 0.000001f * (float)( DCR() % 16u );
				if( side == 0u ) fx = -out; else if( side == 1u ) fx = out; else if( side == 2u ) fy = -out; else fy = out;
				if( kind == 2u && k == n - 1u && ( t & 8u )) { fx = 0.5f * DCF(); fy = 0.5f * DCF(); }   /* one vertex back inside */
			}
			if( kind == 4u ) { fx = ( k & 1u ) ? -1.0f : 1.0f; }                 /* on a side exactly */
			if( kind == 5u ) d = -( 1.0f + 500.0f * DCF());                      /* behind the eye */
			ez = -d; ex = fx * d / pr[0]; ey = fy * d / pr[5];
			if( kind == 6u && k == 1u )
			{
				static const unsigned odd[4] = { 0x7FC00000u, 0xFFC00000u, 0x7F800000u, 0xFF800000u };
				union { unsigned u; float f; } q; q.u = odd[( t / 8u ) % 4u];
				if(( t / 32u ) & 1u ) ex = q.f; else ez = q.f;
			}
			dc_vertex( ex, ey, ez );
			cx = pr[0] * ex + pr[8] * ez; cy = pr[5] * ey + pr[9] * ez; cw = -ez;
			if( cx < -cw ) o |= 1u;
			if( cx > cw ) o |= 2u;
			if( cy < -cw ) o |= 4u;
			if( cy > cw ) o |= 8u;
			all &= o;
		}
		mine = dc_outside();
		if( mine ) nd++;
		if( all ) np++;
		if( mine && !all ) bad++;
	}
#undef DCR
#undef DCF
	g_dc_on = 0; g_dcull = keep_on; g_dcull_reject = keep_rej; memset( g_dc_pr, 0, sizeof( g_dc_pr ));
	if( batches ) *batches = 4000u;
	if( dropped ) *dropped = nd;
	if( plain ) *plain = np;
	if( bad ) g_dcull = 0;
	return bad;
}

static void bias_begin( int threed )
{
	float pr[16], n, steps;
	g_po = 0; g_dc_on = 0; g_dv_on = 0u;
	if( !S_polyofs || !g_bias_scale || !threed || !S.en_depth || S.depth_mask || S.depth_func == ZGL_EQUAL ) return;
	steps = (float)g_bias_scale * ( S_po_units < 0.0f ? -S_po_units : S_po_units );
	if( steps <= 0.0f ) return;
	zzglGetFloatv( ZGL_PROJECTION_MATRIX, pr );
	if( pr[10] - 1.0f == 0.0f ) return;
	n = pr[14] / ( pr[10] - 1.0f );                  /* glFrustum: P10 = -(f+n)/(f-n), P14 = -2fn/(f-n) */
	if( !( n > 0.0f )) return;
	g_po_c = steps / ( n * 65536.0f );
	zzglGetFloatv( ZGL_MODELVIEW_MATRIX, g_po_mv );
	zzglMatrixMode( ZGL_MODELVIEW ); zzglLoadIdentity(); zzglMatrixMode( S_matrix_mode );
	g_po = 1; g_biased++;
	dc_begin( pr );                                  /* build 94 */
}
static void bias_vertex( float *x, float *y, float *z )
{
	const float *m = g_po_mv;
	float ex = m[0] * *x + m[4] * *y + m[8] * *z + m[12];
	float ey = m[1] * *x + m[5] * *y + m[9] * *z + m[13];
	float ez = m[2] * *x + m[6] * *y + m[10] * *z + m[14];
	float d = -ez;
	if( d > 0.0f )
	{
		float k = g_po_c * d;
		if( k > 0.08f ) k = 0.08f;
		ex *= 1.0f - k; ey *= 1.0f - k; ez *= 1.0f - k;
	}
	*x = ex; *y = ey; *z = ez;
}
static void bias_end( void )
{
	if( !g_po ) return;
	zzglMatrixMode( ZGL_MODELVIEW ); zzglLoadMatrixf( g_po_mv ); zzglMatrixMode( S_matrix_mode );
	g_po = 0;
}

/* build 84, SPRTRIM: which texels of the bound texture CANNOT change the picture in the state
   ref_gl has set now.  Bit 0: a texel whose alpha is 0; bit 1: a texel whose colour is black.
   0: none, or a state in which leaving a pixel out could still be seen.
     - never when the draw writes the depth buffer: a pixel that adds nothing to the colour
       would still leave its depth behind;
     - alpha test GREATER (reference 0 or more) or GEQUAL (above 0): alpha 0 is killed outright;
     - blend (SRC_ALPHA, ONE_MINUS_SRC_ALPHA): alpha 0 leaves the destination as it is;
     - blend (ONE, ONE): black adds nothing; (SRC_ALPHA, ONE): black or alpha 0 adds nothing.
   Only with the MODULATE and REPLACE environments, where a zero texel stays zero. */
int glq_trim_kind( void )
{
	int k = 0;
	if( !S.en_tex || ( S.tex_env != ZGL_MODULATE && S.tex_env != ZGL_REPLACE )) return 0;
	if( S.en_depth && S.depth_mask ) return 0;
	if( S.en_alpha && (( S.alpha_func == ZGL_GREATER && S.alpha_ref >= 0.0f ) || ( S.alpha_func == ZGL_GEQUAL && S.alpha_ref > 0.0f ))) k |= 1;
	if( S.en_blend )
	{
		if( S.blend_d == ZGL_ONE && S.blend_s == ZGL_ONE ) k |= 2;
		else if( S.blend_d == ZGL_ONE && S.blend_s == ZGL_SRC_ALPHA ) k |= 3;
		else if( S.blend_s == ZGL_SRC_ALPHA && S.blend_d == ZGL_ONE_MINUS_SRC_ALPHA ) k |= 1;
	}
	return k;
}

void glq_set_sort( int on ) { if( !on && g_nb ) glq_flush( GLQ_WHY_STATE ); g_sort = on ? 1 : 0; }
void glq_set_bindtest( int mode ) { g_bindtest = mode; }
int  glq_sort_on( void ) { return g_sort; }
const glq_stats_t *glq_stats( void ) { return &st; }
void glq_texture_size( unsigned tex, unsigned w, unsigned h ) { if( tex < GLQ_NTEX ) { g_tex_w[tex] = (unsigned short)w; g_tex_h[tex] = (unsigned short)h; } }

/* Lightmap depth equality must remain exact to avoid visible seams or missing pixels. */
static unsigned g_lmdepth = 1u;
void glq_set_lm_depth( int mode ) { g_lmdepth = mode < 0 ? 0u : mode > 2 ? 2u : (unsigned)mode; }
static unsigned depth_out( unsigned f )
{
	if( f != ZGL_EQUAL || g_lmdepth == 1u ) return f;
	return g_lmdepth == 2u ? (unsigned)ZGL_ALWAYS : (unsigned)ZGL_LEQUAL;
}


/* ---- ZZGL side ---- */
static void zz_enable( unsigned cap, int on ) { if( on ) zzglEnable( cap ); else zzglDisable( cap ); }

static void apply_key( const glq_key_t *k )
{
	zz_enable( ZGL_TEXTURE_2D, k->en_tex );
	zz_enable( ZGL_DEPTH_TEST, k->en_depth );
	zz_enable( ZGL_BLEND, k->en_blend );
	zz_enable( ZGL_ALPHA_TEST, k->en_alpha );
	zz_enable( ZGL_CULL_FACE, k->en_cull );
	zzglDepthFunc( depth_out( k->depth_func ));
	zzglDepthMask( k->depth_mask );
	zzglBlendFunc( k->blend_s, k->blend_d );
	zzglAlphaFunc( k->alpha_func, k->alpha_ref );
	zzglCullFace( k->cull_mode );
	zzglFrontFace( k->front_face );
	zzglShadeModel( k->shade_flat ? ZGL_FLAT : ZGL_SMOOTH );
	zzglTexEnvf( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, (float)k->tex_env );
}

/* the two 8x8 textures of BINDTEST, made once (the engine's bind is restored after) */
static void tiny_make( void )
{
	static unsigned char px[8 * 8 * 3];
	unsigned i;
	if( g_tiny_ready ) return;
	for( i = 0; i < sizeof( px ); i++ ) px[i] = ( i % 3 == 1 ) ? 0xA0u : 0xC0u;
	g_tiny[0] = 2294u; g_tiny[1] = 2295u;           /* under the skybox remap slots (2296..2303), above ref_gl's names */
	for( i = 0; i < 2u; i++ )
	{
		zzglBindTexture( ZGL_TEXTURE_2D, g_tiny[i] );
		zzglTexImage2D( ZGL_TEXTURE_2D, 0, 3, 8, 8, 0, ZGL_RGB, ZGL_UNSIGNED_BYTE, px );
		glq_texture_size( g_tiny[i], 8u, 8u );
	}
	zzglBindTexture( ZGL_TEXTURE_2D, g_tex );
	g_tiny_ready = 1;
}

/* the bind a draw really uses: BINDTEST substitution, statistics */
static void bind_for_draw( unsigned tex, int threed )
{
	unsigned eff = tex;
	if( g_bindtest && threed )
	{
		tiny_make();
		if( g_bindtest == 2 ) g_tiny_k ^= 1u;
		eff = g_tiny[g_bindtest == 2 ? g_tiny_k : 0u];
	}
	if( eff != g_last_done )
	{
		st.binds_done++;
		if( eff < GLQ_NTEX ) st.bind_kib += ((unsigned)g_tex_w[eff] * g_tex_h[eff] * 2u ) / 1024u;
		g_last_done = eff;
	}
	zzglBindTexture( ZGL_TEXTURE_2D, eff );
}

static int proj_is_ortho( void )
{
	float p[16];
	zzglGetFloatv( ZGL_PROJECTION_MATRIX, p );
	return p[15] != 0.0f;                 /* ZZGL: perspective iff p[15] == 0 */
}

/* the biased overlays (decals, scorch marks, blood) in a third group instead of vidding
   the queue.  Measured on the A4000 (13/11, c2a5f): ref_gl issues 204 binds a frame for 59 distinct
   textures and 174 were sent, because two flushes cut the frame in three and each piece rebound its
   world textures.  Group 2 is replayed AFTER groups 0 and 1, in the order ref_gl recorded it (one
   bucket, not sorted by texture): two overlays that cover each other blend in the same order as
   before, and against the world the depth test decides as before (an overlay never writes depth,
   and sits on a surface whose depth is already written).  DECALQ=0 restores the build 53 behaviour. */
/* 0 = a biased overlay is not recordable (it flushes, build 53); 1 = third group replayed last in
   the order it was recorded (build 54); 2 = third group replayed last and sorted by texture
   (build 55).  c2a5f, A4000 13/11: 120 biased batches a frame, 177 binds sent for 63 distinct
   textures with 1, the same 114 extra binds as with 0 - the overlays, not the flushes, are what
   binds.  Sorting them is worth about 7 ms a frame there, at the cost of the recorded order
   between two overlays of DIFFERENT textures (the sort is stable, so two of the same texture keep
   theirs): only overlays that overlap on one surface can show it, hence the option. */
static int g_decal_group = 1;
void glq_set_decal_group( int on ) { if( !on && g_nb ) glq_flush( GLQ_WHY_STATE ); g_decal_group = on < 0 ? 0 : on > 2 ? 2 : on; }

/* -1: not recordable; 0: opaque; 1: lightmap modulation pass; 2: biased overlay (set in glq_begin) */
static int group_of( const glq_key_t *k )
{
	if( !k->en_depth ) return -1;
	if( !k->en_blend )
	{
		if( !k->depth_mask ) return -1;
		if( k->depth_func == ZGL_LESS || k->depth_func == ZGL_LEQUAL || k->depth_func == ZGL_GREATER || k->depth_func == ZGL_GEQUAL ) return 0;
		return -1;
	}
	if( k->depth_mask || k->en_alpha || k->depth_func != ZGL_EQUAL ) return -1;
	if(( k->blend_s == ZGL_ZERO && k->blend_d == ZGL_SRC_COLOR ) || ( k->blend_s == ZGL_DST_COLOR && k->blend_d == ZGL_SRC_COLOR )) return 1;
	return -1;
}

/* ---- state entry points: shadow, then ZZGL ---- */
void glq_enable( unsigned cap, int on )
{
	if( cap == ZGL_TEXTURE_1D ) cap = ZGL_TEXTURE_2D;   /* ref_gl's 1-pixel-high textures */
	switch( cap )
	{
	case ZGL_TEXTURE_2D: S.en_tex = (unsigned char)on; break;
	case ZGL_DEPTH_TEST: S.en_depth = (unsigned char)on; break;
	case ZGL_BLEND: S.en_blend = (unsigned char)on; break;
	case ZGL_ALPHA_TEST: S.en_alpha = (unsigned char)on; break;
	case ZGL_CULL_FACE: S.en_cull = (unsigned char)on; break;
	case ZGL_SCISSOR_TEST: if( g_nb ) glq_flush( GLQ_WHY_CLEAR ); S_scissor = (unsigned char)on; break;
	case ZGL_POLYGON_OFFSET_FILL: S_polyofs = (unsigned char)on; break;
	default: break;
	}
	zz_enable( cap, on );
}
void glq_depth_func( unsigned f ) { S.depth_func = (unsigned short)f; zzglDepthFunc( depth_out( f )); }
void glq_depth_mask( int on ) { S.depth_mask = (unsigned char)( on ? 1 : 0 ); zzglDepthMask( on ? 1u : 0u ); }
void glq_blend_func( unsigned s, unsigned d ) { S.blend_s = (unsigned short)s; S.blend_d = (unsigned short)d; zzglBlendFunc( s, d ); }
void glq_alpha_func( unsigned f, float ref ) { S.alpha_func = (unsigned short)f; S.alpha_ref = ref; zzglAlphaFunc( f, ref ); }
void glq_cull_face( unsigned m ) { S.cull_mode = (unsigned short)m; zzglCullFace( m ); }
void glq_front_face( unsigned m ) { S.front_face = (unsigned short)m; zzglFrontFace( m ); }
void glq_shade_model( unsigned m ) { S.shade_flat = (unsigned char)( m == ZGL_FLAT ); zzglShadeModel( m ); }
void glq_polygon_mode( unsigned m ) { S_fill = (unsigned char)( m == ZGL_FILL ); zzglPolygonMode( ZGL_FRONT_AND_BACK, m ); }
void glq_tex_env( unsigned mode ) { S.tex_env = (unsigned short)mode; zzglTexEnvf( ZGL_TEXTURE_ENV, ZGL_TEXTURE_ENV_MODE, (float)mode ); }
void glq_color_mask( int on ) { S_color_mask = (unsigned char)( on ? 1 : 0 ); zzglColorMask( on, on, on, on ); }
void glq_scissor( int x, int y, int w, int h ) { if( g_nb ) glq_flush( GLQ_WHY_CLEAR ); zzglScissor( x, y, w, h ); }
void glq_viewport( int x, int y, int w, int h ) { if( g_nb ) glq_flush( GLQ_WHY_CLEAR ); zzglViewport( x, y, w, h ); }
void glq_depth_range( double n, double f ) { if( g_nb ) glq_flush( GLQ_WHY_CLEAR ); zzglDepthRange( n, f ); }
void glq_matrix_mode( unsigned m ) { S_matrix_mode = m; zzglMatrixMode( m ); }
void glq_bind( unsigned tex ) { g_tex = tex; zzglBindTexture( ZGL_TEXTURE_2D, tex ); }
/* build 92, RECFAST=1 (off by default): the colour and the texture coordinates of a vertex that is
   being RECORDED.  ref_gl gives a model's colour in bytes (glColor4ubv, once per vertex).  It was
   turned into four floats by four divisions, handed to ZZGL - which does nothing with it until
   the replay - then turned back into the four bytes the recorded vertex keeps, through eight
   float comparisons (f2b's clamps), each a costly crossing from the FPU to the core on a
   Cortex-A9.  f2b( x / 255.0f ) is x for the 256 values of x (glq_recfast_check, and tests/
   test_glq.c): with RECFAST the bytes go straight into the recorded vertex and ZZGL is told
   nothing meanwhile.  At the batch's end the current colour and texture coordinates are given to
   ZZGL as they would have been, so what follows the batch finds the same state.  What is recorded,
   and so what is replayed, is the same, bit for bit. */
static int g_recfast;
static unsigned char g_colb[4];
static int g_colb_on;                 /* the current colour was given in bytes: g_colb is f2b of it */
static unsigned g_attr_stale;         /* inside a recorded batch: 1 = g_col and ZZGL's colour are behind g_colb, 2 = ZZGL's texture coordinates behind g_st */
void glq_set_recfast( int on ) { g_recfast = on ? 1 : 0; }
int  glq_recfast( void ) { return g_recfast; }
/* ---- build 95, EMITPROF=1: a MEASURE, off by default and nothing else changes without it.
 * Where the time of a recorded vertex goes between ref_gl's calls and inside them.  A4000, 17/11,
 * save010 (the Gonarch): the models' emission is 7 282 us a frame for about 4 150 vertices,
 * 1.75 us each, and neither reading the code nor RECFAST (which lost) says what in it is slow.
 * Every recorded call reads the global timer (the register librixgpu reads, 3 ns a tick) at its
 * entry and its exit: time INSIDE glq_begin, the colour call, the texture-coordinate call,
 * glq_vertex, glq_end and the GPU pump glq_end makes; and the GAPS between them, which are
 * ref_gl's own work for a vertex: after a vertex until the next colour (the loop, R_LightLambert),
 * colour to coordinates, coordinates to vertex.  Two classes: models with the weapon in hand, and
 * everything else recorded.  The two reads lengthen every call: the frame times of such a run are
 * not to be compared with anything. */
enum { EP_BEGIN, EP_COLOR, EP_TEXCOORD, EP_VERTEX, EP_END, EP_PUMP, EP_GAP_V2C, EP_GAP_C2T, EP_GAP_T2V, EP_GAP_OTHER, EP_N };
static int g_eprof;
static unsigned long long g_ep_ticks[2][EP_N];
static unsigned g_ep_calls[2][EP_N];
static unsigned g_ep_empty, g_ep_last, g_ep_prev;      /* an empty pair of reads; the tick the last timed call ended at; what it was (0 none) */
#ifdef ZZHL_HOST_TEST
static unsigned g_ep_fake;
#define GLQ_TICK() ( g_ep_fake += 7u )
#else
#define GLQ_TICK() ( *(volatile unsigned *)0xF8F00200u )
#endif
#define EP_CLASS() (( g_org == (unsigned)ZORG_STUDIO || g_org == (unsigned)ZORG_VIEWMODEL ) ? 0 : 1 )
static inline void ep_add( int what, unsigned ticks ) { const int c = EP_CLASS(); g_ep_ticks[c][what] += ticks; g_ep_calls[c][what]++; }
/* entry of a timed call of kind k (1 colour, 2 coordinates, 3 vertex): the gap since the one before */
static inline unsigned ep_in( unsigned k )
{
	const unsigned t = GLQ_TICK();
	if( g_ep_prev ) ep_add(( g_ep_prev == 3u && k == 1u ) ? EP_GAP_V2C : ( g_ep_prev == 1u && k == 2u ) ? EP_GAP_C2T : ( g_ep_prev == 2u && k == 3u ) ? EP_GAP_T2V : EP_GAP_OTHER, t - g_ep_last );
	return t;
}
static inline void ep_out( int what, unsigned k, unsigned t0 ) { const unsigned t = GLQ_TICK(); ep_add( what, t - t0 ); g_ep_last = t; g_ep_prev = k; }
void glq_set_emit_prof( int on )
{
	unsigned i, best = 0xFFFFFFFFu;
	g_eprof = on ? 1 : 0;
	memset( g_ep_ticks, 0, sizeof( g_ep_ticks )); memset( g_ep_calls, 0, sizeof( g_ep_calls ));
	for( i = 0; i < 64u; i++ ) { const unsigned a = GLQ_TICK(), b = GLQ_TICK(); if( b - a < best ) best = b - a; }
	g_ep_empty = best;
}
int glq_emit_prof( void ) { return g_eprof; }
unsigned glq_emit_prof_empty( void ) { return g_ep_empty; }
unsigned glq_emit_prof_get( int cls, int what, unsigned long long *ticks )
{
	if( cls < 0 || cls > 1 || what < 0 || what >= EP_N ) { if( ticks ) *ticks = 0ull; return 0u; }
	if( ticks ) *ticks = g_ep_ticks[cls][what];
	return g_ep_calls[cls][what];
}

static void color_body( float r, float g, float b, float a ) { g_col[0] = r; g_col[1] = g; g_col[2] = b; g_col[3] = a; g_colb_on = 0; g_attr_stale &= ~1u; zzglColor4f( r, g, b, a ); }
void glq_color( float r, float g, float b, float a )
{
	if( g_eprof && g_in_begin && g_rec ) { const unsigned t0 = ep_in( 1u ); color_body( r, g, b, a ); ep_out( EP_COLOR, 1u, t0 ); return; }
	color_body( r, g, b, a );
}
static void color4ub_body( unsigned r, unsigned g, unsigned b, unsigned a )
{
	if( g_recfast && g_in_begin && g_rec )
	{
		g_colb[0] = (unsigned char)r; g_colb[1] = (unsigned char)g; g_colb[2] = (unsigned char)b; g_colb[3] = (unsigned char)a;
		g_colb_on = 1; g_attr_stale |= 1u;
		return;
	}
	color_body( (unsigned char)r / 255.0f, (unsigned char)g / 255.0f, (unsigned char)b / 255.0f, (unsigned char)a / 255.0f );
}
void glq_color4ub( unsigned r, unsigned g, unsigned b, unsigned a )
{
	if( g_eprof && g_in_begin && g_rec ) { const unsigned t0 = ep_in( 1u ); color4ub_body( r, g, b, a ); ep_out( EP_COLOR, 1u, t0 ); return; }
	color4ub_body( r, g, b, a );
}
static inline void texcoord_body( float s, float t )
{
	g_st[0] = s; g_st[1] = t;
	if( g_recfast && g_in_begin && g_rec ) { g_attr_stale |= 2u; return; }
	zzglTexCoord2f( s, t );
}
void glq_texcoord( float s, float t )
{
	if( g_eprof && g_in_begin && g_rec ) { const unsigned t0 = ep_in( 2u ); texcoord_body( s, t ); ep_out( EP_TEXCOORD, 2u, t0 ); return; }
	texcoord_body( s, t );
}

unsigned glq_bound( void ) { return g_tex; }
void glq_texture_touched( unsigned tex )
{
	if( tex < GLQ_NTEX && g_tex_gen[tex] == g_gen && g_nb ) glq_flush( GLQ_WHY_TEXTURE );
}

/* ---- splitting runs over ZZGL's 64-vertex Begin/End buffer ----
 * Build 15.  Build 5 split TRIANGLES and QUADS only; the beams of gl_beams.c are
 * TRIANGLE_STRIPs (TriBegin( TRI_TRIANGLE_STRIP )) whose segment count grows with the beam
 * length and noise, and ZZGL refused every one over 64 vertices (GL_OUT_OF_MEMORY at
 * gl_rmain.c:939, CL_DrawEFX: 161 times in the test chamber c1a0e on 04/11, the resonance
 * cascade is made of such beams).  A run is cut every 60 vertices (an even count) and the
 * next block restarts with what keeps the primitive identical:
 *   TRIANGLES / QUADS / POINTS / LINES: nothing (60 is a multiple of 3, 4, 1 and 2);
 *   TRIANGLE_STRIP / QUAD_STRIP: the last two vertices (the cut is at an even index, so the
 *     strip keeps its winding parity: culling sees the same triangles);
 *   TRIANGLE_FAN / POLYGON: the first vertex and the last one;
 *   LINE_STRIP: the last vertex.
 * LINE_LOOP is not cut (its closing edge needs the first vertex at the very end). */
#define GLQ_SPLIT_AT 60u
enum { SPLIT_NONE, SPLIT_PLAIN, SPLIT_STRIP, SPLIT_FAN, SPLIT_LINESTRIP };
static int split_kind( unsigned mode )
{
	switch( mode )
	{
	case ZGL_POINTS: case ZGL_LINES: case ZGL_TRIANGLES: case ZGL_QUADS: return SPLIT_PLAIN;
	case ZGL_TRIANGLE_STRIP: case ZGL_QUAD_STRIP: return SPLIT_STRIP;
	case ZGL_TRIANGLE_FAN: case ZGL_POLYGON: return SPLIT_FAN;
	case ZGL_LINE_STRIP: return SPLIT_LINESTRIP;
	default: return SPLIT_NONE;
	}
}
static void emit_v( const glq_vert_t *v )
{
	zzglColor4ubv( v->rgba );
	zzglTexCoord2f( v->s, v->t );
	zzglVertex3f( v->x, v->y, v->z );
}
static unsigned split_restart( int kind, const glq_vert_t *first, const glq_vert_t *prev2, const glq_vert_t *prev1 )
{
	switch( kind )
	{
	case SPLIT_STRIP: emit_v( prev2 ); emit_v( prev1 ); return 2u;
	case SPLIT_FAN: emit_v( first ); emit_v( prev1 ); return 2u;
	case SPLIT_LINESTRIP: emit_v( prev1 ); return 1u;
	default: return 0u;
	}
}
/* pass-through state: the vertices a restart may need, with the attributes they were sent with */
static glq_vert_t g_pt_first, g_pt_prev[2];
static unsigned g_pt_total;
static int g_split_kind;
static unsigned g_splits;
unsigned glq_splits( void ) { return g_splits; }

/* ---- recording ---- */
static unsigned key_index( void )
{
	unsigned i;
	for( i = 0; i < g_nkeys; i++ ) if( !memcmp( &g_keys[i], &S, sizeof( S ))) return i;
	if( g_nkeys == GLQ_MAX_KEYS ) return GLQ_MAX_KEYS;
	g_keys[g_nkeys] = S;
	return g_nkeys++;
}
static unsigned mat_index( void )
{
	glq_mat_t m;
	unsigned i;
	zzglGetFloatv( ZGL_MODELVIEW_MATRIX, m.mv );
	zzglGetFloatv( ZGL_PROJECTION_MATRIX, m.pr );
	if( g_nmats && !memcmp( &g_mats[g_nmats - 1u], &m, sizeof( m ))) return g_nmats - 1u;   /* the usual case: the previous batch's matrices */
	for( i = 0; i + 1u < g_nmats; i++ ) if( !memcmp( &g_mats[i], &m, sizeof( m ))) return i;
	if( g_nmats == GLQ_MAX_MATS ) return GLQ_MAX_MATS;
	g_mats[g_nmats] = m;
	return g_nmats++;
}

static unsigned char f2b( float f ) { int v = (int)( f * 255.0f + 0.5f ); return (unsigned char)( v < 0 ? 0 : v > 255 ? 255 : v ); }
/* what RECFAST rests on, checked where it runs: the 256 byte values through the division
   and f2b come back as themselves.  Returns how many do not: must be 0. */
unsigned glq_recfast_check( void )
{
	unsigned x, bad = 0u;
	for( x = 0u; x < 256u; x++ )
	{
		volatile float f = (unsigned char)x / 255.0f;
		if( f2b( f ) != (unsigned char)x ) bad++;
	}
	if( bad ) g_recfast = 0;
	return bad;
}

static void begin_body( unsigned mode )
{
	int group = -1, threed;
	unsigned tex = S.en_tex ? g_tex : GLQ_TEX_NONE;
	if( g_in_begin ) return;
	threed = !proj_is_ortho();
	g_org = threed ? zzhl_origin_now() : (unsigned)ZORG_2D;   /* asked BEFORE any flush this batch may force */
	bias_begin( threed );            /* before the recording decision: a recorded batch keeps the identity modelview */
	if( zzhl_decal_mark && !g_dv_on && !g_po && threed ) dv_begin_plain();   /* a marked batch that is no biased overlay */
	st.batches++;
	/* statistics of the binds as ref_gl issued them */
	if( tex != GLQ_TEX_NONE && tex != g_last_req )
	{
		st.binds_req++; zzhl_fx[ZFX_BINDS_REQ]++;
		if( threed ) st.binds_3d++; else st.binds_2d++;
		if( g_tex_frame[tex] == g_frame ) st.rebinds++;
		else { g_tex_frame[tex] = g_frame; st.distinct++; zzhl_fx[ZFX_TEX_DISTINCT]++; }
		g_last_req = tex;
	}
	if( g_sort && threed && S_fill && S_color_mask && !S_scissor && mode >= ZGL_TRIANGLES && mode <= ZGL_POLYGON )
	{
		group = group_of( &S );
		/* g_po: bias_begin just said this batch is a biased overlay (depth test on, no depth write,
		   depth func not EQUAL, 3D).  Blended on top of that = a decal or an overlay: group 2. */
		if( group < 0 && g_decal_group && g_po && S.en_blend ) group = 2;
	}
	if( group >= 0 )
	{
		unsigned k, m;
		S.group = (unsigned char)group;                            /* part of the key */
		if( g_nb >= GLQ_MAX_BATCH || g_nv + GLQ_BATCH_ROOM > GLQ_MAX_VERT || g_nidx + GLQ_IDX_ROOM > GLQ_MAX_IDX ) glq_flush( GLQ_WHY_FULL );
		k = key_index(); m = mat_index();
		if( k == GLQ_MAX_KEYS || m == GLQ_MAX_MATS ) { glq_flush( GLQ_WHY_FULL ); k = key_index(); m = mat_index(); }
		g_b[g_nb].first = g_nv; g_b[g_nb].count = 0u; g_b[g_nb].tex = (unsigned short)tex; g_b[g_nb].key = (unsigned short)k;
		g_b[g_nb].idx_first = g_nidx; g_b[g_nb].idx_count = 0u; g_b[g_nb].pad = 0u;
		g_b[g_nb].mode = (unsigned char)mode; g_b[g_nb].mat = (unsigned char)m; g_b[g_nb].group = (unsigned char)group;
		/* the lightmap pass and the overlays are origins of their own, whoever owns the surface */
		g_b[g_nb].org = (unsigned char)( group == 1 ? ZORG_LIGHTMAP : group == 2 ? ZORG_DECAL : g_org );
		g_bsum[g_nb] = 0.0f; g_rec_mv = g_mats[m].mv;
		if( tex != GLQ_TEX_NONE ) g_tex_gen[tex] = g_gen;
		g_rec = 1;
	}
	else
	{
		if( g_nb ) { zzhl_fx[ZFX_FLUSHBY0 + g_org]++; glq_flush( GLQ_WHY_STATE ); }
		zzgl_origin_set( g_org );
		if( g_fxtime ) { g_pt_t0 = zzhl_us64(); g_pt_w0 = zzhl_gpu_wait_us(); }
		if( tex != GLQ_TEX_NONE ) bind_for_draw( tex, threed );
		zzglBegin( mode );
		g_rec = 0;
	}
	g_in_begin = 1; g_mode = mode; g_count = 0u;
	g_split_kind = split_kind( mode ); g_pt_total = 0u;
}
void glq_begin( unsigned mode )
{
	if( g_eprof )
	{
		const unsigned t0 = GLQ_TICK();
		begin_body( mode );
		g_ep_prev = 0u;
		if( g_rec ) { const unsigned t = GLQ_TICK(); ep_add( EP_BEGIN, t - t0 ); g_ep_last = t; }
		return;
	}
	begin_body( mode );
}

static void vertex_body( float x, float y, float z )
{
	if( !g_in_begin ) return;
	if( g_dv_on == 2u ) dv_vertex_plain( x, y, z );             /* the check on a batch that is not biased */
	if( g_po ) bias_vertex( &x, &y, &z );
	if( g_rec )
	{
		glq_vert_t *v;
		if( g_nv >= GLQ_MAX_VERT ) return;                       /* GLQ_BATCH_ROOM makes this unreachable for ref_gl's polygons */
		v = &g_v[g_nv++];
		v->x = x; v->y = y; v->z = z; v->s = g_st[0]; v->t = g_st[1];
		if( g_colb_on ) { v->rgba[0] = g_colb[0]; v->rgba[1] = g_colb[1]; v->rgba[2] = g_colb[2]; v->rgba[3] = g_colb[3]; }   /* build 92 */
		else { v->rgba[0] = f2b( g_col[0] ); v->rgba[1] = f2b( g_col[1] ); v->rgba[2] = f2b( g_col[2] ); v->rgba[3] = f2b( g_col[3] ); }
		g_b[g_nb].count++;
		if( g_dv_on == 1u ) dv_vertex( x, y, z );                /* build 96, the check: before DECALCULL's own test */
		if( g_dc_on ) dc_vertex( x, y, z );                      /* x, y, z are in eye space here (g_po) */
		if( g_f2b ) g_bsum[g_nb] -= g_rec_mv[2] * x + g_rec_mv[6] * y + g_rec_mv[10] * z + g_rec_mv[14];   /* view distance = -eye z */
		return;
	}
	/* pass-through: ZZGL's Begin/End buffer holds 64 vertices (see split_kind) */
	if( g_split_kind != SPLIT_NONE && g_count >= GLQ_SPLIT_AT )
	{
		zzglEnd(); zzglBegin( g_mode );
		g_count = split_restart( g_split_kind, &g_pt_first, &g_pt_prev[0], &g_pt_prev[1] );
		zzglColor4f( g_col[0], g_col[1], g_col[2], g_col[3] );     /* the current vertex's own attributes again */
		zzglTexCoord2f( g_st[0], g_st[1] );
		g_splits++;
	}
	{
		glq_vert_t v;
		v.x = x; v.y = y; v.z = z; v.s = g_st[0]; v.t = g_st[1];
		v.rgba[0] = f2b( g_col[0] ); v.rgba[1] = f2b( g_col[1] ); v.rgba[2] = f2b( g_col[2] ); v.rgba[3] = f2b( g_col[3] );
		if( !g_pt_total ) g_pt_first = v;
		g_pt_prev[0] = g_pt_prev[1]; g_pt_prev[1] = v;
		g_pt_total++;
	}
	g_count++;
	zzglVertex3f( x, y, z );
}
void glq_vertex( float x, float y, float z )
{
	if( g_eprof && g_in_begin && g_rec ) { const unsigned t0 = ep_in( 3u ); vertex_body( x, y, z ); ep_out( EP_VERTEX, 3u, t0 ); return; }
	vertex_body( x, y, z );
}

/* build 32 (R1): while ref_gl's walk is recorded, nothing reaches ZZGL; with pipelined frames the GPU
   still works on the previous frame and stops at its next bind until Core1 pumps the queue.  One pump
   every 4 recorded batches (a few us; Core1/zzhl_gpu.c, no-op when not pipelined). */
#ifdef ZZHL_HOST_TEST
static void zzhl_gpu_pump( void ) { }
static void zzhl_gpu_phase( unsigned ph ) { (void)ph; }
#else
extern void zzhl_gpu_pump( void );
extern void zzhl_gpu_phase( unsigned ph );   /* Core1/zzhl_gpu.c, librixgpu RIX_PH_* */
#endif
static unsigned g_rec_pump;
static unsigned st_idx_batches, st_idx_tris;
static unsigned g_ep_pump_ticks;
static const unsigned char *g_end_idx;   /* glq_end_indexed is ending this batch */
static unsigned g_end_nidx;
static void end_body( void )
{
	unsigned src;
	if( !g_in_begin ) return;
	src = zzhl_emit_decal ? 1u : zzhl_emit_water ? 0u : zzhl_emit_bmodel == 1 ? 2u : zzhl_emit_bmodel == 2 ? 3u : 4u;
	zzhl_emit_decal = 0u;
	if( zzhl_decal_mark )
	{   /* build 96, DECALFRUST=2 (and WATERCULL=2, build 98): ref_gl's test called this polygon out of view */
		zzhl_decal_mark = 0u; g_dv_marked++;
		if( g_dv_on == 2u ) { if( !g_dv_and ) g_dv_wrong++; }    /* recorded or passed through alike */
		else if( !g_rec || !g_dv_on ) g_dv_unchecked++;
		else if( !g_dv_and ) g_dv_wrong++;
	}
	if( g_rec )
	{
		if( g_dc_on && g_b[g_nb].count >= 3u && dc_outside())
		{   /* build 94, DECALCULL: wholly out of view - never recorded */
			g_dc_batches++; g_dc_verts += g_b[g_nb].count;
			g_ov_drop[src]++; g_ov_dropv[src] += g_b[g_nb].count;
			g_nv = g_b[g_nb].first;
		}
		else if( g_b[g_nb].count )
		{
			if( g_b[g_nb].group == 2u ) { g_ov_keep[src]++; g_ov_keepv[src] += g_b[g_nb].count; }
			if( g_end_idx && g_end_nidx && g_nidx + g_end_nidx <= GLQ_MAX_IDX && g_end_nidx <= 0xFFFFu )
			{   /* the triangles of this batch are index triples (GLQ_IDX_ROOM was kept free at its begin) */
				memcpy( &g_idx[g_nidx], g_end_idx, g_end_nidx );
				g_b[g_nb].idx_first = g_nidx; g_b[g_nb].idx_count = (unsigned short)g_end_nidx;
				g_nidx += g_end_nidx; st_idx_batches++; st_idx_tris += g_end_nidx / 3u;
			}
			g_nb++; st.batches_recorded++; st.verts_recorded += g_b[g_nb - 1u].count; g_frame_batches++; g_frame_verts += g_b[g_nb - 1u].count;
		}
		else g_nv = g_b[g_nb].first;
		if(( ++g_rec_pump & 3u ) == 0u )
		{
			if( g_eprof ) { const unsigned t0 = GLQ_TICK(); zzhl_gpu_pump( ); g_ep_pump_ticks = GLQ_TICK() - t0; ep_add( EP_PUMP, g_ep_pump_ticks ); }
			else zzhl_gpu_pump( );
		}
		if( g_attr_stale )
		{   /* build 92, RECFAST: the state the batch leaves, as it was left before */
			if( g_attr_stale & 1u )
			{
				g_col[0] = g_colb[0] / 255.0f; g_col[1] = g_colb[1] / 255.0f; g_col[2] = g_colb[2] / 255.0f; g_col[3] = g_colb[3] / 255.0f;
				zzglColor4f( g_col[0], g_col[1], g_col[2], g_col[3] );
			}
			if( g_attr_stale & 2u ) zzglTexCoord2f( g_st[0], g_st[1] );
			g_attr_stale = 0u;
		}
	}
	else
	{
		if( g_end_idx ) zzglEndIndexed( g_end_idx, g_end_nidx ); else zzglEnd();
		if( g_fxtime )
		{
			zzhl_fx[ZFX_ORG( g_org, ZFXO_US )] += (unsigned)( zzhl_us64() - g_pt_t0 );
			zzhl_fx[ZFX_ORG( g_org, ZFXO_WAIT_US )] += waits_since( g_pt_w0 );
		}
	}
	g_in_begin = 0; g_rec = 0;
	bias_end();
}
void glq_end( void )
{
	if( g_eprof && g_in_begin && g_rec )
	{
		const unsigned t0 = GLQ_TICK();
		const int c = EP_CLASS();
		g_ep_pump_ticks = 0u;
		end_body();
		g_ep_ticks[c][EP_END] += ( GLQ_TICK() - t0 ) - g_ep_pump_ticks; g_ep_calls[c][EP_END]++;
		g_ep_prev = 0u;
		return;
	}
	end_body();
}
/* the end of a glq_begin( ZGL_TRIANGLES ) whose vertices were given ONCE each (60 at most);
   idx: n indices into them, three a triangle.  Recorded or passed through like any batch. */
void glq_end_indexed( const unsigned char *idx, unsigned n )
{
	g_end_idx = idx; g_end_nidx = n;
	glq_end();
	g_end_idx = NULL; g_end_nidx = 0u;
}
unsigned glq_indexed_stats( unsigned *tris ) { if( tris ) *tris = st_idx_tris; return st_idx_batches; }

/* ---- replay ---- */
static void emit_batch( const glq_batch_t *b )
{
	const glq_vert_t *v0 = &g_v[b->first];
	unsigned i, n = b->count, k = 0u;
	int kind = split_kind( b->mode );
	zzglBegin( b->mode );
	if( b->idx_count )
	{   /* every vertex once (60 at most: no cut), then the triangles by their indices */
		for( i = 0; i < n; i++ ) emit_v( &v0[i] );
		zzglEndIndexed( &g_idx[b->idx_first], b->idx_count );
		return;
	}
	for( i = 0; i < n; i++ )
	{
		if( kind != SPLIT_NONE && k >= GLQ_SPLIT_AT )
		{
			zzglEnd(); zzglBegin( b->mode );
			k = split_restart( kind, &v0[0], &v0[i - 2u], &v0[i - 1u] );
			g_splits++;
		}
		k++;
		emit_v( &v0[i] );
	}
	zzglEnd();
}

/* the counting-sort bucket: groups 0 and 1 by texture (order within a texture stays ref_gl's);
   group 2 (the overlays) in ONE bucket with DECALQ=1, so the stable sort leaves them in the order
   they were recorded, or by texture like the others with DECALQ=2 */
static unsigned bucket_of( const glq_batch_t *b )
{
	unsigned t = ( b->tex == GLQ_TEX_NONE ? GLQ_NTEX : b->tex );
	if( b->group >= 2u ) return 2u * ( GLQ_NTEX + 1u ) + ( g_decal_group >= 2 ? t : 0u );
	return b->group * ( GLQ_NTEX + 1u ) + t;
}

/* build 84, F2B=1: the opaque group's textures replayed from the nearest to the farthest.
   Within the group every texture's batches are one run of g_order (the counting sort above), and
   the final picture of opaque depth-tested draws does not depend on their order, so the runs can
   be put in any order: here by the mean view distance of their vertices.  What it can buy: a
   fragment drawn behind one already there is rejected by the depth test instead of being textured
   and written.  Whether RasterIX charges less for a rejected pixel is what GPUBENCH=1 measures;
   until the A4000 says so this is an option.  The number of binds does not change. */
static void f2b_order( void )
{
	static unsigned short run_first[GLQ_NTEX + 1u], run_len[GLQ_NTEX + 1u], run_idx[GLQ_NTEX + 1u], tmp[GLQ_MAX_BATCH];
	static float run_key[GLQ_NTEX + 1u];
	unsigned i = 0u, n0, nr = 0u, k;
	for( n0 = 0u; n0 < g_nb && g_b[g_order[n0]].group == 0u; n0++ ) ;
	while( i < n0 )
	{
		unsigned tex = g_b[g_order[i]].tex, j = i, cnt = 0u;
		float sum = 0.0f;
		while( j < n0 && g_b[g_order[j]].tex == tex ) { sum += g_bsum[g_order[j]]; cnt += g_b[g_order[j]].count; j++; }
		run_first[nr] = (unsigned short)i; run_len[nr] = (unsigned short)( j - i ); run_key[nr] = cnt ? sum / (float)cnt : 0.0f;
		run_idx[nr] = (unsigned short)nr; nr++;
		i = j;
	}
	if( nr < 2u ) return;
	for( i = 1u; i < nr; i++ )                       /* insertion sort, stable: a few dozen runs */
	{
		unsigned short r = run_idx[i];
		int j = (int)i - 1;
		while( j >= 0 && run_key[run_idx[j]] > run_key[r] ) { run_idx[j + 1] = run_idx[j]; j--; }
		run_idx[j + 1] = r;
	}
	for( i = 0u, k = 0u; i < nr; i++ )
	{
		memcpy( &tmp[k], &g_order[run_first[run_idx[i]]], run_len[run_idx[i]] * sizeof( tmp[0] ));
		k += run_len[run_idx[i]];
	}
	memcpy( g_order, tmp, n0 * sizeof( tmp[0] ));
}
void glq_set_f2b( int on ) { if( g_nb ) glq_flush( GLQ_WHY_STATE ); g_f2b = on ? 1 : 0; }
int  glq_f2b( void ) { return g_f2b; }
/* build 84, EARLY=1: the world replayed as soon as ref_gl has walked it (R_DrawWorld returns:
   its surfaces, their lightmap pass, their decals and the sky are all recorded by then) instead
   of at the first order-dependent draw of the entities.  Regime A of docs/PERF.md 15.1: on the
   heavy outdoor frames the GPU sat with nothing queued for up to 12-14 ms while Core1 walked the
   entities.  The picture is the engine's own: world first, then the entities, is ref_gl's order.
   The price is the textures the world shares with brush entities or models, bound twice. */
/* build 89, EARLY=2: the program chooses, frame by frame.  A4000, 16/11, EARLY=1 gives
   0,9 ms back on c2a5f and 1,9 ms on c1a1b (Core1 no longer waits for the GPU at all) and COSTS
   1,9 ms on c1a1d, where the GPU has no idle time to fill (5 more binds, waits moved to the end).
   What tells the two cases apart is measured every frame already: the time the GPU spent idle
   with nothing queued (rix_frame_starved_take) - 5,2 and 20,9 ms a frame on the first two, 0 on
   the third.  So: early replay while that time, smoothed over a few frames, is 2 ms or more;
   not below 1 ms; between the two, as the frame before (no flapping).  Either way the picture is
   the same one: only the moment the world is handed to the GPU changes. */
#define GLQ_EARLY_ON_US   2000u
#define GLQ_EARLY_OFF_US  1000u
static int g_early_now;
static unsigned g_early_avg;
void glq_set_early( int mode ) { g_early = mode == 2 ? 2 : mode ? 1 : 0; g_early_now = 0; g_early_avg = 0u; }
int  glq_early( void ) { return g_early; }
/* EARLY=2: the GPU's idle time with nothing queued during the frame that just ended, in us */
void glq_early_feed( unsigned starved_us )
{
	g_early_avg = ( 3u * g_early_avg + starved_us ) / 4u;
	if( g_early_avg >= GLQ_EARLY_ON_US ) g_early_now = 1;
	else if( g_early_avg < GLQ_EARLY_OFF_US ) g_early_now = 0;
}
int  glq_early_now( void ) { return g_early == 1 || ( g_early == 2 && g_early_now ); }
void zzhl_world_done( void ) { if( glq_early_now() && g_nb && !g_in_begin ) glq_flush( GLQ_WHY_EARLY ); }

void glq_flush( int why )
{
	static unsigned short count[3u * ( GLQ_NTEX + 1u )];
	unsigned i, nbk = g_decal_group >= 2 ? 3u * ( GLQ_NTEX + 1u ) : 2u * ( GLQ_NTEX + 1u ) + 1u, acc, cur_key = 0xFFFFu, cur_tex = GLQ_TEX_NONE, cur_mat = 0xFFFFu;
	unsigned cur_grp, cur_org = 0xFFu, entph, wo = 0u;
	unsigned long long t0, tg, to;
	float mv[16], pr[16];
	if( g_in_begin && g_rec ) return;                /* never inside a recorded batch */
	if( !g_nb ) { g_nv = 0u; g_nkeys = 0u; g_nmats = 0u; g_nidx = 0u; return; }
	if( why >= 0 && why < GLQ_WHY_COUNT ) { st.flushes[why]++; zzhl_fx[ZFX_FLUSH_FRAME + why]++; }
	if( why != GLQ_WHY_FRAME ) zzhl_fx[ZFX_MID_BATCHES] += g_nb;
	zzhl_gpu_phase( 2u );                           /* RIX_PH_REPLAY */
	entph = zzhl_entphase_swap( ZZ_ENTPH_REPLAY );   /* the replay is nobody's phase but its own */
	t0 = zzhl_us64();
	/* order: group, then texture, stable (counting sort: the order within a texture is ref_gl's) */
	memset( count, 0, nbk * sizeof( count[0] ));
	for( i = 0; i < g_nb; i++ ) count[bucket_of( &g_b[i] )]++;
	for( i = 0, acc = 0u; i < nbk; i++ ) { unsigned c = count[i]; count[i] = (unsigned short)acc; acc += c; }
	for( i = 0; i < g_nb; i++ ) g_order[count[bucket_of( &g_b[i] )]++] = (unsigned short)i;
	if( g_f2b ) f2b_order();
	/* the engine's current matrices, restored after */
	zzglGetFloatv( ZGL_MODELVIEW_MATRIX, mv );
	zzglGetFloatv( ZGL_PROJECTION_MATRIX, pr );
	/* the replay walks the groups in order (0, 1, 2), so one timestamp at each boundary
	   gives the time each group costs; binds and vertices are counted as they go */
	cur_grp = 0xFFu; tg = to = t0;
	for( i = 0; i < g_nb; i++ )
	{
		const glq_batch_t *b = &g_b[g_order[i]];
		unsigned grp = b->group > 2u ? 2u : b->group;
		if( grp != cur_grp )
		{
			unsigned long long now = zzhl_us64();
			if( cur_grp < 3u ) st.grp_us[cur_grp] += (unsigned)( now - tg );
			tg = now; cur_grp = grp;
		}
		if( b->org != cur_org )
		{   /* ZZGL counts what follows under the batch's own origin, and so does the clock */
			if( g_fxtime )
			{
				unsigned long long now = zzhl_us64();
				if( cur_org < (unsigned)ZORG_COUNT )
				{
					zzhl_fx[ZFX_ORG( cur_org, ZFXO_US )] += (unsigned)( now - to );
					zzhl_fx[ZFX_ORG( cur_org, ZFXO_WAIT_US )] += waits_since( wo );
				}
				to = now; wo = zzhl_gpu_wait_us();
			}
			cur_org = b->org < (unsigned)ZORG_COUNT ? b->org : (unsigned)ZORG_OTHER;
			zzgl_origin_set( cur_org );
		}
		st.grp_batches[grp]++; st.grp_verts[grp] += b->count;
		if( b->mat != cur_mat )
		{
			zzglMatrixMode( ZGL_PROJECTION ); zzglLoadMatrixf( g_mats[b->mat].pr );
			zzglMatrixMode( ZGL_MODELVIEW ); zzglLoadMatrixf( g_mats[b->mat].mv );
			cur_mat = b->mat;
		}
		if( b->key != cur_key ) { apply_key( &g_keys[b->key] ); cur_key = b->key; }
		if( b->tex != cur_tex ) { if( b->tex != GLQ_TEX_NONE ) { bind_for_draw( b->tex, 1 ); st.grp_binds[grp]++; } cur_tex = b->tex; }
		emit_batch( b );
	}
	if( cur_grp < 3u ) st.grp_us[cur_grp] += (unsigned)( zzhl_us64() - tg );
	if( g_fxtime && cur_org < (unsigned)ZORG_COUNT )
	{
		zzhl_fx[ZFX_ORG( cur_org, ZFXO_US )] += (unsigned)( zzhl_us64() - to );
		zzhl_fx[ZFX_ORG( cur_org, ZFXO_WAIT_US )] += waits_since( wo );
	}
	/* back to what ref_gl set last */
	zzglMatrixMode( ZGL_PROJECTION ); zzglLoadMatrixf( pr );
	zzglMatrixMode( ZGL_MODELVIEW ); zzglLoadMatrixf( mv );
	zzglMatrixMode( S_matrix_mode );
	apply_key( &S );
	zzglBindTexture( ZGL_TEXTURE_2D, g_tex );
	zzglColor4f( g_col[0], g_col[1], g_col[2], g_col[3] );
	zzglTexCoord2f( g_st[0], g_st[1] );
	g_nb = 0u; g_nv = 0u; g_nkeys = 0u; g_nmats = 0u; g_nidx = 0u;
	g_gen++; if( g_gen == 0u ) g_gen = 1u;
	{ unsigned dt = (unsigned)( zzhl_us64() - t0 ); st.replay_us += dt; zzhl_fx[ZFX_REPLAY_US] += dt; }
	(void)zzhl_entphase_swap( entph );
	zzhl_gpu_phase( 1u );                           /* RIX_PH_REF: back in ref_gl */
}

void glq_frame_end( void )
{
	if( g_nb ) glq_flush( GLQ_WHY_FRAME );
	st.frames++;
	if( g_frame_batches > st.max_batches ) st.max_batches = g_frame_batches;
	if( g_frame_verts > st.max_verts ) st.max_verts = g_frame_verts;
	g_frame_batches = 0u; g_frame_verts = 0u;
	g_frame++; if( g_frame == 0u ) g_frame = 1u;
	g_last_req = GLQ_TEX_NONE;
}
