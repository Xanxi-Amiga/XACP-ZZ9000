/* SOAK and SURVEY modes: load successive Half-Life maps to exercise
 * texture allocation, file access and memory behaviour without gameplay.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include "common.h"
#include "server.h"                        /* sv.model_precache ... */
#include <stdlib.h>

extern int  zzhl_option_int( const char *key, int def );
extern const char *zzhl_option( const char *key );
extern void zzhl_pool_status( unsigned *free_kib, unsigned *largest_kib, unsigned *min_free_kib, int reset_min );
extern unsigned zzhl_heap_used( void );
extern void zzgl_tex_counts( unsigned *uploads, unsigned *downscaled, unsigned *refused, unsigned *evicted );
extern unsigned zzgl_live_textures( void );
extern int  xacp_fs_survey_active( void );                                               /* build 43 */
extern void xacp_fs_survey_map_end( int ch, unsigned *items, unsigned *bytes );
extern int  xacp_fs_survey_write( int ch, const char *title, const char *maps, unsigned *items, unsigned *bytes );
extern void xacp_fs_survey_common( unsigned *items, unsigned *bytes );
extern void xacp_fs_set_disk_saves( int on );
extern void xacp_fs_survey_add( const char *path );                                      /* build 44 */
extern void xacp_fs_survey_add_bsp_textures( const char *bsp );
extern int  xacp_chapter_count( void );
extern const char *xacp_chapter_title( int c );
extern int  xacp_chapter_of( const char *map );

#define SOAK_MAX_MAPS 256
#define SOAK_NAME     32
static int    g_soak = -1;                 /* -1 not decided yet, 0 off, 1 running */
static char   g_maps[SOAK_MAX_MAPS][SOAK_NAME];
static unsigned char g_bad[SOAK_MAX_MAPS];
static int    g_nmaps, g_next, g_cur = -1, g_state, g_stay, g_problems;
static double g_t_issue, g_t_active, g_t_start, g_load_s;
static unsigned g_up0, g_ds0, g_rf0;
#define SV_CH 21                           /* the chapters and "none" */
static int    g_survey;
static unsigned char g_ch_present[SV_CH], g_ch_done[SV_CH], g_ch_written[SV_CH];
static char   g_ch_maps[SV_CH][160];
static unsigned g_sv_bytes;

static void soak_counters( unsigned *up, unsigned *ds, unsigned *rf );
static int is_campaign( const char *n )
{
	if( n[0] == 'c' && n[1] >= '0' && n[1] <= '9' && n[2] == 'a' && n[3] >= '0' && n[3] <= '9' ) return 1;
	if( !strncmp( n, "t0a0", 4 )) return 1;
	/* Uplink.  SURVEY=1 walks what this function accepts, so without it the three
	   hldemo maps are never surveyed and the chapter above stays without a list. */
	return !strncmp( n, "hldemo", 6 );
}
static int cmp_name( const void *a, const void *b ) { return strcmp((const char *)a, (const char *)b ); }

static void soak_init( void )
{
	search_t *t;
	int i, k;
	const char *from = zzhl_option( "SOAKFROM" );
	g_survey = xacp_fs_survey_active();
	g_soak = ( zzhl_option_int( "SOAK", 0 ) || g_survey ) ? 1 : 0;
	if( !g_soak ) return;
	g_stay = zzhl_option_int( "SOAKTIME", g_survey ? 2 : 6 );
	if( g_stay < 1 ) g_stay = 1;
	t = FS_Search( "maps/*.bsp", true, false );
	for( i = 0; t && i < t->numfilenames && g_nmaps < SOAK_MAX_MAPS; i++ )
	{
		const char *f = t->filenames[i], *b = strrchr( f, '/' );
		char n[SOAK_NAME];
		b = b ? b + 1 : f;
		Q_strncpy( n, b, sizeof( n ));
		for( k = 0; n[k]; k++ ) if( n[k] >= 'A' && n[k] <= 'Z' ) n[k] = (char)( n[k] + 32 );
		k = Q_strlen( n );
		if( k > 4 && !Q_strcmp( n + k - 4, ".bsp" )) n[k - 4] = 0;
		if( !is_campaign( n )) continue;
		for( k = 0; k < g_nmaps; k++ ) if( !Q_strcmp( g_maps[k], n )) break;
		if( k == g_nmaps ) Q_strncpy( g_maps[g_nmaps++], n, SOAK_NAME );
	}
	if( t ) Mem_Free( t );
	qsort( g_maps, (size_t)g_nmaps, SOAK_NAME, cmp_name );
	if( g_survey )
	{   /* which chapters, how many of their maps are here */
		for( i = 0; i < g_nmaps; i++ )
		{
			int c = xacp_chapter_of( g_maps[i] );
			if( c < 0 || c >= SV_CH - 1 ) c = SV_CH - 1;
			g_ch_present[c]++;
			if( Q_strlen( g_ch_maps[c] ) + Q_strlen( g_maps[i] ) + 2 < sizeof( g_ch_maps[c] )) { if( g_ch_maps[c][0] ) Q_strncat( g_ch_maps[c], " ", sizeof( g_ch_maps[c] )); Q_strncat( g_ch_maps[c], g_maps[i], sizeof( g_ch_maps[c] )); }
		}
		xacp_fs_set_disk_saves( 0 );
		Con_Printf( "SURVEY: the files of the paks each map opens, by chapter, to data/zzhl_chNN.lst; saves stay in memory\n" );
	}
	g_next = 0;
	if( from && from[0] ) while( g_next < g_nmaps && Q_strcmp( g_maps[g_next], from ) < 0 ) g_next++;
	Con_Printf( "SOAK: %d campaign maps, from %s, %d s each once in the game\n", g_nmaps, g_next < g_nmaps ? g_maps[g_next] : "-", g_stay );
	{   /* the map of the command line (xacp_main.c makes it SOAKFROM) is loading: it counts as the first */
		const char *m = zzhl_option( "MAP" );
		if( from && from[0] ) m = from;
		if( !m || !m[0] ) m = "c0a0";
		if( g_next < g_nmaps && !Q_stricmp( g_maps[g_next], m )) { g_cur = g_next++; soak_counters( &g_up0, &g_ds0, &g_rf0 ); zzhl_pool_status( NULL, NULL, NULL, 1 ); }
	}
	g_t_start = g_t_issue = Sys_DoubleTime();
	g_state = 0;
}

static void soak_counters( unsigned *up, unsigned *ds, unsigned *rf )
{
	unsigned ev;
	zzgl_tex_counts( up, ds, rf, &ev );
}

/* the map surveyed joins its chapter; the chapter's list when its maps are all done */
static void survey_write( int c )
{
	unsigned it, by;
	int ok = xacp_fs_survey_write( c, xacp_chapter_title( c ), g_ch_maps[c], &it, &by );
	if( !ok ) ok = xacp_fs_survey_write( c, xacp_chapter_title( c ), g_ch_maps[c], &it, &by );   /* once more (ch01 of 11/11: the 68k missed it) */
	g_ch_written[c] = (unsigned char)ok;
	Con_Printf( "SURVEY chapter %02d %s: %d of %d maps, %u files and textures, %.1f MiB -> %s\n", c, xacp_chapter_title( c ), g_ch_done[c], g_ch_present[c], it, by / 1048576.0,
		ok ? va( "data/zzhl_ch%02d.lst", c ) : "NOT WRITTEN" );
}
static void survey_map_end( void )
{
	unsigned it, by;
	int c;
	if( !g_survey || g_cur < 0 ) return;
	c = xacp_chapter_of( g_maps[g_cur] );
	if( c < 0 || c >= SV_CH - 1 ) c = SV_CH - 1;
	{   /* what the map needs, opened again or kept by the engine from the map before */
		int i;
		for( i = 1; i < MAX_MODELS; i++ ) if( sv.model_precache[i][0] ) xacp_fs_survey_add( sv.model_precache[i] );
		for( i = 1; i < MAX_SOUNDS; i++ )
		{
			const char *n = sv.sound_precache[i];
			if( !n[0] || n[0] == '!' ) continue;
			while( *n == '*' ) n++;
			xacp_fs_survey_add( va( "sound/%s", n ));
		}
		for( i = 0; i < MAX_CUSTOM; i++ ) if( sv.files_precache[i][0] ) xacp_fs_survey_add( sv.files_precache[i] );
		for( i = 1; i < MAX_EVENTS; i++ ) if( sv.event_precache[i][0] ) xacp_fs_survey_add( sv.event_precache[i] );
		xacp_fs_survey_add_bsp_textures( va( "maps/%s.bsp", g_maps[g_cur] ));
	}
	xacp_fs_survey_map_end( c, &it, &by );
	g_sv_bytes += by;
	g_ch_done[c]++;
	Con_Printf( "SURVEY %s (%s): %u files and textures opened, %.1f MiB\n", g_maps[g_cur], xacp_chapter_title( c ), it, by / 1048576.0 );
	if( g_ch_done[c] >= g_ch_present[c] && !g_ch_written[c] ) survey_write( c );
}
static void soak_issue_next( double now )
{
	if( g_cur >= 0 ) survey_map_end();                          /* build 43 */
	if( g_next >= g_nmaps )
	{
		int i;
		if( g_survey )
		{   /* the chapters not complete (a map missing), then the common part */
			unsigned it, by;
			for( i = 0; i < SV_CH; i++ ) if( g_ch_done[i] && !g_ch_written[i] ) survey_write( i );   /* incomplete, or not written the first time */
			xacp_fs_survey_common( &it, &by );
			Con_Printf( "SURVEY done: %d maps; common to every chapter %u files and textures, %.1f MiB\n", g_nmaps, it, by / 1048576.0 );
		}
		Con_Printf( "SOAK done: %d maps in %.0f s, %d with a problem%s\n", g_nmaps, now - g_t_start, g_problems, g_problems ? ":" : "" );
		for( i = 0; i < g_nmaps; i++ ) if( g_bad[i] )
			Con_Printf( "SOAK problem: %s (%s%s%s)\n", g_maps[i], ( g_bad[i] & 1 ) ? "did not load " : "", ( g_bad[i] & 2 ) ? "textures reduced " : "", ( g_bad[i] & 4 ) ? "textures REFUSED" : "" );
		Cbuf_AddText( "quit\n" );
		g_soak = 0;
		return;
	}
	g_cur = g_next++;
	soak_counters( &g_up0, &g_ds0, &g_rf0 );
	zzhl_pool_status( NULL, NULL, NULL, 1 );
	Con_Printf( "SOAK %d/%d %s: loading\n", g_cur + 1, g_nmaps, g_maps[g_cur] );
	Cbuf_AddText( va( "map %s\n", g_maps[g_cur] ));
	g_t_issue = now;
	g_state = 1;                              /* wait for the client to leave the game, then to come back */
}

void xacp_soak_frame( void )
{
	double now;
	if( g_soak < 0 ) soak_init();
	if( !g_soak ) return;
	now = Sys_DoubleTime();
	switch( g_state )
	{
	case 1:                                   /* "map" issued: the old level goes first */
		if( !CL_Active() || now - g_t_issue > 15.0 ) g_state = 0;
		return;
	case 0:                                   /* loading: until the client is in the game */
		if( CL_Active())
		{
			g_load_s = now - g_t_issue;
			g_t_active = now;
			g_state = 2;
			return;
		}
		if( now - g_t_issue > 150.0 )
		{
			if( g_cur >= 0 ) { g_bad[g_cur] |= 1; g_problems++; Con_Printf( "SOAK %d/%d %s: NOT in the game after 150 s\n", g_cur + 1, g_nmaps, g_maps[g_cur] ); }
			soak_issue_next( now );
		}
		return;
	default:                                  /* in the game: stay, report, next */
		if( now - g_t_active < (double)g_stay ) return;
		if( g_cur >= 0 )
		{
			unsigned up, ds, rf, fk, lk, mk;
			soak_counters( &up, &ds, &rf );
			zzhl_pool_status( &fk, &lk, &mk, 0 );
			Con_Printf( "SOAK %d/%d %s: in the game after %.1f s, %u uploads (reduced %u, refused %u), pool free %u KiB (min %u, largest %u), %u live textures, heap %u KiB\n",
				g_cur + 1, g_nmaps, g_maps[g_cur], g_load_s, up - g_up0, ds - g_ds0, rf - g_rf0, fk, mk, lk, zzgl_live_textures(), zzhl_heap_used() / 1024u );
			if( ds != g_ds0 || rf != g_rf0 )
			{
				if( !g_bad[g_cur] ) g_problems++;
				if( ds != g_ds0 ) g_bad[g_cur] |= 2;
				if( rf != g_rf0 ) g_bad[g_cur] |= 4;
			}
		}
		soak_issue_next( now );
		return;
	}
}
