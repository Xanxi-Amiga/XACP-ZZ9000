/* SPDX-License-Identifier: GPL-3.0-or-later */
/* RasterIX descriptor self-tests against known scalar results.
 * Tests reject invalid or divergent descriptor output.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include "rixdesc.h"
#include "rixclip.h"
#include "rixdesc_golden.h"

/* the comparison is run twice, once with the NEON paths and once with rix_neon = 0, so
   the answer no longer depends only on a table generated on another machine: it also says, on this
   Amiga, whether NEON and the scalar reference agree bit for bit on the same inputs. */
extern int rix_neon;

unsigned zzhl_rixdesc_check( unsigned *tris_refused )
{
	unsigned bad = 0, refused = 0, i, j;
	const int fit_was = rix_box_fit;      /* the table was made without BOXFIT */
	rix_box_fit = 0;
	for( i = 0; i < RIXDESC_GOLDEN_TRIS; i++ )
	{
		rix_vertex v[3];
		u32 d[RIX_TRI_DESC_WORDS];
		for( j = 0; j < 3u; j++ )
		{
			const float *s = rixdesc_golden_v[i][j];
			v[j].sx = s[0]; v[j].sy = s[1]; v[j].z = s[2]; v[j].invw = s[3];
			v[j].u  = s[4]; v[j].v  = s[5];
			v[j].r  = s[6]; v[j].g  = s[7]; v[j].b  = s[8]; v[j].a = s[9];
		}
		{
			u32 e[RIX_TRI_DESC_WORDS];
			int was = rix_neon, ok1, ok2;
			for( j = 0; j < RIX_TRI_DESC_WORDS; j++ ) d[j] = e[j] = 0xDEADBEEFu;
			rix_neon = 1; ok1 = rix_tri_desc( &v[0], &v[1], &v[2], d );
			rix_neon = 0; ok2 = rix_tri_desc( &v[0], &v[1], &v[2], e );
			rix_neon = was;
			if( !ok1 || !ok2 ) { refused++; continue; }
			for( j = 0; j < RIX_TRI_DESC_WORDS; j++ )
			{
				if( d[j] != rixdesc_golden_w[i][j] ) bad++;        /* NEON against the PC table */
				else if( e[j] != rixdesc_golden_w[i][j] ) bad++;   /* scalar against the PC table */
			}
		}
	}
	rix_box_fit = fit_was;
	if( tris_refused ) *tris_refused = refused;
	return bad;
}

/* BOXFIT on this Amiga.  The same triangles with rix_box_fit = 1 and 2, by the NEON path
   and by the scalar one.
     returned: the words on which NEON and scalar differ (must be 0);
     *vs_table: in mode 1, the words that differ from the table other than the END of the box
                (must be 0: mode 1 only brings bbEnd.y down), plus a box end that grew or whose x
                changed;
     *cut: the triangles whose box mode 2 made smaller or dropped (says the code ran).
   The counters of the frame are put back as they were. */
unsigned zzhl_rixfit_check( unsigned *vs_table, unsigned *cut )
{
	unsigned bad = 0, badt = 0, ncut = 0, i, j;
	const int fit_was = rix_box_fit, neon_was = rix_neon;
	const u32 l_was = rix_box_fit_lines, d_was = rix_box_fit_dropped;
	int mode;
	for( mode = 1; mode <= 2; mode++ )
	{
		for( i = 0; i < RIXDESC_GOLDEN_TRIS; i++ )
		{
			rix_vertex v[3];
			u32 d[RIX_TRI_DESC_WORDS], e[RIX_TRI_DESC_WORDS];
			int ok1, ok2;
			for( j = 0; j < 3u; j++ )
			{
				const float *s = rixdesc_golden_v[i][j];
				v[j].sx = s[0]; v[j].sy = s[1]; v[j].z = s[2]; v[j].invw = s[3];
				v[j].u  = s[4]; v[j].v  = s[5];
				v[j].r  = s[6]; v[j].g  = s[7]; v[j].b  = s[8]; v[j].a = s[9];
			}
			for( j = 0; j < RIX_TRI_DESC_WORDS; j++ ) d[j] = e[j] = 0xDEADBEEFu;
			rix_box_fit = mode;
			rix_neon = 1; ok1 = rix_tri_desc( &v[0], &v[1], &v[2], d );
			rix_neon = 0; ok2 = rix_tri_desc( &v[0], &v[1], &v[2], e );
			if( !ok1 != !ok2 ) { bad += RIX_TRI_DESC_WORDS; continue; }
			if( !ok1 ) { if( mode == 2 ) ncut++; continue; }             /* no pixel in its box: not sent, by both */
			for( j = 0; j < RIX_TRI_DESC_WORDS; j++ ) if( d[j] != e[j] ) bad++;
			if( mode == 1 )
			{
				const u32 g2 = rixdesc_golden_w[i][2];
				for( j = 0; j < RIX_TRI_DESC_WORDS; j++ ) if( j != 2u && e[j] != rixdesc_golden_w[i][j] ) badt++;
				if(( e[2] & 0xFFFFu ) != ( g2 & 0xFFFFu ) || ( e[2] >> 16 ) > ( g2 >> 16 )) badt++;
			}
			else if( e[1] != rixdesc_golden_w[i][1] || e[2] != rixdesc_golden_w[i][2] ) ncut++;
		}
	}
	rix_box_fit = fit_was; rix_neon = neon_was;
	rix_box_fit_lines = l_was; rix_box_fit_dropped = d_was;
	if( vs_table ) *vs_table = badt;
	if( cut ) *cut = ncut;
	return bad;
}

/* rix_project, the same way */
unsigned zzhl_rixproj_check( void )
{
	rix_viewport vp;
	rix_clipvert cv[RIXPROJ_GOLDEN_N];
	rix_vertex pv[RIXPROJ_GOLDEN_N];
	unsigned bad = 0, i, w;
	vp.scale_x = rixproj_golden_vp[0]; vp.trans_x = rixproj_golden_vp[1];
	vp.scale_y = rixproj_golden_vp[2]; vp.trans_y = rixproj_golden_vp[3];
	vp.scale_z = rixproj_golden_vp[4]; vp.trans_z = rixproj_golden_vp[5];
	for( i = 0; i < RIXPROJ_GOLDEN_N; i++ )
	{
		const float *s = rixproj_golden_in[i];
		cv[i].x = s[0]; cv[i].y = s[1]; cv[i].z = s[2]; cv[i].w = s[3];
		cv[i].u = s[4]; cv[i].v = s[5];
		cv[i].r = s[6]; cv[i].g = s[7]; cv[i].b = s[8]; cv[i].a = s[9];
	}
	{
		rix_vertex sv[RIXPROJ_GOLDEN_N];
		int was = rix_neon;
		rix_neon = 1; rix_project( cv, (u32)RIXPROJ_GOLDEN_N, &vp, pv );
		rix_neon = 0; rix_project( cv, (u32)RIXPROJ_GOLDEN_N, &vp, sv );
		rix_neon = was;
		for( i = 0; i < RIXPROJ_GOLDEN_N; i++ )
		{
			const u32 *q = (const u32 *)&pv[i], *r = (const u32 *)&sv[i];
			for( w = 0; w < 10u; w++ )
			{
				if( q[w] != rixproj_golden_out[i][w] ) bad++;
				else if( r[w] != rixproj_golden_out[i][w] ) bad++;
			}
		}
	}
	return bad;
}
