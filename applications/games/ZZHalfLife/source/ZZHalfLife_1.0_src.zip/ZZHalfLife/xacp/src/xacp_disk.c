/* Timed wrappers around Core1-to-Amiga file service calls.
 * Records request sizes and latency for loading and gameplay diagnostics.
 */
#include <stdio.h>
#include <string.h>
#include "xacp_rt.h"

extern const zzhl_rt_t *zzhl_rt;
extern unsigned long long zzhl_us64( void );
extern int xacp_loading_in_play( void );             /* xacp_loading.c */
extern const char *xacp_loading_mapname( void );     /* xacp_loading.c */
extern const char *xacp_fs_pak_entry( const char *flat, unsigned off );   /* xacp_fs.c */

enum { K_READ = 0, K_WRITE, K_STAT, K_READAT, K_N };
static const char *const g_kname[K_N] = { "READ", "WRITE", "STAT", "READAT" };

typedef struct { unsigned n; unsigned long long us, bytes; } dk_sum_t;
typedef struct { unsigned t_ms; unsigned char kind; char name[52]; unsigned off, bytes, us; } dk_ev_t;
typedef struct { char name[52]; unsigned char kind; unsigned n; unsigned long long us, bytes; } dk_name_t;

#define DK_EVENTS 64
#define DK_NAMES  48

static const zzhl_rt_t *g_orig;
static zzhl_rt_t g_rt;
static struct { FILE *f; char name[52]; } g_wf[8];   /* files open for writing: their WRITE is at fclose */

static dk_sum_t g_all[K_N], g_play[K_N], g_seg[K_N];
static unsigned long long g_t0, g_load_t0, g_play_t0, g_play_time, g_play_max_us;
static unsigned g_loads, g_was_play, g_play_others;
static dk_ev_t g_ev[DK_EVENTS];
static unsigned g_ev_n;
static dk_name_t g_nm[2][DK_NAMES];               /* [0] the loads, [1] the game */
static unsigned g_nm_n[2];
static dk_sum_t g_nm_rest[2];                      /* requests of names past the table */

static void copy_name( char *d, const char *s, unsigned cap )
{
	unsigned i = 0;
	if( !s ) s = "?";
	while( s[i] && i + 1 < cap ) { d[i] = s[i]; i++; }
	d[i] = 0;
}
static void by_name( int play, int kind, const char *name, unsigned long long us, unsigned bytes )
{
	unsigned i;
	dk_name_t *t = g_nm[play];
	for( i = 0; i < g_nm_n[play]; i++ )
		if( t[i].kind == kind && !strncmp( t[i].name, name, sizeof( t[i].name ) - 1 )) break;
	if( i == g_nm_n[play] )
	{
		if( i == DK_NAMES ) { g_nm_rest[play].n++; g_nm_rest[play].us += us; g_nm_rest[play].bytes += bytes; return; }
		memset( &t[i], 0, sizeof( t[i] ));
		copy_name( t[i].name, name, sizeof( t[i].name ));
		t[i].kind = (unsigned char)kind;
		g_nm_n[play]++;
	}
	t[i].n++; t[i].us += us; t[i].bytes += bytes;
}
/* the game hides: a load starts (from xacp_disk_frame, or from a request - the server's
   part of a change of map starts inside a frame of the game) */
static void to_load( unsigned long long now )
{
	g_play_time += now - g_play_t0;
	g_load_t0 = now;
	memcpy( g_seg, g_all, sizeof( g_seg ));
	g_was_play = 0;
}
static void note( int kind, const char *name, unsigned off, unsigned bytes, unsigned long long t0 )
{
	unsigned long long t1 = zzhl_us64(), us = t1 - t0;
	int play = xacp_loading_in_play() ? 1 : 0;
	char full[52];
	const char *key = name;
	if( !play && g_was_play ) to_load( t0 );
	g_all[kind].n++; g_all[kind].us += us; g_all[kind].bytes += bytes;
	if( play && kind == K_READAT )
	{   /* the file inside the pak, when the pak's directory is known */
		const char *e = xacp_fs_pak_entry( name, off );
		if( e ) { snprintf( full, sizeof( full ), "%s %s", name, e ); key = full; }
	}
	by_name( play, kind, key, us, bytes );
	if( !play ) return;
	g_play[kind].n++; g_play[kind].us += us; g_play[kind].bytes += bytes;
	if( us > g_play_max_us ) g_play_max_us = us;
	if( g_ev_n < DK_EVENTS )
	{
		dk_ev_t *e = &g_ev[g_ev_n++];
		e->t_ms = (unsigned)(( t0 - g_t0 ) / 1000u);
		e->kind = (unsigned char)kind;
		copy_name( e->name, key, sizeof( e->name ));
		e->off = off; e->bytes = bytes; e->us = (unsigned)us;
	}
	else g_play_others++;
}

static FILE *w_fopen( const char *p, const char *m )
{
	unsigned long long t0 = zzhl_us64();
	FILE *f = g_orig->fopen( p, m );
	long len = 0;
	int i;
	if( m && ( m[0] == 'w' || m[0] == 'a' ))
	{   /* nothing asked to the 68k yet: the WRITE goes at fclose */
		if( f ) for( i = 0; i < 8; i++ ) if( !g_wf[i].f ) { g_wf[i].f = f; copy_name( g_wf[i].name, p, sizeof( g_wf[i].name )); break; }
		return f;
	}
	if( f && g_orig->ftell && g_orig->fseek )
	{
		long here = g_orig->ftell( f );
		if( g_orig->fseek( f, 0, SEEK_END ) == 0 ) len = g_orig->ftell( f );
		g_orig->fseek( f, here, SEEK_SET );
	}
	note( K_READ, p, 0, len > 0 ? (unsigned)len : 0u, t0 );
	return f;
}
static int w_fclose( FILE *f )
{
	int i, r;
	for( i = 0; i < 8; i++ )
		if( f && g_wf[i].f == f )
		{
			unsigned long long t0 = zzhl_us64();
			long n = g_orig->ftell ? g_orig->ftell( f ) : 0;
			char name[52];
			copy_name( name, g_wf[i].name, sizeof( name ));
			g_wf[i].f = NULL;
			r = g_orig->fclose( f );
			note( K_WRITE, name, 0, n > 0 ? (unsigned)n : 0u, t0 );
			return r;
		}
	return g_orig->fclose( f );     /* a file read: its slot freed, no request */
}
static int w_file_time( const char *p )
{
	unsigned long long t0 = zzhl_us64();
	int r = g_orig->file_time( p );
	note( K_STAT, p, 0, 0, t0 );
	return r;
}
static int w_read_at( const char *name, unsigned off, void *dst, unsigned len, unsigned *total )
{
	unsigned long long t0 = zzhl_us64();
	int got = g_orig->read_at( name, off, dst, len, total );
	note( K_READAT, name, off, got > 0 ? (unsigned)got : 0u, t0 );
	return got;
}

/* zzhl_core_entry: the runtime with the four calls timed; the others unchanged */
const zzhl_rt_t *xacp_disk_wrap( const zzhl_rt_t *rt )
{
	if( !rt ) return rt;
	g_orig = rt;
	g_rt = *rt;
	if( rt->fopen ) g_rt.fopen = w_fopen;
	if( rt->fclose ) g_rt.fclose = w_fclose;
	if( rt->file_time ) g_rt.file_time = w_file_time;
	if( rt->read_at ) g_rt.read_at = w_read_at;
	g_t0 = g_load_t0 = zzhl_us64();
	return &g_rt;
}

/* Core1/zzhl_gpu.c (the slow frames, build 39): every request now, not the READATs only */
void zzhl_fs_io_totals( unsigned *n, unsigned *bytes, unsigned *us )
{
	unsigned k, a = 0; unsigned long long b = 0, u = 0;
	for( k = 0; k < K_N; k++ ) { a += g_all[k].n; b += g_all[k].bytes; u += g_all[k].us; }
	*n = a; *bytes = (unsigned)b; *us = (unsigned)u;
}

static void tenths( char *out, unsigned cap, unsigned long long us )
{
	unsigned long long t = ( us + 50000u ) / 100000u;
	snprintf( out, cap, "%u.%u", (unsigned)( t / 10u ), (unsigned)( t % 10u ));
}
/* once a frame (Platform_RunEvents, xacp_input.c): a load ends when the game shows again */
void xacp_disk_frame( void )
{
	int p;
	unsigned long long now;
	if( !g_orig ) return;
	p = xacp_loading_in_play() ? 1 : 0;
	if( p == (int)g_was_play ) return;
	now = zzhl_us64();
	if( p )
	{
		unsigned k, n = 0, pct;
		unsigned long long us = 0, len = now - g_load_t0;
		char a[16], b[16], line[300], part[4][48];
		for( k = 0; k < K_N; k++ ) { n += g_all[k].n - g_seg[k].n; us += g_all[k].us - g_seg[k].us; }
		for( k = 0; k < K_N; k++ )
		{
			unsigned kn = g_all[k].n - g_seg[k].n;
			unsigned kms = (unsigned)(( g_all[k].us - g_seg[k].us ) / 1000u);
			if( k == K_READAT ) snprintf( part[k], sizeof( part[k] ), "READAT %u, %u KiB, %u ms", kn, (unsigned)(( g_all[k].bytes - g_seg[k].bytes ) / 1024u ), kms );
			else snprintf( part[k], sizeof( part[k] ), "%s %u, %u ms", g_kname[k], kn, kms );
		}
		pct = len ? (unsigned)( us * 100u / len ) : 0u;
		tenths( a, sizeof( a ), len ); tenths( b, sizeof( b ), us );
		g_loads++;
		snprintf( line, sizeof( line ), "ZZHalfLife: load %u (%s): %s s, of which the disk %s s (%u %%) in %u requests: %s; %s; %s; %s",
			g_loads, xacp_loading_mapname(), a, b, pct, n, part[K_READAT], part[K_READ], part[K_STAT], part[K_WRITE] );
		printf( "%s\n", line );
		g_play_t0 = now;
	}
	else to_load( now );
	g_was_play = (unsigned)p;
}

static void top_names( int play, const char *title )
{
	unsigned i, j, shown = 0;
	unsigned char done[DK_NAMES];
	memset( done, 0, sizeof( done ));
	printf( "ZZHalfLife: %s, by file (the 10 slowest in total; %u names, %u requests past the table):\n", title, g_nm_n[play], g_nm_rest[play].n );
	while( shown < 10u )
	{
		int best = -1;
		for( i = 0; i < g_nm_n[play]; i++ )
			if( !done[i] && ( best < 0 || g_nm[play][i].us > g_nm[play][best].us )) best = (int)i;
		if( best < 0 ) break;
		done[best] = 1;
		j = (unsigned)best;
		printf( "  %c %-6s %s: %u requests, %u KiB, %u ms\n", (char)( 'a' + shown ), g_kname[g_nm[play][j].kind], g_nm[play][j].name,
			g_nm[play][j].n, (unsigned)( g_nm[play][j].bytes / 1024u ), (unsigned)( g_nm[play][j].us / 1000u ));
		shown++;
	}
}
/* the end of the run (xacp_main.c) */
void xacp_disk_report( void )
{
	unsigned k, n = 0, pn = 0, i;
	unsigned long long us = 0, pus = 0, pbytes = 0, now = zzhl_us64(), play = g_play_time;
	char a[16], b[16], c[16];
	if( !g_orig ) return;
	if( g_was_play ) play += now - g_play_t0;
	for( k = 0; k < K_N; k++ ) { n += g_all[k].n; us += g_all[k].us; pn += g_play[k].n; pus += g_play[k].us; pbytes += g_play[k].bytes; }
	tenths( a, sizeof( a ), us );
	printf( "ZZHalfLife: disk, every request to the 68k: %u in %s s (READAT %u, %u KiB, %u ms; READ %u, %u KiB, %u ms; STAT %u, %u ms; WRITE %u, %u KiB, %u ms)\n",
		n, a, g_all[K_READAT].n, (unsigned)( g_all[K_READAT].bytes / 1024u ), (unsigned)( g_all[K_READAT].us / 1000u ),
		g_all[K_READ].n, (unsigned)( g_all[K_READ].bytes / 1024u ), (unsigned)( g_all[K_READ].us / 1000u ),
		g_all[K_STAT].n, (unsigned)( g_all[K_STAT].us / 1000u ),
		g_all[K_WRITE].n, (unsigned)( g_all[K_WRITE].bytes / 1024u ), (unsigned)( g_all[K_WRITE].us / 1000u ));
	tenths( b, sizeof( b ), play ); tenths( c, sizeof( c ), pus );
	printf( "ZZHalfLife: disk during the game (%s s of game shown, %u loads): %u requests, %u KiB, %s s, the longest %u ms (READAT %u, READ %u, STAT %u, WRITE %u)\n",
		b, g_loads, pn, (unsigned)( pbytes / 1024u ), c, (unsigned)( g_play_max_us / 1000u ),
		g_play[K_READAT].n, g_play[K_READ].n, g_play[K_STAT].n, g_play[K_WRITE].n );
	for( i = 0; i < g_ev_n; i++ )
	{   /* two letters of its own: the console mirror folds lines that differ only by digits */
		const dk_ev_t *e = &g_ev[i];
		char t[16];
		tenths( t, sizeof( t ), (unsigned long long)e->t_ms * 1000u );
		printf( "  %c%c t %s s: %-6s %s at %u, %u bytes, %u ms\n", (char)( 'a' + i / 26u ), (char)( 'a' + i % 26u ), t, g_kname[e->kind], e->name, e->off, e->bytes, e->us / 1000u );
	}
	if( g_play_others ) printf( "  (and %u requests after these %u)\n", g_play_others, DK_EVENTS );
	top_names( 0, "disk during the loads" );
	top_names( 1, "disk during the game" );
}
#ifdef ZZHL_HOST_TEST
/* tests/test_xacp_fs.c: the i-th request of the game kept, its kind (0 READ, 1 WRITE, 2 STAT, 3 READAT) */
const char *xacp_disk_test_event( unsigned i, unsigned *kind, unsigned *bytes )
{
	if( i >= g_ev_n ) return NULL;
	*kind = g_ev[i].kind; *bytes = g_ev[i].bytes;
	return g_ev[i].name;
}
unsigned xacp_disk_test_loads( void ) { return g_loads; }
#endif
