/* xacp_snd.c - ZZHalfLife: Xash3D sound output on the ZZQuake PCM ring (XASH_SOUND == 4).
 *
 * The 68k launcher runs an AHI process (zzq_ahi.c, ZZQuake/ZZQuake2/ZZOpenLara) that pulls
 * interleaved signed 16-bit STEREO frames, little-endian, 22050 Hz, from a 64 KiB ring in the
 * non-cacheable shared section (ZZQ_PCM_ARM): Core1 appends and publishes SH_PCM_WRITE_POS,
 * the 68k consumes and publishes SH_PCM_READ_POS, both in bytes.  The launcher sets
 * SH_PCM_ENABLE (0 with NOSOUND) and SH_PCM_RATE before Core1 starts.  Same protocol as the
 * release's snd_zz9000.c (Quake I); the AHI side is whatever the user's unit 0 is (Paula,
 * ZZ9000AX, a sound card).
 *
 * Xash3D mixes at SOUND_DMA_SPEED = 44100 Hz (fixed in engine/client/sound.h: every loaded
 * sound is resampled to it) into a DMA-style buffer that this backend owns; the engine asks
 * for the hardware position (snd.samplepos) to know how far it may paint ahead.  This backend
 * therefore: keeps a 32768-frame 44.1 kHz buffer, halves it to 22050 Hz (average of each pair
 * of frames) when copying to the ring, and derives samplepos from what the 68k has consumed.
 * Lead kept in the ring: ZZQ_PCM_TARGET_FILL (16 KiB = 4096 frames = 186 ms), as the release.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include "common.h"
#if XASH_SOUND == 4
#include "sound.h"
#include "xacp_rt.h"
#include "zzquake_config.h"

extern const zzhl_rt_t *zzhl_rt;

/* 44.1 kHz stereo frames in the paint buffer (power of two).  32768, not 8192: the engine's
 * S_GetSoundtime() detects buffer wraps by "samplepos went backwards" between two S_Update
 * calls, so the position must never advance by a whole buffer between calls.  With the 8192
 * buffer of builds 7-8 one wrap was exactly the 16 KiB of ring lead: an engine stall over
 * ~90 ms (a sound file read, a level change) let the 68k take two 8 KiB pulls, samplepos came
 * back to the same value, the wrap went uncounted and the mixer's idea of the played position
 * fell one buffer behind for good - from then on it painted nothing new (silence after
 * the first stall, 81 % of the AHI pulls empty).  Four times the lead makes a missed wrap
 * impossible: the ring never holds more than 16 KiB, so the 68k cannot consume half a buffer
 * between two calls. */
#define XSND_FRAMES      32768u
#define XSND_RING        ZZQ_PCM_RING_SIZE      /* bytes */
#define XSND_FILL        ZZQ_PCM_TARGET_FILL    /* bytes of lead kept in the ring */
#define XSND_RATE        22050u

static short    g_buf[XSND_FRAMES * 2];
static unsigned g_copied;          /* 44.1 kHz frames already pushed to the ring (monotonic) */
static unsigned g_wpos;            /* ring write position, bytes */
static unsigned g_last_rd;         /* last SH_PCM_READ_POS seen */
static unsigned g_consumed;        /* ring bytes consumed by the 68k (monotonic) */
static unsigned g_pushed_frames, g_submits, g_full;
static const char g_name[] = "XACP PCM ring -> AHI (22050 Hz stereo)";

static void xsnd_update_pos( void )
{
	volatile unsigned *sh = zzhl_rt->shared;
	unsigned rd = sh[SH_PCM_READ_POS] % XSND_RING;
	unsigned delta = ( rd >= g_last_rd ) ? ( rd - g_last_rd ) : ( XSND_RING - g_last_rd + rd );
	g_last_rd = rd;
	g_consumed += delta;
	/* ring frames consumed * 2 = 44.1 kHz frames played; samplepos counts mono samples */
	snd.samplepos = (int)((( g_consumed / 4u ) * 2u * 2u ) % ( XSND_FRAMES * 2u ));
}

qboolean SNDDMA_Init( void )
{
	volatile unsigned *sh = zzhl_rt->shared;
	if( !sh[SH_PCM_ENABLE] )
	{
		Con_Printf( "Audio: the launcher has sound off (NOSOUND)\n" );
		return false;
	}
	if( sh[SH_PCM_RATE] != XSND_RATE || ( sh[SH_PCM_SIZE_SLOT] && sh[SH_PCM_SIZE_SLOT] != XSND_RING ))
	{
		Con_Printf( "Audio: launcher PCM ring %u Hz / %u bytes not supported (expected %u / %u)\n",
			sh[SH_PCM_RATE], sh[SH_PCM_SIZE_SLOT], XSND_RATE, (unsigned)XSND_RING );
		return false;
	}
	memset( g_buf, 0, sizeof( g_buf ));
	g_copied = 0; g_wpos = 0; g_consumed = 0; g_pushed_frames = g_submits = g_full = 0;
	g_last_rd = sh[SH_PCM_READ_POS] % XSND_RING;
	/* start writing where the 68k reads: an empty ring */
	g_wpos = g_last_rd;
	sh[SH_PCM_WRITE_POS] = g_wpos;

	snd.format.speed    = SOUND_DMA_SPEED;
	snd.format.channels = 2;
	snd.format.width    = 2;
	snd.samples         = (int)( XSND_FRAMES * 2u );
	snd.buffer          = (byte *)g_buf;
	snd.samplepos       = 0;
	snd.initialized     = true;
	snd.backend_name    = g_name;
	Con_Printf( "Audio: %s, mixed at %d Hz, %u frames of lead\n", g_name, SOUND_DMA_SPEED, (unsigned)( XSND_FILL / 4u ));
	return true;
}

/* what the mix costs.  The engine calls SNDDMA_BeginPainting, paints, then calls
   SNDDMA_Submit (S_UpdateChannels, engine/client/sound/s_main.c), once after the frame and again
   from inside the rendering (CL_ExtraUpdate), so the time between the two calls is the mix
   wherever it runs.  It goes to the frame's counters (zzhl_fx.h): until now it was hidden in
   "engine" and in whichever rendering phase called it. */
#include "zzhl_fx.h"
extern unsigned long long zzhl_us64( void );
static unsigned long long g_paint_t0;
static int g_painting;
void SNDDMA_BeginPainting( void )
{
	xsnd_update_pos();
	g_paint_t0 = zzhl_us64(); g_painting = 1;
}
static void paint_done( void )
{
	if( !g_painting ) return;
	zzhl_fx[ZFX_SND_US] += (unsigned)( zzhl_us64() - g_paint_t0 );
	zzhl_fx[ZFX_SND_MIXES]++;
	g_painting = 0;
}

extern void zzhl_l2_sync( void );      /* Core1/zzhl_present.c (PL310 Cache Sync) */
static void snd_submit( void );
void SNDDMA_Submit( void ) { snd_submit(); paint_done(); }
static void snd_submit( void )
{
	volatile unsigned *sh = zzhl_rt->shared;
	volatile unsigned *ring = (volatile unsigned *)ZZQ_PCM_ARM;
	unsigned painted = (unsigned)snd.paintedtime, rd, used, room, n, nring, i;

	if( !snd.initialized || !sh[SH_PCM_ENABLE] ) return;
	g_submits++;
	xsnd_update_pos();
	if( painted <= g_copied ) return;

	rd = g_last_rd;
	used = ( g_wpos >= rd ) ? ( g_wpos - rd ) : ( XSND_RING - rd + g_wpos );
	if( used >= XSND_FILL ) { g_full++; return; }
	room = ( XSND_FILL - used ) / 4u;              /* ring frames */

	n = painted - g_copied;                         /* 44.1 kHz frames available */
	nring = n / 2u;
	if( nring > room ) nring = room;
	for( i = 0; i < nring; i++ )
	{
		unsigned f0 = ( g_copied + 2u * i ) & ( XSND_FRAMES - 1u ), f1 = ( f0 + 1u ) & ( XSND_FRAMES - 1u );
		int l = ( (int)g_buf[f0 * 2u] + (int)g_buf[f1 * 2u] ) >> 1;
		int r = ( (int)g_buf[f0 * 2u + 1u] + (int)g_buf[f1 * 2u + 1u] ) >> 1;
		ring[g_wpos >> 2] = ((unsigned)l & 0xFFFFu ) | (((unsigned)r & 0xFFFFu ) << 16 );   /* L lo, L hi, R lo, R hi */
		g_wpos += 4u;
		if( g_wpos >= XSND_RING ) g_wpos = 0;
	}
	g_copied += nring * 2u;
	g_pushed_frames += nring;
	zzhl_l2_sync();                        /* the samples in DDR before the position the 68k reads */
	sh[SH_PCM_WRITE_POS] = g_wpos;
	zzhl_l2_sync();                        /* and the position itself, at once (it waited in the PL310's store buffer) */
}

void SNDDMA_Shutdown( void )
{
	Con_Printf( "Audio: shutting down (%u submits, %u ring frames, %u times full, %u underruns seen by the 68k)\n",
		g_submits, g_pushed_frames, g_full, zzhl_rt->shared[SH_PCM_UNDERRUNS] );
	snd.initialized = false;
	snd.buffer = NULL;
	zzhl_rt->shared[SH_PCM_ENABLE] = 0;     /* as the release's SNDDMA_Shutdown */
}

void S_Activate( qboolean active ) { (void)active; }
qboolean VoiceCapture_Init( void ) { return false; }
qboolean VoiceCapture_Activate( qboolean activate ) { (void)activate; return false; }
qboolean VoiceCapture_Lock( qboolean lock ) { (void)lock; return false; }
void VoiceCapture_Shutdown( void ) { }
#endif
