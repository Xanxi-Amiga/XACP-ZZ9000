/* xacp_video.c - ZZHalfLife: engine/platform video entry points (the role of
 * engine/platform/dos/vid_dos.c): one screen, the one the launcher opened (640x480 or
 * 320x240, 16 or 32 bits), drawn by RasterIX through Core1/zzhl_gpu.c, ZZGL and librixgpu.
 *   R_Init_Video     opens the GPU (zz_rix_open: MMU attributes, librixgpu ladder, ring, pool,
 *                    ZZGL) and declares the mode to the engine
 *   GL_GetProcAddress  the GL name table of xacp_gl.c (ZZGL)
 *   GL_SwapBuffers   ends the GPU frame, waits for its fence, presents it (zzq2_present_rgb565)
 *                    and opens the next target; also drains the key queue and the launcher's
 *                    stop command, since the engine has no other per-frame platform hook
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include "common.h"
#include "client.h"
#include "vid_common.h"
#include "platform/platform.h"
#include "xacp_rt.h"
#include "zzq2_res.h"
#include "xacp_glq.h"

extern const zzhl_rt_t *zzhl_rt;
extern void *zzhl_gl_proc( const char *name );
extern int  zz_rix_open( int w, int h, char *why, int why_cap );
extern void zz_rix_begin_frame( void );
extern void zz_rix_end_frame( void );
extern void zz_rix_console_report( void (*out)( const char *line ));
extern void zz_rix_set_alpha_textures( int on );
extern int  zz_rix_alpha_ok( void );
extern int  zz_rix_alpha4444_ok( void );
extern int  zz_rix_textest( char *report, int cap );
extern void zz_rix_perf_report( char *out, int cap );
extern void zz_rix_set_ring( int mode );
extern void zzgl_set_deferred( int on );
extern void zzgl_set_alpha4444( int on );
extern void zzgl_set_tex_versioning( int on );
extern void zz_rix_set_overlap( int on );
extern void zz_rix_set_pipeline( int on );
extern int  zz_rix_present_dma_test( int want, char *line, int cap );   /* build 35 */
extern void zz_rix_set_engine_pump( int on );                            /* build 35 */
extern void rix_frame_set_idle_watch( int on );
extern void zzhl_gpu_pump( void );
extern void zzgl_set_clear_flush( int on );
extern void zzgl_set_oom_cb( void (*cb)( void ));                        /* build 54 */
extern void zzgl_set_profile( int on );                                  /* build 58 */
extern unsigned zzhl_rixdesc_check( unsigned *refused );                 /* build 59, xacp_rixcheck.c */
extern unsigned zzhl_rixproj_check( void );                              /* build 60 */
extern int rix_neon;                                                     /* NEON=0|1 */
extern unsigned zzgl_oom_calls( void );
extern void Mod_FreeUnused( void );                                      /* engine/common/model.c */
extern void rix_frame_set_pump_interval( unsigned n );
extern void zz_rix_set_timedemo( int on, int regseq );
extern void xacp_gl_frame_end( void );
static void pool_watch( void );            /* build 20, below */
static void zzhl_pool_oom( void );         /* build 54, below */
static void scanout_line( int at_exit );   /* build 30, below */
extern void zzhl_scanout_status( unsigned *samples, unsigned *bad, unsigned first[3], unsigned badv[3], unsigned *pitch );
extern void xacp_gl_set_picmip( int n );
extern int  zzhl_option_int( const char *key, int def );
extern void zz_rix_bind_costs( unsigned *us64, unsigned *us256, unsigned *fifo_words );

static qboolean g_gpu_open;
static vidmode_t g_mode = { "640 x 480", 640, 480 };
static unsigned g_frames;

static void con_line( const char *line ) { Con_Printf( "%s\n", line ); }
/* a report of several lines, one Con_Printf a line (the text is left as it was) */
static void print_lines( const char *text )
{
	const char *l = text, *e;
	char one[512];
	while( *l )
	{
		size_t n;
		e = strchr( l, '\n' );
		n = e ? (size_t)( e - l ) : strlen( l );
		if( n > sizeof( one ) - 1 ) n = sizeof( one ) - 1;
		memcpy( one, l, n ); one[n] = 0;
		Con_Printf( "%s\n", one );
		if( !e ) break;
		l = e + 1;
	}
}
/* the GPU's price list (GPUBENCH=1), kept to be printed again with the exit report: it
   is printed at start-up, and the mirror only keeps the last 256 KiB of a run */
static char g_pricelist[8192];

void Platform_SetStatus( const char *status ) { }
qboolean Platform_DebuggerPresent( void ) { return false; }

static qboolean XACP_OpenGPU( void )
{
	char why[96];
	if( g_gpu_open ) return true;
	why[0] = 0;
	{   /* RING=1 (default, 32 slots of 16 KiB as before), 2 = 64 x 8 KiB, 3 = 128 x 4 KiB,
	       0 = 8 x 64 KiB, always in the same 512 KiB.  A chunk closes at every bind (rule 11) and
	       filled only 14 % of a 16 KiB slot on c2a5f, 21 % on c1a3b, for 85 to 187 chunks a frame:
	       Core1 waited 11,4 to 11,7 ms a frame for a free slot (pumping the queue meanwhile) while
	       the GPU was idle with nothing queued 5,6 to 7,8 ms.  Deeper rings carry more work across
	       the phases where Core1 produces nothing, but they also make Core1 pump less often: which
	       wins cannot be told from the host model (tests/test_rixframe_pipe.c: no difference on its
	       stream), so the default stays where it is until the A4000 says otherwise. */
		int ring = zzhl_option_int( "RING", 1 );
		zz_rix_set_ring( ring );
		Con_Printf( "ZZHalfLife: RING=%d (%s)\n", ring,
			ring == 3 ? "128 slots of 4 KiB" : ring == 2 ? "64 slots of 8 KiB" :
			ring == 1 ? "32 slots of 16 KiB, as build 54" : "8 slots of 64 KiB" );
	}
	if( !zz_rix_open( ZZHL_VID_W, ZZHL_VID_H, why, (int)sizeof( why )))
	{
		Con_Printf( S_ERROR "RasterIX could not open %dx%d: %s\n", ZZHL_VID_W, ZZHL_VID_H, why );
		return false;
	}
	g_gpu_open = true;
	Con_Printf( "ZZHalfLife: RasterIX %dx%d open (ZZGL 0.8.10, librixgpu 1.4.2)\n", ZZHL_VID_W, ZZHL_VID_H );
	zz_rix_console_report( con_line );
	{   /* PRESENTDMA=1 (default) the picture goes to the P96 buffer by the PL330 (Core1/zzhl_present.c) */
		char l[200];
		zz_rix_present_dma_test( zzhl_option_int( "PRESENTDMA", 1 ), l, (int)sizeof( l ));
		Con_Printf( "%s\n", l );
	}
	{   /* texel self-test once, as ZZQuake2RIX, then alpha-keyed textures as RGBA5551 when it passed */
		static char rep[4096];
		int ok = zz_rix_textest( rep, (int)sizeof( rep ));
		int a4444 = zz_rix_alpha4444_ok() > 0 && zzhl_option_int( "A4444", 1 );
		Con_Printf( "ZZHalfLife: RasterIX texel test %s\n", ok ? "ALL OK" : "MISMATCHES" );
		{   /* the alpha lines of the report (the cases themselves stay in rep) */
			char *line = rep, *nl;
			while( line && *line )
			{
				nl = strchr( line, '\n' );
				if( nl ) *nl = 0;
				if( strstr( line, "alpha" ) || strstr( line, "RGBA" )) Con_Printf( "  %s\n", line );
				line = nl ? nl + 1 : NULL;
			}
		}
		zz_rix_set_alpha_textures( zz_rix_alpha_ok() > 0 );
		/* textures with alpha levels (decals) as RGBA4444 when the hardware case passed; A4444=0 keeps RGBA5551 */
		zzgl_set_alpha4444( a4444 );
		Con_Printf( "ZZHalfLife: gradient alpha (decals, soft sprites) as %s\n", a4444 ? "RGBA4444" : "RGBA5551 (one bit)" );
	}
	{   /* ZCLEAR=1, the depth buffer cleared by the PL330 instead of the GPU, on two
		   buffers (xacp/include/zzhl_zclear.h).  Off by default.  Asked for, it is used only if
		   the self-test passes on this machine (Core1/zzhl_gpu.c, zz_rix_zclear_test); its line
		   says which.  BOXPX=1: the pixels of the triangles' bounding boxes are counted too, by
		   origin (a dozen compares per triangle: for one measurement run, not for comparing
		   periods). */
		extern int  zz_rix_zclear_test( int want, char *out, int cap );
		extern void zz_rix_set_boxpx( int on );
		static char zl[720];
		int boxpx = zzhl_option_int( "BOXPX", 0 );
		zz_rix_zclear_test( zzhl_option_int( "ZCLEAR", 1 ), zl, (int)sizeof( zl ));   /* on by default (A4000, 15/11, docs/PERF.md 21) */
		print_lines( zl );
		zz_rix_set_boxpx( boxpx );
		if( boxpx ) Con_Printf( "ZZHalfLife: BOXPX=1, the bounding boxes of the triangles are counted (the periods of this run are not for comparing)\n" );
	}
	{   /* build 87.  BOXFIT=1|2: the triangles' boxes cut to the lines that hold a pixel, so that
		   the rasteriser stops running to the end of a box and back on lines where it draws
		   nothing (librixgpu/rixdesc.c, rix_box_fit; docs/PERF.md 19).  1: the end of the box only,
		   the GPU's output is the same bit for bit.  2: both ends, the same pixels, values equal
		   to float rounding.  Off by default.  WALKSTAT=1: the rasteriser's clocks by origin, by
		   its model - a measurement run, the frame takes about twice as long. */
		extern void zz_rix_set_boxfit( int mode );
		extern void zz_rix_set_walkstat( int on );
		extern void zz_rix_set_reject( int on );
		extern int  zz_rix_reject( void );
		/* Default rendering optimizations are BOXFIT=2, REJECT=1 and ZCLEAR=1. */
		int boxfit = zzhl_option_int( "BOXFIT", 2 ), walkstat = zzhl_option_int( "WALKSTAT", 0 ), reject = zzhl_option_int( "REJECT", 1 );
		zz_rix_set_boxfit( boxfit );
		zz_rix_set_walkstat( walkstat );
		/* REJECT=1: a batch with nothing in view is dropped whole by ZZGL instead of triangle by
		   triangle (zzgl.h, zzgl_set_batch_reject): Core1's time on c1a1b, whose decals were 4120
		   triangles a frame for 303 on the screen (A4000, 15/11).  Off by default. */
		zz_rix_set_reject( reject );
		{   /* its test against a second way of writing it, on this machine */
			extern unsigned zz_rix_reject_check( unsigned *batches, unsigned *outside );
			unsigned nb = 0, no = 0, bad = zz_rix_reject_check( &nb, &no );
			Con_Printf( "ZZHalfLife: REJECT=%d; its test on %u batches (%u outside the view) against a second way of writing it: %u wrong%s\n",
				bad ? 0 : reject ? 1 : 0, nb, no, bad, bad ? "  *** REJECT REFUSED, nothing is dropped ***" : " (identical)" );
		}
		if( reject && zz_rix_reject()) Con_Printf( "ZZHalfLife: REJECT=1, a batch wholly outside the view is dropped at once\n" );
		{   /* build 92, CULLEARLY=1|2 (1 by default since build 98, measured on the A4000 in builds 93 and 97): the models' back faces dropped before the triangle's
			   set-up (Core1/zzhl_gpu.c, zzgl.h).  Its arithmetic is checked on this machine first. */
			extern void zz_rix_set_cull_early( int mode );
			extern unsigned zz_rix_cull_early_check( unsigned *tris, unsigned *culled );
			extern int zz_rix_cull_early( void );
			int ce = zzhl_option_int( "CULLEARLY", 1 );
			extern unsigned zz_rix_cull_early_check_detail( unsigned *nan_two_ways );
			unsigned nt = 0, nc = 0, bad, what, nan2 = 0;
			zz_rix_set_cull_early( ce );
			bad = zz_rix_cull_early_check( &nt, &nc );
			what = zz_rix_cull_early_check_detail( &nan2 );   /* build 93 */
			Con_Printf( "ZZHalfLife: CULLEARLY=%d; its test on %u triangles (%u back faces) against the triangle path's projection and verdict: %u different%s; a NaN spelled two ways on %u (allowed: same verdict); failed tests %u (1 near plane, 2 position, 4 area, 8 verdict)\n",
				zz_rix_cull_early(), nt, nc, bad, bad ? "  *** CULLEARLY REFUSED, nothing changes ***" : " (identical)", nan2, what );
			if( zz_rix_cull_early()) Con_Printf( "ZZHalfLife: CULLEARLY=%d, back faces of %s dropped before their triangle is set up\n", zz_rix_cull_early(), zz_rix_cull_early() == 2 ? "every origin" : "the models and the weapon in hand" );
		}
		{   /* build 92, RECFAST=1 (off by default): a recorded vertex's colour kept in bytes (xacp_glq.c) */
			unsigned bad;
			glq_set_recfast( zzhl_option_int( "RECFAST", 0 ));
			bad = glq_recfast_check();
			Con_Printf( "ZZHalfLife: RECFAST=%d; the 256 byte values of a colour through the division and back: %u changed%s\n",
				glq_recfast(), bad, bad ? "  *** RECFAST REFUSED, nothing changes ***" : " (identical)" );
			if( glq_recfast()) Con_Printf( "ZZHalfLife: RECFAST=1, the colour of a recorded vertex stays in bytes and ZZGL is told nothing until the replay\n" );
		}
		{   /* build 97, MESHIDX=1 (by default since build 98, measured on the A4000 in build 97): the vertices of an indexed triangle list once each (xacp_gl.c) */
			extern void xacp_gl_set_meshidx( int on );
			extern int xacp_gl_meshidx( void );
			xacp_gl_set_meshidx( zzhl_option_int( "MESHIDX", 1 ));
			if( xacp_gl_meshidx()) Con_Printf( "ZZHalfLife: MESHIDX=1, the models' indexed triangle lists go to ZZGL with each vertex once (blocks of 60 vertices at most)\n" );
		}
		glq_set_decal_frust( zzhl_option_int( "DECALFRUST", 0 ));   /* build 96 (xacp_glq.c, build_arm.sh 0d2) */
		if( glq_decal_frust() == 1 ) Con_Printf( "ZZHalfLife: DECALFRUST=1, ref_gl does not emit a decal whose polygon is wholly beyond one plane of its frustum by more than one unit\n" );
		if( glq_decal_frust() == 2 ) Con_Printf( "ZZHalfLife: DECALFRUST=2, a CHECK: every decal is emitted; those ref_gl's test would leave out are compared with their clip coordinates\n" );
		glq_set_water_cull( zzhl_option_int( "WATERCULL", 0 ));     /* build 98 (xacp_glq.c, build_arm.sh 0d3) */
		if( glq_water_cull() == 1 ) Con_Printf( "ZZHalfLife: WATERCULL=1, ref_gl does not emit a water polygon wholly beyond one side of the view (clip coordinates, wave and a margin counted)\n" );
		if( glq_water_cull() == 2 ) Con_Printf( "ZZHalfLife: WATERCULL=2, a CHECK: every water polygon is emitted; those ref_gl's test would leave out are compared with their clip coordinates\n" );
		glq_set_emit_prof( zzhl_option_int( "EMITPROF", 0 ));   /* a measure (xacp_glq.c) */
		if( glq_emit_prof()) Con_Printf( "ZZHalfLife: EMITPROF=1, every recorded GL call is timed (two timer reads each, %u ticks of 3 ns for an empty pair): a MEASURE, the frame times of this run are not to be compared\n", glq_emit_prof_empty());
		{   /* build 94, DECALCULL=1 (by default since build 98, measured on the A4000 in builds 94 and 97): an overlay wholly out of view is dropped at its glEnd,
			   before the queue (xacp_glq.c).  A4000, 17/11, save007: 4 ms a frame go to 577 overlay batches
			   of which nine triangles in ten are thrown away by REJECT after the replay. */
			extern int zz_rix_reject( void );
			unsigned nb = 0, nd = 0, np = 0, bad;
			glq_set_decal_cull( zzhl_option_int( "DECALCULL", 1 ));
			glq_decal_cull_reject_is( zz_rix_reject());
			bad = glq_decal_cull_check( &nb, &nd, &np );
			Con_Printf( "ZZHalfLife: DECALCULL=%d; its test on %u batches: it drops %u, the plain comparisons drop %u, dropped by it alone %u%s\n",
				glq_decal_cull(), nb, nd, np, bad, bad ? "  *** DECALCULL REFUSED, nothing changes ***" : " (never one the plain test keeps)" );
			if( glq_decal_cull()) Con_Printf( "ZZHalfLife: DECALCULL=1, an overlay wholly out of view is dropped at its glEnd, before the queue\n" );
		}
		if( boxfit ) Con_Printf( "ZZHalfLife: BOXFIT=%d, the triangles' boxes are cut to the lines that hold a pixel (%s)\n", boxfit > 1 ? 2 : 1, boxfit > 1 ? "both ends" : "the end of the box only" );
		if( walkstat ) Con_Printf( "ZZHalfLife: WALKSTAT=1, every triangle is walked by the model of the rasteriser: the frames take about twice as long (not for comparing)\n" );
	}
	if( zzhl_option_int( "GPUBENCH", 0 ))
	{   /* GPUBENCH=1, what RasterIX charges for a pixel by drawing mode, for a bind by
		   texture size and for a triangle (Core1/zzhl_gpu.c, zz_rix_gpubench).  Here and nowhere
		   else: the GPU is idle, nothing of the game is uploaded yet, and the submission is still
		   the immediate one the texel test uses.  About 40 hidden frames, a second or two. */
		extern void zz_rix_gpubench( char *out, int cap );
		zz_rix_gpubench( g_pricelist, (int)sizeof( g_pricelist ));
		print_lines( g_pricelist );
	}
	{   /* FREEOLD=1 (default) the previous map's models are released when the pool is full.
	       Mod_PurgeStudioCache marks them NL_FREE_UNUSED when the new world loads, but the engine only
	       frees them with Mod_FreeUnused() at the END of the client's precache (cl_parse.c), so their
	       pages stay in the 16 MiB pool while the whole new map uploads: c2a5e -> c2a5f refused 43
	       textures and reduced 4 (A4000, 13/11).  Called from ZZGL only when an upload does not fit,
	       so a map that fits pays nothing; a model both maps use is read again from the chapter, which
	       is in RAM.  FREEOLD=0 = build 53. */
		int fo = zzhl_option_int( "FREEOLD", 1 );
		zzgl_set_oom_cb( fo ? zzhl_pool_oom : NULL );
		Con_Printf( "ZZHalfLife: FREEOLD=%d (%s)\n", fo ? 1 : 0,
			fo ? "the previous map's models freed when the texture pool is full" : "freed at the end of the precache, as build 53" );
	}
	/* ZZQuake2RIX 0.9.4 defaults: deferred submission, texture versioning, overlap, clear flush */
	zzgl_set_deferred( 1 );
	zzgl_set_tex_versioning( 1 );
	zz_rix_set_overlap( 1 );
	zzgl_set_clear_flush( 1 );
	{   /* build 32 (R1): PIPE=1 (default) frame N+1 begins while the GPU finishes N (Core1/zzhl_gpu.c); PIPE=0 = build 31 */
		int pipe = zzhl_option_int( "PIPE", 1 );
		zz_rix_set_pipeline( pipe );
		rix_frame_set_idle_watch( zzhl_option_int( "GPUIDLE", 1 ));   /* GPU idle measured by the pumps (report: frames by period) */
		Con_Printf( "ZZHalfLife: PIPE=%d (%s)\n", pipe ? 1 : 0, pipe ? "frame N+1 built while the GPU finishes N" : "each frame drained at its end, as build 31" );
		{   /* ENGPUMP=1 (default) the game libraries' hot calls pump the GPU queue (xacp/dll) */
			int ep = zzhl_option_int( "ENGPUMP", 1 );
			zz_rix_set_engine_pump( ep );
			Con_Printf( "ZZHalfLife: ENGPUMP=%d (%s)\n", ep ? 1 : 0, ep ? "the GPU fed during the game logic" : "no pump between frames, as build 34" );
		}
	}
	{
		/* the texture work.  Launch options, forwarded by the 68k wrapper:
		   SORT=1 (default): order-independent batches replayed sorted by texture (xacp_glq.c)
		   PICMIP=n (default 0): mipmapped textures loaded at level n (xacp_gl.c)
		   PUMP=n (default 32): triangles between two pumps of the deferred queue
		   BINDTEST=1|2 (default 0): measurement only, wrong picture: 1 = no 3D binds, 2 = 1-page binds */
		int sort = zzhl_option_int( "SORT", 1 ), picmip = zzhl_option_int( "PICMIP", 0 );
		int pump = zzhl_option_int( "PUMP", 32 ), bindtest = zzhl_option_int( "BINDTEST", 0 );
		int decalbias = zzhl_option_int( "DECALBIAS", 4 );
		int decalq = zzhl_option_int( "DECALQ", 2 );        /* DECALQ defaults to 2. */
		unsigned us64, us256, fifo;
		zz_rix_bind_costs( &us64, &us256, &fifo );
		glq_set_sort( sort );
		glq_set_bindtest( bindtest );
		glq_set_decal_bias( decalbias );
		glq_set_decal_group( decalq );
		{   /* the NEON rix_tri_desc against the words the scalar one produced on the PC
		       (xacp/include/rixdesc_golden.h).  Twelve triangles, 39 words each; must print 0. */
			unsigned refused = 0, bad, badp;
			int neon = zzhl_option_int( "NEON", 1 );
			rix_neon = neon ? 1 : 0;
			bad = zzhl_rixdesc_check( &refused ); badp = zzhl_rixproj_check();
			Con_Printf( "ZZHalfLife: NEON=%d; NEON and the scalar reference against the table: descriptors %u word%s different of %u (%u triangles refused), projection %u of %u%s\n",
				rix_neon, bad, bad == 1u ? "" : "s", (unsigned)( 24u * 39u ), refused, badp, (unsigned)( 24u * 10u ),
				bad || refused || badp ? "  *** THEY DIFFER ***" : " (identical)" );
			if( !neon ) Con_Printf( "ZZHalfLife: NEON=0, everything runs on the scalar paths (slower; for comparing the image)\n" );
			{   /* the same triangles with BOXFIT=1 and 2, NEON against scalar, and mode 1
			       against the table apart from the end of the box (xacp_rixcheck.c) */
				extern unsigned zzhl_rixfit_check( unsigned *vs_table, unsigned *cut );
				extern int zz_rix_boxfit( void );
				extern void zz_rix_set_boxfit( int mode );
				unsigned vst = 0, cut = 0, badf = zzhl_rixfit_check( &vst, &cut );
				Con_Printf( "ZZHalfLife: BOXFIT=%d; modes 1 and 2 on the table's triangles (%u boxes cut by mode 2): NEON against scalar %u words different, mode 1 against the table but for the box end %u%s\n",
					badf || vst ? 0 : zz_rix_boxfit(), cut, badf, vst, badf || vst ? "  *** BOXFIT REFUSED ***" : " (identical)" );
				if( badf || vst ) zz_rix_set_boxfit( 0 );
			}
		}
		{   /* RIXPROF=1 splits zzglEnd into descriptor computation (rix_tri_desc), descriptor
		       writes (rix_frame_tri, 40 words each) and the rest (copy, clamps, near clip, project,
		       cull, screen clip).  zzglEnd costs 2636 ns per incoming triangle, 8,1 ms a frame on
		       c2a5f and 11,5 ms on a heavy one (A4000, 13/11): the split says whether NEON belongs in
		       the arithmetic or whether the cost is the writing, which NEON would not help.
		       It reads the timer twice per descriptor, so it slows the frame it measures: a diagnostic,
		       never a default. */
			int rp = zzhl_option_int( "RIXPROF", 0 );
			zzgl_set_profile( rp );
			if( rp ) Con_Printf( "ZZHalfLife: RIXPROF=1 (zzglEnd split measured; the frame is slower than usual)\n" );
		}
		{   /* LMDEPTH, the depth test of the lightmap pass.  1 = GL_EQUAL as the engine asks
		       (default), 0 = GL_LEQUAL, 2 = GL_ALWAYS (a probe).  See xacp_glq.c: isolated bright
		       pixels along the internal edges of the polygons, present with SORT=0 too. */
			int lmd = zzhl_option_int( "LMDEPTH", 1 );
			glq_set_lm_depth( lmd );
			Con_Printf( "ZZHalfLife: LMDEPTH=%d (%s)\n", lmd,
				lmd == 2 ? "GL_ALWAYS, a probe: the image is wrong, it only says whether the pass covers the pixel" :
				lmd == 0 ? "GL_LEQUAL, tolerant of a rounding difference" : "GL_EQUAL, as the engine asks" );
		}
		{   /* two options for the frame rate work of 17/11, both OFF by default and both
			   meant to leave the picture as it is (xacp_glq.c).  EARLY=1: the world is replayed as soon
			   as ref_gl has walked it, so the GPU works while Core1 walks the entities.  F2B=1: the
			   opaque textures are replayed from the nearest to the farthest. */
			/* EARLY defaults to 2; EARLY=0 selects the older presentation ordering. */
			int early = zzhl_option_int( "EARLY", 2 ), f2b = zzhl_option_int( "F2B", 0 ), sprtrim = zzhl_option_int( "SPRTRIM", 0 );
			extern void xacp_gl_set_sprtrim( int on );
			extern void zz_rix_note_sprtrim( int on );
			glq_set_early( early );
			{   /* build 89, EARLY=2: the choice is made frame by frame on the GPU's idle time (xacp_glq.c) */
				extern void zz_rix_set_starved_hook( void (*fn)( unsigned us ));
				zz_rix_set_starved_hook( early == 2 ? glq_early_feed : 0 );
			}
			glq_set_f2b( f2b );
			glq_set_fxtime( zzhl_option_int( "FXTIME", 1 ));   /* FXTIME=0: no clock reading for Core1's time by origin (the "us" column reads 0) */
			xacp_gl_set_sprtrim( sprtrim );          /* SPRTRIM=1: a sprite's quad reduced to the part of its picture that can show (xacp_gl.c) */
			zz_rix_note_sprtrim( sprtrim );
			Con_Printf( "ZZHalfLife: EARLY=%d (%s), F2B=%d (%s), SPRTRIM=%d (%s)\n",
				early == 2 ? 2 : early ? 1 : 0, early == 2 ? "the world replayed early on the frames that follow a GPU left without work" : early ? "the world replayed at the end of its walk" : "the world replayed at the first order-dependent draw, as build 83",
				f2b ? 1 : 0, f2b ? "opaque textures from the nearest to the farthest" : "opaque textures in texture order, as build 83",
				sprtrim ? 1 : 0, sprtrim ? "sprite quads without their empty margins" : "sprite quads whole, as build 83" );
			{   /* build 90 (xacp_main.c) */
				extern int zzhl_fpsmax( void );
				int cap = zzhl_fpsmax();
				if( cap ) Con_Printf( "ZZHalfLife: FPSMAX=%d (fps_max, the engine's own frame cap, set at every start; the top right counter counts the engine's frames, the launcher's img/s the frames shown)\n", cap );
				else Con_Printf( "ZZHalfLife: FPSMAX=0 (fps_max 0: the engine's frames are not capped; the launcher's img/s counts the frames shown)\n" );
			}
		}
		xacp_gl_set_picmip( picmip );
		rix_frame_set_pump_interval( (unsigned)( pump < 1 ? 1 : pump ));
		Con_Printf( "ZZHalfLife: GL queue SORT=%d PICMIP=%d PUMP=%d BINDTEST=%d DECALBIAS=%d DECALQ=%d\n", sort, picmip, pump, bindtest, decalbias, decalq );
		Con_Printf( "RIX: bind cost measured at init: 64x64 %u us, 256x256 %u us (0 = not measured); FIFO %u words\n",
			us64, us256, fifo );
	}
	zz_rix_begin_frame();
	return true;
}

qboolean R_Init_Video( ref_graphic_apis_t type )
{
	if( type != REF_GL )
	{
		Con_Printf( S_ERROR "ZZHalfLife: only the GL renderer (ref_gl on RasterIX) exists here\n" );
		return false;
	}
	if( !XACP_OpenGPU( )) return false;
	if( !VID_SetMode( )) return false;
	/* as every platform backend (sdl2/vid_sdl2.c R_Init_Video): the ref resolves its pgl*
	   pointers through GL_GetProcAddress here; ref_gl's R_Init then calls GL_SetDefaults,
	   which would jump through NULL pointers without it */
	ref.dllFuncs.GL_InitExtensions();
	host.renderinfo_changed = false;
	return true;
}

void R_Free_Video( void )
{
	/* the GPU context is kept across vid_restart (as ZZQuake2RIX) */
	ref.dllFuncs.GL_ClearExtensions();
}

qboolean VID_SetMode( void )
{
	return R_ChangeDisplaySettings( ZZHL_VID_W, ZZHL_VID_H, WINDOW_MODE_FULLSCREEN ) == rserr_ok;
}

rserr_t R_ChangeDisplaySettings( int width, int height, window_mode_t window_mode )
{
	width = ZZHL_VID_W; height = ZZHL_VID_H;   /* the launcher's screen, nothing else */
	if( !ref.dllFuncs.R_SetDisplayTransform( 0, 0, 0, 1.0f, 1.0f ))
		Con_Printf( S_WARN "failed to setup screen transform\n" );
	R_SaveVideoMode( width, height, width, height, false );
	return rserr_ok;
}

int GL_SetAttribute( int attr, int val ) { return 0; }
int GL_GetAttribute( int attr, int *val )
{
	switch( attr )
	{
	case REF_GL_RED_SIZE: case REF_GL_BLUE_SIZE: *val = 5; return 0;
	case REF_GL_GREEN_SIZE: *val = 6; return 0;
	case REF_GL_ALPHA_SIZE: *val = 0; return 0;
	case REF_GL_DEPTH_SIZE: *val = 16; return 0;
	case REF_GL_STENCIL_SIZE: *val = 0; return 0;
	case REF_GL_MULTISAMPLESAMPLES: *val = 0; return 0;
	case REF_GL_CONTEXT_MAJOR_VERSION: *val = 1; return 0;
	case REF_GL_CONTEXT_MINOR_VERSION: *val = 1; return 0;
	}
	*val = 0;
	return -1;
}
int R_MaxVideoModes( void ) { return 1; }
vidmode_t *R_GetVideoMode( int num ) { return num == 0 ? &g_mode : NULL; }
void *GL_GetProcAddress( const char *name ) { return zzhl_gl_proc( name ); }
void GL_UpdateSwapInterval( void ) { }
ref_window_type_t R_GetWindowHandle( void **handle, ref_window_type_t type ) { return REF_WINDOW_TYPE_NULL; }
void VID_Info_f( void ) { Con_Printf( "ZZHalfLife: %dx%d RasterIX, frames %u\n", ZZHL_VID_W, ZZHL_VID_H, g_frames ); }

void GL_SwapBuffers( void )
{
	if( !g_gpu_open ) return;
	xacp_gl_frame_end();         /* the queue's last flush of the frame */
	pool_watch();
	zz_rix_end_frame();          /* frame fence, present (zzhl_present.c), reports */
	zz_rix_begin_frame();        /* next target */
	zzhl_gpu_pump();             /* the end of this frame, while the engine runs its logic */
	g_frames++;
	{   /* the first scanout sample, once (below) */
		static int said;
		unsigned n, bad, first[3], badv[3], pitch;
		if( !said ) { zzhl_scanout_status( &n, &bad, first, badv, &pitch ); if( n ) { said = 1; scanout_line( 0 ); } }
	}
	if( zzhl_rt->pump( ))        /* the launcher asked to stop (Esc in the shell / timeout) */
	{
		Con_Printf( "ZZHalfLife: stop requested by the launcher\n" );
		Sys_Quit( "launcher stop" );
	}
}

/* software renderer entry points: not built (ref_soft is not part of ZZHalfLife A0) */
void *SW_LockBuffer( void ) { return NULL; }
void SW_UnlockBuffer( void ) { }
qboolean SW_CreateBuffer( int width, int height, uint *stride, uint *bpp, uint *r, uint *g, uint *b ) { return false; }

/* ---- texture pool watch (build 20) ----
 * The 16 MiB of RasterIX texture memory, sampled at the end of every frame that followed uploads;
 * after each burst of 40 uploads or more (a map load) one console line; the minimum free space of
 * the run goes to the exit report.  zzhl_pool_status serves xacp_soak.c. */
extern unsigned rix_texpool_free_pages( void );
extern unsigned rix_texpool_largest_free( void );
extern void zzgl_tex_counts( unsigned *uploads, unsigned *downscaled, unsigned *refused, unsigned *evicted );
extern unsigned zzgl_live_textures( void );
extern unsigned zzgl_sub_dropped( void );
#define POOL_KIB( pages ) ((pages) * 2u)
static unsigned g_pool_min = 0xFFFFFFFFu, g_pool_min_map = 0xFFFFFFFFu, g_pool_last_up, g_pool_burst;
static void pool_sample( void )
{
	unsigned f = rix_texpool_free_pages();
	if( f < g_pool_min ) g_pool_min = f;
	if( f < g_pool_min_map ) g_pool_min_map = f;
}
void zzhl_pool_status( unsigned *free_kib, unsigned *largest_kib, unsigned *min_free_kib, int reset_min )
{
	unsigned f = rix_texpool_free_pages();
	if( reset_min ) { g_pool_min_map = f; return; }
	if( f < g_pool_min_map ) g_pool_min_map = f;
	if( free_kib ) *free_kib = POOL_KIB( f );
	if( largest_kib ) *largest_kib = POOL_KIB( rix_texpool_largest_free());
	if( min_free_kib ) *min_free_kib = POOL_KIB( g_pool_min_map );
}
/* ZZGL could not fit an upload (zzgl_set_oom_cb).  Mod_FreeUnused only frees the models the
   engine has already marked unused, so it is safe at any moment; the guard is for the frees it makes,
   which upload nothing but do call back into ZZGL (zzglDeleteTextures). */
static void zzhl_pool_oom( void )
{
	static int busy;
	if( busy ) return;
	busy = 1;
	Mod_FreeUnused();
	busy = 0;
}

static void pool_watch( void )
{
	unsigned up, ds, rf, ev;
	zzgl_tex_counts( &up, &ds, &rf, &ev );
	if( up != g_pool_last_up ) { g_pool_burst += up - g_pool_last_up; g_pool_last_up = up; pool_sample(); return; }
	if( g_pool_burst >= 40u )
	{
		unsigned f = rix_texpool_free_pages();
		pool_sample();
		Con_Printf( "RIX pool after a load: %u textures, %u KiB free of 16384 (largest block %u KiB); since the start %u uploads reduced, %u refused\n",
			zzgl_live_textures(), POOL_KIB( f ), POOL_KIB( rix_texpool_largest_free()), ds, rf );
	}
	g_pool_burst = 0u;
}

/* the scanout line geometry (Core1/zzhl_present.c samples it every 32 frames) */
extern void zzhl_scanout_status( unsigned *samples, unsigned *bad, unsigned first[3], unsigned badv[3], unsigned *pitch );
static void scanout_line( int at_exit )
{
	unsigned n, bad, first[3], badv[3], pitch;
	zzhl_scanout_status( &n, &bad, first, badv, &pitch );
	if( !n ) { if( at_exit ) Con_Printf( "scanout: not sampled\n" ); return; }
	if( !at_exit )
		Con_Printf( "scanout: VDMA line %u bytes, %u lines, stride %u (screen pitch %u, %u lines): %s\n",
			first[0], first[1], first[2], pitch, ZZHL_VID_H,
			( first[0] == pitch && first[1] == ZZHL_VID_H && first[2] == pitch ) ? "ok" : "*** MISMATCH, the picture is wrong (pan width X2 of the ZZ9000 stale?)" );
	else if( !bad )
		Con_Printf( "scanout: %u samples, all ok (stride %u = pitch)\n", n, pitch );
	else
		Con_Printf( "scanout: %u samples, *** %u wrong, first wrong: line %u bytes, %u lines, stride %u (pitch %u, %u lines)\n",
			n, bad, badv[0], badv[1], badv[2], pitch, ZZHL_VID_H );
}

void zzhl_video_report( void )
{
	static char rep[16384];         /* 4096 -> 8192 (frames by period); 16384, the report grew */
	const glq_stats_t *q = glq_stats();
	unsigned f;
	scanout_line( 1 );
	if( !g_gpu_open ) return;
	if( g_pricelist[0] ) print_lines( g_pricelist );   /* said again, see above */
	zz_rix_perf_report( rep, (int)sizeof( rep ));
	print_lines( rep );             /* a line at a time (one Con_Printf holds 8192 characters, the report nears 7000) */
	{   /* the load by origin, bucket by bucket */
		extern int zz_rix_fx_report( int b, char *out, int cap );
		int b;
		for( b = 0; zz_rix_fx_report( b, rep, (int)sizeof( rep )); b++ ) print_lines( rep );
	}
	{   /* the frames of 80 ms and more, one line each */
		extern void zz_rix_hitch_report( char *out, int cap );
		char *l, *e;
		zz_rix_hitch_report( rep, (int)sizeof( rep ));
		for( l = rep; *l; l = e + 1 ) { e = strchr( l, '\n' ); if( !e ) { Con_Printf( "%s\n", l ); break; } *e = 0; Con_Printf( "%s\n", l ); }
	}
	f = q->frames ? q->frames : 1u;
	Con_Printf( "GL queue (xacp_glq.c), per frame over %u frames, SORT=%d:\n", q->frames, glq_sort_on());
	Con_Printf( "  binds as ref_gl issued them   %u (3D %u, 2D %u): %u distinct textures, %u re-binds of a texture already used in the frame\n",
		q->binds_req / f, q->binds_3d / f, q->binds_2d / f, q->distinct / f, q->rebinds / f );
	Con_Printf( "  binds sent after the queue    %u, streaming %u KiB of texels\n", q->binds_done / f, q->bind_kib / f );
	Con_Printf( "  batches %u, recorded %u (%u vertices), replay %u us; peak %u batches / %u vertices in a frame\n",
		q->batches / f, q->batches_recorded / f, q->verts_recorded / f, q->replay_us / f, q->max_batches, q->max_verts );
	if( glq_emit_prof())
	{   /* ns per call net of the empty pair, calls and us per frame */
		static const char *const wn[10] = { "glq_begin", "colour call", "texcoord call", "glq_vertex", "glq_end", "pump in glq_end",
			"gap vertex->colour", "gap colour->texcoord", "gap texcoord->vertex", "gap other" };
		int c, w;
		const unsigned e = glq_emit_prof_empty();
		Con_Printf( "  EMITPROF, recorded calls, per frame over %u frames (an empty pair of reads = %u ticks, taken off each; 3 ns a tick):\n", f, e );
		for( c = 0; c < 2; c++ ) for( w = 0; w < 10; w++ )
		{
			unsigned long long tk = 0ull;
			const unsigned n = glq_emit_prof_get( c, w, &tk );
			const unsigned long long net = tk > (unsigned long long)n * e ? tk - (unsigned long long)n * e : 0ull;
			if( !n ) continue;
			Con_Printf( "    %s %-20s %6u a frame, %5u ns each, %6u us a frame\n", c ? "others" : "models", wn[w], n / f, (unsigned)( net * 3ull / n ), (unsigned)( net * 3ull / 1000ull / f ));
		}
	}
	{   /* build 97 */
		extern int xacp_gl_meshidx( void );
		extern void xacp_gl_meshidx_stats( unsigned v[3] );
		unsigned v[3];
		xacp_gl_meshidx_stats( v );
		if( xacp_gl_meshidx()) Con_Printf( "  indexed triangle lists (MESHIDX=1): %u blocks, %u triangles, %u vertices per frame (unrolled: %u vertices)\n", v[0] / f, v[1] / f, v[2] / f, 3u * ( v[1] / f ));
	}
	if( glq_decal_frust())
	{   /* build 96 */
		unsigned v[5];
		glq_decal_frust_stats( v );
		Con_Printf( "  decals and ref_gl's frustum (DECALFRUST=%d): %u looked at, %u out of view per frame%s\n", glq_decal_frust(), v[0] / f, v[1] / f, glq_decal_frust() == 1 ? ", not emitted" : ", emitted all the same (check)" );
		if( glq_decal_frust() == 2 ) Con_Printf( "    check over the run: %u decals called out of view, the clip test disagrees on %u (must be 0), could not check %u\n", v[2], v[3], v[4] );
	}
	{   /* build 94 */
		unsigned dv = 0, db = glq_decal_culled( &dv );
		Con_Printf( "  overlays dropped at their glEnd, out of view (DECALCULL=%d): %u batches, %u vertices per frame\n", glq_decal_cull(), db / f, dv / f );
	}
	{   /* what the overlays are, as ref_gl says it */
		static const char *const sn[GLQ_OV_SRC] = { "water", "decals", "brush entities at rest", "moved brush entities", "the rest" };
		unsigned d[GLQ_OV_SRC], dv[GLQ_OV_SRC], k[GLQ_OV_SRC], kv[GLQ_OV_SRC], w[8], i;
		glq_overlay_src_stats( d, dv, k, kv ); glq_water_stats( w );
		Con_Printf( "  overlays by source, per frame (batches/vertices):\n" );
		for( i = 0; i < GLQ_OV_SRC; i++ )
			Con_Printf( "    %-24s dropped out of view %5u /%6u   recorded %5u /%6u\n", sn[i], d[i] / f, dv[i] / f, k[i] / f, kv[i] / f );
		Con_Printf( "  water polygons (WATERCULL=%d): %u looked at, %u tested, %u wholly out of view per frame%s\n", glq_water_cull(), w[0] / f, w[2] / f, w[1] / f,
			glq_water_cull() == 1 ? ", not emitted" : glq_water_cull() == 2 ? ", emitted all the same (check)" : " (tested only with the option)" );
		Con_Printf( "    over the run: %u looked at, %u tested, %u out of view; water surfaces drawn by the world %u, by an entity at rest %u, moved %u, rotated %u; highest wave %u.%03u\n",
			w[0], w[2], w[1], w[4], w[5], w[6], w[7], w[3] / 1000u, w[3] % 1000u );
		if( glq_water_cull() == 2 )
		{
			unsigned v[5];
			glq_decal_frust_stats( v );
			Con_Printf( "    check over the run: %u polygons called out of view, the clip test disagrees on %u (must be 0), could not check %u\n", v[2], v[3], v[4] );
		}
	}
	{   /* what each group of the replay costs (0 opaque, 1 the lightmap pass, 2 the biased
	       overlays): the question of the evening is what the decals cost in binds and in time */
		static const char *const gn[3] = { "opaque", "lightmaps", "overlays" };
		int gi;
		for( gi = 0; gi < 3; gi++ )
			Con_Printf( "  replay, %-9s: %u batches, %u binds, %u vertices, %u us per frame\n",
				gn[gi], q->grp_batches[gi] / f, q->grp_binds[gi] / f, q->grp_verts[gi] / f, q->grp_us[gi] / f );
	}
	Con_Printf( "  runs cut at 60 vertices (strips, fans, beams) since the start: %u\n", glq_splits());
	{ extern unsigned zzgl_tex4444_count( void ); Con_Printf( "  decals and overlays depth-biased: %u batches; textures stored as RGBA4444: %u\n", glq_biased(), zzgl_tex4444_count()); }
	{
		unsigned up, ds, rf, ev;
		zzgl_tex_counts( &up, &ds, &rf, &ev );
		Con_Printf( "  texture pool: lowest free %u KiB of 16384; %u uploads, %u stored reduced, %u refused, %u evicted, %u sub-uploads of reduced textures dropped\n",
			g_pool_min == 0xFFFFFFFFu ? 16384u : POOL_KIB( g_pool_min ), up, ds, rf, ev, zzgl_sub_dropped());
		Con_Printf( "  pool full during an upload (FREEOLD, the previous map's models freed): %u times\n", zzgl_oom_calls());
	}
	{ extern unsigned xacp_gl_name_overflows( void ); if( xacp_gl_name_overflows()) Con_Printf( "  *** texture names exhausted %u times (textures shared the overflow name)\n", xacp_gl_name_overflows()); }
	{   /* the GL_INVALID_ENUM ref_gl reports, by call and value (ZZGL 0.8.2) */
		extern int zzgl_bad_enum( unsigned i, const char **fn, unsigned *v, unsigned *n );
		const char *fn; unsigned i, v, n;
		for( i = 0; zzgl_bad_enum( i, &fn, &v, &n ); i++ )
			Con_Printf( "  GL_INVALID_ENUM: %s( 0x%04X ) %u times (not in ZZGL)\n", fn, v, n );
	}
	/* x1000.  The whole division by the frame count printed 0 for anything under one a
	   frame, which is every line that matters; the same numbers are also given
	   per bucket above ("GL queue flushes x1000"). */
#define PER1000( n ) ((unsigned)(((unsigned long long)( n ) * 1000ull ) / f ))
	Con_Printf( "  flushes per frame x1000, every frame of the run: end of frame %u, order-dependent draw %u, texture update %u, clear/scissor/viewport %u, full %u, early %u\n",
		PER1000( q->flushes[GLQ_WHY_FRAME] ), PER1000( q->flushes[GLQ_WHY_STATE] ), PER1000( q->flushes[GLQ_WHY_TEXTURE] ), PER1000( q->flushes[GLQ_WHY_CLEAR] ),
		PER1000( q->flushes[GLQ_WHY_FULL] ), PER1000( q->flushes[GLQ_WHY_EARLY] ));
#undef PER1000
}
