/* Loading-screen renderer for Core1, including level transitions.
 * Draws an RGB565 status image while the 3D renderer is unavailable.
 * Font attribution remains with xacp/include/font8x8_basic.h.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "font8x8_basic.h"

#ifndef ZZHL_HOST_TEST
#include "common.h"
#include "client.h"
#ifndef ZZHL_HOST_TEST
#include "server.h"                 /* sv.state, the server's part of a change of map */
#endif
#include "xacp_rt.h"
#include "zzq2_res.h"
#define LW ZZHL_VID_W
#define LH ZZHL_VID_H
#else
#ifndef LW
#define LW 640
#define LH 480
#endif
#endif

#define C_WHITE  0xFFFFu
#define C_GREY   0x8410u
#define C_DGREY  0x39E7u
#define C_ORANGE 0xFD00u        /* the HUD's orange, 255 160 0 */
#define C_LIGHT  0xDEFBu        /* 222 222 222, a little under the logo's white (235) */

static unsigned short *g_buf, *g_bg;   /* the screen, and its background (black or the game, darkened) */

static void fill( int x, int y, int w, int h, unsigned short c )
{
	int i, j;
	if( x < 0 ) { w += x; x = 0; }
	if( y < 0 ) { h += y; y = 0; }
	if( x + w > LW ) w = LW - x;
	if( y + h > LH ) h = LH - y;
	for( j = 0; j < h; j++ ) for( i = 0; i < w; i++ ) g_buf[( y + j ) * LW + x + i] = c;
}
/* Use the antialiased glyph path for text over the original Half-Life loading artwork. */
#define GL_S_MAX   8                                   /* 8 * s <= 64 */
#define GL_LO      40u                                /* under this: background */
#define GL_HI      150u                               /* over this: solid; between: the edge */
#define GL_PAD_MAX ( GL_S_MAX / 2 )
#define GL_M_MAX   ( 8 * GL_S_MAX + 2 * GL_PAD_MAX )
static unsigned char g_cov[GL_M_MAX * GL_M_MAX], g_cov2[GL_M_MAX * GL_M_MAX];

static unsigned short mix565( unsigned short bg, unsigned short fg, unsigned a )
{   /* a in 0..256, so the blend is a shift and never a division (no hardware divide on A9) */
	unsigned ia = 256u - a;
	unsigned r = ((( bg >> 11 ) & 31u ) * ia + (( fg >> 11 ) & 31u ) * a ) >> 8;
	unsigned g = ((( bg >>  5 ) & 63u ) * ia + (( fg >>  5 ) & 63u ) * a ) >> 8;
	unsigned b = ((  bg         & 31u ) * ia + (  fg         & 31u ) * a ) >> 8;
	return (unsigned short)(( r << 11 ) | ( g << 5 ) | b );
}
static void glyph_soft( int x, int y, int s, unsigned short c, const unsigned char *g )
{
	int n = 8 * s, r = s / 2, m = n + 2 * r, i, j, k;
	unsigned inv;
	if( m > GL_M_MAX ) { r = 0; m = n; }
	for( k = 0; k < m * m; k++ ) g_cov[k] = 0;
	for( j = 0; j < n; j++ )
		for( i = 0; i < n; i++ )
			if( g[j / s] & ( 1u << ( i / s ))) g_cov[( j + r ) * m + i + r] = 255;
	if( r > 0 )
	{   /* separable, two passes; one multiply instead of a divide per pixel */
		inv = 65536u / (unsigned)( 2 * r + 1 );
		for( j = 0; j < m; j++ )
			for( i = 0; i < m; i++ )
			{
				unsigned sum = 0;
				for( k = -r; k <= r; k++ ) { int q = i + k; if( q >= 0 && q < m ) sum += g_cov[j * m + q]; }
				g_cov2[j * m + i] = (unsigned char)(( sum * inv ) >> 16 );
			}
		for( j = 0; j < m; j++ )
			for( i = 0; i < m; i++ )
			{
				unsigned sum = 0, v;
				for( k = -r; k <= r; k++ ) { int q = j + k; if( q >= 0 && q < m ) sum += g_cov2[q * m + i]; }
				v = ( sum * inv ) >> 16;
				/* The blur alone is not enough at s = 2: a stroke of the doubled 8x8 is TWO pixels
				   wide, so no pixel keeps a full neighbourhood and the whole letter comes out grey
				   (first try, 15/11: the test counted zero pixels at the full colour, and it was
				   right to fail).  So the ramp is stretched back: everything under GL_LO is
				   background, everything over GL_HI is solid, and only the edge in between ramps.
				   The core of the stroke is given back, the staircase stays a ramp. */
				v = v <= GL_LO ? 0u : v >= GL_HI ? 255u : (( v - GL_LO ) * 255u ) / ( GL_HI - GL_LO );
				g_cov[j * m + i] = (unsigned char)v;
			}
	}
	for( j = 0; j < m; j++ )
	{
		int py = y + j - r;
		if( py < 0 || py >= LH ) continue;
		for( i = 0; i < m; i++ )
		{
			int px = x + i - r;
			unsigned a = g_cov[j * m + i];
			if( !a || px < 0 || px >= LW ) continue;
			if( a > 255u ) a = 255u;
			g_buf[py * LW + px] = mix565( g_buf[py * LW + px], c, a + ( a >> 7 ));   /* 0..256 */
		}
	}
}
static void text( int x, int y, int s, unsigned short c, const char *t )
{
	for( ; *t; t++, x += 8 * s )
	{
		const unsigned char *g = font8x8_basic[(unsigned char)*t & 127u];
		int r, b;
		if( x + 8 * s > LW ) break;
		if( s > 1 && s <= GL_S_MAX ) { glyph_soft( x, y, s, c, g ); continue; }
		for( r = 0; r < 8; r++ ) for( b = 0; b < 8; b++ ) if( g[r] & ( 1u << b )) fill( x + b * s, y + r * s, s, s, c );
	}
}
static int text_w( const char *t, int s ) { return (int)strlen( t ) * 8 * s; }

/* background: the given picture at a quarter of its brightness, or black */
static void set_background( const unsigned short *src, unsigned pitch_bytes )
{
	int x, y;
	if( !src || !pitch_bytes ) { memset( g_bg, 0, LW * LH * 2 ); return; }
	for( y = 0; y < LH; y++ )
	{
		const unsigned short *s = (const unsigned short *)((const unsigned char *)src + (unsigned)y * pitch_bytes );
		for( x = 0; x < LW; x++ ) g_bg[y * LW + x] = (unsigned short)(( s[x] >> 2 ) & 0x39E7u );
	}
}

/* the console line as shown: no colour codes (ESC [ ... m, ^n), no "[hh:mm:ss] " stamp, printable */
static void clean_line( char *out, unsigned outsz, const char *p, unsigned n )
{
	unsigned i = 0, o = 0;
	while( i < n && o + 1 < outsz )
	{
		char c = p[i];
		if( c == 27 ) { i++; if( i < n && p[i] == '[' ) { while( i < n && p[i] != 'm' ) i++; } i++; continue; }
		if( c == '^' && i + 1 < n && p[i + 1] >= '0' && p[i + 1] <= '9' ) { i += 2; continue; }
		if( c == '[' && o == 0 && i + 10 <= n && p[i + 3] == ':' && p[i + 6] == ':' && p[i + 9] == ']' ) { i += 10; if( i < n && p[i] == ' ' ) i++; continue; }
		out[o++] = ( c >= 32 && c < 127 ) ? c : ' ';
		i++;
	}
	while( o && out[o - 1] == ' ' ) o--;
	out[o] = 0;
}

/* ---- Half-Life's own loading picture, read from the player's files ----
 * Nothing of the game is in ZZHalfLife: the picture is read at run time from the pak(s) of the
 * player's install, the way GameUI does it on the PC.  In order (build 24 and 25 put two sources
 * first: the player's own zzhl_loading.png / .tga / .bmp, then zzhl_loadscreen.tga, made on his PC
 * by tools/hl_loading.py from his Steam files - the 21_9 tiles, Steam's 800 ones being black):
 *  1. resource/BackgroundLoadingLayout.txt (Steam install): "resolution W H" then lines
 *     "<image> scaled|tiled <x> <y>"; the tiles (TGA, 256 x 256) are put together on a W x H
 *     canvas, then scaled to the screen;
 *  2. without that file, resource/background/<640|800>_<row>_<col>_loading.tga by name;
 *  3. gfx/shell/splash.bmp (the WON menu picture, 640 x 480);
 *  4. nothing: black, as in build 22.
 * Steam's resource/background/ is left out by the pak0.pak command recommended so far
 * (tools/hl_pak.py); hl_pak.py -i makes a small pak1.pak with it, which the engine mounts next
 * to pak0.pak.  Loaded once, from GL_SwapBuffers (never from inside a file read, an upload or a
 * console line: the engine's file system and image library are not re-entrant). */
typedef struct { int w, h; const unsigned char *rgba; void *handle; } xl_img_t;
typedef struct
{
	int  (*img_load)( const char *name, xl_img_t *out );   /* RGBA 8:8:8:8, top line first */
	void (*img_free)( xl_img_t *img );
	char *(*text_load)( const char *name );                /* NUL-terminated, malloc'ed */
	unsigned char *(*bin_load)( const char *name, int *len );   /* malloc'ed */
} xl_io_t;
static unsigned short *g_pic;          /* the picture at LW x LH, RGB565; NULL = none */
static char g_pic_from[160];           /* where it came from, or why none (console line) */
static int g_pic_user;                 /* the player's own picture: it carries its own LOADING, only the bar is drawn */
static int g_pic_made;                 /* zzhl_loadscreen.tga by tools/hl_loading.py - the logo's letters end at LS_LOGO_BOTTOM */
#define LS_LOGO_BOTTOM 42              /* percent of the height; the same 42 in tools/hl_loading.py (LOGO_BOTTOM) */

static void canvas_put( unsigned char *cv, int cw, int ch, const xl_img_t *im, int x0, int y0 )
{
	int y, w = im->w;
	if( x0 < 0 || y0 < 0 || x0 >= cw || y0 >= ch ) return;
	if( x0 + w > cw ) w = cw - x0;
	for( y = 0; y < im->h && y0 + y < ch; y++ ) memcpy( cv + (( y0 + y ) * cw + x0 ) * 4, im->rgba + y * im->w * 4, (size_t)w * 4 );
}
/* bilinear, canvas RGBA -> dst RGB565, LW x LH */
static void canvas_scale( const unsigned char *cv, int cw, int ch, unsigned short *dst )
{
	int dx, dy;
	for( dy = 0; dy < LH; dy++ )
	{
		int fy = (int)((( 2 * dy + 1 ) * ch * 256 ) / ( 2 * LH )) - 128, y0, wy;   /* (dy + 0.5) * ch / LH - 0.5, 8 fraction bits */
		if( fy < 0 ) fy = 0;
		y0 = fy >> 8; wy = fy & 255;
		if( y0 >= ch - 1 ) { y0 = ch - 1; wy = 0; }
		for( dx = 0; dx < LW; dx++ )
		{
			int fx = (int)((( 2 * dx + 1 ) * cw * 256 ) / ( 2 * LW )) - 128, x0, wx, c, v[3];
			const unsigned char *a, *b;
			if( fx < 0 ) fx = 0;
			x0 = fx >> 8; wx = fx & 255;
			if( x0 >= cw - 1 ) { x0 = cw - 1; wx = 0; }
			a = cv + ( y0 * cw + x0 ) * 4;
			b = a + ( y0 < ch - 1 ? cw * 4 : 0 );
			for( c = 0; c < 3; c++ )
			{
				int a1 = x0 < cw - 1 ? a[4 + c] : a[c], b1 = x0 < cw - 1 ? b[4 + c] : b[c];
				int top = a[c] * ( 256 - wx ) + a1 * wx, bot = b[c] * ( 256 - wx ) + b1 * wx;
				v[c] = ( top * ( 256 - wy ) + bot * wy ) >> 16;
			}
			dst[dy * LW + dx] = (unsigned short)((( v[0] >> 3 ) << 11 ) | (( v[1] >> 2 ) << 5 ) | ( v[2] >> 3 ));
		}
	}
}
static int place_tile( const xl_io_t *io, unsigned char *cv, int cw, int ch, const char *name, int x, int y )
{
	char n[96];
	xl_img_t im;
	size_t l = strlen( name );
	int ok = 0;
	if( l + 5 >= sizeof( n )) return 0;
	strcpy( n, name );
	if( l < 4 || n[l - 4] != '.' ) strcpy( n + l, ".tga" );
	if( io->img_load( n, &im )) ok = 1;
	else if( l < 4 || name[l - 4] != '.' ) { strcpy( n + l, ".bmp" ); ok = io->img_load( n, &im ); }
	if( !ok ) return 0;
	canvas_put( cv, cw, ch, &im, x, y );
	io->img_free( &im );
	return 1;
}
static int next_token( const char **p, char *out, int outsz )
{
	const char *q = *p;
	int n = 0;
	while( *q == ' ' || *q == '\t' || *q == '\r' ) q++;
	if( !*q || *q == '\n' ) { *p = q; return 0; }
	if( *q == '"' ) { q++; while( *q && *q != '"' && *q != '\n' ) { if( n < outsz - 1 ) out[n++] = *q; q++; } if( *q == '"' ) q++; }
	else while( *q && *q != ' ' && *q != '\t' && *q != '\r' && *q != '\n' ) { if( n < outsz - 1 ) out[n++] = *q; q++; }
	out[n] = 0;
	*p = q;
	return 1;
}
/* a canvas with nothing brighter than 24 of 255 is no picture */
static int canvas_black( const unsigned char *cv, int cw, int ch )
{
	size_t i, n = (size_t)cw * ch * 4;
	for( i = 0; i < n; i += 4 ) if( cv[i] >= 24 || cv[i + 1] >= 24 || cv[i + 2] >= 24 ) return 0;
	return 1;
}
/* sources 1 and 2: the Steam tiles, by the layout file then by name; *cv allocated, 1 = some tiles */
static int src_layout( const xl_io_t *io, unsigned char **cvp, int *cwp, int *chp )
{
	unsigned char *cv = NULL;
	int cw = 0, ch = 0, tiles = 0;
	char *lay = io->text_load( "resource/BackgroundLoadingLayout.txt" );
	const char *p = lay;
	while( p && *p )
	{
		char t[4][96];
		int k = 0;
		while( k < 4 && next_token( &p, t[k], sizeof( t[k] ))) k++;
		while( *p && *p != '\n' ) p++;
		if( *p ) p++;
		if( k >= 3 && !strcmp( t[0], "resolution" ) && !cv )
		{
			cw = atoi( t[1] ); ch = atoi( t[2] );
			if( cw < 64 || ch < 48 || cw > 2048 || ch > 1536 ) break;
			cv = (unsigned char *)calloc( (size_t)cw * ch, 4 );
			if( !cv ) break;
		}
		else if( k == 4 && cv && t[0][0] != '/' ) tiles += place_tile( io, cv, cw, ch, t[0], atoi( t[2] ), atoi( t[3] ));
	}
	free( lay );
	*cvp = cv; *cwp = cw; *chp = ch;
	return tiles > 0;
}
static int src_names( const xl_io_t *io, unsigned char **cvp, int *cwp, int *chp )
{
	static const int widths[2] = { 640, 800 };
	int i, r, c, tiles = 0;
	for( i = 0; i < 2; i++ )
	{
		int cw = widths[i], ch = cw * 3 / 4;
		unsigned char *cv = (unsigned char *)calloc( (size_t)cw * ch, 4 );
		if( !cv ) return 0;
		for( r = 0; r * 256 < ch; r++ ) for( c = 0; c * 256 < cw; c++ )
		{
			char n[64];
			sprintf( n, "resource/background/%d_%d_%c_loading", cw, r + 1, 'a' + c );
			tiles += place_tile( io, cv, cw, ch, n, c * 256, r * 256 );
		}
		if( tiles ) { *cvp = cv; *cwp = cw; *chp = ch; return 1; }
		free( cv );
	}
	return 0;
}
/* source 3: the WON menu picture */
static int src_won( const xl_io_t *io, unsigned char **cvp, int *cwp, int *chp )
{
	xl_img_t im;
	unsigned char *cv;
	if( !io->img_load( "gfx/shell/splash.bmp", &im )) return 0;
	cv = (unsigned char *)malloc( (size_t)im.w * im.h * 4 );
	if( cv ) memcpy( cv, im.rgba, (size_t)im.w * im.h * 4 );
	*cvp = cv; *cwp = im.w; *chp = im.h;
	io->img_free( &im );
	return cv != NULL;
}
/* source 0 (build 24): a picture the player puts in PROGDIR:data/ himself - zzhl_loading.png,
   .tga or .bmp, any size (scaled to the screen), 512 KiB at most (the release file service).
   Nothing of the kind ships with ZZHalfLife. */
static int src_whole( const xl_io_t *io, const char *name, unsigned char **cvp, int *cwp, int *chp )
{
	xl_img_t im;
	unsigned char *cv;
	if( !io->img_load( name, &im )) return 0;
	cv = (unsigned char *)malloc( (size_t)im.w * im.h * 4 );
	if( cv ) memcpy( cv, im.rgba, (size_t)im.w * im.h * 4 );
	*cvp = cv; *cwp = im.w; *chp = im.h;
	io->img_free( &im );
	return cv != NULL;
}
static int src_user( const xl_io_t *io, unsigned char **cvp, int *cwp, int *chp )
{
	static const char *n[3] = { "zzhl_loading.png", "zzhl_loading.tga", "zzhl_loading.bmp" };
	int i;
	for( i = 0; i < 3; i++ ) if( src_whole( io, n[i], cvp, cwp, chp )) return 1;
	return 0;
}
/* source 1 (build 25): PROGDIR:data/zzhl_loadscreen.tga, made on the player's PC by
   tools/hl_loading.py from his own Steam files (the 21_9 loading tiles of the 25th anniversary
   update, resource/logo.tga): 640 x 480 grey, the HALF-LIFE logo's letters ending at
   LS_LOGO_BOTTOM % of the height; LOADING, the bar and the console line go under them */
static int src_made( const xl_io_t *io, unsigned char **cvp, int *cwp, int *chp )
{
	return src_whole( io, "zzhl_loadscreen.tga", cvp, cwp, chp );
}
/* Mark fully black loading tiles as absent. */
static int build_picture( const xl_io_t *io )
{
	static const char *names[5] = { "PROGDIR:data/zzhl_loading", "PROGDIR:data/zzhl_loadscreen.tga (tools/hl_loading.py)", "resource/BackgroundLoadingLayout.txt", "resource/background/*_loading.tga", "gfx/shell/splash.bmp" };
	int (*src[5])( const xl_io_t *, unsigned char **, int *, int * ) = { src_user, src_made, src_layout, src_names, src_won };
	unsigned short *pic;
	int i;
	g_pic_from[0] = 0;
	g_pic_user = 0;
	g_pic_made = 0;
	for( i = 0; i < 5; i++ )
	{
		unsigned char *cv = NULL;
		int cw = 0, ch = 0;
		if( !src[i]( io, &cv, &cw, &ch ) || !cv ) { free( cv ); continue; }
		if( canvas_black( cv, cw, ch ))
		{
			if( strlen( g_pic_from ) + strlen( names[i] ) + 10 < sizeof( g_pic_from )) { strcat( g_pic_from, names[i] ); strcat( g_pic_from, " black; " ); }
			free( cv );
			continue;
		}
		pic = (unsigned short *)malloc( LW * LH * 2 );   /* g_pic only once complete */
		if( !pic ) { free( cv ); return 0; }
		canvas_scale( cv, cw, ch, pic );
		free( cv );
		free( g_pic );
		g_pic = pic;
		strncpy( g_pic_from, names[i], sizeof( g_pic_from ) - 1 );
		g_pic_user = ( i == 0 );
		g_pic_made = ( i == 1 );
		return 1;
	}
	return 0;
}

/* ---- zzhl_loadscreen.tga decoded here, without the engine ----
 * Read through the launcher's file service before Host_Main (xacp_loading_start), the picture is
 * behind LOADING from the first second instead of from the engine's first frame (07/11, * "a few seconds of LOADING on black first").  Formats: what hl_loading.py writes, uncompressed
 * grey (type 3, 8 bits), and uncompressed colour (type 2, 24 or 32 bits), either line order. */
static int tga_canvas( const unsigned char *b, int len, unsigned char **cvp, int *wp, int *hp )
{
	int it, w, h, bpp, n, top, x, y;
	const unsigned char *px;
	unsigned char *cv;
	if( len < 18 || b[1] ) return 0;
	it = b[2]; w = b[12] | b[13] << 8; h = b[14] | b[15] << 8; bpp = b[16]; top = b[17] & 0x20;
	if( !w || !h || w > 2048 || h > 2048 ) return 0;
	if( !(( it == 3 && bpp == 8 ) || ( it == 2 && ( bpp == 24 || bpp == 32 )))) return 0;
	n = bpp / 8;
	if( 18 + b[0] + w * h * n > len ) return 0;
	px = b + 18 + b[0];
	cv = (unsigned char *)malloc( (size_t)w * h * 4 );
	if( !cv ) return 0;
	for( y = 0; y < h; y++ )
	{
		const unsigned char *q = px + (size_t)( top ? y : h - 1 - y ) * w * n;
		unsigned char *d = cv + (size_t)y * w * 4;
		for( x = 0; x < w; x++, q += n, d += 4 )
		{
			if( n == 1 ) d[0] = d[1] = d[2] = q[0];
			else { d[0] = q[2]; d[1] = q[1]; d[2] = q[0]; }
			d[3] = 255;
		}
	}
	*cvp = cv; *wp = w; *hp = h;
	return 1;
}
/* 1 when g_pic holds the picture of these TGA bytes; user: the player's zzhl_loading.tga (own
   LOADING), else hl_loading.py's zzhl_loadscreen.tga (LOADING under the logo) */
static int pic_from_tga( const unsigned char *b, int len, int user )
{
	unsigned char *cv;
	unsigned short *pic;
	int w, h;
	if( !tga_canvas( b, len, &cv, &w, &h )) return 0;
	if( canvas_black( cv, w, h )) { free( cv ); return 0; }
	pic = (unsigned short *)malloc( LW * LH * 2 );
	if( !pic ) { free( cv ); return 0; }
	canvas_scale( cv, w, h, pic );
	free( cv );
	free( g_pic );
	g_pic = pic;
	g_pic_user = user;
	g_pic_made = !user;
	strncpy( g_pic_from, user ? "PROGDIR:data/zzhl_loading.tga" : "PROGDIR:data/zzhl_loadscreen.tga (tools/hl_loading.py)", sizeof( g_pic_from ) - 1 );
	return 1;
}

/* ---- the HALF-LIFE title of the intro (build 23) ----
 * When the install has no loading picture (Steam: black tiles; no gfx/shell/splash.bmp), the
 * screen shows the game's own title, the one the intro shows at the start of c0a0: the sprites
 * "title_half" and "title_life" of sprites/hud.txt at the HUD resolution of the screen (640, or
 * 320 below 640 wide, as the client's GetSpriteRes), side by side, drawn additively on black in
 * the colour titles.txt gives GAMETITLE - what cl_dll/message.cpp does. */
static int g_logo_y, g_logo_w, g_logo_h;

static int rd32( const unsigned char *p ) { return (int)( p[0] | p[1] << 8 | p[2] << 16 | (unsigned)p[3] << 24 ); }
/* whitespace-separated words across lines, // comments skipped */
static int next_word( const char **pp, char *out, int outsz )
{
	const char *p = *pp;
	int n = 0;
	for( ;; )
	{
		while( *p == ' ' || *p == '\t' || *p == '\r' || *p == '\n' ) p++;
		if( p[0] == '/' && p[1] == '/' ) { while( *p && *p != '\n' ) p++; continue; }
		break;
	}
	if( !*p ) { *pp = p; return 0; }
	while( *p && *p != ' ' && *p != '\t' && *p != '\r' && *p != '\n' ) { if( n < outsz - 1 ) out[n++] = *p; p++; }
	out[n] = 0;
	*pp = p;
	return 1;
}
typedef struct { char spr[64]; int x, y, w, h; } hudspr_t;
/* sprites/hud.txt: a count, then "name res sprite x y w h" */
static int hud_find( const char *txt, const char *name, int res, hudspr_t *o )
{
	const char *p = txt;
	char f[7][64];
	int k;
	if( !next_word( &p, f[0], 64 )) return 0;
	for( ;; )
	{
		for( k = 0; k < 7; k++ ) if( !next_word( &p, f[k], 64 )) return 0;
		if( !strcmp( f[0], name ) && atoi( f[1] ) == res )
		{
			strcpy( o->spr, f[2] ); o->x = atoi( f[3] ); o->y = atoi( f[4] ); o->w = atoi( f[5] ); o->h = atoi( f[6] );
			return o->w > 0 && o->h > 0 && o->w <= 1024 && o->h <= 1024;
		}
	}
}
/* titles.txt: the "$color r g b" and "$position x y" in force where GAMETITLE is defined */
static void title_style( const char *txt, int *rgb, float *ypos )
{
	const char *p = txt;
	while( p && *p )
	{
		char line[128];
		int n = 0, r, g, b;
		float x, y;
		while( *p && *p != '\n' ) { if( n < 127 ) line[n++] = *p; p++; }
		if( *p ) p++;
		while( n && ( line[n - 1] == '\r' || line[n - 1] == ' ' || line[n - 1] == '\t' )) n--;
		line[n] = 0;
		if( !strncmp( line, "$color ", 7 ) || !strncmp( line, "$color\t", 7 ))
		{ if( sscanf( line + 7, "%d %d %d", &r, &g, &b ) == 3 ) { rgb[0] = r; rgb[1] = g; rgb[2] = b; } }
		else if( !strncmp( line, "$position", 9 ) && sscanf( line + 9, "%f %f", &x, &y ) == 2 ) *ypos = y;
		else if( !strcmp( line, "GAMETITLE" )) return;
	}
}
/* one sprite rectangle, additively onto pic at (dx, dy), tinted */
static int spr_blit( const unsigned char *b, int len, const hudspr_t *hs, unsigned short *pic, int dx, int dy, const int *rgb )
{
	int fmt, ncol, off, w, h, i, j;
	const unsigned char *pal, *px;
	if( len < 42 || memcmp( b, "IDSP", 4 ) || rd32( b + 4 ) != 2 ) return 0;
	fmt = rd32( b + 12 );
	ncol = b[40] | b[41] << 8;
	if( ncol < 1 || ncol > 256 ) return 0;
	pal = b + 42;
	off = 42 + ncol * 3;
	if( off + 20 > len || rd32( b + off ) != 0 ) return 0;     /* frame 0 must be a single frame */
	w = rd32( b + off + 12 ); h = rd32( b + off + 16 );
	off += 20;
	if( w <= 0 || h <= 0 || off + w * h > len ) return 0;
	px = b + off;
	for( j = 0; j < hs->h; j++ ) for( i = 0; i < hs->w; i++ )
	{
		int sx = hs->x + i, sy = hs->y + j, x = dx + i, y = dy + j, idx, c[3], k;
		unsigned short o;
		if( sx < 0 || sy < 0 || sx >= w || sy >= h || x < 0 || y < 0 || x >= LW || y >= LH ) continue;
		idx = px[sy * w + sx];
		if( fmt == 3 && idx == 255 ) continue;                            /* alpha test */
		for( k = 0; k < 3; k++ )
		{
			int v = fmt == 2 ? pal[255 * 3 + k] * idx / 255 : pal[( idx < ncol ? idx : 0 ) * 3 + k];   /* index alpha / colours */
			c[k] = v * rgb[k] / 255;
		}
		o = pic[y * LW + x];
		c[0] += ( o >> 11 ) << 3; c[1] += (( o >> 5 ) & 63 ) << 2; c[2] += ( o & 31 ) << 3;
		for( k = 0; k < 3; k++ ) if( c[k] > 255 ) c[k] = 255;
		pic[y * LW + x] = (unsigned short)((( c[0] >> 3 ) << 11 ) | (( c[1] >> 2 ) << 5 ) | ( c[2] >> 3 ));
	}
	return 1;
}
/* 1 when g_pic holds the title on black */
static int build_logo( const xl_io_t *io )
{
	char *hud = io->text_load( "sprites/hud.txt" ), *tit;
	hudspr_t half, life;
	int res = LW >= 640 ? 640 : 320, rgb[3] = { 255, 160, 0 }, x, y, ok = 0;
	float ypos = -1.0f;
	unsigned short *pic;
	if( !hud ) return 0;
	ok = hud_find( hud, "title_half", res, &half ) && hud_find( hud, "title_life", res, &life );
	free( hud );
	if( !ok ) return 0;
	tit = io->text_load( "titles.txt" );
	if( tit ) { title_style( tit, rgb, &ypos ); free( tit ); }
	pic = (unsigned short *)calloc( LW * LH, 2 );
	if( !pic ) return 0;
	x = ( LW - half.w - life.w ) / 2;
	y = ( ypos >= 0.0f && ypos <= 0.8f ) ? (int)( ypos * LH ) : ( LH - half.h ) / 2 - LH / 10;
	{
		hudspr_t *parts[2] = { &half, &life };
		int k, dx = x;
		ok = 1;
		for( k = 0; k < 2 && ok; k++ )
		{
			char n[96];
			int len = 0;
			unsigned char *b;
			snprintf( n, sizeof( n ), "sprites/%s.spr", parts[k]->spr );
			b = io->bin_load( n, &len );
			ok = b && spr_blit( b, len, parts[k], pic, dx, y, rgb );
			free( b );
			dx += parts[k]->w;
		}
	}
	if( !ok ) { free( pic ); return 0; }
	free( g_pic );
	g_pic = pic;
	g_logo_y = y; g_logo_w = half.w + life.w; g_logo_h = half.h;
	snprintf( g_pic_from, sizeof( g_pic_from ), "the game title, sprites/%s.spr (hud.txt %d)", half.spr, res );
	return 1;
}

/* Keep the short port credit readable at the supported screen resolutions. */
#define ZZHL_CREDIT       "ZZHalfLife 1.0 - port by Xanxi - Xash3D FWGS on MNT ZZ9000 RasterIX"
#define ZZHL_CREDIT_SHORT "ZZHalfLife 1.0 by Xanxi"
/* one picture: background, LOADING, the moving bar, the console line, the credit line */
static int g_bg_kind;                  /* the background: 0 black or the darkened game, 1 Half-Life's picture (band at the bottom), 2 the title */
static void bar( int bx, int by, int bw, int bh, unsigned now_us )
{
	int pos, blk = bw / 5, span = bw + blk, a, b;
	fill( bx - 1, by - 1, bw + 2, 1, C_DGREY ); fill( bx - 1, by + bh, bw + 2, 1, C_DGREY );
	fill( bx - 1, by, 1, bh, C_DGREY ); fill( bx + bw, by, 1, bh, C_DGREY );
	pos = (int)(( now_us / 8000u ) % (unsigned)span ) - blk;
	a = pos < 0 ? 0 : pos; b = pos + blk > bw ? bw : pos + blk;
	if( b > a ) fill( bx + a, by, b - a, bh, C_ORANGE );
}
static void draw( unsigned now_us, const char *line )
{
	int s = LW >= 640 ? 2 : 1, tw, bx, bw, bh, by, ty;
	memcpy( g_buf, g_bg, LW * LH * 2 );
	if( g_bg_kind == 2 )
	{   /* under the title: LOADING, the bar as wide as the title, the console line */
		int w = g_logo_w > LW / 3 ? g_logo_w : LW / 3, y = g_logo_y + g_logo_h + 14 * s;
		text(( LW - text_w( "LOADING", s )) / 2, y, s, C_WHITE, "LOADING" );
		bar(( LW - w ) / 2, y + 14 * s, w, 2 * s, now_us );
		if( line && line[0] )
		{
			char t[LW / 8 + 1];
			int max = LW / 8 - 2;
			strncpy( t, line, sizeof( t ) - 1 ); t[sizeof( t ) - 1] = 0;
			if( (int)strlen( t ) > max ) t[max] = 0;
			text(( LW - text_w( t, 1 )) / 2, y + 24 * s, 1, C_GREY, t );
		}
		text( 8, LH - 12, 1, C_DGREY, LW >= 640 ? ZZHL_CREDIT : ZZHL_CREDIT_SHORT );
		return;
	}
	if( g_bg_kind == 1 && g_pic_made )
	{   /* build 25, the picture of tools/hl_loading.py: under the logo, L O A D I N G spaced like
	       its letters, the bar, the console line; the credit line at the bottom */
		static const char ld[] = "L O A D I N G";
		int y = LH * LS_LOGO_BOTTOM / 100 + 14 * s;
		text(( LW - text_w( ld, s )) / 2, y, s, C_LIGHT, ld );
		bw = LW * 9 / 16; bh = s + 1; bx = ( LW - bw ) / 2; by = y + 8 * s + 12 * s;
		bar( bx, by, bw, bh, now_us );
		if( line && line[0] )
		{
			char t[LW / 8 + 1];
			int max = LW / 8 - 2;
			strncpy( t, line, sizeof( t ) - 1 ); t[sizeof( t ) - 1] = 0;
			if( (int)strlen( t ) > max ) t[max] = 0;
			text(( LW - text_w( t, 1 )) / 2, by + bh + 10 * s, 1, C_GREY, t );
		}
		text( 8, LH - 12, 1, C_DGREY, LW >= 640 ? ZZHL_CREDIT : ZZHL_CREDIT_SHORT );
		return;
	}
	if( g_bg_kind == 1 && g_pic_user )
	{   /* the player's picture has its own LOADING: a thin darkened strip with the bar and the line */
		int band = 16 * s, y, x;
		for( y = LH - band; y < LH; y++ ) for( x = 0; x < LW; x++ ) g_buf[y * LW + x] = (unsigned short)(( g_buf[y * LW + x] >> 1 ) & 0x7BEFu );
		bar( 8 * s, LH - band + 3 * s, LW - 16 * s, s + 1, now_us );
		if( line && line[0] )
		{
			char t[LW / 8 + 1];
			int max = ( LW - 16 * s ) / 8;
			strncpy( t, line, sizeof( t ) - 1 ); t[sizeof( t ) - 1] = 0;
			if( (int)strlen( t ) > max ) t[max] = 0;
			text( 8 * s, LH - band + 6 * s + 2, 1, C_GREY, t );
		}
		return;
	}
	if( g_bg_kind == 1 )
	{   /* a darkened band at the bottom: LOADING, the bar, the console line */
		int band = 24 * s, y, x;
		for( y = LH - band; y < LH; y++ ) for( x = 0; x < LW; x++ ) g_buf[y * LW + x] = (unsigned short)(( g_buf[y * LW + x] >> 2 ) & 0x39E7u );
		text( 8 * s, LH - band + 4 * s, s, C_WHITE, "LOADING" );
		bx = 8 * s + text_w( "LOADING", s ) + 8 * s; bw = LW - bx - 8 * s;
		bar( bx, LH - band + 6 * s, bw, 3 * s / 2 + 1, now_us );
		if( line && line[0] )
		{
			char t[LW / 8 + 1];
			int max = bw / 8;
			strncpy( t, line, sizeof( t ) - 1 ); t[sizeof( t ) - 1] = 0;
			if( (int)strlen( t ) > max ) t[max] = 0;
			text( bx, LH - band + 14 * s, 1, C_GREY, t );
		}
		return;
	}
	tw = text_w( "LOADING", 2 * s );
	ty = LH * 2 / 5;
	text(( LW - tw ) / 2, ty, 2 * s, C_WHITE, "LOADING" );
	bw = LW * 3 / 8; bh = 3 * s; bx = ( LW - bw ) / 2; by = ty + 16 * s + 10 * s;
	bar( bx, by, bw, bh, now_us );
	if( line && line[0] )
	{
		char t[LW / 8 + 1];
		int max = LW / 8 - 2;
		strncpy( t, line, sizeof( t ) - 1 ); t[sizeof( t ) - 1] = 0;
		if( (int)strlen( t ) > max ) t[max] = 0;
		text(( LW - text_w( t, 1 )) / 2, by + bh + 12 * s, 1, C_GREY, t );
	}
	text( 8, LH - 12, 1, C_DGREY, LW >= 640 ? ZZHL_CREDIT : ZZHL_CREDIT_SHORT );
}

#ifdef ZZHL_HOST_TEST
/* host test: one picture into the caller's buffer (tests/test_loading.c) */
void xacp_loading_test_draw( unsigned short *out, const unsigned short *bg, unsigned bg_pitch, unsigned now_us, const char *raw )
{
	char line[128];
	g_buf = out;
	if( !g_bg ) g_bg = (unsigned short *)malloc( LW * LH * 2 );
	set_background( bg, bg_pitch );
	clean_line( line, sizeof( line ), raw, (unsigned)strlen( raw ));
	draw( now_us, line );
}
/* host test: Half-Life's picture built from the test's files, then one screen over it */
int xacp_loading_test_picture( unsigned short *out, int (*img_load)( const char *, xl_img_t * ), void (*img_free)( xl_img_t * ), char *(*text_load)( const char * ), const char *raw, char *from, unsigned fromsz )
{
	xl_io_t io;
	char line[128];
	io.img_load = img_load; io.img_free = img_free; io.text_load = text_load; io.bin_load = NULL;
	g_buf = out;
	if( !g_bg ) g_bg = (unsigned short *)malloc( LW * LH * 2 );
	if( !build_picture( &io )) { strncpy( from, g_pic_from, fromsz - 1 ); from[fromsz - 1] = 0; return 0; }
	memcpy( g_bg, g_pic, LW * LH * 2 );
	g_bg_kind = 1;
	clean_line( line, sizeof( line ), raw, (unsigned)strlen( raw ));
	draw( 400000u, line );
	g_bg_kind = 0;
	strncpy( from, g_pic_from, fromsz - 1 ); from[fromsz - 1] = 0;
	return 1;
}
/* host test: the title from the test's hud.txt / titles.txt / sprite, then one screen */
int xacp_loading_test_tga( unsigned short *out, const unsigned char *b, int len, const char *raw )
{   /* the picture decoded without the engine, then one screen */
	char line[128];
	g_buf = out;
	if( !g_bg ) g_bg = (unsigned short *)malloc( LW * LH * 2 );
	if( !pic_from_tga( b, len, 0 )) return 0;
	memcpy( g_bg, g_pic, LW * LH * 2 );
	g_bg_kind = 1;
	clean_line( line, sizeof( line ), raw, (unsigned)strlen( raw ));
	draw( 400000u, line );
	g_bg_kind = 0; g_pic_made = 0;
	return 1;
}
int xacp_loading_test_logo( unsigned short *out, char *(*text_load)( const char * ), unsigned char *(*bin_load)( const char *, int * ), const char *raw, char *from, unsigned fromsz )
{
	xl_io_t io;
	char line[128];
	memset( &io, 0, sizeof( io ));
	io.text_load = text_load; io.bin_load = bin_load;
	g_buf = out;
	if( !g_bg ) g_bg = (unsigned short *)malloc( LW * LH * 2 );
	if( !build_logo( &io )) return 0;
	memcpy( g_bg, g_pic, LW * LH * 2 );
	g_bg_kind = 2;
	clean_line( line, sizeof( line ), raw, (unsigned)strlen( raw ));
	draw( 400000u, line );
	g_bg_kind = 0;
	strncpy( from, g_pic_from, fromsz - 1 ); from[fromsz - 1] = 0;
	return 1;
}
#else
extern const zzhl_rt_t *zzhl_rt;
extern int zzhl_option_int( const char *key, int def );
extern void zzq2_present_rgb565( const unsigned short *pixels, unsigned pitch_bytes );
extern const unsigned short *(*zzhl_present_override)( unsigned *pitch_bytes );
extern const unsigned short *zzhl_last_game_picture( unsigned *pitch_bytes );
extern int zzhl_present_ready( void );

static int g_allowed, g_init, g_on, g_console, g_showing, g_busy, g_in_present, g_pic_tried, g_pic_on;
static int g_pic_kind;                 /* g_pic: 0 none, 1 picture (band at the bottom), 2 title on black */

/* the engine's file system and image library (build 23) */
static int eng_img_load( const char *name, xl_img_t *o )
{
	rgbdata_t *pic;
	if( !FS_FileExists( name, false )) return 0;
	pic = FS_LoadImage( name, NULL, 0 );
	if( !pic ) return 0;
	if( pic->type != PF_RGBA_32 ) Image_Process( &pic, 0, 0, IMAGE_FORCE_RGBA, 0 );
	if( pic->type != PF_RGBA_32 || !pic->buffer || !pic->width || !pic->height ) { FS_FreeImage( pic ); return 0; }
	o->w = pic->width; o->h = pic->height; o->rgba = pic->buffer; o->handle = pic;
	return 1;
}
static void eng_img_free( xl_img_t *o ) { if( o->handle ) FS_FreeImage( (rgbdata_t *)o->handle ); o->handle = NULL; }
static unsigned char *eng_bin_load( const char *name, int *len )
{
	fs_offset_t n = 0;
	byte *b;
	unsigned char *t;
	*len = 0;
	if( !FS_FileExists( name, false )) return NULL;
	b = FS_LoadFile( name, &n, false );
	if( !b ) return NULL;
	t = (unsigned char *)malloc( (size_t)n + 1 );
	if( t ) { memcpy( t, b, (size_t)n ); *len = (int)n; }
	Mem_Free( b );
	return t;
}
static char *eng_text_load( const char *name )
{
	fs_offset_t len = 0;
	byte *b;
	char *t;
	if( !FS_FileExists( name, false )) return NULL;
	b = FS_LoadFile( name, &len, false );
	if( !b ) return NULL;
	t = (char *)malloc( (size_t)len + 1 );
	if( t ) { memcpy( t, b, (size_t)len ); t[len] = 0; }
	Mem_Free( b );
	return t;
}
static unsigned g_draw_us, g_present_us, g_shown;
/* what the screen did, printed at the end (xacp_loading_report): the first hardware
   run of build 25 (06/11) showed no loading screen and left no trace to say why */
static unsigned g_t0, g_n_up, g_n_sent, g_n_shown, g_n_notready, g_n_engine, g_first_ms;
extern unsigned zzhl_frames_presented( void );
static char g_line[LW / 8 + 1];
static int g_line_new;

static int g_quitting;                 /* Esc Esc - the client disconnects to quit, not to load */
void xacp_loading_quit( void ) { g_quitting = 1; }
/* xacp_disk.c: 1 while the game is shown - the time the disk's requests count as "the game" */
/* not while the server spawns the next map (sv.state ss_loading): in the run of 11/11
   that part of a change of map (~6 s, the client still "active") counted as the game */
int xacp_loading_in_play( void ) { return !g_quitting && cls.state == ca_active && !cls.disable_screen && sv.state != ss_loading; }
const char *xacp_loading_mapname( void ) { return clgame.mapname[0] ? clgame.mapname : "-"; }
static int wanted( void )
{
	if( g_quitting || host.status == HOST_SHUTDOWN || host.status == HOST_ERR_FATAL ) return 0;
	if( cls.state == ca_active && !cls.disable_screen ) return 0;
	if( cls.state == ca_disconnected && g_console ) return 0;
	/* with the menu (mainui), the client sits disconnected under it before any game:
	   that is not a load.  Up to 51b this screen covered the menu at the start without MAP= (A4000,
	   12/11: LOADING and its moving bar, for good).  Shown again as soon as a game starts
	   (connecting), while the engine starts (the menu not up yet), and during a change of level. */
	if( cls.state == ca_disconnected && gameui.hInstance && UI_IsVisible()) return 0;
	/* Hide the loading display whenever the engine is no longer loading a level. */
	if( Con_Visible() && sv.state == ss_dead && !cls.disable_screen ) return 0;
	return 1;
}
/* 1 while the loading screen is the picture; draws it again when due */
static int showing( void )
{
	unsigned now;
	int w;
	if( !g_init )
	{
		g_init = 1;
		g_on = zzhl_option_int( "LOADSCREEN", 1 );
		g_console = zzhl_option_int( "CONSOLE", 0 );
		g_pic_on = zzhl_option_int( "LOADPIC", 1 );
		if( g_on )
		{
			g_buf = (unsigned short *)malloc( LW * LH * 2 );
			g_bg = (unsigned short *)malloc( LW * LH * 2 );
			if( !g_buf || !g_bg ) g_on = 0;
		}
		if( g_on ) { memset( g_bg, 0, LW * LH * 2 ); g_draw_us = 0; }
	}
	if( !g_on ) return 0;
	w = wanted();
	now = zzhl_rt->us_now();
	if( w && !g_showing )
	{   /* a load starts: the game's last picture behind, darkened; before any game, Half-Life's
	       loading picture (build 23) or black */
		unsigned pitch = 0;
		const unsigned short *p = g_shown ? zzhl_last_game_picture( &pitch ) : NULL;
		if( !g_shown && g_pic ) { memcpy( g_bg, g_pic, LW * LH * 2 ); g_bg_kind = g_pic_kind; }
		else { set_background( p, pitch ); g_bg_kind = 0; }
		g_showing = 1;
		g_n_up++;
		g_draw_us = now - 1000000u;
	}
	else if( !w ) g_showing = 0;
	if( !g_showing ) return 0;
	if( g_line_new || now - g_draw_us >= 50000u )
	{
		draw( now, g_line );
		g_draw_us = now;
		g_line_new = 0;
	}
	return 1;
}
static const unsigned short *override( unsigned *pitch_bytes )
{
	if( g_busy ) return NULL;
	g_busy = 1;
	if( !showing()) { g_busy = 0; if( cls.state == ca_active ) g_shown = 1; return NULL; }
	g_busy = 0;
	*pitch_bytes = LW * 2;
	g_n_engine++;                           /* an engine frame replaced by the loading screen */
	return g_buf;
}
/* xacp_main.c, once the options are read (LOADSCREEN, CONSOLE): nothing is shown before */
static int g_pic_early;                /* g_pic read before Host_Main */
static void early_picture( void )
{
	static const char *n[2] = { "zzhl_loading.tga", "zzhl_loadscreen.tga" };
	int i;
	if( !zzhl_rt->fopen || !zzhl_option_int( "LOADSCREEN", 1 ) || !zzhl_option_int( "LOADPIC", 1 )) return;
	for( i = 0; i < 2; i++ )
	{
		FILE *f = zzhl_rt->fopen( n[i], "rb" );
		long len;
		unsigned char *b;
		int ok = 0;
		if( !f ) continue;
		zzhl_rt->fseek( f, 0, SEEK_END );
		len = zzhl_rt->ftell( f );
		zzhl_rt->fseek( f, 0, SEEK_SET );
		b = ( len > 18 && len <= 524288 ) ? (unsigned char *)malloc( (size_t)len ) : NULL;
		if( b && (long)zzhl_rt->fread( b, 1, (size_t)len, f ) == len ) ok = pic_from_tga( b, (int)len, i == 0 );
		zzhl_rt->fclose( f );
		free( b );
		if( ok ) { g_pic_kind = 1; g_pic_early = 1; return; }
	}
}
void xacp_loading_start( void )
{
	g_allowed = 1;
	g_t0 = zzhl_rt ? zzhl_rt->us_now() : 0;
	early_picture();
}
/* a progress point: shows the screen again if the last time is 100 ms ago or more */
void xacp_loading_tick( void )
{
	unsigned now;
	if( !g_allowed || g_busy || g_in_present || !zzhl_rt ) return;
	if( !zzhl_present_override ) zzhl_present_override = override;
	if( g_init && !g_on ) return;
	now = zzhl_rt->us_now();
	if( g_init && now - g_present_us < 100000u ) return;
	if( !zzhl_present_ready()) { g_n_notready++; return; }
	g_busy = 1;
	if( !showing()) { g_busy = 0; return; }
	g_busy = 0;
	g_present_us = now;
	g_in_present = 1;                       /* a console line printed by the presentation must not come back here */
	{
		unsigned before = zzhl_frames_presented();
		zzq2_present_rgb565( g_buf, LW * 2 );
		g_n_sent++;
		if( zzhl_frames_presented() != before )
		{
			g_n_shown++;
			if( !g_first_ms ) g_first_ms = ( now - g_t0 ) / 1000u + 1u;
		}
	}
	g_in_present = 0;
}
/* each console line (xacp_libc.c, before the mirror's collapsing of repeats) */
void xacp_loading_line( const char *p, unsigned n )
{
	char t[sizeof( g_line )];
	if( !g_allowed || ( g_init && !g_on )) return;
	clean_line( t, sizeof( t ), p, n );
	if( !t[0] || ( t[0] == '(' && t[1] == '+' )) return;
	/* the engine's developer warnings ("Warning: FS_LoadImage: couldn't load "alpha_sky""
	   at each map: the Quake sky layers a Half-Life map does not have) and errors stay in the
	   console, not on the loading screen */
	if( !strncmp( t, "Warning:", 8 ) || !strncmp( t, "Error:", 6 )) return;
	{   /* Debug loading messages are optional; leave the release display uncluttered. */
		static int lt = -1;
		if( lt < 0 ) lt = zzhl_option_int( "LOADTEXT", 0 ) ? 1 : 0;
		if( !lt ) { xacp_loading_tick(); return; }
	}
	memcpy( g_line, t, sizeof( g_line ));
	g_line_new = 1;
	xacp_loading_tick();
}
/* the end of the run (xacp_main.c): what the loading screen did */
void xacp_loading_report( void )
{
	printf( "ZZHalfLife: loading screen %s: up %u times, %u pictures sent, %u shown (the others found no free buffer), first at %u ms; %u engine frames replaced; presentation not ready %u times\n",
		!g_allowed ? "never allowed" : !g_init ? "never started" : g_on ? "on" : "off (LOADSCREEN=0)",
		g_n_up, g_n_sent, g_n_shown, g_first_ms ? g_first_ms - 1u : 0u, g_n_engine, g_n_notready );
	printf( "ZZHalfLife: loading picture: %s\n", g_pic_kind ? g_pic_from : g_pic_tried ? ( g_pic_from[0] ? g_pic_from : "none in the game's files" ) : "not looked for" );
}
/* once a frame, at its start (Platform_RunEvents, xacp_input.c): nothing of the engine is busy
   there.  The first time the engine runs its frames, Half-Life's loading picture is read; while
   the loading screen is up and nothing of the game was shown yet, it becomes its background. */
void xacp_loading_frame( void )
{
	/* Platform_RunEvents runs from Host_RunFrame only, after Host_Init.  Builds 23-25
	   waited for host.status == HOST_FRAME, which only the SDL platforms set (window focus): on
	   the ZZ9000 host.status stays HOST_INIT, so the picture was never read (06/11, build 25) */
	if( !g_allowed || !g_init || !g_on || !g_pic_on || g_pic_tried || host.status == HOST_SHUTDOWN || host.status == HOST_ERR_FATAL ) return;
	{
		xl_io_t io;
		g_pic_tried = 1;
		io.img_load = eng_img_load; io.img_free = eng_img_free; io.text_load = eng_text_load; io.bin_load = eng_bin_load;
		if( g_pic_early )
		{   /* read before Host_Main; the player's own .png / .bmp still comes first */
			static const char *u[2] = { "zzhl_loading.png", "zzhl_loading.bmp" };
			int k;
			for( k = 0; k < 2 && !g_pic_user; k++ )
			{
				unsigned char *cv = NULL;
				int cw = 0, ch = 0;
				if( src_whole( &io, u[k], &cv, &cw, &ch ) && cv && !canvas_black( cv, cw, ch ))
				{
					unsigned short *pic = (unsigned short *)malloc( LW * LH * 2 );
					if( pic )
					{
						canvas_scale( cv, cw, ch, pic );
						free( g_pic ); g_pic = pic;
						g_pic_user = 1; g_pic_made = 0;
						snprintf( g_pic_from, sizeof( g_pic_from ), "PROGDIR:data/%s", u[k] );
					}
				}
				free( cv );
			}
			Con_Printf( "ZZHalfLife: loading screen with %s (read before the engine started)\n", g_pic_from );
		}
		else if( build_picture( &io )) g_pic_kind = 1;
		else
		{
			if( g_pic_from[0] ) Con_Printf( "ZZHalfLife: loading picture: %s\n", g_pic_from );
			if( build_logo( &io )) g_pic_kind = 2;
		}
		if( !g_pic_early )
		{
			if( g_pic_kind ) Con_Printf( "ZZHalfLife: loading screen with %s (the game's own files)\n", g_pic_from );
			else Con_Printf( "ZZHalfLife: no loading picture nor title in the game's files (docs/TEST.md)\n" );
		}
		if( g_pic && g_showing && !g_shown ) { memcpy( g_bg, g_pic, LW * LH * 2 ); g_bg_kind = g_pic_kind; g_draw_us = 0; g_line_new = 1; }
	}
}
#endif
