// xacp_vgui_app.cpp - ZZHalfLife: FreeVGUI's platform/posix/app.cpp (BSD-3-Clause, Alibek
// Omarov) for Core1: the clock comes from the stage-1 runtime instead of clock_gettime.
// SPDX-License-Identifier: BSD-3-Clause
// ASCII only.
#include "app.h"
extern "C" unsigned long long zzhl_us64( void );

using namespace vgui;

void App::internalSetMouseArena(int, int, int, int, bool)
{
}

long int App::getTimeMillis()
{
	return (long int)( zzhl_us64() / 1000ull );
}

void App::platTick()
{
}
