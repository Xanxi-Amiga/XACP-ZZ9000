/* xacp_gl.c - ZZHalfLife: the OpenGL entry points ref_gl asks the engine for by name
 * (gEngfuncs.GL_GetProcAddress, ref/gl/gl_opengl.c opengl_110funcs[]), implemented on ZZGL
 * (zzgl/zzgl.c: the immediate-mode GL subset Quake II's ref_gl used on librixgpu, vendored
 * from ZZQuake2RIX) through the draw queue of xacp_glq.c (texture-sorted replay of the
 * order-independent batches, bind statistics).  Every GL 1.1 name resolves, so that ref_gl's
 * "OpenGL 1.1.0" check passes; what RasterIX has no equivalent for is an empty function
 * (stencil, fog, polygon offset, display lists, accumulation, 1D/3D textures).  Vertex arrays
 * ARE implemented (on the immediate mode): the studio renderer draws every character through
 * them.  No extension name resolves: one TMU, two-pass lightmaps, no compressed textures
 * (XX19d-RIX).  The RIX2 (two TMU) build will expose GL_ARB_multitexture here
 * (docs/RIX2_NOTES.md).
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <string.h>
#include "zzgl.h"
#include "xacp_glq.h"
#include "zzhl_fx.h"                       /* the sprite quads counted */

typedef unsigned int GLenum;
typedef unsigned char GLboolean;
typedef unsigned int GLbitfield;
typedef int GLint;
typedef unsigned int GLuint;
typedef int GLsizei;
typedef float GLfloat;
typedef double GLdouble;
typedef unsigned char GLubyte;

/* ---- PICMIP: launch option, 0 = off ---- */
static int g_picmip;
void xacp_gl_set_picmip( int n ) { g_picmip = n < 0 ? 0 : n > 3 ? 3 : n; }

/* ---- skybox texture names ----
 * ref_gl forces the six sky sides onto the FIXED texture names 5800..5805 (SKYBOX_BASE_NUM,
 * GL_AllocTexture's "skyboxhack"), bypassing glGenTextures.  ZZGL's table stops at
 * ZZGL_MAX_TEXTURES (2304): the bind was refused, the six sky uploads landed in whatever
 * texture was bound at map load (A0 build 3/4 hardware: sky drawn with a random texture, and
 * the overwritten one - the HUD font among the candidates - turned to desert-sky noise).
 * The wrapper remaps 5800..5807 onto the top of ZZGL's range; zzglGenTextures allocates
 * bottom-up, so those slots are free in practice. */
static GLuint remap_texnum( GLuint t )
{
	return ( t >= 5800u && t < 5808u ) ? ( 2296u + ( t - 5800u )) : t;
}

/* ---- texture uploads ----
 * Textures below 8 texels (ref_gl's 4x4 default / grey / black textures) are replicated to 8x8
 * before ZZGL, which refuses anything under 8.
 * PICMIP=n: ref_gl uploads a mipmapped texture (world, models, sprites, decals: everything
 * without TF_NOMIPMAP) as level 0 followed by the levels it builds itself with a box filter
 * (GL_BuildMipMap, in place in the same buffer).  ZZGL keeps one level.  With PICMIP the level-0
 * upload is held in a copy until the texture's parameters, another texture or a draw follows:
 * if level 1..n arrived meanwhile (still 8x8 or larger), that level is what ZZGL gets.  Fonts,
 * HUD pictures and lightmaps carry TF_NOMIPMAP, come as level 0 only and stay sharp.  A
 * texture loaded with half the texels streams in half the time at every bind (zzgl.h: a
 * 64x64 bind streams in 16 us; 128x128 world textures are the common case). */
static struct {
	int valid;
	GLuint tex;
	GLsizei w, h;
	GLint internal, border;
	GLenum format, type, target;
	int level;
	unsigned char buf[256 * 256 * 4];
} g_pend;

/* ---- the part of a texture that can show (SPRTRIM) ----
 * A sprite is a quad as large as its picture, and the picture of a halo, a flare or a muzzle
 * flash is mostly empty towards its edges: the GPU fetches, tests and blends those pixels for
 * nothing.  At every upload the smallest box holding the texels whose alpha is not 0, and the
 * one holding those whose colour is not black, are kept (one pass over the picture; when the four
 * corners are neither, both boxes are the whole picture and nothing is scanned, which is the case
 * of nearly every wall).  zzhl_sprite_trim() then tells ref_gl's sprite quad (generated patch of
 * gl_sprite.c) which part of it can change the picture in the state it is drawn in (glq_trim_kind,
 * xacp_glq.c), grown by one texel on every side for the bilinear filter.  The quad is drawn
 * smaller with the texture coordinates of the part kept: the same texels land on the same pixels.
 * Counted in every run (zzhl_fx.h: quads, how many have a margin, how much of them remains);
 * applied only with SPRTRIM=1, and never in a session where a texture had to be stored reduced
 * (ZZGL's box filter spreads the texels). */
typedef struct { unsigned char known, ax0, ay0, ax1, ay1, rx0, ry0, rx1, ry1, pad; unsigned short w, h; } texbox_t;
static texbox_t g_box[ZZGL_MAX_TEXTURES];
static int g_sprtrim;
void xacp_gl_set_sprtrim( int on ) { g_sprtrim = on ? 1 : 0; }
static void box_forget( GLuint tex ) { if( tex < ZZGL_MAX_TEXTURES ) g_box[tex].known = 0; }
static void box_scan( GLuint tex, GLsizei w, GLsizei h, GLenum format, GLenum type, const void *pixels )
{
	const unsigned char *p = (const unsigned char *)pixels;
	texbox_t *b;
	int bpp, x, y, ax0, ay0, ax1, ay1, rx0, ry0, rx1, ry1;
	if( tex >= ZZGL_MAX_TEXTURES ) return;
	b = &g_box[tex]; b->known = 0;
	if( !p || type != ZGL_UNSIGNED_BYTE || ( format != ZGL_RGBA && format != ZGL_RGB ) || w < 16 || h < 16 || w > 256 || h > 256 ) return;
	bpp = ( format == ZGL_RGBA ) ? 4 : 3;
	{   /* the four corners all visible in both senses: the boxes are the whole picture */
		const unsigned char *c[4];
		int i, full = 1;
		c[0] = p; c[1] = p + ( w - 1 ) * bpp; c[2] = p + ( h - 1 ) * w * bpp; c[3] = p + (( h - 1 ) * w + ( w - 1 )) * bpp;
		for( i = 0; i < 4; i++ ) if( !( c[i][0] | c[i][1] | c[i][2] ) || ( bpp == 4 && !c[i][3] )) full = 0;
		if( full ) return;                              /* nothing to trim: not "known", the query answers no at once */
	}
	ax0 = rx0 = w; ay0 = ry0 = h; ax1 = rx1 = ay1 = ry1 = -1;
	for( y = 0; y < h; y++ )
		for( x = 0; x < w; x++, p += bpp )
		{
			if( p[0] | p[1] | p[2] ) { if( x < rx0 ) rx0 = x; if( x > rx1 ) rx1 = x; if( ry0 == h ) ry0 = y; ry1 = y; }
			if( bpp == 3 || p[3] )   { if( x < ax0 ) ax0 = x; if( x > ax1 ) ax1 = x; if( ay0 == h ) ay0 = y; ay1 = y; }
		}
	if( ax1 < 0 || rx1 < 0 ) return;                    /* a picture with nothing in it: left alone */
	b->ax0 = (unsigned char)ax0; b->ay0 = (unsigned char)ay0; b->ax1 = (unsigned char)ax1; b->ay1 = (unsigned char)ay1;
	b->rx0 = (unsigned char)rx0; b->ry0 = (unsigned char)ry0; b->rx1 = (unsigned char)rx1; b->ry1 = (unsigned char)ry1;
	b->w = (unsigned short)w; b->h = (unsigned short)h; b->known = 1;
}
/* 1 and the part to draw (u from the left, v from the top, both 0..1) when the quad about to be
   drawn with the bound texture may be made smaller; 0 = draw it whole */
int zzhl_sprite_trim( float *u0, float *v0, float *u1, float *v1 )
{
	unsigned tex = glq_bound(), kept;
	const texbox_t *b;
	int kind, x0, y0, x1, y1;
	zzhl_fx[ZFX_SPR_QUADS]++;
	if( tex >= ZZGL_MAX_TEXTURES ) return 0;
	b = &g_box[tex];
	if( !b->known ) return 0;
	kind = glq_trim_kind();
	if( !kind ) return 0;
	x0 = 0; y0 = 0; x1 = b->w - 1; y1 = b->h - 1;
	if( kind & 1 ) { if( b->ax0 > x0 ) x0 = b->ax0; if( b->ay0 > y0 ) y0 = b->ay0; if( b->ax1 < x1 ) x1 = b->ax1; if( b->ay1 < y1 ) y1 = b->ay1; }
	if( kind & 2 ) { if( b->rx0 > x0 ) x0 = b->rx0; if( b->ry0 > y0 ) y0 = b->ry0; if( b->rx1 < x1 ) x1 = b->rx1; if( b->ry1 < y1 ) y1 = b->ry1; }
	if( x0 > x1 || y0 > y1 ) return 0;                  /* the two boxes do not meet: rare enough to leave whole */
	/* one texel more on every side: a bilinear sample half a texel outside the box still reads it */
	x0 -= 1; y0 -= 1; x1 += 2; y1 += 2;                 /* x1, y1: one past the last texel kept */
	if( x0 < 0 ) x0 = 0;
	if( y0 < 0 ) y0 = 0;
	if( x1 > b->w ) x1 = b->w;
	if( y1 > b->h ) y1 = b->h;
	kept = (unsigned)(( x1 - x0 ) * ( y1 - y0 )) * 1000u / ((unsigned)b->w * b->h );
	if( kept > 900u ) return 0;                         /* under a tenth to gain: not worth a different quad */
	zzhl_fx[ZFX_SPR_TRIMMABLE]++; zzhl_fx[ZFX_SPR_KEPT1000] += kept;
	if( !g_sprtrim ) return 0;
	{ u32 up, ds, rf, ev; zzgl_tex_counts( &up, &ds, &rf, &ev ); if( ds ) return 0; }
	*u0 = (float)x0 / (float)b->w; *u1 = (float)x1 / (float)b->w;
	*v0 = (float)y0 / (float)b->h; *v1 = (float)y1 / (float)b->h;
	return 1;
}

static void upload_now( GLuint tex, GLenum target, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels )
{
	/* the GPU's smallest texture is 8x8: a smaller one is tiled up to 8 in the dimensions that are
	   short, and ONLY those (build 54; before, a 16x1 or 16x2 texture was squeezed to 8x8, which
	   dropped half its texels - ref_gl's 1-pixel-high pictures, its GL_TEXTURE_1D, land here). */
	static unsigned char pad[256 * 8 * 4];
	if( pixels && ( width < 8 || height < 8 ) && width > 0 && height > 0 && width <= 256 && height <= 256
		&& ( format == ZGL_RGBA || format == ZGL_RGB ) && type == ZGL_UNSIGNED_BYTE )
	{
		int bpp = ( format == ZGL_RGBA ) ? 4 : 3, x, y;
		int nw = width < 8 ? 8 : width, nh = height < 8 ? 8 : height;
		if( (size_t)nw * (size_t)nh * (size_t)bpp <= sizeof( pad ))
		{
			for( y = 0; y < nh; y++ )
				for( x = 0; x < nw; x++ )
					memcpy( pad + ( y * nw + x ) * bpp, (const unsigned char *)pixels + (( y % height ) * width + ( x % width )) * bpp, bpp );
			width = nw; height = nh; pixels = pad;
		}
	}
	glq_texture_touched( tex );
	zzglTexImage2D( target, 0, internalformat, width, height, border, format, type, pixels );
	glq_texture_size( tex, (unsigned)width, (unsigned)height );
	box_scan( tex, width, height, format, type, pixels );   /* build 84 */
}
static void pend_flush( void )
{
	if( !g_pend.valid ) return;
	g_pend.valid = 0;
	if( glq_bound() != g_pend.tex ) zzglBindTexture( ZGL_TEXTURE_2D, g_pend.tex );   /* never the case: a bind flushes first */
	upload_now( g_pend.tex, g_pend.target, g_pend.internal, g_pend.w, g_pend.h, g_pend.border, g_pend.format, g_pend.type, g_pend.buf );
	if( glq_bound() != g_pend.tex ) zzglBindTexture( ZGL_TEXTURE_2D, glq_bound());
}
extern void xacp_loading_tick( void );   /* xacp_loading.c (build 22): uploads are progress while loading */
static void x_glTexImage2D( GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void *pixels )
{
	int bpp = ( format == ZGL_RGBA ) ? 4 : ( format == ZGL_RGB ) ? 3 : 0;
	xacp_loading_tick();
	if( g_picmip && pixels && bpp && type == ZGL_UNSIGNED_BYTE && width > 0 && height > 0 && width <= 256 && height <= 256 )
	{
		if( level == 0 )
		{
			pend_flush();
			if( width >= 16 && height >= 16 )
			{
				g_pend.valid = 1; g_pend.tex = glq_bound(); g_pend.w = width; g_pend.h = height; g_pend.level = 0;
				g_pend.internal = internalformat; g_pend.border = border; g_pend.format = format; g_pend.type = type; g_pend.target = target;
				memcpy( g_pend.buf, pixels, (size_t)width * (size_t)height * (size_t)bpp );
				return;
			}
		}
		else if( g_pend.valid && g_pend.tex == glq_bound() && level <= g_picmip && level == g_pend.level + 1 && width >= 8 && height >= 8 )
		{
			g_pend.w = width; g_pend.h = height; g_pend.level = level; g_pend.format = format; g_pend.type = type;
			memcpy( g_pend.buf, pixels, (size_t)width * (size_t)height * (size_t)bpp );
			return;
		}
		else return;                                  /* deeper levels, or levels of an unheld texture */
	}
	if( level != 0 ) return;                          /* no mipmaps on this GPU */
	pend_flush();
	upload_now( glq_bound(), target, internalformat, width, height, border, format, type, pixels );
}
static void x_glTexSubImage2D( GLenum target, GLint level, GLint x, GLint y, GLsizei w, GLsizei h, GLenum format, GLenum type, const void *pixels )
{
	pend_flush();
	glq_texture_touched( glq_bound());
	box_forget( glq_bound());                         /* its picture changes */
	zzglTexSubImage2D( target, level, x, y, w, h, format, type, pixels );
}
static void x_glBindTexture( GLenum target, GLuint t )
{
	(void)target;
	pend_flush();
	glq_bind( remap_texnum( t ));
}
static void x_glDeleteTextures( GLsizei n, const GLuint *ts )
{
	GLsizei i;
	pend_flush();
	for( i = 0; i < n; i++ ) { GLuint t = remap_texnum( ts[i] ); glq_texture_touched( t ); box_forget( t ); zzglDeleteTextures( 1, &t ); }
}
/* glGenTextures never answers 0 (build 16).  When ZZGL has no name left it writes 0, and ref_gl's
   GL_AllocTexture then takes gl_textures[0] for EVERY failed texture (slot 0 is free and its
   texnum stays 0), inserting the same struct again and again into the name hash table: the
   chains loop, and the next walk that does not find its name early never ends.  Run 320 of
   05/11 (ZZGL 0.7.6, names exhausted at the 11th map): Core1 alive, no image any more, right
   after "Spawn Server: c1a0b", i.e. while the previous map's textures were being deleted.
   ZZGL 0.7.7 reuses deleted names, so exhaustion needs ~2288 live textures; should it still
   happen, the textures share one reserved name (wrong pictures, no hang) and the exit report
   counts them. */
#define XACP_GL_OVERFLOW_NAME 2288u
static unsigned g_gen_overflow;
unsigned xacp_gl_name_overflows( void ) { return g_gen_overflow; }
static void x_glGenTextures( GLsizei n, GLuint *ts )
{
	GLsizei i;
	pend_flush();
	zzglGenTextures( n, ts );
	for( i = 0; i < n; i++ ) if( !ts[i] ) { ts[i] = XACP_GL_OVERFLOW_NAME; g_gen_overflow++; }
}
static void x_glTexParameterf( GLenum target, GLenum pname, GLfloat param )
{
	pend_flush(); glq_texture_touched( glq_bound());
	zzglTexParameterf( target == ZGL_TEXTURE_1D ? ZGL_TEXTURE_2D : target, pname, param );   /* build 54 */
}
static void x_glTexParameteri( GLenum target, GLenum pname, GLint param ) { x_glTexParameterf( target, pname, (float)param ); }
static void x_glTexParameterfv( GLenum target, GLenum pname, const GLfloat *p ) { x_glTexParameterf( target, pname, p[0] ); }

/* ---- state ---- */
static void x_glEnable( GLenum cap ) { glq_enable( cap, 1 ); }
static void x_glDisable( GLenum cap ) { glq_enable( cap, 0 ); }
static void x_glDepthFunc( GLenum f ) { glq_depth_func( f ); }
static void x_glDepthMask( GLboolean m ) { glq_depth_mask( m ? 1 : 0 ); }
static void x_glBlendFunc( GLenum s, GLenum d ) { glq_blend_func( s, d ); }
static void x_glAlphaFunc( GLenum f, GLfloat r ) { glq_alpha_func( f, r ); }
static void x_glCullFace( GLenum m ) { glq_cull_face( m ); }
static void x_glFrontFace( GLenum m ) { glq_front_face( m ); }
static void x_glShadeModel( GLenum m ) { glq_shade_model( m ); }
static void x_glPolygonMode( GLenum face, GLenum m ) { (void)face; glq_polygon_mode( m ); }
static void x_glColorMask( GLboolean r, GLboolean g, GLboolean b, GLboolean a ) { glq_color_mask(( r || g || b || a ) ? 1 : 0 ); }
static void x_glScissor( GLint x, GLint y, GLsizei w, GLsizei h ) { glq_scissor( x, y, w, h ); }
static void x_glViewport( GLint x, GLint y, GLsizei w, GLsizei h ) { glq_viewport( x, y, w, h ); }
static void x_glDepthRange( GLdouble n, GLdouble f ) { glq_depth_range( n, f ); }
static void x_glMatrixMode( GLenum m ) { glq_matrix_mode( m ); }
static void x_glTexEnvf( GLenum target, GLenum pname, GLfloat param ) { (void)target; if( pname == ZGL_TEXTURE_ENV_MODE ) glq_tex_env( (unsigned)param ); }
static void x_glTexEnvi( GLenum target, GLenum pname, GLint param ) { x_glTexEnvf( target, pname, (float)param ); }
static void x_glTexEnvfv( GLenum target, GLenum pname, const GLfloat *p ) { x_glTexEnvf( target, pname, p[0] ); }
static void x_glClear( GLbitfield mask ) { pend_flush(); glq_flush( GLQ_WHY_CLEAR ); zzglClear( mask ); }
static void x_glReadPixels( GLint x, GLint y, GLsizei w, GLsizei h, GLenum f, GLenum t, void *p ) { glq_flush( GLQ_WHY_CLEAR ); zzglReadPixels( x, y, w, h, f, t, p ); }
static void x_glFinish( void ) { pend_flush(); glq_flush( GLQ_WHY_CLEAR ); zzglFinish(); }
static void x_glFlush( void ) { pend_flush(); glq_flush( GLQ_WHY_CLEAR ); zzglFlush(); }

/* ---- colours and texture coordinates ---- */
static void x_glColor3f( GLfloat r, GLfloat g, GLfloat b ) { glq_color( r, g, b, 1.0f ); }
static void x_glColor3fv( const GLfloat *v ) { glq_color( v[0], v[1], v[2], 1.0f ); }
static void x_glColor4f( GLfloat r, GLfloat g, GLfloat b, GLfloat a ) { glq_color( r, g, b, a ); }
static void x_glColor4fv( const GLfloat *v ) { glq_color( v[0], v[1], v[2], v[3] ); }
static void x_glColor3ub( GLubyte r, GLubyte g, GLubyte b ) { glq_color( r / 255.0f, g / 255.0f, b / 255.0f, 1.0f ); }
static void x_glColor4ub( GLubyte r, GLubyte g, GLubyte b, GLubyte a ) { glq_color4ub( r, g, b, a ); }           /* RECFAST (xacp_glq.c) */
static void x_glColor4ubv( const GLubyte *v ) { glq_color4ub( v[0], v[1], v[2], v[3] ); }
static void x_glTexCoord1f( GLfloat s ) { glq_texcoord( s, 0.0f ); }
static void x_glTexCoord2f( GLfloat s, GLfloat t ) { glq_texcoord( s, t ); }
static void x_glTexCoord2fv( const GLfloat *v ) { glq_texcoord( v[0], v[1] ); }
static void x_glTexCoord3f( GLfloat s, GLfloat t, GLfloat r ) { (void)r; glq_texcoord( s, t ); }
static void x_glTexCoord4f( GLfloat s, GLfloat t, GLfloat r, GLfloat q ) { (void)r; (void)q; glq_texcoord( s, t ); }
static void x_glTexCoord1fv( const GLfloat *v ) { glq_texcoord( v[0], 0.0f ); }
static void x_glTexCoord3fv( const GLfloat *v ) { glq_texcoord( v[0], v[1] ); }
static void x_glTexCoord4fv( const GLfloat *v ) { glq_texcoord( v[0], v[1] ); }

/* ---- primitives: everything goes through the queue (recorded or passed to ZZGL, which splits
 * TRIANGLES / QUADS runs over 60 vertices: ZZGL's Begin/End buffer holds 64 and Xash3D draws
 * every particle of CL_DrawEFX in ONE glBegin(GL_QUADS), build 4's GL_OUT_OF_MEMORY bursts) ---- */
static void x_glBegin( GLenum mode ) { pend_flush(); glq_begin( mode ); }
static void x_glEnd( void ) { glq_end(); }
static void x_glVertex2f( GLfloat x, GLfloat y ) { glq_vertex( x, y, 0.0f ); }
static void x_glVertex3f( GLfloat x, GLfloat y, GLfloat z ) { glq_vertex( x, y, z ); }
static void x_glVertex3fv( const GLfloat *v ) { glq_vertex( v[0], v[1], v[2] ); }

/* ---- matrices: adapters for the double variants ---- */
static void x_glLoadMatrixd( const GLdouble *m ) { float f[16]; int i; for( i = 0; i < 16; i++ ) f[i] = (float)m[i]; zzglLoadMatrixf( f ); }
static void x_glMultMatrixd( const GLdouble *m ) { float f[16]; int i; for( i = 0; i < 16; i++ ) f[i] = (float)m[i]; zzglMultMatrixf( f ); }
static void x_glRotated( GLdouble a, GLdouble x, GLdouble y, GLdouble z ) { zzglRotatef( (float)a, (float)x, (float)y, (float)z ); }
static void x_glScaled( GLdouble x, GLdouble y, GLdouble z ) { zzglScalef( (float)x, (float)y, (float)z ); }
static void x_glTranslated( GLdouble x, GLdouble y, GLdouble z ) { zzglTranslatef( (float)x, (float)y, (float)z ); }

/* ---- queries ---- */
static GLboolean x_glIsEnabled( GLenum cap ) { (void)cap; return 0; }
static GLboolean x_glIsTexture( GLuint t ) { return t != 0; }
static GLboolean x_glIsList( GLuint l ) { (void)l; return 0; }
static void x_glGetIntegerv( GLenum pname, GLint *params );
static void x_glGetBooleanv( GLenum pname, GLboolean *p ) { GLint v = 0; x_glGetIntegerv( pname, &v ); *p = v ? 1 : 0; }
static void x_glGetDoublev( GLenum pname, GLdouble *p ) { float f[16]; zzglGetFloatv( pname, f ); p[0] = f[0]; }
static void x_glGetTexEnviv( GLenum target, GLenum pname, GLint *p ) { (void)target; (void)pname; *p = 0; }
static void x_glGetTexLevelParameteriv( GLenum t, GLint l, GLenum pname, GLint *p ) { (void)t; (void)l; (void)pname; *p = 0; }
static void x_glGetTexLevelParameterfv( GLenum t, GLint l, GLenum pname, GLfloat *p ) { (void)t; (void)l; (void)pname; *p = 0; }
static void x_glGetClipPlane( GLenum p, GLdouble *e ) { (void)p; e[0] = e[1] = e[2] = e[3] = 0.0; }
static void x_glGetTexImage( GLenum t, GLint l, GLenum f, GLenum ty, void *p ) { (void)t; (void)l; (void)f; (void)ty; (void)p; }
static void x_glDrawPixels( GLsizei w, GLsizei h, GLenum f, GLenum t, const void *p ) { (void)w; (void)h; (void)f; (void)t; (void)p; }

/* ---- vertex arrays, implemented on the immediate mode ----
 * The studio renderer (characters, every .mdl) draws with glVertexPointer/glColorPointer/
 * glTexCoordPointer + glDrawElements by default (ref/gl/gl_studio.c, r_studio_drawelements 1):
 * with these as no-ops the A0 build 3 hardware run showed the world but NO characters.  The
 * emulation below replays the arrays through the queue's Begin/Vertex, which is what the
 * immediate path would have cost anyway.  GL_TRIANGLES runs are split into 20-triangle
 * Begin/End blocks (ZZGL_MAX_VERTS is 64); the other modes cannot be split and never exceed it
 * in ref_gl. */
typedef struct { GLint size; GLenum type; GLsizei stride; const unsigned char *ptr; int on; } xacp_array_t;
static xacp_array_t g_arr_v, g_arr_c, g_arr_t;   /* vertex / color / texcoord */

static const unsigned char *arr_elem( const xacp_array_t *a, GLuint i, unsigned esz )
{
	GLsizei st = a->stride ? a->stride : (GLsizei)( (unsigned)a->size * esz );
	return a->ptr + (unsigned long)i * (unsigned long)st;
}
static void arr_emit( GLuint i )
{
	if( g_arr_c.on && g_arr_c.ptr )
	{
		const unsigned char *p = arr_elem( &g_arr_c, i, ( g_arr_c.type == 0x1406 /*GL_FLOAT*/ ) ? 4u : 1u );
		if( g_arr_c.type == 0x1401 /*GL_UNSIGNED_BYTE*/ )
		{
			if( g_arr_c.size >= 4 ) glq_color( p[0] / 255.0f, p[1] / 255.0f, p[2] / 255.0f, p[3] / 255.0f );
			else glq_color( p[0] / 255.0f, p[1] / 255.0f, p[2] / 255.0f, 1.0f );
		}
		else if( g_arr_c.type == 0x1406 )
		{
			const GLfloat *f = (const GLfloat *)p;
			glq_color( f[0], f[1], f[2], ( g_arr_c.size >= 4 ) ? f[3] : 1.0f );
		}
	}
	if( g_arr_t.on && g_arr_t.ptr && g_arr_t.type == 0x1406 )
	{
		const GLfloat *f = (const GLfloat *)arr_elem( &g_arr_t, i, 4u );
		glq_texcoord( f[0], f[1] );
	}
	if( g_arr_v.on && g_arr_v.ptr && g_arr_v.type == 0x1406 )
	{
		const GLfloat *f = (const GLfloat *)arr_elem( &g_arr_v, i, 4u );
		if( g_arr_v.size >= 3 ) glq_vertex( f[0], f[1], f[2] );
		else glq_vertex( f[0], f[1], 0.0f );
	}
}
static GLuint arr_index( const void *ind, GLenum type, GLsizei k )
{
	switch( type )
	{
	case 0x1401: return ((const unsigned char *)ind)[k];
	case 0x1403: return ((const unsigned short *)ind)[k];        /* GL_UNSIGNED_SHORT: gl_studio */
	default:     return (GLuint)((const unsigned int *)ind)[k];  /* GL_UNSIGNED_INT */
	}
}
static void x_glEnableClientState( GLenum a )
{
	if( a == 0x8074 ) g_arr_v.on = 1;          /* GL_VERTEX_ARRAY */
	else if( a == 0x8076 ) g_arr_c.on = 1;     /* GL_COLOR_ARRAY */
	else if( a == 0x8078 ) g_arr_t.on = 1;     /* GL_TEXTURE_COORD_ARRAY; GL_NORMAL_ARRAY: no lighting on RasterIX */
}
static void x_glDisableClientState( GLenum a )
{
	if( a == 0x8074 ) g_arr_v.on = 0;
	else if( a == 0x8076 ) g_arr_c.on = 0;
	else if( a == 0x8078 ) g_arr_t.on = 0;
}
static void x_glVertexPointer( GLint size, GLenum type, GLsizei stride, const void *p ) { g_arr_v.size = size; g_arr_v.type = type; g_arr_v.stride = stride; g_arr_v.ptr = (const unsigned char *)p; }
static void x_glColorPointer( GLint size, GLenum type, GLsizei stride, const void *p ) { g_arr_c.size = size; g_arr_c.type = type; g_arr_c.stride = stride; g_arr_c.ptr = (const unsigned char *)p; }
static void x_glTexCoordPointer( GLint size, GLenum type, GLsizei stride, const void *p ) { g_arr_t.size = size; g_arr_t.type = type; g_arr_t.stride = stride; g_arr_t.ptr = (const unsigned char *)p; }
/* ---- build 97, MESHIDX=1 (off by default): an indexed triangle list is given to the queue with each
 * of its vertices ONCE.  ref_gl draws the studio models with glDrawRangeElements( GL_TRIANGLES )
 * (r_studio_drawelements, on by default): unrolled as below, a vertex goes through the colour,
 * texture-coordinate and vertex calls, the record, the replay and ZZGL's transform for every
 * triangle that uses it.  A4000, 17/11, EMITPROF: 8 682 vertices of models a frame for 3 544
 * triangles, 0.7 us each at the record alone.
 * The list is cut in blocks of at most 60 different vertices; a block is one glq_begin, its
 * vertices in the order they are first met, and glq_end_indexed with the triangles as triples of
 * positions in the block.  The triangles, their order and the three vertices of each are those of
 * the unrolled list.  An index past the table (never from gl_studio.c): the unrolled way. */
#define IX_MAX 65536u
#define IX_BLOCK_VERTS 60u
#define IX_BLOCK_IDX 600u
static int g_meshidx;
static unsigned short g_ix_stamp[IX_MAX], g_ix_gen;
static unsigned char g_ix_local[IX_MAX];
static unsigned g_ix_blocks, g_ix_tris, g_ix_verts;
void xacp_gl_set_meshidx( int on ) { g_meshidx = on ? 1 : 0; }
int  xacp_gl_meshidx( void ) { return g_meshidx; }
void xacp_gl_meshidx_stats( unsigned v[3] ) { v[0] = g_ix_blocks; v[1] = g_ix_tris; v[2] = g_ix_verts; }
static int draw_elements_indexed( GLsizei count, GLenum type, const void *indices )
{
	GLsizei k;
	if( type != 0x1401 && type != 0x1403 )
		for( k = 0; k < count; k++ ) if( arr_index( indices, type, k ) >= IX_MAX ) return 0;
	for( k = 0; k + 2 < count; )
	{
		unsigned char loc[IX_BLOCK_IDX];
		unsigned nu = 0u, nl = 0u;
		if( ++g_ix_gen == 0u ) { memset( g_ix_stamp, 0, sizeof( g_ix_stamp )); g_ix_gen = 1u; }
		glq_begin( ZGL_TRIANGLES );
		while( k + 2 < count && nl + 3u <= IX_BLOCK_IDX )
		{
			GLuint i[3];
			unsigned need, j;
			i[0] = arr_index( indices, type, k ); i[1] = arr_index( indices, type, k + 1 ); i[2] = arr_index( indices, type, k + 2 );
			need = ( g_ix_stamp[i[0]] != g_ix_gen ) + ( i[1] != i[0] && g_ix_stamp[i[1]] != g_ix_gen )
			     + ( i[2] != i[0] && i[2] != i[1] && g_ix_stamp[i[2]] != g_ix_gen );
			if( nu + need > IX_BLOCK_VERTS ) break;            /* the block is full: this triangle opens the next */
			for( j = 0; j < 3u; j++ )
			{
				if( g_ix_stamp[i[j]] != g_ix_gen ) { g_ix_stamp[i[j]] = g_ix_gen; g_ix_local[i[j]] = (unsigned char)nu++; arr_emit( i[j] ); }
				loc[nl++] = g_ix_local[i[j]];
			}
			k += 3;
		}
		glq_end_indexed( loc, nl );
		g_ix_blocks++; g_ix_tris += nl / 3u; g_ix_verts += nu;
	}
	return 1;
}
static void x_glDrawElements( GLenum mode, GLsizei count, GLenum type, const void *indices )
{
	GLsizei k;
	if( !g_arr_v.on || !g_arr_v.ptr || !indices || count <= 0 ) return;
	pend_flush();
	if( mode == ZGL_TRIANGLES )
	{
		if( g_meshidx && draw_elements_indexed( count, type, indices )) return;   /* build 97 */
		for( k = 0; k < count; )
		{
			GLsizei n = count - k;
			if( n > 60 ) n = 60;                       /* 20 triangles a block, under ZZGL_MAX_VERTS */
			glq_begin( ZGL_TRIANGLES );
			for( ; n; n--, k++ ) arr_emit( arr_index( indices, type, k ));
			glq_end();
		}
		return;
	}
	glq_begin( mode );
	for( k = 0; k < count; k++ ) arr_emit( arr_index( indices, type, k ));
	glq_end();
}
static void x_glDrawArrays( GLenum mode, GLint first, GLsizei count )
{
	GLsizei k;
	if( !g_arr_v.on || !g_arr_v.ptr || count <= 0 ) return;
	pend_flush();
	if( mode == ZGL_TRIANGLES )
	{
		for( k = 0; k < count; )
		{
			GLsizei n = count - k;
			if( n > 60 ) n = 60;
			glq_begin( ZGL_TRIANGLES );
			for( ; n; n--, k++ ) arr_emit( (GLuint)( first + k ));
			glq_end();
		}
		return;
	}
	glq_begin( mode );
	for( k = 0; k < count; k++ ) arr_emit( (GLuint)( first + k ));
	glq_end();
}
static void x_glArrayElement( GLint i ) { arr_emit( (GLuint)i ); }

/* glGetIntegerv: ZZGL only answers GL_MAX_TEXTURE_SIZE and leaves anything else UNWRITTEN
 * (and counts an error); ref_gl's GL_InitExtensions reads several other caps into glConfig,
 * which therefore held stack garbage on builds 1-3.  Everything unknown is now 0, the
 * single-TMU unit counts are 1. */
static void x_glGetIntegerv( GLenum pname, GLint *params )
{
	*params = 0;
	switch( pname )
	{
	case ZGL_MAX_TEXTURE_SIZE: zzglGetIntegerv( pname, params ); return;
	case 0x84E2:                                   /* GL_MAX_TEXTURE_UNITS_ARB */
	case 0x8871:                                   /* GL_MAX_TEXTURE_COORDS_ARB */
	case 0x8872: *params = 1; return;              /* GL_MAX_TEXTURE_IMAGE_UNITS_ARB */
	default: return;
	}
}

/* no-ops: no equivalent on RasterIX G4C, ref_gl works without them */
#define NOP0( n ) static void n( void ) { }
#define NOP1( n, a ) static void n( a x ) { (void)x; }
#define NOP2( n, a, b ) static void n( a x, b y ) { (void)x; (void)y; }
#define NOP3( n, a, b, c ) static void n( a x, b y, c z ) { (void)x; (void)y; (void)z; }
static void x_glAccum( GLenum op, GLfloat v ) { (void)op; (void)v; }
NOP3( x_glIndexPointer, GLenum, GLsizei, const void * )
NOP3( x_glNormalPointer, GLenum, GLsizei, const void * )
NOP3( x_glTexGenf, GLenum, GLenum, GLfloat )
NOP3( x_glTexGenfv, GLenum, GLenum, const GLfloat * )
NOP3( x_glTexGeni, GLenum, GLenum, GLint )
NOP3( x_glNormal3f, GLfloat, GLfloat, GLfloat )
NOP1( x_glNormal3fv, const GLfloat * )
NOP1( x_glLineWidth, GLfloat )
NOP1( x_glPointSize, GLfloat )
NOP2( x_glRasterPos2f, GLfloat, GLfloat )
NOP1( x_glPushAttrib, GLbitfield )
NOP0( x_glPopAttrib )
NOP3( x_glStencilFunc, GLenum, GLint, GLuint )
NOP1( x_glStencilMask, GLuint )
NOP3( x_glStencilOp, GLenum, GLenum, GLenum )
NOP1( x_glClearStencil, GLint )
NOP2( x_glPixelStoref, GLenum, GLfloat )
NOP2( x_glPixelStorei, GLenum, GLint )
/* ref_gl makes a GL_TEXTURE_1D of every picture wider than one pixel and one pixel high
   (gl_image.c, "trying to determine texture type"), and these two were no-ops: those pictures were
   never uploaded and their draws had no texture at all, while ZZGL refused the matching
   glEnable/glDisable( GL_TEXTURE_1D ) (529 times each in c2a5f on the A4000, 13/11).  The RasterIX
   has one kind of texture: a 1D texture is a 2D texture one line high. */
static void x_glTexImage1D( GLenum t, GLint l, GLint i, GLsizei w, GLint b, GLenum f, GLenum ty, const void *p )
{
	(void)t; x_glTexImage2D( ZGL_TEXTURE_2D, l, i, w, 1, b, f, ty, p );
}
static void x_glTexSubImage1D( GLenum t, GLint l, GLint x, GLsizei w, GLenum f, GLenum ty, const void *p )
{
	(void)t; x_glTexSubImage2D( ZGL_TEXTURE_2D, l, x, 0, w, 1, f, ty, p );
}
static void x_glCopyTexImage1D( GLenum t, GLint l, GLenum i, GLint x, GLint y, GLsizei w, GLint b ) { (void)t; (void)l; (void)i; (void)x; (void)y; (void)w; (void)b; }
static void x_glCopyTexImage2D( GLenum t, GLint l, GLenum i, GLint x, GLint y, GLsizei w, GLsizei h, GLint b ) { (void)t; (void)l; (void)i; (void)x; (void)y; (void)w; (void)h; (void)b; }
static void x_glCopyTexSubImage1D( GLenum t, GLint l, GLint xo, GLint x, GLint y, GLsizei w ) { (void)t; (void)l; (void)xo; (void)x; (void)y; (void)w; }
static void x_glCopyTexSubImage2D( GLenum t, GLint l, GLint xo, GLint yo, GLint x, GLint y, GLsizei w, GLsizei h ) { (void)t; (void)l; (void)xo; (void)yo; (void)x; (void)y; (void)w; (void)h; }
static void x_glPolygonOffset( GLfloat factor, GLfloat units ) { glq_polygon_offset( factor, units ); }
NOP1( x_glPolygonStipple, const GLubyte * )
NOP2( x_glClipPlane, GLenum, const GLdouble * )
NOP2( x_glFogfv, GLenum, const GLfloat * )
NOP2( x_glFogf, GLenum, GLfloat )
NOP2( x_glFogi, GLenum, GLint )

typedef struct { const char *name; void *fn; } glent_t;
#define Z( n ) { #n, (void *)zz##n }
#define A( n ) { #n, (void *)x_##n }
static const glent_t g_gl[] = {
	Z( glClearColor ), A( glClear ), A( glAlphaFunc ), A( glBlendFunc ), A( glCullFace ), Z( glDrawBuffer ), Z( glReadBuffer ),
	A( glAccum ), A( glEnable ), A( glDisable ), A( glEnableClientState ), A( glDisableClientState ), A( glGetBooleanv ),
	A( glGetDoublev ), Z( glGetFloatv ), A( glGetIntegerv ), Z( glGetError ), Z( glGetString ), A( glFinish ), A( glFlush ),
	Z( glClearDepth ), A( glDepthFunc ), A( glDepthMask ), A( glDepthRange ), A( glFrontFace ), A( glDrawElements ),
	A( glDrawArrays ), A( glColorMask ), A( glIndexPointer ), A( glVertexPointer ), A( glNormalPointer ), A( glColorPointer ),
	A( glTexCoordPointer ), A( glArrayElement ), A( glColor3f ), A( glColor3fv ), A( glColor4f ), A( glColor4fv ),
	A( glColor3ub ), A( glColor4ub ), A( glColor4ubv ), A( glTexCoord1f ), A( glTexCoord2f ), A( glTexCoord3f ),
	A( glTexCoord4f ), A( glTexCoord1fv ), A( glTexCoord2fv ), A( glTexCoord3fv ), A( glTexCoord4fv ), A( glTexGenf ),
	A( glTexGenfv ), A( glTexGeni ), A( glVertex2f ), A( glVertex3f ), A( glVertex3fv ), A( glNormal3f ), A( glNormal3fv ),
	A( glBegin ), A( glEnd ), A( glLineWidth ), A( glPointSize ), A( glMatrixMode ), Z( glOrtho ), A( glRasterPos2f ),
	Z( glFrustum ), A( glViewport ), Z( glPushMatrix ), Z( glPopMatrix ), A( glPushAttrib ), A( glPopAttrib ),
	Z( glLoadIdentity ), A( glLoadMatrixd ), Z( glLoadMatrixf ), A( glMultMatrixd ), Z( glMultMatrixf ), A( glRotated ),
	Z( glRotatef ), A( glScaled ), Z( glScalef ), A( glTranslated ), Z( glTranslatef ), A( glReadPixels ), A( glDrawPixels ),
	A( glStencilFunc ), A( glStencilMask ), A( glStencilOp ), A( glClearStencil ), A( glIsEnabled ), A( glIsList ),
	A( glIsTexture ), A( glTexEnvf ), A( glTexEnvfv ), A( glTexEnvi ), A( glTexParameterf ), A( glTexParameterfv ),
	A( glTexParameteri ), Z( glHint ), A( glPixelStoref ), A( glPixelStorei ), A( glGenTextures ), A( glDeleteTextures ),
	A( glBindTexture ), A( glTexImage1D ), A( glTexImage2D ), A( glTexSubImage1D ), A( glTexSubImage2D ),
	A( glCopyTexImage1D ), A( glCopyTexImage2D ), A( glCopyTexSubImage1D ), A( glCopyTexSubImage2D ), A( glScissor ),
	A( glGetTexImage ), A( glGetTexEnviv ), A( glPolygonOffset ), A( glPolygonMode ), A( glPolygonStipple ), A( glClipPlane ),
	A( glGetClipPlane ), A( glShadeModel ), A( glGetTexLevelParameteriv ), A( glGetTexLevelParameterfv ), A( glFogfv ),
	A( glFogf ), A( glFogi ),
	{ 0, 0 }
};

void *zzhl_gl_proc( const char *name )
{
	const glent_t *e;
	for( e = g_gl; e->name; e++ ) if( !strcmp( e->name, name )) return e->fn;
	return 0;   /* every extension: not supported (one TMU, two-pass lightmaps) */
}

/* GL_SwapBuffers (xacp_video.c): the frame's last flush and the per-frame statistics */
void xacp_gl_frame_end( void )
{
	pend_flush();
	glq_frame_end();
}
