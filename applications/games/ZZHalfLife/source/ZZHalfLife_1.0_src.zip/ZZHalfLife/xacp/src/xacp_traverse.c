/* Campaign traversal test for level transitions and save-state growth.
 * TRAVERSE=1 follows the campaign's changelevel links without player input.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include "common.h"
#include "server.h"
#include "client.h"                        /* cls.state (the server killed by a Host_Error) */
#include "fscallback.h"                    /* GI, the game's gameinfo (older copies of the saves) */
#include <malloc.h>
#include <stdlib.h>

extern int  zzhl_option_int( const char *key, int def );
extern const char *zzhl_option( const char *key );
extern unsigned zzhl_heap_used( void );
extern unsigned zzhl_heap_peak( void );
extern unsigned zzhl_stack_used( void );                                                   /* xacp_libc.c */
extern void zzhl_fs_save_memory( unsigned *files, unsigned *bytes, unsigned *taken, unsigned *largest_sav );   /* xacp_fs.c */
extern unsigned zzhl_fs_scratch_size( const char *path );
extern void zzhl_fs_save_stats( unsigned *written, unsigned *read, unsigned *bad );
extern void xacp_fs_disk_saves_only( const char *prefix );
extern int  xacp_chapter_count( void );
extern const char *xacp_chapter_title( int c );
extern const char *xacp_chapter_maplist( int c );
extern int  xacp_chapter_of( const char *map );

/* ---- for every game: no older copies of the autosave and the quick save ----
 * Xash3D keeps two (autosave01, autosave02, quick01, quick02: SAVE_AGED_COUNT, gameinfo.c, which
 * accepts 2 at the least from gameinfo.txt) for its load menu.  Here the A0 has no menu, the copies
 * never reach the disk (the launcher's file service cannot rename) and are gone at the exit: they
 * only took Core1's memory, a save each (up to ~2.8 MiB at the end of Office Complex).  With 0 the
 * new save replaces the old one (AgeSaveList renames nothing).  SAVECOPIES=<n> brings them back. */
static void saves_once( void )
{
	static int done;
	int keep;
	gameinfo_t *gi;
	if( done || !FI || !FI->GameInfo ) return;
	done = 1;
	keep = zzhl_option_int( "SAVECOPIES", 0 );
	if( keep < 0 ) keep = 0;
	if( keep > 99 ) keep = 99;
	gi = (gameinfo_t *)FI->GameInfo;
	gi->autosave_aged_count = gi->quicksave_aged_count = keep;
	Con_Printf( "ZZHalfLife: older copies of the autosave and the quick save kept in memory: %d (SAVECOPIES=; Xash3D's 2 never reached the disk here)\n", keep );
}

#define TR_MAX  128
#define TR_NAME 24
enum { ST_WAIT_GAME = 0, ST_STAY, ST_LEAVE, ST_RELOAD_LEAVE, ST_RELOAD_WAIT };
static int    g_tr = -1;                   /* -1 not decided yet, 0 off, 1 running */
static char   g_list[TR_MAX][TR_NAME];
static unsigned char g_seen[TR_MAX];
static int    g_nlist, g_state, g_stay, g_quick_every, g_maps_done, g_jumps, g_problems, g_tagn, g_retry;
static char   g_cur[TR_NAME], g_target[TR_NAME], g_how[96];
static double g_t_issue, g_t_active, g_t_start, g_load_s;
static unsigned g_save_kib, g_save_ms, g_reload_ms;
static int    g_save_ok, g_reloaded;
static int    g_again, g_refusals;     /* back after a refused transition; how many */
static struct { unsigned v; char map[TR_NAME]; } g_max_heap, g_max_saves, g_max_save, g_max_write;
static struct { unsigned v; char map[TR_NAME]; } g_min_tex = { 0xFFFFFFFFu, "" };   /* the most loaded map in textures */
extern void zzhl_pool_status( unsigned *free_kib, unsigned *largest_kib, unsigned *min_free_kib, int reset_min );   /* xacp_video.c */
extern void zzgl_tex_counts( unsigned *uploads, unsigned *downscaled, unsigned *refused, unsigned *evicted );

/* the traversal's lines also go to PROGDIR:data/zzhl_trav.txt, written again every 5 maps and at the
   end: the console ring (256 KiB) holds ~2 KiB a map and may lose the first maps of a 103-map run */
static char g_rep[96 * 1024];
static unsigned g_rep_n;
static void tr_print( const char *fmt, ... ) __attribute__(( format( printf, 1, 2 )));
static void tr_print( const char *fmt, ... )
{
	char line[512];
	va_list ap;
	unsigned l;
	va_start( ap, fmt );
	Q_vsnprintf( line, sizeof( line ), fmt, ap );
	va_end( ap );
	Con_Printf( "%s", line );
	l = (unsigned)strlen( line );
	if( g_rep_n + l < sizeof( g_rep )) { memcpy( g_rep + g_rep_n, line, l ); g_rep_n += l; }
}
static void rep_flush( void )
{
	file_t *f = FS_Open( "zzhl_trav.txt", "wb", true );
	if( !f ) return;
	FS_Write( f, g_rep, g_rep_n );
	FS_Close( f );
}

static void lower( char *d, const char *s, size_t cap )
{
	size_t i;
	for( i = 0; s[i] && i + 1 < cap; i++ ) d[i] = ( s[i] >= 'A' && s[i] <= 'Z' ) ? (char)( s[i] + 32 ) : s[i];
	d[i] = 0;
}
static int list_index( const char *m )
{
	int i;
	for( i = 0; i < g_nlist; i++ ) if( !Q_stricmp( g_list[i], m )) return i;
	return -1;
}
static int in_game( void ) { return CL_Active() && sv.state == ss_active; }
static char tag( void ) { return (char)( 'a' + ( g_tagn++ % 26 )); }
static void note_max( unsigned v, unsigned *best, char *map )
{
	if( v > *best ) { *best = v; Q_strncpy( map, g_cur, TR_NAME ); }
}

static void traverse_init( void )
{
	int c, n = xacp_chapter_count(), i;
	const char *from = zzhl_option( "TRAVFROM" );
	g_tr = zzhl_option_int( "TRAVERSE", 0 ) ? 1 : 0;
	if( !g_tr ) return;
	g_stay = zzhl_option_int( "TRAVTIME", 3 );
	if( g_stay < 1 ) g_stay = 1;
	g_quick_every = zzhl_option_int( "TRAVQUICK", 5 );
	for( c = 1; c <= n; c++ )
	{   /* the chapters 1.. in the game's order, then 0 (the Hazard Course) */
		const char *p = xacp_chapter_maplist( c == n ? 0 : c );
		while( *p && g_nlist < TR_MAX )
		{
			char m[TR_NAME];
			unsigned l = 0;
			while( *p == ' ' ) p++;
			while( p[l] && p[l] != ' ' && l + 1 < sizeof( m )) { m[l] = p[l]; l++; }
			m[l] = 0;
			p += l;
			while( *p && *p != ' ' ) p++;
			if( l && FS_FileExists( va( "maps/%s.bsp", m ), false )) Q_strncpy( g_list[g_nlist++], m, TR_NAME );
		}
	}
	if( from && from[0] && ( i = list_index( from )) > 0 ) memset( g_seen, 1, (size_t)i );
	xacp_fs_disk_saves_only( "trav" );
	tr_print( "TRAVERSE: %d maps in the game's order from %s, by their own transitions; %d s in each, \"save trav\" in each, \"save travq\" + \"load travq\" every %d; only trav* saves reach the disk\n",
		g_nlist, from && from[0] ? from : "c0a0", g_stay, g_quick_every > 0 ? g_quick_every : 0 );
	Q_strncpy( g_how, "new game", sizeof( g_how ));
	g_t_start = g_t_issue = Sys_DoubleTime();
	g_state = ST_WAIT_GAME;
}

static void ghost( void )
{
	edict_t *pl = SV_EdictNum( 1 );
	if( !pl || pl->free ) return;
	pl->v.flags |= FL_GODMODE | FL_NOTARGET;
	pl->v.movetype = MOVETYPE_NOCLIP;
	pl->v.solid = SOLID_NOT;
	SV_LinkEdict( pl, false );
}
static void arrive( double now )
{
	int i;
	lower( g_cur, sv.name, sizeof( g_cur ));
	if(( i = list_index( g_cur )) >= 0 ) g_seen[i] = 1;
	g_load_s = now - g_t_issue;
	g_t_active = now;
	g_reloaded = 0;
	g_retry = 0;
	ghost();
	g_state = ST_STAY;
}

/* "save trav", timed: the save, its packing of the levels' states, its writing to the disk */
static void save_trav( double *t_end )
{
	unsigned w0, w1, r, b;
	double t0 = Sys_DoubleTime();
	zzhl_fs_save_stats( &w0, &r, &b );
	g_save_ok = SV_SaveGame( "trav" ) ? 1 : 0;
	*t_end = Sys_DoubleTime();
	zzhl_fs_save_stats( &w1, &r, &b );
	if( w1 == w0 ) g_save_ok = g_save_ok ? 2 : 0;          /* 2: saved, not on the disk */
	g_save_ms = (unsigned)(( *t_end - t0 ) * 1000.0 );
	g_save_kib = zzhl_fs_scratch_size( "valve/save/trav.sav" ) / 1024u;
}

static void report_map( void )
{
	unsigned sf, sb, st, sl, hu = zzhl_heap_used(), hp = zzhl_heap_peak(), sk = zzhl_stack_used();
	struct mallinfo mi = mallinfo();
	int c = xacp_chapter_of( g_cur );
	char t1 = tag(), t2 = tag();
	zzhl_fs_save_memory( &sf, &sb, &st, &sl );
	g_maps_done++;
	tr_print( "TRAVERSE %c %d/%d %s (%s) %s: in the game after %.1f s; save trav %u KiB %s %u.%u s%s\n",
		t1, g_maps_done, g_nlist, g_cur, xacp_chapter_title( c ), g_how, g_load_s, g_save_kib,
		g_save_ok == 1 ? "to the disk in" : g_save_ok == 2 ? "NOT on the disk," : "REFUSED,",
		g_save_ms / 1000u, ( g_save_ms % 1000u ) / 100u,
		g_reloaded ? va( "; travq saved, loaded in %u.%u s", g_reload_ms / 1000u, ( g_reload_ms % 1000u ) / 100u ) : "" );
	{   /* the RasterIX texture memory of this map: free now, lowest since the previous map's
		   line (its load included), largest block; the most loaded map in the summary */
		unsigned tf, tl, tm, up, ds, rf, ev;
		zzhl_pool_status( &tf, &tl, &tm, 0 );
		zzgl_tex_counts( &up, &ds, &rf, &ev );
		tr_print( "TRAVERSE %c %s memory: heap %u KiB (peak %u, malloc holds %u), saves in memory %u files %u KiB (heap %u), stack %u KiB; textures %u KiB free (lowest %u, largest block %u), %u reduced and %u refused since the start\n",
			t2, g_cur, hu / 1024u, hp / 1024u, (unsigned)mi.uordblks / 1024u, sf, sb / 1024u, st / 1024u, sk / 1024u, tf, tm, tl, ds, rf );
		if( tm < g_min_tex.v ) { g_min_tex.v = tm; Q_strncpy( g_min_tex.map, g_cur, sizeof( g_min_tex.map )); }
		zzhl_pool_status( NULL, NULL, NULL, 1 );
	}
	if( g_save_ok != 1 ) g_problems++;
	note_max( hu / 1024u, &g_max_heap.v, g_max_heap.map );
	note_max( st / 1024u, &g_max_saves.v, g_max_saves.map );
	note_max( g_save_kib, &g_max_save.v, g_max_save.map );
	note_max( g_save_ms, &g_max_write.v, g_max_write.map );
	if( g_maps_done % 5 == 0 ) rep_flush();
}

static void finish( double now )
{
	int i, left = 0;
	for( i = 0; i < g_nlist; i++ ) if( !g_seen[i] ) left++;
	tr_print( "TRAVERSE done: %d maps in %.0f s, %d of the list not reached, %d jumps without a transition, %d transitions refused by the engine, %d problems (saves not on the disk, maps not reached)\n",
		g_maps_done, now - g_t_start, left, g_jumps, g_refusals, g_problems );
	for( i = 0; i < g_nlist; i++ ) if( !g_seen[i] ) tr_print( "TRAVERSE not reached: %s\n", g_list[i] );
	tr_print( "TRAVERSE most: heap %u KiB (%s), peak %u KiB; saves in memory %u KiB of heap (%s); save %u KiB (%s); writing %u.%u s (%s); stack %u KiB\n",
		g_max_heap.v, g_max_heap.map, zzhl_heap_peak() / 1024u, g_max_saves.v, g_max_saves.map, g_max_save.v, g_max_save.map,
		g_max_write.v / 1000u, ( g_max_write.v % 1000u ) / 100u, g_max_write.map, zzhl_stack_used() / 1024u );
	{
		unsigned up, ds, rf, ev;
		zzgl_tex_counts( &up, &ds, &rf, &ev );
		tr_print( "TRAVERSE textures: lowest free %u KiB of 16384 (%s); %u uploads, %u reduced, %u refused\n",
			g_min_tex.v, g_min_tex.map, up, ds, rf );
	}
	tr_print( "TRAVERSE: these lines are in PROGDIR:data/zzhl_trav.txt too\n" );
	rep_flush();
	Cbuf_AddText( "quit\n" );
	g_tr = 0;
}

/* the trigger_changelevel blocks of an entity string: cb( map (lower case), landmark, ctx ) for each */
static void each_changelevel( const char *e, void ( *cb )( const char *map, const char *lm, void *ctx ), void *ctx )
{
	char cls[64], map[TR_NAME], lm[TR_NAME], key[64], val[64];
	int depth = 0;
	cls[0] = map[0] = lm[0] = 0;
	while( *e )
	{   /* { "key" "value" ... } blocks */
		if( *e == '{' ) { depth = 1; cls[0] = map[0] = lm[0] = 0; e++; continue; }
		if( *e == '}' )
		{
			if( depth && !Q_stricmp( cls, "trigger_changelevel" ) && map[0] ) cb( map, lm, ctx );
			depth = 0; e++; continue;
		}
		if( *e == '"' && depth )
		{
			const char *k = ++e;
			size_t n;
			while( *e && *e != '"' ) e++;
			n = (size_t)( e - k ); if( n >= sizeof( key )) n = sizeof( key ) - 1;
			memcpy( key, k, n ); key[n] = 0;
			if( *e ) e++;
			while( *e == ' ' || *e == '\t' ) e++;
			if( *e != '"' ) continue;
			k = ++e;
			while( *e && *e != '"' ) e++;
			n = (size_t)( e - k ); if( n >= sizeof( val )) n = sizeof( val ) - 1;
			memcpy( val, k, n ); val[n] = 0;
			if( *e ) e++;
			if( !Q_stricmp( key, "classname" )) Q_strncpy( cls, val, sizeof( cls ));
			else if( !Q_stricmp( key, "map" )) lower( map, val, sizeof( map ));
			else if( !Q_stricmp( key, "landmark" )) Q_strncpy( lm, val, sizeof( lm ));
			continue;
		}
		e++;
	}
}

/* the engine takes a transition with a landmark only when the new map has a
   trigger_changelevel back to the old one (sv_save.c LoadAdjacentEntities: "Level transition ERROR
   Can't find connection to <old> from <new>", Host_Error, the server killed).  c1a0b has one to c1a0c
   that c1a0c does not answer (A4000, 12/11: the traversal stopped there): a transition is taken only
   when the target's entities (its .bsp's entity lump, read through the pak) lead back. */
typedef struct { const char *want; int found; } back_ctx_t;
static void back_cb( const char *map, const char *lm, void *ctx )
{
	back_ctx_t *b = (back_ctx_t *)ctx;
	(void)lm;
	if( !Q_stricmp( map, b->want )) b->found = 1;
}
static int leads_back( const char *target, const char *from )
{
	file_t *f = FS_Open( va( "maps/%s.bsp", target ), "rb", false );
	int hdr[3], n;
	char *ents;
	back_ctx_t b;
	if( !f ) return 1;                       /* cannot tell: let the engine decide */
	if( FS_Read( f, hdr, sizeof( hdr )) != (int)sizeof( hdr ) || hdr[1] <= 0 || hdr[2] <= 0 || hdr[2] > 4 * 1024 * 1024 )
	{ FS_Close( f ); return 1; }             /* BSP v30: version, then lump 0 (entities) offset and length */
	ents = (char *)malloc( (size_t)hdr[2] + 1u );
	if( !ents ) { FS_Close( f ); return 1; }
	FS_Seek( f, hdr[1], SEEK_SET );
	n = FS_Read( f, ents, hdr[2] );
	FS_Close( f );
	ents[n > 0 ? n : 0] = 0;
	b.want = from; b.found = 0;
	each_changelevel( ents, back_cb, &b );
	free( ents );
	return b.found;
}
/* transitions the engine refused anyway (recovered by "load trav", then avoided) */
static struct { char from[TR_NAME], to[TR_NAME]; } g_bad[32];
static int g_nbad;
static int is_bad( const char *from, const char *to )
{
	int i;
	for( i = 0; i < g_nbad; i++ ) if( !Q_stricmp( g_bad[i].from, from ) && !Q_stricmp( g_bad[i].to, to )) return 1;
	return 0;
}
typedef struct { int best; char lm[TR_NAME]; int one_way; } next_ctx_t;
static void next_cb( const char *map, const char *lm, void *ctx )
{
	next_ctx_t *x = (next_ctx_t *)ctx;
	int i = list_index( map );
	if( i < 0 || g_seen[i] || !lm[0] || ( x->best >= 0 && i >= x->best ) || is_bad( g_cur, map )) return;
	if( !leads_back( map, g_cur )) { x->one_way++; return; }
	x->best = i;
	Q_strncpy( x->lm, lm, sizeof( x->lm ));
}

/* the next map: the two-way transition of this map's entities to the first map of the list not visited */
static void go_next( double now )
{
	next_ctx_t x;
	int i;
	x.best = -1; x.lm[0] = 0; x.one_way = 0;
	each_changelevel(( sv.worldmodel && sv.worldmodel->entities ) ? sv.worldmodel->entities : "", next_cb, &x );
	if( x.best >= 0 )
	{
		Q_strncpy( g_target, g_list[x.best], sizeof( g_target ));
		Q_snprintf( g_how, sizeof( g_how ), "from %s, landmark %s", g_cur, x.lm );
		Cbuf_AddText( va( "changelevel2 %s %s\n", g_target, x.lm ));
	}
	else
	{
		for( i = 0; i < g_nlist && g_seen[i]; i++ );
		if( i >= g_nlist ) { finish( now ); return; }
		Q_strncpy( g_target, g_list[i], sizeof( g_target ));
		if( xacp_chapter_of( g_target ) == 0 && xacp_chapter_of( g_cur ) != 0 )
		{   /* the Hazard Course: a game of its own */
			Q_strncpy( g_how, "new game", sizeof( g_how ));
			Cbuf_AddText( va( "map %s\n", g_target ));
		}
		else
		{
			g_jumps++;
			Q_snprintf( g_how, sizeof( g_how ), "JUMP from %s (no two-way transition to a new map%s)", g_cur, x.one_way ? ", one-way ones left" : "" );
			Cbuf_AddText( va( "changelevel %s\n", g_target ));
		}
	}
	g_t_issue = Sys_DoubleTime();          /* after the report's disk write */
	g_state = ST_LEAVE;
}

void xacp_traverse_frame( void )
{
	double now;
	saves_once();
	if( g_tr < 0 ) traverse_init();
	if( g_tr <= 0 ) return;
	now = Sys_DoubleTime();
	switch( g_state )
	{
	case ST_WAIT_GAME:                       /* a level loads: until the client is in the game */
		if( in_game()) { arrive( now ); return; }
		if( g_target[0] && g_cur[0] && sv.state == ss_dead && cls.state == ca_disconnected && now - g_t_issue > 3.0 && g_nbad < 32 )
		{   /* the engine refused the change (Host_Error, server killed): back to this map's
			   "save trav", that transition avoided from now on */
			Q_strncpy( g_bad[g_nbad].from, g_cur, TR_NAME ); Q_strncpy( g_bad[g_nbad].to, g_target, TR_NAME ); g_nbad++;
			g_refusals++;
			tr_print( "TRAVERSE %c %s -> %s refused by the engine: back to %s (load trav), another way\n", tag(), g_cur, g_target, g_cur );
			g_again = 1;
			Cbuf_AddText( "load trav\n" );
			g_t_issue = now;
			return;
		}
		if( now - g_t_issue > 240.0 )
		{
			g_problems++;
			tr_print( "TRAVERSE %c %s: NOT in the game after 240 s, stopping\n", tag(), g_target[0] ? g_target : "start" );
			finish( now );
		}
		return;
	case ST_STAY:                            /* in the game: stay, save, next */
		if( !in_game() || Q_stricmp( sv.name, g_cur ))
		{   /* the game changed level by itself (or reloaded) */
			Q_snprintf( g_how, sizeof( g_how ), "from %s by the game", g_cur );
			g_t_issue = now;
			g_state = ST_WAIT_GAME;
			return;
		}
		if( now - g_t_active < (double)g_stay ) return;
		if( g_again ) { g_again = 0; go_next( now ); return; }   /* back after a refusal: reported already */
		{
			double t_end;
			save_trav( &t_end );
			if( g_quick_every > 0 && ( g_maps_done + 1 ) % g_quick_every == 0 && g_save_ok )
			{
				if( SV_SaveGame( "travq" ))
				{
					Cbuf_AddText( "load travq\n" );
					g_t_issue = Sys_DoubleTime();
					g_state = ST_RELOAD_LEAVE;
					return;
				}
			}
		}
		report_map();
		go_next( now );
		return;
	case ST_RELOAD_LEAVE:                    /* "load travq": the level goes, then comes back */
		if( !in_game() || now - g_t_issue > 15.0 ) g_state = ST_RELOAD_WAIT;
		return;
	case ST_RELOAD_WAIT:
		if( in_game())
		{
			ghost();
			g_reload_ms = (unsigned)(( now - g_t_issue ) * 1000.0 );
			g_reloaded = 1;
			report_map();
			go_next( now );
			return;
		}
		if( now - g_t_issue > 240.0 ) { g_problems++; tr_print( "TRAVERSE %c %s: NOT back in the game 240 s after load travq, stopping\n", tag(), g_cur ); finish( now ); }
		return;
	case ST_LEAVE:                           /* a change of level asked: the old level goes */
		if( !in_game() || Q_stricmp( sv.name, g_cur )) { g_state = ST_WAIT_GAME; return; }
		if( now - g_t_issue > 20.0 )
		{   /* the change did not happen (a landmark the engine refused...): once without it, then skip */
			int i = list_index( g_target );
			if( !g_retry++ )
			{
				g_jumps++;
				Q_snprintf( g_how, sizeof( g_how ), "JUMP from %s (its transition failed)", g_cur );
				Cbuf_AddText( va( "changelevel %s\n", g_target ));
				g_t_issue = now;
				return;
			}
			tr_print( "TRAVERSE %c %s: could not be reached from %s, skipped\n", tag(), g_target, g_cur );
			if( i >= 0 ) g_seen[i] = 1;
			g_problems++;
			g_retry = 0;
			go_next( now );
		}
		return;
	}
}
