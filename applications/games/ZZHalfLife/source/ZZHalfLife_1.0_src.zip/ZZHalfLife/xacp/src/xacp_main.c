/* Entry point for the Xash3D engine image on Core1.
 * Initializes the game module and enters the engine using the stage-1 runtime.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include "common.h"
#include <setjmp.h>
#include <stdlib.h>
#include "xacp_rt.h"
#include "zzhl_core.h"
#include "zzq2_res.h"

extern const zzhl_rt_t *zzhl_rt;
extern void zzhl_log( const char *s );
extern void zzhl_video_report( void );
extern void zzhl_fs_stats( unsigned *req, unsigned *bytes, unsigned *hit, unsigned *miss, unsigned *direct, unsigned *svc, unsigned *neg, unsigned *writes );
extern void zzhl_fs_stats2( unsigned *short_reads, unsigned *verify_mismatch, int *verify_on );
extern void xacp_fs_set_verify( int on );
extern void xacp_fs_set_disk_saves( int on );
extern void zzhl_fs_save_stats( unsigned *written, unsigned *read, unsigned *bad );
extern void zzhl_fs_write_stats( unsigned *refused, unsigned *given_up );
extern unsigned zzhl_heap_peak( void );
extern int EXPORT Host_Main( int argc, char **argv, const char *progname, int bChangeGame, pfnChangeGame pChangeGame );
extern void __libc_init_array( void );

/* the header the loader checks; tools/mkcore.py fills the sizes */
__attribute__((section(".zzhlhdr"), used))
const zzhl_core_hdr_t zzhl_core_hdr = {
	ZZHL_CORE_MAGIC0, ZZHL_CORE_MAGIC1, ZZHL_CORE_VERSION, sizeof( zzhl_core_hdr_t ),
	ZZHL_CORE_LOAD, 0, 0, 0, 0, 0, ZZHL_VID_W, ZZHL_VID_H, { 0, 0, 0, 0 }
};

/* the identity the 68k wrapper looks for in the stage-1 blob is in zzhl_glue.c; this one is
   printed by the engine */
#define ZZHL_CORE_VERSION_S "1"
const char zzhl_core_ident[] = "ZZHALFLIFE-CORE-A0 " ZZHL_CORE_VERSION_S;

#define MAX_ARGS 32
static char *g_argv[MAX_ARGS];
static int g_argc;
static char g_argbuf[1024];
static int g_argpos;

static void add_arg( const char *s )
{
	size_t n = strlen( s );
	if( g_argc >= MAX_ARGS - 1 || g_argpos + n + 1 > sizeof( g_argbuf )) return;
	memcpy( g_argbuf + g_argpos, s, n + 1 );
	g_argv[g_argc++] = g_argbuf + g_argpos;
	g_argpos += (int)n + 1;
}

/* options file in the boot container (PACK, the 68k wrapper writes it: "KEY=VALUE\n" lines).
   MAP=c0a0 -> "+map c0a0"; DEV=n -> "-dev n"; CONSOLE=1 -> "-console"; ARGS=... -> appended. */
static char g_opt[2048];          /* the options file, "KEY=VALUE" lines, NUL-separated after parsing */
static unsigned g_optlen;

/* any KEY=VALUE the 68k wrapper forwarded (it forwards every argument carrying an '='):
   the value string, or NULL.  The GPU layer reads SORT, PICMIP, BINDTEST, PUMP this way. */
const char *zzhl_option( const char *key )
{
	unsigned i = 0, n = (unsigned)strlen( key );
	while( i < g_optlen )
	{
		const char *line = g_opt + i;
		unsigned len = (unsigned)strlen( line );
		if( !strncmp( line, key, n ) && line[n] == '=' ) return line + n + 1;
		i += len + 1;
	}
	return NULL;
}
int zzhl_option_int( const char *key, int def )
{
	const char *v = zzhl_option( key );
	return v ? atoi( v ) : def;
}

/* build 90, FPSMAX=n (default 72; 0 = no cap; otherwise 20 to 200): fps_max, the engine's own frame
   cap.  72 is Xash3D's default and what every run made so far: the port never set it.  A4000, 16/11: in the light scenes the engine ran its 72 frames a second (13,9 ms measured
   from one presentation to the next), the screen took 60, and the frame that found no free buffer
   was dropped (Core1/zzhl_present.c) - 6 108 frames rendered and never shown in 34 minutes.  The
   option is there to MEASURE another value against 72, launcher log against launcher log.  The
   cvar is archived, so a value typed at the console stays in config.cfg: this sets it at every
   start. */
int zzhl_fpsmax( void )
{
	int cap = zzhl_option_int( "FPSMAX", 72 );
	if( cap <= 0 ) return 0;
	return cap < 20 ? 20 : cap > 200 ? 200 : cap;
}

static void read_options( void )
{
	const unsigned char *p = (const unsigned char *)zzhl_rt->pack0_addr;
	unsigned size = zzhl_rt->pack0_size, dofs, dlen, i;
	/* Keep developer diagnostics disabled by default in release builds. */
	const char *map = NULL, *dev = "0";
	int console = 0;
	char *opt = g_opt;
	unsigned optlen = 0;
	if( size >= 12 && p[0] == 'P' && p[1] == 'A' && p[2] == 'C' && p[3] == 'K' )
	{
		dofs = p[4] | ( p[5] << 8 ) | ( p[6] << 16 ) | ( p[7] << 24 );
		dlen = p[8] | ( p[9] << 8 ) | ( p[10] << 16 ) | ( p[11] << 24 );
		for( i = 0; i + 64 <= dlen && dofs + i + 64 <= size; i += 64 )
		{
			const unsigned char *e = p + dofs + i;
			unsigned fofs = e[56] | ( e[57] << 8 ) | ( e[58] << 16 ) | ( e[59] << 24 );
			unsigned flen = e[60] | ( e[61] << 8 ) | ( e[62] << 16 ) | ( e[63] << 24 );
			if( !strncmp(( const char * )e, "zzhalflife.cfg", 56 ) && fofs + flen <= size && flen < sizeof( g_opt ))
			{
				memcpy( opt, p + fofs, flen );
				optlen = flen;
				break;
			}
		}
	}
	opt[optlen] = 0;
	g_optlen = optlen;
	{
		char *line = opt, *next;
		while( line && *line )
		{
			next = strchr( line, '\n' );
			if( next ) *next++ = 0;
			{ unsigned k = (unsigned)strlen( line ); while( k && ( line[k - 1] == '\r' || line[k - 1] == ' ' )) line[--k] = 0; }
			/* Normalize option names while preserving case-sensitive option values. */
			{ char *q = line; while( *q && *q != '=' ) { if( *q >= 'a' && *q <= 'z' ) *q = (char)( *q - 'a' + 'A' ); q++; } }
			if( !strncmp( line, "MAP=", 4 )) map = line + 4;
			else if( !strncmp( line, "DEV=", 4 )) dev = line + 4;
			else if( !strcmp( line, "CONSOLE=1" )) console = 1;
			line = next;
		}
	}
	/* the menu (FWGS mainui, linked in as the "menu" library).  Without MAP= the game starts
	   on it; MENU=0 keeps the engine from finding it (-menulib) and starts on c0a0 as before */
	if( !map ) map = zzhl_option_int( "MENU", 1 ) ? "" : "c0a0";
	{ extern void zzhl_set_date( unsigned long t ); const char *d = zzhl_option( "DATE" ); if( d ) zzhl_set_date( strtoul( d, NULL, 10 )); }   /* build 50 */
	if( zzhl_option_int( "SOAK", 0 ) || zzhl_option_int( "SURVEY", 0 ))
	{   /* SOAK=1 (xacp_soak.c) starts on SOAKFROM, quiet console unless DEV= was given;
		   SURVEY=1 too, from the first campaign map (c0a0) unless SOAKFROM= */
		const char *sf = zzhl_option( "SOAKFROM" );
		if( sf && sf[0] ) map = sf;
		else if( zzhl_option_int( "SURVEY", 0 )) map = "c0a0";
		if( !zzhl_option( "DEV" )) dev = "0";
	}
	if( zzhl_option_int( "TRAVERSE", 0 ))
	{   /* TRAVERSE=1 (xacp_traverse.c) starts a new game on c0a0, or on TRAVFROM= */
		const char *tf = zzhl_option( "TRAVFROM" );
		map = ( tf && tf[0] ) ? tf : "c0a0";
		if( !zzhl_option( "DEV" )) dev = "0";
	}
	add_arg( "zzhl" );
	add_arg( "-dev" ); add_arg( dev );
	add_arg( "-noip" );
	if( !zzhl_option_int( "MENU", 1 )) { add_arg( "-menulib" ); add_arg( "nomenu" ); }   /* build 50 */
	/* sound: xacp_snd.c on the launcher's PCM ring; the launcher's NOSOUND option clears SH_PCM_ENABLE */
	if( console ) add_arg( "-console" );
	add_arg( "-game" ); add_arg( "valve" );
	/* 0.2 s of mixed-ahead audio (engine default 0.12; the cvar's console name is _snd_mixahead,
	   NOT s_mixahead - build 7 set the wrong name and ran at the default: the 68k AHI process
	   pulls 2048 frames (93 ms) at a time, the ring held 8.8 KiB at most and 10 % of the pulls
	   came up short).  The backend caps the lead at 16 KiB of ring (186 ms) anyway.  Applied
	   after config.cfg (valve.rc's stuffcmds). */
	add_arg( "+_snd_mixahead" ); add_arg( "0.2" );
	/* Display console notifications only when developer diagnostics are enabled. */
	add_arg( "+con_notifytime" ); add_arg( atoi( dev ) > 0 ? "3" : "-1" );
	{   /* FPS=0|1|2 (default 1): the engine's own counter at the top right (cl_showfps: 1 = the
	       frames of the last second, 2 = min / current / max since the start).  The cvar is
	       archived: config.cfg keeps the last value, the option sets it at every start. */
		int fps = zzhl_option_int( "FPS", 1 );
		add_arg( "+cl_showfps" ); add_arg( fps == 2 ? "2" : fps ? "1" : "0" );
	}
	{   /* FPSMAX (zzhl_fpsmax, above), after config.cfg like the others */
		char cap[8];
		Q_snprintf( cap, sizeof( cap ), "%d", zzhl_fpsmax());
		add_arg( "+fps_max" ); add_arg( cap );
		/* The engine must honour fps_max; presentation is paced by the Amiga launcher. */
		if( zzhl_fpsmax() > 0 ) { add_arg( "+gl_vsync" ); add_arg( "0" ); }
	}
	if( zzhl_option_int( "QUICKKEYS", 1 ))
	{   /* Half-Life's own quick save / quick load keys, in case config.cfg lost them */
		add_arg( "+bind" ); add_arg( "F6" ); add_arg( "save quick" );
		add_arg( "+bind" ); add_arg( "F9" ); add_arg( "load quick" );
	}
	{   /* LOAD=<name> starts from a save on the disk (no menu in A0) instead of MAP= */
		const char *ld = zzhl_option( "LOAD" );
		if( ld && ld[0] ) { add_arg( "+load" ); add_arg( ld ); }
		else if( map[0] ) { add_arg( "+map" ); add_arg( map ); }
	}
	g_argv[g_argc] = NULL;
}

int zzhl_core_entry( const zzhl_rt_t *rt )
{
	int rc;
	unsigned req, bytes, hit, miss, direct, svc, neg, writes;
	if( !rt || rt->magic != ZZHL_RT_MAGIC || rt->version != ZZHL_RT_VERSION || rt->size < sizeof( zzhl_rt_t ))
		return -1;
	zzhl_rt = rt;
	{ extern void zzhl_stack_paint( void ); zzhl_stack_paint(); }   /* the stack's deepest use, at the end (xacp_libc.c) */
	{   /* the file calls that reach the 68k timed (xacp_disk.c) */
		extern const zzhl_rt_t *xacp_disk_wrap( const zzhl_rt_t *rt );
		zzhl_rt = xacp_disk_wrap( rt );
	}
	{   /* exit() (never reached through Host_ExitInMain, but newlib's abort/assert or a stub may call it) */
		extern jmp_buf zzhl_exit_jmp; extern int zzhl_exit_jmp_set;
		int code = setjmp( zzhl_exit_jmp );
		if( code ) { printf( "ZZHalfLife: exit(%d)\n", code ); return code; }
		zzhl_exit_jmp_set = 1;
	}
	__libc_init_array();     /* newlib init, the engine's and the menu's C++ constructors */
	zzhl_log( zzhl_core_ident );
	{   /* the HLSDK server and client are a second image (xacp_game.c, zzhl_game.h) */
		extern int zzhl_game_load( void );
		int grc = zzhl_game_load();
		if( grc ) return 100 + grc;
	}
	read_options();
	{ extern void xacp_loading_start( void ); xacp_loading_start(); }   /* the loading screen (xacp_loading.c) */
	{ extern void zzhl_status_create_ok( void ); zzhl_status_create_ok(); }   /* the launcher's display loop starts now, not two minutes later (Core1/zzhl_present.c) */
	xacp_fs_set_verify( zzhl_option_int( "VERIFY", 0 ));    /* every READAT read twice and compared */
	/* valve/save/<name>.sav to PROGDIR:data/hlsv_<name>.sav (xacp_fs.c); not
	   during SOAK=1 (06/11: a map's autosave would replace the player's autosave on the disk) */
	xacp_fs_set_disk_saves( zzhl_option_int( "SAVES", ( zzhl_option_int( "SOAK", 0 ) || zzhl_option_int( "SURVEY", 0 )) ? 0 : 1 ));
	rc = Host_Main( g_argc, g_argv, "valve", false, NULL );
	zzhl_video_report();
	zzhl_fs_stats( &req, &bytes, &hit, &miss, &direct, &svc, &neg, &writes );
	printf( "ZZHalfLife: engine returned %d; readat %u requests %u KiB, cache %u hits %u misses %u direct, service %u, absent %u, writes %u, heap peak %u KiB\n",
		rc, req, bytes / 1024u, hit, miss, direct, svc, neg, writes, zzhl_heap_peak() / 1024u );
	{
		unsigned sr, vm; int von;
		zzhl_fs_stats2( &sr, &vm, &von );
		printf( "ZZHalfLife: READAT short answers %u (retried), VERIFY=%d mismatches %u\n", sr, von, vm );
		{   /* xacp_fs.c, svc_read_whole: the files read whole are read until two answers agree */
			extern unsigned zzhl_fs_read_again( unsigned *unsure );
			unsigned un, ra = zzhl_fs_read_again( &un );
			printf( "ZZHalfLife: whole-file READs answered two ways %u (asked again), never twice the same %u\n", ra, un );
		}
		{   /* xacp_fs.c: a .cfg answered with the right size and binary bytes */
			extern void zzhl_fs_cfg_stats( unsigned v[4] );
			unsigned cv[4];
			zzhl_fs_cfg_stats( cv );
			printf( "ZZHalfLife: .cfg answered with binary data %u, read right at last %u, refused %u, configs not written back %u\n", cv[0], cv[1], cv[2], cv[3] );
		}
		{   /* build 86 (xacp_fs.c, save_peek) */
			extern void zzhl_fs_peek_retry_stats( unsigned *retries, unsigned *recovered, unsigned *lost );
			unsigned pr, pc, pl;
			zzhl_fs_peek_retry_stats( &pr, &pc, &pl );
			printf( "ZZHalfLife: save headers that did not read %u, saves read at last %u, given up for the session %u\n", pr, pc, pl );
		}
		{   /* build 34 (xacp_fs.c, bsp_check) */
			extern void zzhl_fs_bsp_stats( unsigned *checks, unsigned *bad, unsigned *fixed );
			unsigned bc, bb, bf;
			zzhl_fs_bsp_stats( &bc, &bb, &bf );
			printf( "ZZHalfLife: maps checked when read %u, found wrong %u, fixed by a new read %u\n", bc, bb, bf );
			{ extern void zzhl_fs_mdl_stats( unsigned *checks, unsigned *bad, unsigned *fixed );
			  zzhl_fs_mdl_stats( &bc, &bb, &bf );
			  printf( "ZZHalfLife: models checked when read %u, found wrong %u, fixed by a new read %u\n", bc, bb, bf ); }
			{ extern void zzhl_fs_cache_stats( unsigned *mib, unsigned *direct_hits, unsigned *kept );
			  unsigned cm, dh, kp;
			  zzhl_fs_cache_stats( &cm, &dh, &kp );
			  printf( "ZZHalfLife: block cache %u MiB: %u blocks of direct reads served from it (%u KiB not read again), %u kept\n", cm, dh, dh * 64u, kp ); }
			{ extern void zzhl_fs_answer_stats( unsigned *wrong_total, unsigned *probe_disagree );
			  unsigned wt, pd;
			  zzhl_fs_answer_stats( &wt, &pd );
			  printf( "ZZHalfLife: READAT answers with another file's size %u (asked again), file sizes answered differently %u\n", wt, pd ); }
			{ extern void zzhl_fs_crc_stats( unsigned *blocks, unsigned *bad, unsigned *fixed, unsigned *lost, int *state );
			  unsigned cb, cw, cf, cl; int cs;
			  zzhl_fs_crc_stats( &cb, &cw, &cf, &cl, &cs );
			  printf( "ZZHalfLife: pak blocks checked by CRC %u, found wrong %u, fixed by a new read %u, still wrong %u (%s)\n", cb, cw, cf, cl,
			          cs == 1 ? "pak0.crc on" : cs == -2 ? "pak0.crc made for another pak" : "no pak0.crc: tools/hl_pakcrc.py" ); }
		}
		{ unsigned w, r, b; zzhl_fs_save_stats( &w, &r, &b ); printf( "ZZHalfLife: saves written to the disk %u, read from the disk %u, refused %u\n", w, r, b ); }
		{ extern void zzhl_fs_shot_stats( unsigned *, unsigned * ); unsigned w, r; zzhl_fs_shot_stats( &w, &r );   /* build 74 */
		  printf( "ZZHalfLife: save screenshots written to the disk %u, read from the disk %u\n", w, r ); }
		{ unsigned rf, gu; zzhl_fs_write_stats( &rf, &gu ); printf( "ZZHalfLife: disk writes refused by the launcher %u, not written after a second try %u\n", rf, gu ); }
		{ extern void zzhl_fs_prefetch_stats( unsigned *files, unsigned *kib, unsigned *ms, unsigned *missing );   /* build 41 */
		  unsigned pf, pk, pm, px;
		  zzhl_fs_prefetch_stats( &pf, &pk, &pm, &px );
		  printf( "ZZHalfLife: animation files read ahead with their model %u, %u KiB, %u ms; not found in the paks %u\n", pf, pk, pm, px ); }
		{ extern void zzhl_fs_voice_stats( unsigned *sets, unsigned *files, unsigned *kib, unsigned *ms, unsigned *skipped );   /* build 42 */
		  unsigned vs, vf, vk, vm, vx;
		  zzhl_fs_voice_stats( &vs, &vf, &vk, &vm, &vx );
		  printf( "ZZHalfLife: voices, HUD and decals read ahead: %u sets (%u over VOICEMB, not read), %u files, %u KiB, %u ms\n", vs, vx, vf, vk, vm ); }
		{ extern void zzhl_fs_chapter_stats( unsigned *opened, unsigned *kib, unsigned *ms, int *on );   /* build 45 */
		  unsigned co, ck, cm; int con;
		  zzhl_fs_chapter_stats( &co, &ck, &cm, &con );
		  printf( "ZZHalfLife: chapters read whole when they opened: %u, %u KiB, %u ms%s\n", co, ck, cm, con ? "" : " (no pak0.chp, or CHAPTERS=0)" ); }
		{ extern void xacp_disk_report( void ); xacp_disk_report(); }   /* build 41 */
		{   /* the saves in memory at the end, and the stack */
			extern void zzhl_fs_save_memory( unsigned *files, unsigned *bytes, unsigned *taken, unsigned *largest_sav );
			extern unsigned zzhl_stack_used( void );
			unsigned sf, sb, st, sl;
			zzhl_fs_save_memory( &sf, &sb, &st, &sl );
			printf( "ZZHalfLife: saves in memory at the end: %u files (levels' states and saves), %u KiB (heap taken %u KiB), largest save %u KiB\n", sf, sb / 1024u, st / 1024u, sl / 1024u );
			printf( "ZZHalfLife: stack: deepest use %u KiB of %u\n", zzhl_stack_used() / 1024u, ( ZZHL_STACK_HI - ZZHL_STACK_LO ) / 1024u );
		}
	}
	{ extern void xacp_loading_report( void ); xacp_loading_report(); }   /* build 26 */
	if( rc ) { extern char zzhl_last_fatal[]; printf( "ZZHalfLife: fatal error was: %s\n", zzhl_last_fatal[0] ? zzhl_last_fatal : "(none reported)" ); }
	return rc;
}
