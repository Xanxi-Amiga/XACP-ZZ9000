/* xacp_platform.c - ZZHalfLife: engine/platform/platform.h for the XACP Core1 target (the
 * part engine/platform/dos/sys_dos.c plays for DOS): time, sleep, the few desktop calls.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include "platform/platform.h"
#include "xacp_rt.h"
#include <stdio.h>

extern const zzhl_rt_t *zzhl_rt;
extern unsigned long long zzhl_us64( void );

double Platform_DoubleTime( void )
{
	return (double)zzhl_us64() * 1.0e-6;
}

void Platform_Sleep( int msec )
{
	unsigned long long end = zzhl_us64() + (unsigned long long)msec * 1000ull;
	while( zzhl_us64() < end ) zzhl_rt->pump();
}

void Platform_ShellExecute( const char *path, const char *parms ) { }

/* XASH_MESSAGEBOX=5 (port-local value, no engine backend): Sys_Error and Host_Error pass the
 * fatal text here.  It goes to the console (the 68k-readable mirror) and is kept so that the
 * final "engine returned" line of xacp_main.c repeats it: the launcher shows only the last
 * console line, and a reader of the mirror finds the cause next to the exit statistics. */
char zzhl_last_fatal[192];
void Platform_MessageBox( const char *title, const char *message, qboolean parentMainWindow )
{
	unsigned i = 0;
	(void)parentMainWindow;
	while( i < sizeof( zzhl_last_fatal ) - 1 && message[i] ) { zzhl_last_fatal[i] = message[i] == '\n' ? ' ' : message[i]; i++; }
	zzhl_last_fatal[i] = 0;
	printf( "ZZHL: %s: %s\n", title, zzhl_last_fatal );
}
void Platform_Minimize_f( void ) { }
platform_orientation_t Platform_GetDisplayOrientation( void ) { return ORIENTATION_LANDSCAPE; }
