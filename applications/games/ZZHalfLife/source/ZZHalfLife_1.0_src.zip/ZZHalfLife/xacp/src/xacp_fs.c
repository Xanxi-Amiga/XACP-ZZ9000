/* Xash3D filesystem services for the ZZ9000 Core1 runtime.
 * Large files are read on demand through the Amiga file service; small files,
 * save data and configuration use the shared file service and memory buffers.
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "dirent.h"
#include "xacp_rt.h"

extern const zzhl_rt_t *zzhl_rt;
extern void zzhl_log( const char *s );
extern void zzhl_present_keepalive( void );   /* Core1/zzhl_present.c: the launcher's image watchdog */
extern void xacp_loading_tick( void );        /* xacp_loading.c (build 22) */
extern unsigned long long zzhl_us64( void );
static unsigned long long g_last_readat_us;   /* time of the last READAT (write guard) */

#define FS_MAX_FD        128
#define FS_MAX_SCRATCH   512           /* 48 filled up after ~12 level changes (3 save/<map>.HL? files a map,
                                          kept in memory for the whole game) and the next changelevel looped on ENOSPC */
#define FS_MAX_SVC       8
#define FS_MAX_NEG       512
#define FS_NAME_MAX      128
#define FS_SERVICE_MAX   (512u * 1024u)
/* Reject oversized configuration files before passing them to the engine command buffer. */
#define CFG_SERVE_MAX    (24u * 1024u)
/* the save thumbnails, deflated.  Header: magic, uncompressed size, compressed
   size.  A .bmp that does not start with it is one written before this build. */
#define SHOT_MAGIC       0x4D42485Au          /* 'ZHBM' little-endian */
#define SHOT_HDR         12u
#define XFS_BLOCK        (64u * 1024u)
#define XFS_CACHE_BLOCKS 128u          /* up to 8 MiB block cache; the smallest one */
/* XCACHE=<MiB> (default 64): the block cache, taken from the heap at the first read (it
   halves until it fits, down to 8 MiB).  From 16 MiB on, the whole blocks of the direct reads (maps,
   WADs, models) are kept too and served from it: a level change, a reload after a death or a save
   reads again only what the previous levels did not.  Heap: 159 MiB, peak measured 40-50 MiB. */
#define XFS_CACHE_MAX    2048u         /* 128 MiB at most */
#define XFS_DIRECT_MIN   XFS_BLOCK     /* a read this big bypasses the cache */

enum { FD_NONE = 0, FD_STD, FD_SVC, FD_SCRATCH, FD_PEEK };   /* FD_PEEK: build 50, below */

typedef struct {
	char name[FS_NAME_MAX];   /* engine path, normalised: "valve/config.cfg" */
	unsigned char *data;
	unsigned size, cap;
	int dirty, refs;
	unsigned mtime;           /* seconds (zzhl_wall_time) of the last write, or of the save on the disk */
} scratch_t;

typedef struct {                /* a big file served by READAT */
	char name[FS_NAME_MAX];   /* engine path "valve/pak0.pak" */
	unsigned size;
	int used, refs;
	int crc_state;            /* 0 not looked for, 1 block CRCs loaded (<pak>.crc), -1 none */
	unsigned *crc, crc_n;
} svcfile_t;

typedef struct {
	int kind;
	unsigned pos;
	int flags;
	scratch_t *sc;
	svcfile_t *sv;
	char pstem[32];           /* build 50, FD_PEEK: the save's name on the disk (SAVE_STEM_MAX + 1 at most) */
	char pname[FS_NAME_MAX];  /* and the engine's, for reading it whole if the engine goes on */
	unsigned psize;
	unsigned praw;             /* bytes served verbatim from the disk (peek_t.raw) */
} fd_t;

typedef struct { int file; unsigned block; unsigned len; unsigned stamp; } cblk_t;

static fd_t g_fd[FS_MAX_FD];
static scratch_t g_sc[FS_MAX_SCRATCH];
static svcfile_t g_sv[FS_MAX_SVC];
static char g_neg[FS_MAX_NEG][FS_NAME_MAX];
static int g_neg_n;
static char g_dirs[32][FS_NAME_MAX];
static int g_dirs_n;
static cblk_t g_cb[XFS_CACHE_MAX];
static unsigned g_ncb = XFS_CACHE_BLOCKS;    /* blocks of the cache (build 39) */
static unsigned g_st_dhit, g_st_kept;         /* direct-read blocks served from the cache / kept in it */
static unsigned char *g_cbuf_base;   /* XFS_CACHE_BLOCKS x XFS_BLOCK, 32-byte aligned, malloc'ed once */
#define g_cbuf_at( i ) ( g_cbuf_base + (i) * XFS_BLOCK )
static unsigned g_stamp;
static unsigned g_st_req, g_st_bytes, g_st_hit, g_st_miss, g_st_direct, g_st_svc, g_st_neg, g_st_writes;

/* ---- names ---- */
static void norm( char *out, const char *in )
{
	int i = 0, j = 0;
	if( in[0] == '.' && ( in[1] == '/' || in[1] == '\\' )) in += 2;
	while( in[i] && j < FS_NAME_MAX - 1 )
	{
		char c = in[i++];
		if( c == '\\' ) c = '/';
		if( c == '/' && j > 0 && out[j-1] == '/' ) continue;
		out[j++] = c;
	}
	while( j > 1 && out[j-1] == '/' ) j--;
	out[j] = 0;
	if( j == 0 ) { out[0] = '.'; out[1] = 0; }
}
static int ieq( const char *a, const char *b )
{
	for( ;; a++, b++ )
	{
		int ca = ( *a >= 'A' && *a <= 'Z' ) ? *a + 32 : *a, cb = ( *b >= 'A' && *b <= 'Z' ) ? *b + 32 : *b;
		if( ca != cb ) return 0;
		if( !ca ) return 1;
	}
}
static const char *basename_of( const char *p )
{
	const char *b = p, *q;
	for( q = p; *q; q++ ) if( *q == '/' ) b = q + 1;
	return b;
}
/* "valve/<flat name>": what the launcher can serve from PROGDIR:data/ */
static int is_servable( const char *n ) { return !strncasecmp( n, "valve/", 6 ) && n[6] && !strchr( n + 6, '/' ); }
/* what is never written to the Amiga disk.  "demoheader.tmp" is rewritten by the
   engine at every map (CL_StartupDemoHeader) and only read back if a demo recording starts:
   it stays a memory file.  The 03/11 long run showed a service WRITE of that file executed by
   the 68k under the name of the READAT request before it ('pak0.pak', 15183 bytes, refused
   only because the launcher keeps pak0.pak open): the fewer writes during play, the better,
   and a write can never target a .pak (see also _link). */
static int is_pak_name( const char *n ) { size_t l = strlen( n ); return l > 4 && !strcasecmp( n + l - 4, ".pak" ); }
/* "<name>.new" and "<name>.bak" too.  Host_FinalizeConfig (con_utils.c) writes
   config.cfg.new, renames config.cfg to config.cfg.bak and config.cfg.new to config.cfg;
   builds 21-30 wrote config.cfg.new, video.cfg.new, opengl.cfg.new to the disk at the close
   and did the renames in memory only: PROGDIR:data/ never had a config.cfg, the settings and
   keys were lost at every run (couldn't exec video.cfg, 08/11).  Now the final name is
   written at the rename (_link). */
static int has_suffix( const char *n, const char *sfx ) { size_t l = strlen( n ), k = strlen( sfx ); return l > k && !strcasecmp( n + l - k, sfx ); }
static int keep_in_memory( const char *n )
{
	if( has_suffix( n, ".tmp" ) || has_suffix( n, ".new" ) || has_suffix( n, ".bak" )) return 1;
	return is_pak_name( n );
}
static int is_dir_name( const char *n )
{
	int i;
	if( ieq( n, "." ) || ieq( n, "valve" )) return 1;
	for( i = 0; i < g_dirs_n; i++ ) if( ieq( g_dirs[i], n )) return 1;
	return 0;
}

/* ---- negative cache ---- */
/* a loose file of PROGDIR:data/ found once is there for the session (the engine only
   reads them; what it writes lives in memory first, found before).  Up to build 41 each listing
   of valve/ asked the 68k again: Xash3D lists the directory at each name it looks for
   (filesystem/dir.c, FS_FixFileCase), and zzhl_loadscreen.tga, on the disk, cost one STAT each
   time - 3599 STATs, 53.6 s of the run of 11/11 (26.3 s of the first load, 6.3-6.7 s of each
   change of map, 557 stops of ~11 ms in the game). */
static char g_pos[24][FS_NAME_MAX];
static int g_pos_n;
static int pos_has( const char *n ) { int i; for( i = 0; i < g_pos_n; i++ ) if( ieq( g_pos[i], n )) return 1; return 0; }
static void pos_add( const char *n ) { if( g_pos_n < 24 && !pos_has( n )) { strncpy( g_pos[g_pos_n], n, FS_NAME_MAX - 1 ); g_pos[g_pos_n][FS_NAME_MAX - 1] = 0; g_pos_n++; } }
static int neg_has( const char *n ) { int i; for( i = 0; i < g_neg_n; i++ ) if( ieq( g_neg[i], n )) return 1; return 0; }
static void neg_add( const char *n ) { if( g_neg_n < FS_MAX_NEG ) { strncpy( g_neg[g_neg_n], n, FS_NAME_MAX - 1 ); g_neg[g_neg_n][FS_NAME_MAX-1] = 0; g_neg_n++; } g_st_neg++; }
static void neg_del( const char *n ) { int i; for( i = 0; i < g_neg_n; i++ ) if( ieq( g_neg[i], n )) g_neg[i][0] = '\001'; }

/* ---- service files (READAT) ---- */
static svcfile_t *sv_find( const char *n ) { int i; for( i = 0; i < FS_MAX_SVC; i++ ) if( g_sv[i].used && ieq( g_sv[i].name, n )) return &g_sv[i]; return NULL; }
/* answers carrying another file's size (the launcher served its previous file: the request
   was read before it was visible, see Core1/zzhl_fsat.c), asked again */
static unsigned g_wrong_total, g_probe_disagree;
static void fs_logf( const char *what, const char *name, unsigned off, unsigned want, int got, unsigned size );
/* opens (or finds) a READAT file: one request of 1 byte learns its size; NULL if absent */
static svcfile_t *sv_open( const char *n )
{
	svcfile_t *s = sv_find( n );
	unsigned total = 0;
	unsigned char probe[4];
	int i, got;
	if( s ) return s;
	if( !zzhl_rt->read_at || !is_servable( n ) || neg_has( n )) return NULL;
	g_st_svc++;
	got = zzhl_rt->read_at( basename_of( n ), 0, probe, 1, &total );
	g_last_readat_us = zzhl_us64();
	if( got < 0 ) { neg_add( n ); return NULL; }
	{   /* the size learnt twice (a third time when they differ): an answer can be another file's */
		unsigned t2 = 0, t3 = 0;
		int g2 = zzhl_rt->read_at( basename_of( n ), 0, probe, 1, &t2 );
		if( g2 < 0 || t2 != total )
		{
			int g3 = zzhl_rt->read_at( basename_of( n ), 0, probe, 1, &t3 );
			g_probe_disagree++;
			fs_logf( "size of a file answered differently:", n, total, t2, g3 < 0 ? -1 : (int)t3, 0 );
			if( g3 >= 0 && ( t3 == t2 || t3 == total )) total = t3;
			else if( g2 >= 0 ) total = t2;
		}
	}
	for( i = 0; i < FS_MAX_SVC; i++ ) if( !g_sv[i].used ) { s = &g_sv[i]; break; }
	if( !s ) return NULL;
	memset( s, 0, sizeof( *s ));
	strncpy( s->name, n, FS_NAME_MAX - 1 );
	s->size = total; s->used = 1;
	return s;
}
static int sv_index( const svcfile_t *s ) { return (int)( s - g_sv ); }

/* ---- READAT with a short-read retry, and the VERIFY option ----
 * Build 10 run (03/11): a level load ended on thousands of "bad normal for plane" and a
 * 561 MB realloc in Mod_LoadSubmodels: the BSP read out of pak0.pak was partly garbage.  The
 * same exit (rc 1 after the second level change) had happened once on build 8.  Two ways a
 * READAT can leave garbage in the engine's buffer: a request answered short before the end
 * of the file (the engine's FS_Read does not check the count: the rest of the buffer stays
 * uninitialised), or an answer carrying the wrong bytes.  The first is now detected (the file
 * size is known), logged and retried up to 3 times; VERIFY=1 reads every request twice and
 * logs the first difference, to prove or clear the second on the hardware. */
static int g_verify, g_short_reads, g_verify_mismatch;
void zzhl_fs_answer_stats( unsigned *wrong_total, unsigned *probe_disagree ) { *wrong_total = g_wrong_total; *probe_disagree = g_probe_disagree; }
void xacp_fs_set_verify( int on ) { g_verify = on; }
static void fs_logf( const char *what, const char *name, unsigned off, unsigned want, int got, unsigned size )
{
	char line[200], *p = line;
	const char *q;
	unsigned v[4] = { off, want, (unsigned)got, size }, k;
	for( q = "xacp_fs: "; *q; ) *p++ = *q++;
	for( q = what; *q; ) *p++ = *q++;
	*p++ = ' ';
	for( q = name; *q && p < line + 120; ) *p++ = *q++;
	for( k = 0; k < 4u; k++ )
	{
		static const char *lab[4] = { " off ", " want ", " got ", " size " };
		char d[12]; int n = 0; unsigned x = v[k];
		for( q = lab[k]; *q; ) *p++ = *q++;
		if( k == 2u && got < 0 ) { *p++ = '-'; *p++ = '1'; continue; }
		do { d[n++] = (char)( '0' + x % 10u ); x /= 10u; } while( x );
		while( n ) *p++ = d[--n];
	}
	*p = 0;
	zzhl_log( line );
}
/* every READAT of the pak layer, for the hitch report (Core1/zzhl_gpu.c) */
static unsigned g_io_n, g_io_us, g_io_bytes;
/* zzhl_fs_io_totals moved to xacp_disk.c (every request to the 68k, not these READATs only) */
void zzhl_fs_readat_totals( unsigned *n, unsigned *bytes, unsigned *us ) { *n = g_io_n; *bytes = g_io_bytes; *us = g_io_us; }
/* one request of n bytes at off, retried when the answer is short before the end of the file */
static int sv_readat( svcfile_t *s, unsigned off, unsigned char *dst, unsigned n )
{
	int got, tries;
	for( tries = 0; tries < 4; tries++ )
	{
		unsigned total = 0;
		unsigned long long t_io = zzhl_us64();
		got = zzhl_rt->read_at( basename_of( s->name ), off, dst, n, &total );
		g_last_readat_us = zzhl_us64();
		g_io_n++; g_io_us += (unsigned)( g_last_readat_us - t_io ); if( got > 0 ) g_io_bytes += (unsigned)got;   /* build 39 */
		zzhl_present_keepalive();
		xacp_loading_tick();          /* the loading screen moves on each read */
		if( got >= 0 && s->size && total != s->size )
		{   /* the answer is another file's: the bytes too, ask again */
			g_wrong_total++;
			fs_logf( tries < 3 ? "READAT answered with another file's size, again:" : "READAT answered with another file's size, giving up:", s->name, off, n, (int)total, s->size );
			continue;
		}
		if( got >= 0 && ( (unsigned)got == n || off + (unsigned)got >= s->size )) break;
		g_short_reads++;
		fs_logf( tries < 3 ? "short READAT, retrying:" : "short READAT, giving up:", s->name, off, n, got, s->size );
	}
	if( g_verify && got > 0 )
	{
		/* a second read of the same bytes into the cache's spare block (the block the next
		   fill would take), compared with the first */
		static unsigned char *spare;
		unsigned i, m = (unsigned)got;
		if( !spare ) spare = (unsigned char *)malloc( FS_SERVICE_MAX );
		if( spare )
		{
			unsigned done = 0;
			while( done < m )
			{
				unsigned chunk = m - done; int g2;
				if( chunk > FS_SERVICE_MAX ) chunk = FS_SERVICE_MAX;
				g2 = zzhl_rt->read_at( basename_of( s->name ), off + done, spare, chunk, NULL );
				if( g2 != (int)chunk ) { fs_logf( "VERIFY: second read short:", s->name, off + done, chunk, g2, s->size ); g_verify_mismatch++; break; }
				for( i = 0; i < chunk; i++ ) if( spare[i] != dst[done + i] ) break;
				if( i < chunk ) { fs_logf( "VERIFY: MISMATCH at", s->name, off + done + i, chunk, (int)i, s->size ); g_verify_mismatch++; break; }
				done += chunk;
			}
		}
	}
	return got;
}
static int crc_fix( svcfile_t *s, unsigned block, unsigned char *p, unsigned len );   /* build 37, below */
static unsigned char *cache_find( int file, unsigned block, unsigned *len )
{
	unsigned i;
	for( i = 0; i < g_ncb; i++ )
		if( g_cb[i].file == file + 1 && g_cb[i].block == block ) { g_cb[i].stamp = ++g_stamp; *len = g_cb[i].len; g_st_hit++; return g_cbuf_at( i ); }
	return NULL;
}
static int cache_has( int file, unsigned block )
{
	unsigned i;
	for( i = 0; i < g_ncb; i++ ) if( g_cb[i].file == file + 1 && g_cb[i].block == block ) return 1;
	return 0;
}
/* the cache memory, once; XCACHE= MiB, halved until malloc gives it */
extern const char *zzhl_option( const char *key );
static int cache_alloc( void )
{
	unsigned mib, blocks;
	unsigned char *m = NULL;
	char line[120];
	if( g_cbuf_base ) return 1;
	mib = 80u;                     /* 80 (64 up to build 45) - a chapter (up to ~43 MiB) and the common part */
	{ const char *v = zzhl_option( "XCACHE" ); if( v && *v ) { mib = (unsigned)atoi( v ); if( mib < 8u ) mib = 8u; if( mib > 128u ) mib = 128u; } }
	for( blocks = mib * 16u; blocks >= XFS_CACHE_BLOCKS; blocks /= 2u )
		if(( m = (unsigned char *)malloc( blocks * XFS_BLOCK + 32 ))) break;
	if( !m ) return 0;
	g_ncb = blocks;
	g_cbuf_base = (unsigned char *)((( size_t )m + 31u ) & ~( size_t )31u );
	snprintf( line, sizeof( line ), "xacp_fs: block cache %u MiB (%u blocks of 64 KiB)%s", blocks / 16u, blocks, blocks >= 256u ? ", maps/WADs/models kept across levels" : "" );
	zzhl_log( line );
	return 1;
}
/* the least recently used block, emptied */
static unsigned cache_victim( void )
{
	unsigned i, best = 0, bstamp = 0xFFFFFFFFu;
	for( i = 0; i < g_ncb; i++ ) if( g_cb[i].stamp < bstamp ) { bstamp = g_cb[i].stamp; best = i; }
	g_cb[best].file = 0; g_cb[best].stamp = 0;
	return best;
}
/* a whole block read directly (already checked): a copy kept for the next time */
static void cache_keep( svcfile_t *s, unsigned block, const unsigned char *p, unsigned len )
{
	unsigned v;
	if( g_ncb < 256u || !g_cbuf_base || cache_has( sv_index( s ), block )) return;
	v = cache_victim();
	memcpy( g_cbuf_at( v ), p, len );
	g_cb[v].file = sv_index( s ) + 1; g_cb[v].block = block; g_cb[v].len = len; g_cb[v].stamp = ++g_stamp;
	g_st_kept++;
}
static unsigned char *cache_fill( svcfile_t *s, unsigned block, unsigned *len )
{
	unsigned best;
	int got;
	if( !cache_alloc()) return NULL;
	best = cache_victim();                                     /* never a stale entry while the read is in flight */
	got = sv_readat( s, block * XFS_BLOCK, g_cbuf_at( best ), XFS_BLOCK );
	g_st_req++; g_st_miss++;
	if( got < 0 ) return NULL;
	crc_fix( s, block, g_cbuf_at( best ), (unsigned)got );           /* build 37 */
	g_st_bytes += (unsigned)got;
	g_cb[best].file = sv_index( s ) + 1; g_cb[best].block = block; g_cb[best].len = (unsigned)got; g_cb[best].stamp = ++g_stamp;
	*len = (unsigned)got;
	return g_cbuf_at( best );
}
static int sv_read( svcfile_t *s, unsigned pos, unsigned char *dst, unsigned n )
{
	unsigned done = 0;
	if( pos >= s->size ) return 0;
	if( n > s->size - pos ) n = s->size - pos;
	while( done < n )
	{
		unsigned off = pos + done, block = off / XFS_BLOCK, in = off % XFS_BLOCK, want = n - done, blen;
		unsigned char *b;
		if( in == 0 && want >= XFS_DIRECT_MIN )
		{   /* a whole block or more, aligned: straight to the destination; the blocks the
			   cache holds come from it, the others in runs of up to 8 (512 KiB, one request), kept */
			unsigned nblk = want / XFS_BLOCK, k = 0, stop = 0;
			(void)cache_alloc();
			while( k < nblk && !stop )
			{
				unsigned cl = 0, run = 1, j, whole;
				unsigned char *cb = cache_find( sv_index( s ), block + k, &cl );
				int got;
				if( cb )
				{
					g_st_hit--; g_st_dhit++;                       /* counted apart */
					if( cl < XFS_BLOCK ) { stop = 2; break; }      /* the file's short last block: the path below */
					memcpy( dst + done, cb, XFS_BLOCK );
					done += XFS_BLOCK; k++;
					continue;
				}
				while( k + run < nblk && run < 8u && !cache_has( sv_index( s ), block + k + run )) run++;
				got = sv_readat( s, ( block + k ) * XFS_BLOCK, dst + done, run * XFS_BLOCK );
				g_st_req += ( run * XFS_BLOCK + FS_SERVICE_MAX - 1 ) / FS_SERVICE_MAX; g_st_direct++;
				if( got <= 0 ) { stop = 1; break; }
				whole = (unsigned)got / XFS_BLOCK;
				for( j = 0; j < whole; j++ )
				{   /* each whole block against the pak's CRC table; then kept */
					if( crc_fix( s, block + k + j, dst + done + j * XFS_BLOCK, XFS_BLOCK ) >= 0 )   /* never keep a block still wrong */
						cache_keep( s, block + k + j, dst + done + j * XFS_BLOCK, XFS_BLOCK );
				}
				g_st_bytes += (unsigned)got;
				done += (unsigned)got;
				k += whole;
				if( (unsigned)got < run * XFS_BLOCK ) stop = 1;
			}
			if( stop == 1 ) break;
			if( !( stop == 2 && k == 0 )) continue;   /* a short cached block first: the cache path below (off, block, in still hold) */
		}
		b = cache_find( sv_index( s ), block, &blen );
		if( !b ) b = cache_fill( s, block, &blen );
		if( !b || in >= blen ) break;
		if( want > blen - in ) want = blen - in;
		memcpy( dst + done, b + in, want );
		done += want;
		if( in + want == blen && blen < XFS_BLOCK ) break;   /* end of the file */
	}
	return (int)done;
}

/* ---- scratch files (small, memory, release service) ---- */
static scratch_t *sc_find( const char *n ) { int i; for( i = 0; i < FS_MAX_SCRATCH; i++ ) if( g_sc[i].name[0] && ieq( g_sc[i].name, n )) return &g_sc[i]; return NULL; }
static scratch_t *sc_new( const char *n )
{
	int i;
	for( i = 0; i < FS_MAX_SCRATCH; i++ )
		if( !g_sc[i].name[0] )
		{
			memset( &g_sc[i], 0, sizeof( g_sc[i] ));
			strncpy( g_sc[i].name, n, FS_NAME_MAX - 1 );
			return &g_sc[i];
		}
	return NULL;
}
static int sc_reserve( scratch_t *s, unsigned need )
{
	unsigned cap;
	unsigned char *d;
	if( need <= s->cap ) return 1;
	cap = s->cap ? s->cap : 4096;
	while( cap < need ) cap *= 2;
	d = (unsigned char *)realloc( s->data, cap );
	if( !d ) return 0;
	s->data = d; s->cap = cap;
	return 1;
}
static void slog( const char *a, const char *b, unsigned x, const char *c, unsigned y );  /* used below */
/* a whole-file READ answered with the launcher's PREVIOUS answer.
   A4000, 16/11 at 23 h 36 (build 90, DEV=0, BENCH=save009,...): the READ of pak0.chp came back
   as 83 KiB - what the READAT of hlsv_save009.sav just before it had returned - instead of its
   10 272 bytes.  "pak0.chp not for this pak0.pak", and no chapter was read whole for the rest
   of the run (one frame of 157 ms in play for a sound read from the disk).  Same family as the
   WRITE carried out under the previous request's name (03/11) and the READAT answered with
   another file's size (build 38, asked again since): the 68k can serve a request before it has
   seen it.  READAT had its guard, the release runtime's whole-file READ had none - and a
   config.cfg answered that way is either refused as too big (build 79) or executed as another
   file: possibly the keys lost on 13-15/11 [not proven].
   A stale answer is the previous request's, so the same READ asked again is answered right:
   a file is read until two answers in a row agree (absent twice = absent), four requests at
   most.  A disagreement is counted and said.  Cost: every small file asked twice, about 0,7 s
   at the start (the READ total of that run: 10 requests, 730 ms). */
static unsigned g_st_read_again, g_st_read_unsure;
static unsigned char *svc_read_whole( const char *base, long *len_out )
{
	unsigned char *prev = NULL;
	long plen = -2;                               /* -2: nothing yet, -1: answered absent */
	int tries;
	for( tries = 0; tries < 4; tries++ )
	{
		unsigned char *cur = NULL;
		long len = -1;
		FILE *f = zzhl_rt->fopen( base, "rb" );
		if( f )
		{
			zzhl_rt->fseek( f, 0, SEEK_END );
			len = zzhl_rt->ftell( f );
			zzhl_rt->fseek( f, 0, SEEK_SET );
			if( len >= 0 && ( cur = (unsigned char *)malloc( (size_t)len + 1u )) != NULL )
				len = (long)zzhl_rt->fread( cur, 1, (size_t)len, f );
			else len = -1;
			zzhl_rt->fclose( f );
		}
		if( plen != -2 && plen == len && ( len < 0 || !memcmp( prev, cur, (size_t)len )))
		{
			free( prev );
			*len_out = len;
			return cur;                            /* NULL when absent twice */
		}
		if( plen != -2 )
		{
			g_st_read_again++;
			slog( "READ answered two ways, asked again: ", base, plen < 0 ? 0u : (unsigned)plen, plen < 0 ? " (absent) then bytes " : " bytes then ", len < 0 ? 0u : (unsigned)len );
		}
		free( prev ); prev = cur; plen = len;
	}
	g_st_read_unsure++;
	slog( "READ never answered twice the same, the last answer kept: ", base, plen < 0 ? 0u : (unsigned)plen, NULL, 0 );
	*len_out = plen;
	return prev;
}
unsigned zzhl_fs_read_again( unsigned *unsure ) { if( unsure ) *unsure = g_st_read_unsure; return g_st_read_again; }

/* Configuration reads must return the actual file contents, not a stale buffer. */
static unsigned g_st_cfg_binary, g_st_cfg_rescued, g_st_cfg_refused, g_st_cfg_unwritten;
#define CFG_KEEP_MAX 6
static char g_cfg_keep[CFG_KEEP_MAX][FS_NAME_MAX];
static int g_cfg_keep_n;
static int cfg_kept( const char *n ) { int i; for( i = 0; i < g_cfg_keep_n; i++ ) if( ieq( g_cfg_keep[i], n )) return 1; return 0; }
static void cfg_keep( const char *n )
{
	if( cfg_kept( n ) || g_cfg_keep_n >= CFG_KEEP_MAX ) return;
	strncpy( g_cfg_keep[g_cfg_keep_n], n, FS_NAME_MAX - 1 ); g_cfg_keep[g_cfg_keep_n][FS_NAME_MAX - 1] = 0; g_cfg_keep_n++;
}
/* text: no NUL at all, and at most one byte in a hundred that is a control code other than
   tab, line feed and carriage return (a stray Ctrl-Z from an editor is not damage).  Random
   bytes have one such code in nine. */
static int cfg_is_text( const unsigned char *p, long len )
{
	long i; unsigned bad = 0;
	for( i = 0; i < len; i++ )
	{
		unsigned c = p[i];
		if( c == 0u ) return 0;
		if(( c < 0x20u && c != 9u && c != 10u && c != 13u ) || c == 0x7Fu ) bad++;
	}
	return bad * 100u <= (unsigned)len;
}
static void hold_pak0( void );
static void cfg_settle( void )
{
	unsigned long long t = zzhl_us64();
	hold_pak0();
	while( zzhl_us64() - t < 100000ull ) zzhl_rt->pump();
}
/* the whole file by READAT (one request: a .cfg is small); NULL when that road gives nothing whole */
static unsigned char *cfg_read_at( const char *base, long *len_out )
{
	unsigned total = 0; int got;
	unsigned char *b;
	if( !zzhl_rt->read_at || ( b = (unsigned char *)malloc( CFG_SERVE_MAX + 1u )) == NULL ) return NULL;
	got = zzhl_rt->read_at( base, 0, b, CFG_SERVE_MAX, &total );
	hold_pak0();                                  /* the 68k holds pak0.pak again (see sc_flush) */
	if( got < 0 || (unsigned)got != total ) { free( b ); return NULL; }
	*len_out = (long)got;
	return b;
}
void zzhl_fs_cfg_stats( unsigned v[4] ) { v[0] = g_st_cfg_binary; v[1] = g_st_cfg_rescued; v[2] = g_st_cfg_refused; v[3] = g_st_cfg_unwritten; }

static scratch_t *sc_load_service( const char *n )
{
	unsigned char *whole;
	long len;
	scratch_t *s;
	if( !zzhl_rt->fopen || !is_servable( n ) || neg_has( n )) return NULL;
	g_st_svc++;
	whole = svc_read_whole( basename_of( n ), &len );   /* two answers that agree */
	if( !whole ) { neg_add( n ); return NULL; }
	if( has_suffix( n, ".cfg" ) && !cfg_is_text( whole, len ))
	{   /* the right size and binary bytes (see above) */
		const char *base = basename_of( n );
		int t, good = 0;
		g_st_cfg_binary++;
		for( t = 0; t < 2 && !good; t++ )
		{
			unsigned char *alt; long alen = -1;
			slog( "cfg answered with BINARY data, not executed, asked again: ", base, (unsigned)len, " bytes, try ", (unsigned)t + 1u );
			free( whole ); whole = NULL;
			cfg_settle();
			alt = cfg_read_at( base, &alen );
			if( alt && alen <= (long)CFG_SERVE_MAX && cfg_is_text( alt, alen )) { whole = alt; len = alen; good = 1; break; }
			free( alt );
			cfg_settle();
			whole = svc_read_whole( base, &len );
			if( whole && cfg_is_text( whole, len )) { good = 1; break; }
		}
		if( !good )
		{
			free( whole );
			g_st_cfg_refused++;
			cfg_keep( n );
			slog( "cfg REFUSED, binary data every time; the file on the disk is left as it is this session: ", base, 0, NULL, 0 );
			neg_add( n );
			return NULL;
		}
		g_st_cfg_rescued++;
		slog( "cfg read right at last: ", base, (unsigned)len, " bytes, binary answers before it ", (unsigned)t + 1u );
	}
	/* A configuration script larger than the engine command buffer would discard all bindings. */
	if( len > (long)CFG_SERVE_MAX && has_suffix( n, ".cfg" ))
	{
		free( whole );
		slog( "cfg REFUSED, too big for the engine's command buffer: ", basename_of( n ),
		      (unsigned)len, " bytes, max ", (unsigned)CFG_SERVE_MAX );
		neg_add( n );
		return NULL;
	}
	s = sc_new( n );
	if( !s || len < 0 || !sc_reserve( s, (unsigned)len + 1 ))
	{
		free( whole );
		if( s ) s->name[0] = 0;
		return NULL;
	}
	memcpy( s->data, whole, (size_t)len );
	s->size = (unsigned)len;
	free( whole );
	/* say what we SERVE for a .cfg, next to what the engine says it received
	   (cmd.c, patched the same build).  The two numbers together tell a big file on the disk
	   apart from a length we got wrong ourselves - the question I could not answer on 15/11
	   without guessing, twice.  Cheap: a few .cfg per start, none in play. */
	if( has_suffix( n, ".cfg" ))
		slog( "cfg served: ", basename_of( n ), s->size, " bytes, ftell said ", (unsigned)len );
	return s;
}
/* a service WRITE never follows a READAT closely.  Whatever makes the 68k see the
   previous request's name (its cache of the shared block, or the board's), the most recent
   READAT name is 'pak0.pak' and the launcher's write replaces the target file: half a second
   of distance makes a stale line unlikely to survive, and the launcher is told the size of
   pak0.pak afterwards so that a change would at least be reported. */
static void write_guard_before( void )
{
	unsigned long long now = zzhl_us64();
	if( g_last_readat_us && now - g_last_readat_us < 500000ull )
	{
		while( zzhl_us64() - g_last_readat_us < 500000ull ) zzhl_rt->pump();
	}
}
static void write_guard_after( void )
{
	svcfile_t *s = sv_find( "valve/pak0.pak" );
	unsigned total = 0; unsigned char probe[4];
	if( !s || !zzhl_rt->read_at ) return;
	if( zzhl_rt->read_at( "pak0.pak", 0, probe, 1, &total ) < 0 || total != s->size )
	{
		char line[120], *p = line; const char *q; unsigned v[2], k;
		v[0] = total; v[1] = s->size;
		for( q = "xacp_fs: *** pak0.pak CHANGED after a service write: size now "; *q; ) *p++ = *q++;
		for( k = 0; k < 2u; k++ ) { char d[12]; int n = 0; unsigned x = v[k]; do { d[n++] = (char)( '0' + x % 10u ); x /= 10u; } while( x ); while( n ) *p++ = d[--n]; if( !k ) for( q = " expected "; *q; ) *p++ = *q++; }
		*p = 0;
		zzhl_log( line );
	}
	g_last_readat_us = zzhl_us64();
}
/* what the launcher does with READAT and WRITE (ZZOpenLara launcher, ZZQuake2_A0.c,
   fs_do_read_at / fs_do_write, read 06/11):
   - a READAT keeps its file OPEN (MODE_OLDFILE, a shared lock) until a READAT of another name;
   - a WRITE goes to <name>.tmp, then DeleteFile( <name> ) and Rename( <name>.tmp, <name> ).
   AmigaDOS does not delete an open file: a WRITE of the file the last READAT read is refused
   ("save '<name>' ... : ECHEC", <name>.tmp left beside it).  Build 19's same-name probe (a READAT
   of the target right before its WRITE) did exactly that: every file that was already on the
   disk was refused - .xash_id, config.cfg.new and the others, the second autosave (SOAK run of
   06/11); only files written for the first time went through.
   Now the request right before every WRITE is a one-byte READAT of pak0.pak: the 68k closes what
   it held (the target included) and holds pak0.pak, so that a WRITE carried out under a stale
   name - the 03/11 case, demoheader.tmp written as 'pak0.pak', the name of the request before -
   is refused by AmigaDOS in the same way instead of replacing pak0.pak.  That is also why 03/11
   left pak0.pak intact.  The launcher's answer (zzq_fclose: 0 written, -1 refused or no answer
   in 2 s) is now checked; a refused write is tried once more. */
static unsigned g_write_refused, g_write_given_up;
static void slog( const char *a, const char *b, unsigned x, const char *c, unsigned y );
static void hold_pak0( void )
{
	unsigned char b[4]; unsigned total = 0;
	if( zzhl_rt->read_at ) zzhl_rt->read_at( "pak0.pak", 0, b, 1, &total );
}
/* n bytes as <base> on the disk; guard: the half-second distance from the last READAT first.
   0 when the launcher said written. */
static int service_write( const char *base, const unsigned char *p, unsigned n, int guard )
{
	int attempt;
	for( attempt = 0; attempt < 2; attempt++ )
	{
		FILE *f;
		int ok;
		if( guard || attempt ) write_guard_before();
		hold_pak0();
		f = zzhl_rt->fopen( base, "wb" );
		if( !f ) { slog( "the service has no slot to write ", base, 0, NULL, 0 ); return -1; }
		ok = zzhl_rt->fwrite( p, 1, n, f ) == n;
		if( zzhl_rt->fclose( f ) != 0 ) ok = 0;
		g_st_writes++;
		write_guard_after();
		if( ok ) return 0;
		g_write_refused++;
		slog( attempt ? "write refused by the launcher twice, not written: " : "write refused by the launcher, trying again: ", base, n, NULL, 0 );
	}
	g_write_given_up++;
	return -1;
}
static int save_flush_hook( scratch_t *s );       /* below: valve/save/<name>.sav to the Amiga disk */
extern unsigned zzhl_wall_time( void );   /* xacp_libc.c, the Amiga's date (DATE=) + Core1's time */
static void sc_flush( scratch_t *s )
{
	if( !s->dirty ) return;
	s->dirty = 0;
	s->mtime = zzhl_wall_time();      /* build 50 */
	if( save_flush_hook( s )) return;
	if( !zzhl_rt->fopen || !is_servable( s->name ) || keep_in_memory( s->name )) return;
	if( cfg_kept( s->name ))
	{   /* this .cfg could not be read at the start; what the engine holds is not the user's */
		g_st_cfg_unwritten++;
		slog( "config NOT written, it could not be read at the start; the disk keeps its own: ", basename_of( s->name ), 0, NULL, 0 );
		return;
	}
	if( s->size > FS_SERVICE_MAX ) { zzhl_log( "xacp_fs: file too large for the service, not saved" ); return; }
	/* Verify configuration writes and their resulting lengths before accepting them. */
	{
		const char *base = basename_of( s->name );
		int is_cfg = has_suffix( s->name, ".cfg" );
		unsigned total = 0; unsigned char probe[4];
		int pass;

		if( is_cfg && s->size == 0 && zzhl_rt->read_at )
		{
			int empty_over_real = ( zzhl_rt->read_at( base, 0, probe, 1, &total ) >= 0 && total > 0 );
			hold_pak0();                       /* same reason as below */
			if( empty_over_real )
			{
				slog( "config NOT written, it is empty and the disk has ", base, total, " bytes", 0 );
				return;
			}
		}
		for( pass = 0; pass < 2; pass++ )
		{
			if( service_write( base, s->data, s->size, 1 ))
			{
				if( is_cfg && pass == 0 ) continue;
				slog( "config not written: ", base, 0, NULL, 0 );
				return;
			}
			if( !is_cfg || !zzhl_rt->read_at ) return;
			total = 0;
			{
				int sized = ( zzhl_rt->read_at( base, 0, probe, 1, &total ) >= 0 && total == s->size );
				/* the check itself makes the 68k hold THIS file open; put pak0.pak back at once.
				   That invariant is a safety net, not cosmetics: a WRITE carried out under the
				   previous request's name (seen on 03/11) then lands on a .pak, which is_pak_name()
				   refuses, instead of landing on the config we just wrote. */
				hold_pak0();
				if( sized ) return;
			}
			slog( "config written with the WRONG size: ", base, total, " bytes, expected ", s->size );
		}
		slog( "config STILL wrong after a second write, the disk file is not trustworthy: ", base, 0, NULL, 0 );
	}
}

/* ---- saves on the Amiga disk (build 19) ----
 * Xash3D writes a save as ONE file, valve/save/<name>.sav (the state of every visited level packed
 * in, DirectoryCopy in sv_save.c), and unpacks it into save/<map>.HL? when loading.  Those stay in
 * memory as before; the .sav files go to PROGDIR:data/ when the engine closes them:
 *   hlsv_<name>.sav       header (32 bytes) + the first 512 KiB - 32 of the save,
 *   hlsv_<name>.s01 ...   the rest, 512 KiB a file (the release file service writes 512 KiB at most),
 *   hlsave.idx            the names of the saves on the disk, one a line.
 * Header: "ZHSV", version 1, total size, number of files, CRC-32 of the save; a save whose files
 * do not add up or whose CRC differs is refused with a console line, never loaded half.
 * A save is read back from the disk the first time the engine opens or looks for that name, then
 * lives in memory like the others.  Quick saves and autosaves rotate in memory (quick01...) as on
 * the PC; only the current names (quick, autosave, and any name given to "save") reach the disk.
 * SAVES=0 keeps everything in memory (builds 1-18). */
#define SAVE_MAGIC    0x5653485Au      /* "ZHSV" */
#define SAVE_V1       1u               /* the whole save in clear, builds 19-74 */
#define SAVE_VERSION  2u               /* SAVE_RAW bytes in clear, the rest deflated */
/* Compress saves and preserve backward-compatible loading of previous versions. */
#define SAVE_RAW      ( 32u * 1024u )
extern int mz_compress2( unsigned char *pDest, unsigned long *pDest_len, const unsigned char *pSource, unsigned long source_len, int level );
extern int mz_uncompress( unsigned char *pDest, unsigned long *pDest_len, const unsigned char *pSource, unsigned long source_len );
#define ZZHL_MZ_OK    0
#define SAVE_HDR      32u
#define SAVE_P0       ( FS_SERVICE_MAX - SAVE_HDR )
#define SAVE_STEM_MAX 24
#define SAVE_IDX      "valve/hlsave.idx"
#define SAVE_IDX_MAX  64
static int g_disk_saves = 1;
static int g_idx_loaded;
static char g_idx[SAVE_IDX_MAX][SAVE_STEM_MAX + 1];
static int g_idx_n;
static unsigned g_saves_written, g_saves_read, g_saves_bad;
static unsigned g_shots_written, g_shots_read;   /* the saves' screenshots */
void zzhl_fs_shot_stats( unsigned *written, unsigned *read ) { *written = g_shots_written; *read = g_shots_read; }
static unsigned char *g_save_buf;              /* one 512 KiB file being written */
void xacp_fs_set_disk_saves( int on ) { g_disk_saves = on ? 1 : 0; }
/* TRAVERSE=1 (xacp_traverse.c): only the saves whose name starts with this reach the disk
   ("trav"): an autosave a map makes on its own stays in memory, the player's hlsv_autosave and
   hlsv_quick on the disk are not replaced */
static char g_disk_only[SAVE_STEM_MAX + 1];
void xacp_fs_disk_saves_only( const char *prefix ) { strncpy( g_disk_only, prefix ? prefix : "", SAVE_STEM_MAX ); g_disk_only[SAVE_STEM_MAX] = 0; }
void zzhl_fs_save_stats( unsigned *written, unsigned *read, unsigned *bad ) { *written = g_saves_written; *read = g_saves_read; *bad = g_saves_bad; }

static unsigned crc32_of( const unsigned char *p, unsigned n )
{
	static unsigned t[256];
	unsigned c = 0xFFFFFFFFu, i, k;
	if( !t[1] ) for( i = 0; i < 256u; i++ ) { unsigned v = i; for( k = 0; k < 8u; k++ ) v = ( v & 1u ) ? 0xEDB88320u ^ ( v >> 1 ) : v >> 1; t[i] = v; }
	for( i = 0; i < n; i++ ) c = t[( c ^ p[i] ) & 255u] ^ ( c >> 8 );
	return c ^ 0xFFFFFFFFu;
}
static void put32( unsigned char *p, unsigned v ) { p[0] = (unsigned char)v; p[1] = (unsigned char)( v >> 8 ); p[2] = (unsigned char)( v >> 16 ); p[3] = (unsigned char)( v >> 24 ); }
static unsigned get32( const unsigned char *p ) { return (unsigned)p[0] | ((unsigned)p[1] << 8 ) | ((unsigned)p[2] << 16 ) | ((unsigned)p[3] << 24 ); }
/* ---- block CRCs of the paks ----
 * Builds 8, 10, 33b (maps) and 35 (a model, by the crash it caused) read pieces of pak0.pak with wrong
 * bytes, without any error from the file service; the map and model checks find some of it, a texture
 * or a sound read wrong is found by nothing.  tools/hl_pakcrc.py writes, next to each pak, <pak>.crc:
 * "ZZCRC1\0\0", the block size (65536), the pak's size, the block count, then the CRC-32 (zlib) of
 * every 64 KiB block.  Copied into data/ with the pak, it makes every block of the pak read through
 * this file (the cache's fills and the whole blocks of the direct reads) checked; a block that does
 * not match is read again, at most 3 times, each case logged and counted.  Without the .crc, or with
 * one made for another pak (other size), nothing is checked, as before (one log line says which). */
static unsigned g_crc_blocks, g_crc_bad, g_crc_fixed, g_crc_lost;
static int g_crc_state_seen;                   /* 1 on, -1 absent, -2 mismatch (the last pak looked at) */
void zzhl_fs_crc_stats( unsigned *blocks, unsigned *bad, unsigned *fixed, unsigned *lost, int *state )
{ *blocks = g_crc_blocks; *bad = g_crc_bad; *fixed = g_crc_fixed; *lost = g_crc_lost; *state = g_crc_state_seen; }
static void crc_load( svcfile_t *s )
{
	char cname[FS_NAME_MAX], line[200];
	const char *b = basename_of( s->name );
	unsigned total = 0, need, n, i;
	unsigned char hdr[20], *t;
	size_t l = strlen( b );
	s->crc_state = -1;
	if( l < 5 || l >= sizeof( cname ) || strcasecmp( b + l - 4, ".pak" )) return;
	memcpy( cname, b, l - 4 ); memcpy( cname + l - 4, ".crc", 5 );
	if( zzhl_rt->read_at( cname, 0, hdr, 20, &total ) != 20 || memcmp( hdr, "ZZCRC1\0\0", 8 ))
	{
		snprintf( line, sizeof( line ), "xacp_fs: no %s (tools/hl_pakcrc.py): the blocks of %s are not checked", cname, b );
		zzhl_log( line ); if( g_crc_state_seen != 1 ) g_crc_state_seen = -1; return;
	}
	n = get32( hdr + 16 );
	need = ( s->size + XFS_BLOCK - 1u ) / XFS_BLOCK;
	if( get32( hdr + 8 ) != XFS_BLOCK || get32( hdr + 12 ) != s->size || n != need || total != 20u + 4u * n )
	{
		snprintf( line, sizeof( line ), "xacp_fs: %s was made for another pak (size %u, here %u): the blocks of %s are not checked", cname, get32( hdr + 12 ), s->size, b );
		zzhl_log( line ); g_crc_state_seen = -2; return;
	}
	t = (unsigned char *)malloc( 4u * n );
	if( !t ) return;
	for( i = 0; i < 4u * n; )
	{
		unsigned want = 4u * n - i;
		int got;
		if( want > FS_SERVICE_MAX ) want = FS_SERVICE_MAX;
		got = zzhl_rt->read_at( cname, 20u + i, t + i, want, NULL );
		if( got != (int)want ) { free( t ); zzhl_log( "xacp_fs: pak CRC table read short: not checked" ); return; }
		i += want;
	}
	s->crc = (unsigned *)t; s->crc_n = n; s->crc_state = 1; if( g_crc_state_seen != -2 ) g_crc_state_seen = 1;
	for( i = 0; i < n; i++ ) s->crc[i] = get32( t + 4u * i );        /* in place: little-endian words */
	snprintf( line, sizeof( line ), "xacp_fs: %s: %u blocks of 64 KiB, every block of %s read is checked", cname, n, b );
	zzhl_log( line );
}
/* the block as read (len bytes at p); read again in place when its CRC is not the table's */
static int crc_fix( svcfile_t *s, unsigned block, unsigned char *p, unsigned len )
{
	unsigned want, attempt;
	char line[200];
	if( !s->crc_state ) crc_load( s );
	if( s->crc_state != 1 || block >= s->crc_n ) return 0;
	want = ( block + 1u < s->crc_n ) ? XFS_BLOCK : s->size - block * XFS_BLOCK;
	if( len != want ) return 0;                    /* a short answer: the retry of sv_readat handles it */
	g_crc_blocks++;
	if( crc32_of( p, len ) == s->crc[block] ) return 0;
	g_crc_bad++;
	for( attempt = 1; attempt <= 3u; attempt++ )
	{
		int got;
		snprintf( line, sizeof( line ), "xacp_fs: CRC: block %u of %s (offset %u) read wrong, read again (%u)", block, basename_of( s->name ), block * XFS_BLOCK, attempt );
		zzhl_log( line );
		got = sv_readat( s, block * XFS_BLOCK, p, len );
		if( got == (int)len && crc32_of( p, len ) == s->crc[block] )
		{
			g_crc_fixed++;
			snprintf( line, sizeof( line ), "xacp_fs: CRC: block %u fixed by the new read", block );
			zzhl_log( line );
			return 1;
		}
	}
	g_crc_lost++;
	snprintf( line, sizeof( line ), "xacp_fs: CRC: block %u still wrong after 3 reads (the pak on the disk differs from its .crc?)", block );
	zzhl_log( line );
	return -1;
}
static void slog( const char *a, const char *b, unsigned x, const char *c, unsigned y )
{
	char line[200], *p = line;
	const char *q;
	unsigned v[2], k;
	v[0] = x; v[1] = y;
	for( q = "xacp_fs: "; *q; ) *p++ = *q++;
	for( q = a; *q && p < line + 90; ) *p++ = *q++;
	for( q = b; *q && p < line + 130; ) *p++ = *q++;
	for( k = 0; k < 2u; k++ )
	{
		char d[12]; int n = 0; unsigned w = v[k];
		const char *lab = k ? c : " ";
		if( !c && ( k || !x )) break;                /* no label: the first number only, and only when non-zero */
		for( q = lab; *q && p < line + 180; ) *p++ = *q++;
		do { d[n++] = (char)( '0' + w % 10u ); w /= 10u; } while( w );
		while( n ) *p++ = d[--n];
	}
	*p = 0;
	zzhl_log( line );
}
/* "valve/save/<stem>.sav", stem [A-Za-z0-9_-], 1..24 chars -> the stem, lower case; NULL otherwise */
/* Save-game screenshots use the same extraction path as the save files. */
static const char *stem_of( const char *n, char *stem, const char *ext )
{
	size_t l = strlen( n ), sl, i;
	/* the name is PROVEN, not guessed.  The screenshot is written by ref_gl, not by
	   the engine's save code: FS_SaveImage -> Image_SaveBMP -> FS_Open( name, "wb", FALSE )
	   (img_bmp.c:385).  That FALSE is gamedironly, and FS_Open IGNORES it for write modes
	   (io.c:101) - it builds the path from fs_writepath->dir plus the name through
	   FS_FixFileCase (dir.c:312, FS_AppendToPath of dir->name and path).  So the screenshot
	   reaches us as "valve/save/<name>.bmp", exactly like the save itself.  The name was never
	   the reason build 74 wrote nothing. */
	if( l < 16 || strncasecmp( n, "valve/save/", 11 ) || strcasecmp( n + l - 4, ext )) return NULL;
	sl = l - 15;
	if( sl < 1 || sl > SAVE_STEM_MAX ) return NULL;
	for( i = 0; i < sl; i++ )
	{
		char c = n[11 + i];
		if( !(( c >= 'a' && c <= 'z' ) || ( c >= 'A' && c <= 'Z' ) || ( c >= '0' && c <= '9' ) || c == '_' || c == '-' )) return NULL;
		stem[i] = ( c >= 'A' && c <= 'Z' ) ? (char)( c + 32 ) : c;
	}
	stem[sl] = 0;
	return stem;
}
static const char *save_stem( const char *n, char *stem ) { return stem_of( n, stem, ".sav" ); }
static const char *shot_stem( const char *n, char *stem ) { return stem_of( n, stem, ".bmp" ); }
static void save_diskname( char *out, const char *stem, unsigned part )
{
	char *p = out;
	const char *q;
	for( q = "hlsv_"; *q; ) *p++ = *q++;
	for( q = stem; *q; ) *p++ = *q++;
	if( !part ) { for( q = ".sav"; *q; ) *p++ = *q++; }
	else { *p++ = '.'; *p++ = 's'; *p++ = (char)( '0' + ( part / 10u ) % 10u ); *p++ = (char)( '0' + part % 10u ); }
	*p = 0;
}
/* hlsv_<stem>.bmp, beside hlsv_<stem>.sav.  One file: these pictures are a few tens
   of KiB, far under FS_SERVICE_MAX, so they never need splitting. */
static void shot_diskname( char *out, const char *stem )
{
	char *p = out;
	const char *q;
	for( q = "hlsv_"; *q; ) *p++ = *q++;
	for( q = stem; *q; ) *p++ = *q++;
	for( q = ".bmp"; *q; ) *p++ = *q++;
	*p = 0;
}
static int idx_find( const char *stem ) { int i; for( i = 0; i < g_idx_n; i++ ) if( !strcmp( g_idx[i], stem )) return i; return -1; }
/* the list of saves on the disk, once; makes valve/save a directory when there is any */
static void idx_load( void )
{
	scratch_t *s;
	unsigned i, a;
	if( g_idx_loaded || !g_disk_saves ) return;
	g_idx_loaded = 1;
	s = sc_find( SAVE_IDX );
	if( !s ) s = sc_load_service( SAVE_IDX );
	if( !s ) return;
	for( i = 0, a = 0; i <= s->size; i++ )
	{
		if( i < s->size && s->data[i] != '\n' && s->data[i] != '\r' ) continue;
		if( i > a && i - a <= SAVE_STEM_MAX && g_idx_n < SAVE_IDX_MAX )
		{
			memcpy( g_idx[g_idx_n], s->data + a, i - a ); g_idx[g_idx_n][i - a] = 0;
			if( idx_find( g_idx[g_idx_n] ) < 0 || idx_find( g_idx[g_idx_n] ) == g_idx_n ) g_idx_n++;
		}
		a = i + 1;
	}
	if( g_idx_n && !is_dir_name( "valve/save" ) && g_dirs_n < 32 ) strcpy( g_dirs[g_dirs_n++], "valve/save" );
}
static void idx_write( void )
{
	scratch_t *s = sc_find( SAVE_IDX );
	unsigned need = 0, pos = 0;
	int i;
	for( i = 0; i < g_idx_n; i++ ) need += (unsigned)strlen( g_idx[i] ) + 1u;
	if( !s ) { s = sc_new( SAVE_IDX ); if( !s ) return; neg_del( SAVE_IDX ); }
	if( !sc_reserve( s, need + 1u )) return;
	for( i = 0; i < g_idx_n; i++ ) { size_t l = strlen( g_idx[i] ); memcpy( s->data + pos, g_idx[i], l ); pos += (unsigned)l; s->data[pos++] = '\n'; }
	s->size = pos;
	s->dirty = 1;
	if( !s->refs ) sc_flush( s );
}
/* n bytes at off of a disk file, short answers retried */
static int read_full( const char *base, unsigned off, unsigned char *dst, unsigned n )
{
	unsigned done = 0; int tries = 0;
	while( done < n && tries < 4 )
	{
		int got = zzhl_rt->read_at( base, off + done, dst + done, n - done, NULL );
		g_last_readat_us = zzhl_us64();
		zzhl_present_keepalive();
		xacp_loading_tick();          /* the loading screen moves on each read */
		if( got < 0 ) return -1;
		if( (unsigned)got < n - done ) tries++;
		done += (unsigned)got;
	}
	return done == n ? 0 : -1;
}
static scratch_t *save_load_disk( const char *stem, const char *n )
{
	char base[64];
	unsigned char hdr[SAVE_HDR];
	unsigned total0 = 0, size, parts, crc, k, off, want;
	unsigned version, rawlen, csize, paylen;   /* build 75 */
	unsigned char *pay;
	scratch_t *s;
	if( !zzhl_rt->read_at ) return NULL;
	save_diskname( base, stem, 0 );
	if( zzhl_rt->read_at( base, 0, hdr, SAVE_HDR, &total0 ) != (int)SAVE_HDR ) { slog( "save on the disk not found: ", base, 0, NULL, 0 ); g_saves_bad++; return NULL; }
	g_last_readat_us = zzhl_us64();
	size = get32( hdr + 8 ); parts = get32( hdr + 12 ); crc = get32( hdr + 16 );
	/* version 1 is the whole save in clear (builds 19-74, and the fallback whenever
	   deflate does not help), version 2 is SAVE_RAW bytes in clear then the deflated rest.
	   Both stay readable for ever: the version decides, nothing else changes. */
	version = get32( hdr + 4 );
	if( version == SAVE_V1 ) { rawlen = size; csize = 0; paylen = size; }
	else if( version == SAVE_VERSION )
	{
		rawlen = get32( hdr + 24 ); csize = get32( hdr + 28 );
		paylen = rawlen + csize;
		if( rawlen >= size || !csize || csize > 64u * 1024u * 1024u || paylen < rawlen )
		{ slog( "save refused (bad deflate header): ", base, rawlen, " clear, compressed ", csize ); g_saves_bad++; return NULL; }
	}
	else { slog( "save refused (unknown version): ", base, version, NULL, 0 ); g_saves_bad++; return NULL; }
	if( get32( hdr ) != SAVE_MAGIC || parts != ( paylen <= SAVE_P0 ? 1u : 1u + ( paylen - SAVE_P0 + FS_SERVICE_MAX - 1u ) / FS_SERVICE_MAX )
	    || total0 != SAVE_HDR + ( paylen < SAVE_P0 ? paylen : SAVE_P0 ) || size > 64u * 1024u * 1024u )
	{ slog( "save refused (bad header): ", base, total0, " bytes, says ", size ); g_saves_bad++; return NULL; }
	s = sc_new( n );
	if( !s ) return NULL;
	if( !sc_reserve( s, size + 1u )) { s->name[0] = 0; return NULL; }
	/* version 1 is read straight into place; version 2 needs the payload apart, to inflate from */
	if( version == SAVE_V1 ) pay = s->data;
	else
	{
		pay = (unsigned char *)malloc( paylen );
		if( !pay ) { free( s->data ); memset( s, 0, sizeof( *s )); zzhl_log( "xacp_fs: no memory to inflate the save, not loaded" ); g_saves_bad++; return NULL; }
	}
	for( k = 0, off = 0; k < parts; k++ )
	{
		unsigned total = 0;
		unsigned char b[4];
		want = paylen - off;
		if( !k ) { if( want > SAVE_P0 ) want = SAVE_P0; }
		else if( want > FS_SERVICE_MAX ) want = FS_SERVICE_MAX;
		save_diskname( base, stem, k );
		if( k && ( zzhl_rt->read_at( base, 0, b, 1, &total ) < 0 || total != want )) { slog( "save refused (a file is missing or has the wrong size): ", base, total, " bytes, expected ", want ); break; }
		if( read_full( base, k ? 0u : SAVE_HDR, pay + off, want )) { slog( "save refused (read error): ", base, off, NULL, 0 ); break; }
		off += want;
	}
	if( off == paylen && version == SAVE_VERSION )
	{   /* the clear head, then inflate the tail.  A failure here is a refused save, never a
		   half-loaded one - and the CRC below checks the result anyway. */
		unsigned long ulen = (unsigned long)( size - rawlen );
		memcpy( s->data, pay, rawlen );
		if( mz_uncompress( s->data + rawlen, &ulen, pay + rawlen, (unsigned long)csize ) != ZZHL_MZ_OK || ulen != (unsigned long)( size - rawlen ))
		{ slog( "save refused (inflate failed): hlsv_", stem, (unsigned)ulen, " bytes, expected ", size - rawlen ); off = 0; }
	}
	if( pay != s->data ) free( pay );
	if( off != paylen || crc32_of( s->data, size ) != crc )
	{
		if( off == paylen ) slog( "save refused (CRC differs): hlsv_", stem, size, NULL, 0 );
		free( s->data ); memset( s, 0, sizeof( *s ));
		g_saves_bad++;
		return NULL;
	}
	s->size = size;
	s->dirty = 0;
	s->mtime = get32( hdr + 20 ) ? get32( hdr + 20 ) : 1u;   /* build 50 */
	g_saves_read++;
	if( version == SAVE_VERSION ) slog( "save read from the disk, inflated: ", stem, paylen, " bytes -> ", size );
	else slog( "save read from the disk: ", stem, size, " bytes, files ", parts );
	return s;
}
/* ---- a save on the disk looked at without being read ----
 * The menu lists the saves: FS_Search of the .sav of save/, then for each its time (FS_FileTime -> stat)
 * and its comment (SV_GetSaveComment: the first bytes, the token list and the first section).  Up
 * to build 49 both read the whole save from the disk (save_get) and kept it in memory: every save
 * of the list, up to ~2.8 MiB each at ~1.1 MB/s, for a line of text.  Now stat reads the 32-byte
 * header once (size, time), and a save opened for its comment (the menu's call, through
 * xacp/dll/zzhl_menu_wrap.cpp) is served from the disk by READAT while the engine stays in its first
 * file; a read beyond reads it whole and checked (save_load_disk).  Loading a save is unchanged
 * (whole, CRC).  A save written or deleted forgets what was looked at. */
/* 'raw' is how many bytes from the start the disk serves VERBATIM.  Version 1 keeps
   the whole save in clear, so it is the first file's worth; version 2 keeps SAVE_RAW.  Beyond
   it the engine gets the whole save through save_load_disk(), which inflates - the existing
   fallback of this path, unchanged. */
typedef struct { char stem[SAVE_STEM_MAX + 1]; unsigned size, mtime, raw; int state; } peek_t;
static peek_t g_peek[SAVE_IDX_MAX];
static int g_save_peek_on;
void xacp_fs_save_peek( int on ) { g_save_peek_on = on; }   /* xacp/dll/zzhl_menu_wrap.cpp, around SV_GetSaveComment */
static unsigned g_peek_heads, g_peek_reads, g_peek_whole;
/* a header that could not be read is asked again.  On 15/11 (A4000, 17 h 28) the 32 bytes
   of hlsv_save006.sav and hlsv_save009.sav came back wrong ONCE each, in a run that also had three
   short READATs on the paks; the paks' reads are retried (sv_readat), this one was not, and its
   failure was remembered for the whole session: two saves "not on the disk" that the next run
   loaded.  Now: three requests at once, and a save whose header still does not read is looked at
   again the next time the engine asks for it, three times, before it is given up for the session.
   state: 1 read, -1 given up (a header that reads and is not a save's, or four failed looks),
   -2 and below: 1, 2, 3 failed looks. */
#define PEEK_TRIES   3
#define PEEK_LOOKS   3
static unsigned g_peek_retries, g_peek_recovered, g_peek_lost;
void zzhl_fs_peek_retry_stats( unsigned *retries, unsigned *recovered, unsigned *lost ) { *retries = g_peek_retries; *recovered = g_peek_recovered; *lost = g_peek_lost; }
static void slog( const char *a, const char *b, unsigned x, const char *c, unsigned y );
static void peek_forget( const char *stem )
{
	int i;
	for( i = 0; i < SAVE_IDX_MAX; i++ ) if( g_peek[i].stem[0] && !strcmp( g_peek[i].stem, stem )) memset( &g_peek[i], 0, sizeof( g_peek[i] ));
}
static peek_t *save_peek( const char *stem )
{
	int i, f = -1;
	char base[64];
	unsigned char hdr[SAVE_HDR];
	unsigned total = 0, size, parts;
	peek_t *p;
	int looks = 0;
	for( i = 0; i < SAVE_IDX_MAX; i++ )
	{
		if( g_peek[i].stem[0] && !strcmp( g_peek[i].stem, stem ))
		{
			if( g_peek[i].state > 0 ) return &g_peek[i];
			if( g_peek[i].state == -1 ) return NULL;
			f = i; looks = -g_peek[i].state - 1;          /* its header did not read; look again */
			break;
		}
		if( !g_peek[i].stem[0] && f < 0 ) f = i;
	}
	if( f < 0 || !zzhl_rt->read_at ) return NULL;
	p = &g_peek[f];
	strcpy( p->stem, stem );
	p->state = -1;
	save_diskname( base, stem, 0 );
	g_peek_heads++;
	{   /* see PEEK_TRIES above */
		int t, got = -1;
		for( t = 0; t < PEEK_TRIES; t++ )
		{
			total = 0;
			got = zzhl_rt->read_at( base, 0, hdr, SAVE_HDR, &total );
			g_last_readat_us = zzhl_us64();
			if( got == (int)SAVE_HDR && get32( hdr ) == SAVE_MAGIC ) break;
			g_peek_retries++;
			slog( t + 1 < PEEK_TRIES ? "save header did not read, asking again: " : "save header did not read: ", base, (unsigned)( got < 0 ? 0 : got ), " bytes, starts with ", got >= 4 ? get32( hdr ) : 0u );
		}
		if( t == PEEK_TRIES )
		{
			if( looks + 1 > PEEK_LOOKS ) { g_peek_lost++; slog( "save given up for this session (its header never read): ", base, 0, NULL, 0 ); }
			else p->state = -( looks + 2 );               /* looked at again the next time it is asked for */
			return NULL;
		}
		if( t || looks ) { g_peek_recovered++; slog( "save header read at last, after failed requests: ", base, (unsigned)( t + looks * PEEK_TRIES ), NULL, 0 ); }
	}
	size = get32( hdr + 8 ); parts = get32( hdr + 12 );
	{   /* version 1 or 2; 'parts' counts the PAYLOAD's files, not the save's size */
		unsigned version = get32( hdr + 4 ), rawlen, csize, paylen;
		if( version == SAVE_V1 ) { rawlen = size < SAVE_P0 ? size : SAVE_P0; paylen = size; }
		else if( version == SAVE_VERSION )
		{
			rawlen = get32( hdr + 24 ); csize = get32( hdr + 28 );
			paylen = rawlen + csize;
			if( rawlen >= size || !csize || paylen < rawlen ) return NULL;
		}
		else return NULL;
		if( get32( hdr ) != SAVE_MAGIC || size > 64u * 1024u * 1024u
		    || parts != ( paylen <= SAVE_P0 ? 1u : 1u + ( paylen - SAVE_P0 + FS_SERVICE_MAX - 1u ) / FS_SERVICE_MAX )) return NULL;
		p->raw = rawlen;
	}
	p->size = size;
	p->mtime = get32( hdr + 20 ) ? get32( hdr + 20 ) : 1u;
	p->state = 1;
	return p;
}
void zzhl_fs_peek_stats( unsigned *heads, unsigned *reads, unsigned *whole ) { *heads = g_peek_heads; *reads = g_peek_reads; *whole = g_peek_whole; }

/* a scratch file of the engine's, if it is a save on the disk not read yet */
/* a save renamed away (the engine's rotation autosave.sav -> autosave01.sav) or deleted is
   gone under that name until the engine writes it again.  Before, the next look at the name read
   the disk's copy back - the save just written, 150 to 400 KiB before each autosave (run of 11/11:
   5 reads for 4 saves).  The disk keeps its file: a crash between the rename and the write still
   finds the previous save at the next start. */
static char g_gone[16][FS_NAME_MAX];
static int gone_has( const char *n ) { int i; for( i = 0; i < 16; i++ ) if( g_gone[i][0] && ieq( g_gone[i], n )) return 1; return 0; }
static void gone_del( const char *n ) { int i; for( i = 0; i < 16; i++ ) if( g_gone[i][0] && ieq( g_gone[i], n )) g_gone[i][0] = 0; }
static void gone_add( const char *n )
{
	int i;
	if( gone_has( n )) return;
	for( i = 0; i < 16; i++ ) if( !g_gone[i][0] ) { strncpy( g_gone[i], n, FS_NAME_MAX - 1 ); g_gone[i][FS_NAME_MAX - 1] = 0; return; }
}
/* a save of the engine's that is on the disk and not in memory: its stem */
static int save_on_disk( const char *n, char *stem )
{
	if( !g_disk_saves || !save_stem( n, stem )) return 0;
	if( g_disk_only[0] && strncmp( stem, g_disk_only, strlen( g_disk_only ))) return 0;   /* build 49 */
	if( gone_has( n )) return 0;
	idx_load();
	return idx_find( stem ) >= 0;
}
static scratch_t *save_get( const char *n )
{
	char stem[SAVE_STEM_MAX + 1];
	if( !g_disk_saves || !save_stem( n, stem )) return NULL;
	if( g_disk_only[0] && strncmp( stem, g_disk_only, strlen( g_disk_only ))) return NULL;   /* build 49 */
	if( gone_has( n )) return NULL;
	idx_load();
	if( idx_find( stem ) < 0 ) return NULL;
	return save_load_disk( stem, n );
}
/* the screenshot of a save that is on the disk, read back as a plain BMP.  Its stem
   must be in the index, i.e. its save is on the disk: the picture never outlives the save it
   belongs to.  A missing or unreadable file is NOT an error - the menu simply shows no
   thumbnail, exactly as before this build. */
static scratch_t *shot_get( const char *n )
{
	char stem[SAVE_STEM_MAX + 1], base[64];
	unsigned total = 0;
	unsigned char probe[4];
	scratch_t *s;
	if( !g_disk_saves || !zzhl_rt->read_at || !shot_stem( n, stem )) return NULL;
	if( g_disk_only[0] && strncmp( stem, g_disk_only, strlen( g_disk_only ))) return NULL;
	if( gone_has( n )) return NULL;
	idx_load();
	if( idx_find( stem ) < 0 ) return NULL;
	shot_diskname( base, stem );
	if( zzhl_rt->read_at( base, 0, probe, 1, &total ) < 0 || !total || total > FS_SERVICE_MAX ) { hold_pak0(); return NULL; }
	g_last_readat_us = zzhl_us64();
	s = sc_new( n );
	if( !s ) { hold_pak0(); return NULL; }
	if( !sc_reserve( s, total + 1u )) { s->name[0] = 0; hold_pak0(); return NULL; }
	if( read_full( base, 0, s->data, total )) { free( s->data ); memset( s, 0, sizeof( *s )); hold_pak0(); return NULL; }
	hold_pak0();
	s->size = total;
	/* deflated since this build; a file without the header is one of the older ones and
	   is served as it is.  A picture that fails to inflate is dropped rather than served broken:
	   the menu then shows its own placeholder, which is what it does for a save with no picture. */
	if( total > SHOT_HDR && get32( s->data ) == SHOT_MAGIC )
	{
		unsigned raw = get32( s->data + 4 ), csize = get32( s->data + 8 );
		unsigned char *u = ( raw && raw <= FS_SERVICE_MAX && csize + SHOT_HDR <= total )
		                 ? (unsigned char *)malloc( raw + 1u ) : NULL;
		unsigned long ul = raw;
		if( !u || mz_uncompress( u, &ul, s->data + SHOT_HDR, (unsigned long)csize ) != 0 || ul != raw )
		{
			free( u );
			slog( "save screenshot will not inflate, dropped: ", stem, total, " bytes", 0 );
			free( s->data ); memset( s, 0, sizeof( *s ) );
			return NULL;
		}
		free( s->data );
		s->data = u; s->cap = raw + 1u; s->size = raw;
		slog( "save screenshot inflated from the disk: ", stem, total, " bytes -> ", raw );
	}
	else slog( "save screenshot read from the disk: ", stem, total, " bytes", 0 );
	s->dirty = 0;
	s->mtime = 1u;
	g_shots_read++;
	return s;
}
/* guard: the half-second distance from the last READAT, needed before the first file of a save
   only (the request before each later write is the READAT of the previous file's size check;
   service_write puts the pak0.pak READAT after it).  The size check leaves the file held by the
   68k: harmless, the next write starts with hold_pak0. */
static int write_disk_file( const char *base, const unsigned char *p, unsigned n, int guard )
{
	unsigned total = 0; unsigned char b[4];
	if( service_write( base, p, n, guard )) { slog( "save: not written: ", base, 0, NULL, 0 ); return -1; }
	if( zzhl_rt->read_at( base, 0, b, 1, &total ) < 0 || total != n ) { slog( "save: written file has the wrong size: ", base, total, " bytes, expected ", n ); return -1; }
	g_last_readat_us = zzhl_us64();
	return 0;
}
static int save_flush_hook( scratch_t *s )
{
	char stem[SAVE_STEM_MAX + 1], base[64];
	unsigned parts, k, off, n;
	if( g_disk_saves && shot_stem( s->name, stem ))
	{   /* the save's screenshot.  One file, no header and no CRC on purpose: a picture
	       that fails to arrive costs a missing thumbnail, never a refused save, and the engine
	       re-reads it as a plain BMP.  Written AFTER the save's own files by construction - the
	       engine closes the .sav first (its console prints the save, then "Write ....bmp"). */
		if( g_disk_only[0] && strncmp( stem, g_disk_only, strlen( g_disk_only ))) return 1;
		if( !zzhl_rt->fopen || !s->size ) return 1;
		if( s->size > FS_SERVICE_MAX )
		{ slog( "save screenshot too large for one file, kept in memory: ", stem, s->size, NULL, 0 ); return 1; }
		shot_diskname( base, stem );
		/* Compress screenshot payloads to reduce filesystem I/O. */
		{
			unsigned char *cb = NULL;
			unsigned long cl = 0;
			const unsigned char *out = s->data;
			unsigned outn = s->size;
			cl = (unsigned long)s->size;
			cb = (unsigned char *)malloc( SHOT_HDR + (size_t)cl );
			if( cb )
			{
				if( mz_compress2( cb + SHOT_HDR, &cl, s->data, (unsigned long)s->size, 1 ) == 0
				 && (unsigned)cl + SHOT_HDR < s->size )
				{
					put32( cb, SHOT_MAGIC );
					put32( cb + 4, s->size );
					put32( cb + 8, (unsigned)cl );
					out = cb; outn = SHOT_HDR + (unsigned)cl;
				}
			}
			if( service_write( base, out, outn, 1 )) slog( "save screenshot not written: ", base, 0, NULL, 0 );
			else
			{
				g_shots_written++;
				if( out == s->data ) slog( "save screenshot written to the disk: ", stem, s->size, " bytes", 0 );
				else slog( "save screenshot deflated to the disk: ", stem, outn, " bytes of ", s->size );
			}
			free( cb );
		}
		hold_pak0();
		return 1;
	}
	if( !g_disk_saves || !save_stem( s->name, stem )) return 0;
	if( g_disk_only[0] && strncmp( stem, g_disk_only, strlen( g_disk_only ))) return 1;   /* memory only */
	if( !zzhl_rt->fopen || !zzhl_rt->read_at ) return 1;
	idx_load();
	if( !g_save_buf ) g_save_buf = (unsigned char *)malloc( FS_SERVICE_MAX );
	if( !g_save_buf ) { zzhl_log( "xacp_fs: no memory for the save buffer, save kept in memory only" ); return 1; }
	/* what actually goes to the disk.  Without compression it IS s->data, exactly as
	   builds 19-74; with it, SAVE_RAW bytes in clear then deflate() of the rest, in one buffer.
	   mz_compress2 returns MZ_BUF_ERROR when the result would not fit in what we gave it, which
	   is precisely the "not worth it" case: we then fall back to version 1 and lose nothing. */
	{
		const unsigned char *pay = s->data;
		unsigned paylen = s->size, rawlen = s->size, csize = 0, version = SAVE_V1;
		unsigned char *cbuf = NULL;
		if( s->size > SAVE_RAW + 1024u )
		{
			cbuf = (unsigned char *)malloc( s->size );
			if( cbuf )
			{
				unsigned long clen = (unsigned long)( s->size - SAVE_RAW );
				memcpy( cbuf, s->data, SAVE_RAW );
				if( mz_compress2( cbuf + SAVE_RAW, &clen, s->data + SAVE_RAW, (unsigned long)( s->size - SAVE_RAW ), 1 ) == ZZHL_MZ_OK )
				{
					rawlen = SAVE_RAW; csize = (unsigned)clen;
					paylen = rawlen + csize; pay = cbuf; version = SAVE_VERSION;
				}
				else { free( cbuf ); cbuf = NULL; }
			}
		}
		parts = paylen <= SAVE_P0 ? 1u : 1u + ( paylen - SAVE_P0 + FS_SERVICE_MAX - 1u ) / FS_SERVICE_MAX;
		if( parts > 99u ) { free( cbuf ); slog( "save too large for the disk files, kept in memory: ", stem, s->size, NULL, 0 ); return 1; }
		/* the data files first, file 0 (header) last: a save cut by a crash keeps the previous
		   header, whose CRC then refuses the mix instead of loading it */
		for( k = parts; k-- > 0; )
		{
			save_diskname( base, stem, k );
			if( !k )
			{
				n = paylen < SAVE_P0 ? paylen : SAVE_P0;
				put32( g_save_buf, SAVE_MAGIC ); put32( g_save_buf + 4, version ); put32( g_save_buf + 8, s->size );
				put32( g_save_buf + 12, parts ); put32( g_save_buf + 16, crc32_of( s->data, s->size ));
				memset( g_save_buf + 20, 0, SAVE_HDR - 20u );
				put32( g_save_buf + 20, s->mtime );   /* when (0 before: no time) */
				put32( g_save_buf + 24, rawlen );     /* bytes kept in clear */
				put32( g_save_buf + 28, csize );      /* 0 when version 1 */
				memcpy( g_save_buf + SAVE_HDR, pay, n );
				if( write_disk_file( base, g_save_buf, SAVE_HDR + n, parts == 1u )) { free( cbuf ); return 1; }
			}
			else
			{
				off = SAVE_P0 + ( k - 1u ) * FS_SERVICE_MAX;
				n = paylen - off; if( n > FS_SERVICE_MAX ) n = FS_SERVICE_MAX;
				if( write_disk_file( base, pay + off, n, k == parts - 1u )) { free( cbuf ); return 1; }
			}
		}
		if( version == SAVE_VERSION )
			slog( "save deflated: ", stem, s->size, " bytes -> ", paylen );
		free( cbuf );
	}
	g_saves_written++;
	peek_forget( stem );               /* build 50 */
	slog( "save written to the disk: ", stem, s->size, " bytes, files ", parts );
	if( idx_find( stem ) < 0 && g_idx_n < SAVE_IDX_MAX ) { strcpy( g_idx[g_idx_n++], stem ); idx_write(); }
	return 1;
}

/* ---- fd table ---- */
static int fd_alloc( void )
{
	int i;
	for( i = 3; i < FS_MAX_FD; i++ ) if( g_fd[i].kind == FD_NONE ) return i;
	errno = EMFILE;
	return -1;
}
static fd_t *fd_get( int fd )
{
	if( fd >= 0 && fd < 3 ) { g_fd[fd].kind = FD_STD; return &g_fd[fd]; }
	if( fd < 3 || fd >= FS_MAX_FD || g_fd[fd].kind == FD_NONE ) { errno = EBADF; return NULL; }
	return &g_fd[fd];
}

/* which big files exist: ".pak" names are READAT files, the rest goes to the service READ.
   A file bigger than the service limit that is not a pak would need READAT too: not needed by
   Half-Life (everything is in the paks). */
static int wants_readat( const char *n ) { size_t l = strlen( n ); return l > 4 && !strcasecmp( n + l - 4, ".pak" ); }

/* ---- the syscalls newlib forwards to ---- */
/* (the build 77 diagnostic lines "ASK open" / "ASK stat" are gone: they had answered their question) */
int _open( const char *path, int flags, int mode )
{
	char n[FS_NAME_MAX];
	int fd;
	scratch_t *s;
	svcfile_t *v;
	(void)mode;
	norm( n, path );
	fd = fd_alloc();
	if( fd < 0 ) return -1;
	memset( &g_fd[fd], 0, sizeof( g_fd[fd] ));
	g_fd[fd].flags = flags;
	if(( flags & O_ACCMODE ) == O_RDONLY )
	{
		char stem[SAVE_STEM_MAX + 1];
		peek_t *pk;
		s = sc_find( n );
		if( !s && g_save_peek_on && save_on_disk( n, stem ) && ( pk = save_peek( stem )) != NULL )
		{   /* served from the disk while the engine stays in the first file */
			g_fd[fd].kind = FD_PEEK;
			strcpy( g_fd[fd].pstem, stem );
			strncpy( g_fd[fd].pname, n, sizeof( g_fd[fd].pname ) - 1 );
			g_fd[fd].psize = pk->size;
			g_fd[fd].praw = pk->raw;   /* build 75 */
			return fd;
		}
		if( !s ) s = save_get( n );
		if( !s ) s = shot_get( n );   /* the save's screenshot, for the menu's list */
		if( !s && wants_readat( n ))
		{
			v = sv_open( n );
			if( v ) { v->refs++; g_fd[fd].kind = FD_SVC; g_fd[fd].sv = v; return fd; }
		}
		if( !s ) s = sc_load_service( n );
		if( !s ) { errno = ENOENT; return -1; }
		s->refs++;
		g_fd[fd].kind = FD_SCRATCH; g_fd[fd].sc = s;
		return fd;
	}
	if( wants_readat( n )) { errno = EACCES; return -1; }
	s = sc_find( n );
	if( !s && !( flags & O_TRUNC )) s = save_get( n );
	if( !s && !( flags & O_TRUNC )) s = shot_get( n );   /* the save's screenshot */
	if( !s && !( flags & O_TRUNC )) s = sc_load_service( n );
	if( !s )
	{
		if( !( flags & O_CREAT )) { errno = ENOENT; return -1; }
		s = sc_new( n );
		if( !s ) { errno = ENOSPC; return -1; }
		neg_del( n );
		gone_del( n );                 /* build 41 */
	}
	if( flags & O_TRUNC ) s->size = 0;
	s->refs++;
	s->dirty = 1;
	g_fd[fd].kind = FD_SCRATCH; g_fd[fd].sc = s;
	g_fd[fd].pos = ( flags & O_APPEND ) ? s->size : 0;
	return fd;
}

/* a memory file closed gives back what its doubling growth took beyond its size (a save
   of 2.8 MiB held 4 MiB; Half-Life keeps every visited level's state and the saves in memory) */
static void sc_trim( scratch_t *s )
{
	unsigned char *d;
	if( !s->data || s->cap <= s->size + 65536u ) return;
	d = (unsigned char *)realloc( s->data, s->size + 1u );
	if( d ) { s->data = d; s->cap = s->size + 1u; }
}
/* the memory the saves take: the files under valve/save/ (each visited level's state,
   the saves), their sizes and what the heap gives them; the largest .sav */
void zzhl_fs_save_memory( unsigned *files, unsigned *bytes, unsigned *taken, unsigned *largest_sav )
{
	int i;
	*files = *bytes = *taken = *largest_sav = 0;
	for( i = 0; i < FS_MAX_SCRATCH; i++ )
	{
		size_t l;
		if( !g_sc[i].name[0] || strncasecmp( g_sc[i].name, "valve/save/", 11 )) continue;
		( *files )++; *bytes += g_sc[i].size; *taken += g_sc[i].cap;
		l = strlen( g_sc[i].name );
		if( l > 4 && !strcasecmp( g_sc[i].name + l - 4, ".sav" ) && g_sc[i].size > *largest_sav ) *largest_sav = g_sc[i].size;
	}
}
unsigned zzhl_fs_scratch_size( const char *path )
{
	char n[FS_NAME_MAX];
	scratch_t *s;
	norm( n, path );
	s = sc_find( n );
	return s ? s->size : 0u;
}
int _close( int fd )
{
	fd_t *d = fd_get( fd );
	if( !d ) return -1;
	if( d->kind == FD_SCRATCH && d->sc && --d->sc->refs <= 0 ) { d->sc->refs = 0; sc_flush( d->sc ); sc_trim( d->sc ); }
	if( d->kind == FD_SVC && d->sv && d->sv->refs > 0 ) d->sv->refs--;
	if( fd >= 3 ) memset( d, 0, sizeof( *d ));
	return 0;
}

/* ---- a map read whole is checked, and read again when it is wrong ----
 * Builds 8, 10 and 33b (08/11, c0a0 -> c0a0a): right after a level change, the BSP read out of
 * pak0.pak held a stretch of wrong bytes (1596 planes without a normal, then a 4 GB allocation and
 * Host_Error), with no short answer, no error and no timeout from the file service; 206 map loads
 * of the SOAK, none through a level change, had none.  The cause is not known.  Here: a read of
 * 32 KiB or more that starts with a BSP header (version 29 or 30) whose lumps all lie inside it has
 * its planes checked (a normal of length 0.5 to 1.5, as Mod_LoadPlanes wants); more than 8 bad
 * planes = the read is done again straight from the launcher, the block cache bypassed and its
 * blocks of that range dropped, at most 3 times.  Each case is logged with the 64 KiB blocks that
 * changed between the reads (where the wrong bytes were), and counted in the exit report. */
static unsigned g_bsp_checks, g_bsp_bad, g_bsp_fixed;
void zzhl_fs_bsp_stats( unsigned *checks, unsigned *bad, unsigned *fixed ) { *checks = g_bsp_checks; *bad = g_bsp_bad; *fixed = g_bsp_fixed; }
static unsigned rd_le32( const unsigned char *p ) { return (unsigned)p[0] | ((unsigned)p[1] << 8 ) | ((unsigned)p[2] << 16 ) | ((unsigned)p[3] << 24 ); }
/* -1 = not a whole BSP (not checked), else the number of bad planes; *first = the first bad one */
static int bsp_bad_planes( const unsigned char *b, unsigned n, unsigned *first )
{
	unsigned ver, k, pofs, plen, i, bad = 0;
	if( n < 32768u ) return -1;
	ver = rd_le32( b );
	if( ver != 29u && ver != 30u ) return -1;
	for( k = 0; k < 15u; k++ )
	{
		unsigned o = rd_le32( b + 4u + k * 8u ), l = rd_le32( b + 8u + k * 8u );
		if( o > n || l > n - o ) return -1;          /* not the whole file (or its header is the damage: the engine says so) */
	}
	pofs = rd_le32( b + 4u + 8u ); plen = rd_le32( b + 8u + 8u );       /* LUMP_PLANES = 1 */
	if( plen && b[pofs] == '{' ) { pofs = rd_le32( b + 4u ); plen = rd_le32( b + 8u ); }   /* Blue Shift: planes and entities swapped */
	if( plen % 20u ) return -1;
	*first = 0;
	for( i = 0; i < plen / 20u; i++ )
	{
		float v[3], l2;
		memcpy( v, b + pofs + i * 20u, sizeof( v ));
		l2 = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
		if( !( l2 >= 0.25f && l2 <= 2.25f )) { if( !bad ) *first = i; bad++; }
	}
	return (int)bad;
}
/* a studio model (.mdl, ident IDST, version 10) read whole is checked the same way.  Build 35
 * run of 08/11: a data abort in ref_gl's R_StudioDrawPoints, its sub-model pointer an odd address
 * (0x18b8a045, header + a bodypart's modelindex), right after a load: a model read with wrong bytes,
 * as the maps above, is the likely cause (not proven).  Every table the header points at must lie in
 * the file (bones, controllers, hitboxes, sequences and their events, sequence groups, textures and
 * their pixels, skins, body parts, their models, the meshes, vertices and normals of each model,
 * attachments), with sane counts; the number of tables that do not is the "bad" count, any = read
 * again.  Only a whole file is checked (its length field = the read), texture files (T.mdl) too.
 * Offsets: hlsdk-portable engine/studio.h (studiohdr_t 244 bytes, seqdesc 176, texture 80, bodypart 76,
 * model 112, mesh 20, printed by offsetof on the PC); "first" names the first table found wrong. */
static unsigned g_mdl_checks, g_mdl_bad, g_mdl_fixed;
void zzhl_fs_mdl_stats( unsigned *checks, unsigned *bad, unsigned *fixed ) { *checks = g_mdl_checks; *bad = g_mdl_bad; *fixed = g_mdl_fixed; }
static int tab_bad( unsigned n, unsigned cnt, unsigned idx, unsigned size )
{
	if( cnt == 0u ) return 0;
	if( cnt > 65536u || size == 0u || idx > n ) return 1;
	return ( (unsigned long long)cnt * size > (unsigned long long)( n - idx )) ? 1 : 0;
}
static int mdl_bad_tables( const unsigned char *b, unsigned n, unsigned *first )
{
	unsigned bad = 0, k, m, nbones, nbp, nseq, ntex;
	if( n < 244u || b[0] != 'I' || b[1] != 'D' || b[2] != 'S' || b[3] != 'T' || rd_le32( b + 4u ) != 10u ) return -1;
	if( rd_le32( b + 72u ) != n ) return -1;                   /* not the whole file */
	*first = 0;
#define TB( c, i, sz, tag ) do { if( tab_bad( n, rd_le32( b + ( c )), rd_le32( b + ( i )), ( sz ))) { if( !bad ) *first = ( tag ); bad++; } } while( 0 )
	nbones = rd_le32( b + 140u );
	TB( 140u, 144u, 112u, 1u );                                 /* bones */
	TB( 148u, 152u, 24u, 2u );                                  /* bone controllers */
	TB( 156u, 160u, 32u, 3u );                                  /* hitboxes */
	TB( 164u, 168u, 176u, 4u );                                 /* sequences */
	TB( 172u, 176u, 104u, 5u );                                 /* sequence groups */
	TB( 180u, 184u, 80u, 6u );                                  /* textures */
	TB( 204u, 208u, 76u, 7u );                                  /* body parts */
	TB( 212u, 216u, 88u, 8u );                                  /* attachments */
	{   unsigned refs = rd_le32( b + 192u ), fams = rd_le32( b + 196u );
		if( refs > 4096u || fams > 4096u || tab_bad( n, refs * fams, rd_le32( b + 200u ), 2u )) { if( !bad ) *first = 9u; bad++; } }
	if( bad ) return (int)bad;
	nseq = rd_le32( b + 164u );
	for( k = 0; k < nseq; k++ )
	{
		const unsigned char *q = b + rd_le32( b + 168u ) + k * 176u;
		if( tab_bad( n, rd_le32( q + 48u ), rd_le32( q + 52u ), 76u )) { if( !bad ) *first = 10u; bad++; }   /* events */
		if( rd_le32( q + 156u ) == 0u && rd_le32( q + 124u ) >= n ) { if( !bad ) *first = 11u; bad++; }   /* seqgroup 0: animations in this file */
	}
	ntex = rd_le32( b + 180u );
	if( rd_le32( b + 188u ))
		for( k = 0; k < ntex; k++ )
		{
			const unsigned char *t = b + rd_le32( b + 184u ) + k * 80u;
			unsigned w = rd_le32( t + 68u ), h = rd_le32( t + 72u );
			if( w > 4096u || h > 4096u || tab_bad( n, 1u, rd_le32( t + 76u ), w * h + 768u )) { if( !bad ) *first = 12u; bad++; }
		}
	nbp = rd_le32( b + 204u );
	for( k = 0; k < nbp; k++ )
	{
		const unsigned char *bp = b + rd_le32( b + 208u ) + k * 76u;
		unsigned nm = rd_le32( bp + 64u ), mi = rd_le32( bp + 72u );
		if( tab_bad( n, nm, mi, 112u )) { if( !bad ) *first = 13u; bad++; continue; }
		for( m = 0; m < nm; m++ )
		{
			const unsigned char *md = b + mi + m * 112u;
			unsigned nmesh = rd_le32( md + 72u ), nverts = rd_le32( md + 80u ), nnorms = rd_le32( md + 92u ), x;
			if( tab_bad( n, nmesh, rd_le32( md + 76u ), 20u ) || tab_bad( n, nverts, rd_le32( md + 88u ), 12u ) || tab_bad( n, nverts, rd_le32( md + 84u ), 1u )
			    || tab_bad( n, nnorms, rd_le32( md + 100u ), 12u ) || tab_bad( n, nnorms, rd_le32( md + 96u ), 1u )) { if( !bad ) *first = 14u; bad++; continue; }
			for( x = 0; x < nmesh; x++ )
				if( rd_le32( b + rd_le32( md + 76u ) + x * 20u + 4u ) >= n ) { if( !bad ) *first = 15u; bad++; break; }   /* triangle commands */
		}
	}
	(void)nbones;
#undef TB
	return (int)bad;
}
static unsigned blk_sum( const unsigned char *p, unsigned n ) { unsigned h = 2166136261u, i; for( i = 0; i < n; i++ ) h = ( h ^ p[i] ) * 16777619u; return h; }
/* build 34 (maps), models: read again while the checker finds more than `allowed` bad items */
typedef int ( *whole_checker_t )( const unsigned char *b, unsigned n, unsigned *first );
static void whole_check( svcfile_t *s, unsigned pos, unsigned char *buf, unsigned n, whole_checker_t chk, int allowed,
                         const char *what, const char *items, unsigned *checks, unsigned *bads, unsigned *fixed )
{
	unsigned first = 0, attempt, nb, i;
	int bad = chk( buf, n, &first );
	unsigned sums[128];
	if( bad < 0 ) return;
	( *checks )++;
	if( bad <= allowed ) return;
	( *bads )++;
	nb = ( n + XFS_BLOCK - 1u ) / XFS_BLOCK; if( nb > 128u ) nb = 128u;
	for( attempt = 1; attempt <= 3u; attempt++ )
	{
		char line[200];
		unsigned changed = 0, lo = 0xFFFFFFFFu, hi = 0, b0, b1;
		int got;
		snprintf( line, sizeof( line ), "xacp_fs: %s read check: %d bad %s (first #%u) in %u bytes at %u of %s, read again (%u)", what, bad, items, first, n, pos, basename_of( s->name ), attempt );
		zzhl_log( line );
		for( i = 0; i < nb; i++ ) sums[i] = blk_sum( buf + i * XFS_BLOCK, ( i + 1u ) * XFS_BLOCK <= n ? XFS_BLOCK : n - i * XFS_BLOCK );
		b0 = pos / XFS_BLOCK; b1 = ( pos + n - 1u ) / XFS_BLOCK;     /* the cache may hold the wrong bytes: dropped */
		for( i = 0; i < g_ncb; i++ )
			if( g_cb[i].file == sv_index( s ) + 1 && g_cb[i].block >= b0 && g_cb[i].block <= b1 ) { g_cb[i].file = 0; g_cb[i].stamp = 0; }
		got = sv_readat( s, pos, buf, n );
		for( i = 0; i < nb; i++ )
			if( sums[i] != blk_sum( buf + i * XFS_BLOCK, ( i + 1u ) * XFS_BLOCK <= n ? XFS_BLOCK : n - i * XFS_BLOCK )) { changed++; if( i < lo ) lo = i; hi = i; }
		bad = ( got == (int)n ) ? chk( buf, n, &first ) : 9999;
		if( changed ) snprintf( line, sizeof( line ), "xacp_fs: %s read check: %u of %u blocks of 64 KiB changed (blocks %u..%u of the read, file offset %u..%u); now %d bad %s",
			what, changed, nb, lo, hi, pos + lo * XFS_BLOCK, pos + ( hi + 1u ) * XFS_BLOCK, bad, items );
		else snprintf( line, sizeof( line ), "xacp_fs: %s read check: the second read gave the same bytes; %d bad %s", what, bad, items );
		zzhl_log( line );
		if( bad >= 0 && bad <= allowed ) { ( *fixed )++; snprintf( line, sizeof( line ), "xacp_fs: %s read check: fixed by the new read", what ); zzhl_log( line ); return; }
	}
	{ char line[120]; snprintf( line, sizeof( line ), "xacp_fs: %s read check: still wrong after 3 reads", what ); zzhl_log( line ); }
}

/* ---- the directory of a pak, and the animation files read with their model ----
 * Half-Life keeps part of a character's animations in separate files, the "sequence groups"
 * (models/scientist01.mdl ... named in the model's header), and reads one the first time a
 * character plays an animation of it: during the game, from the disk (run of 11/11, * 9 such loads in 605 s, e.g. barney02 and zombie02 at 00:38:32, each a stop of the game).  When a
 * studio model is read whole (the level's load), its groups are read too, into the block cache:
 * the later load is a copy from memory.  The pak's directory (64-byte entries: name[56], offset,
 * length) is read once, from the cache, the engine reading it as well; it also names the file
 * inside the pak of each READAT of the game in the disk report (xacp_disk.c).  PREFETCH=0: off. */
typedef struct { unsigned char *dir; unsigned n; int state; } pakdir_t;   /* state 0 not read, 1 read, -1 none */
static pakdir_t g_pd[FS_MAX_SVC];
static svcfile_t *g_want_sv;       /* the file and position the engine (or the read-ahead) is reading: the */
static unsigned g_want_pos;        /* READATs of the block cache start at a block's start, maybe another file's */
static int pak_dir( svcfile_t *s )
{
	pakdir_t *d = &g_pd[sv_index( s )];
	unsigned char h[12];
	unsigned ofs, len;
	if( d->state ) return d->state > 0;
	d->state = -1;
	if( !is_pak_name( s->name ) || sv_read( s, 0, h, 12 ) != 12 || memcmp( h, "PACK", 4 )) return 0;
	ofs = rd_le32( h + 4 ); len = rd_le32( h + 8 );
	if( !len || len % 64u || len > 64u * 65536u || ofs > s->size || len > s->size - ofs ) return 0;
	d->dir = (unsigned char *)malloc( len );
	if( !d->dir ) return 0;
	if( sv_read( s, ofs, d->dir, len ) != (int)len ) { free( d->dir ); d->dir = NULL; return 0; }
	d->n = len / 64u; d->state = 1;
	return 1;
}
/* a name of the pak's directory against a model's name: '\' = '/', any case */
static int pak_name_eq( const unsigned char *ent, const char *want )
{
	unsigned i;
	for( i = 0; i < 56u; i++ )
	{
		char a = (char)ent[i], b = want[i];
		if( a == '\\' ) a = '/';
		if( b == '\\' ) b = '/';
		if( a >= 'A' && a <= 'Z' ) a = (char)( a + 32 );
		if( b >= 'A' && b <= 'Z' ) b = (char)( b + 32 );
		if( a != b ) return 0;
		if( !a ) return 1;
	}
	return want[56] == 0;
}
/* the pak holding <want> (the last opened first, as the engine searches), its offset and length */
static svcfile_t *pak_find( const char *want, unsigned *pos, unsigned *len )
{
	int i;
	unsigned k;
	for( i = FS_MAX_SVC; i-- > 0; )
	{
		svcfile_t *s = &g_sv[i];
		if( !s->used || !pak_dir( s )) continue;
		for( k = 0; k < g_pd[i].n; k++ )
		{
			const unsigned char *e = g_pd[i].dir + k * 64u;
			if( !pak_name_eq( e, want )) continue;
			*pos = rd_le32( e + 56u ); *len = rd_le32( e + 60u );
			if( *pos > s->size || *len > s->size - *pos ) return NULL;
			return s;
		}
	}
	return NULL;
}
/* xacp_disk.c: the file of the pak <flat> ("pak0.pak") holding <off>; NULL when the directory is not
   read (never read from here: called in the middle of a request) */
const char *xacp_fs_pak_entry( const char *flat, unsigned off )
{
	static char out[57];
	int i;
	unsigned k;
	for( i = 0; i < FS_MAX_SVC; i++ )
	{
		if( !g_sv[i].used || g_pd[i].state != 1 || !ieq( basename_of( g_sv[i].name ), flat )) continue;
		if( g_want_sv == &g_sv[i] ) off = g_want_pos;
		for( k = 0; k < g_pd[i].n; k++ )
		{
			const unsigned char *e = g_pd[i].dir + k * 64u;
			unsigned p = rd_le32( e + 56u ), l = rd_le32( e + 60u );
			if( off >= p && off - p < ( l ? l : 1u )) { memcpy( out, e, 56 ); out[56] = 0; return out; }
		}
		return "(pak header or directory)";
	}
	return NULL;
}
static unsigned g_pf_files, g_pf_bytes, g_pf_us, g_pf_missing;
static int g_prefetch = -1;
void zzhl_fs_prefetch_stats( unsigned *files, unsigned *kib, unsigned *ms, unsigned *missing ) { *files = g_pf_files; *kib = g_pf_bytes / 1024u; *ms = g_pf_us / 1000u; *missing = g_pf_missing; }
static void mdl_groups_ahead( const unsigned char *b, unsigned n )
{
	unsigned ng, gi, g;
	if( g_prefetch < 0 ) { const char *v = zzhl_option( "PREFETCH" ); g_prefetch = ( v && v[0] == '0' ) ? 0 : 1; }
	if( !g_prefetch ) return;
	if( n < 244u || memcmp( b, "IDST", 4 ) || rd_le32( b + 4u ) != 10u || rd_le32( b + 72u ) != n ) return;
	ng = rd_le32( b + 172u ); gi = rd_le32( b + 176u );
	if( ng < 2u || ng > 100u || tab_bad( n, ng, gi, 104u )) return;
	if( !cache_alloc() || g_ncb < 256u ) return;            /* the cache keeps whole blocks from 16 MiB on only */
	for( g = 1; g < ng; g++ )
	{
		char want[65], line[200];
		unsigned pos = 0, len = 0, b0, b1, k, miss = 0;
		unsigned long long t0;
		unsigned char *tmp;
		svcfile_t *s;
		int got;
		memcpy( want, b + gi + g * 104u + 32u, 64 ); want[64] = 0;
		if( !want[0] ) continue;
		s = pak_find( want, &pos, &len );
		if( !s || !len )
		{
			g_pf_missing++;
			snprintf( line, sizeof( line ), "xacp_fs: animation file not in the paks: %s", want );
			zzhl_log( line );
			continue;
		}
		b0 = pos / XFS_BLOCK; b1 = ( pos + len - 1u ) / XFS_BLOCK;
		for( k = b0; k <= b1; k++ ) if( !cache_has( sv_index( s ), k )) miss++;
		if( !miss ) continue;                                    /* in the cache already */
		tmp = (unsigned char *)malloc( len );
		if( !tmp ) continue;
		t0 = zzhl_us64();
		g_want_sv = s; g_want_pos = pos;
		got = sv_read( s, pos, tmp, len );
		g_want_sv = NULL;
		free( tmp );
		if( got != (int)len ) continue;
		g_pf_files++; g_pf_bytes += len; g_pf_us += (unsigned)( zzhl_us64() - t0 );
		snprintf( line, sizeof( line ), "xacp_fs: animations read with their model: %s, %u KiB, %u ms", want, len / 1024u, (unsigned)(( zzhl_us64() - t0 ) / 1000u ));
		zzhl_log( line );
	}
}

/* what the game read the first time it served, in the run of 11/11 (the 64 first
   requests of the game, build 41): the HEV suit's voice (sound/fvox/), the HUD's sprites and their
   lists (sprites/640*, the .txt of sprites/), the decals (decals.wad), the words of the characters'
   sentences (sound/scientist/ ...).  Each a READAT of ~60 ms in a frame of the game.  Read ahead,
   once a session: the first set at the first load, a character's voice with its model.  A set
   larger than VOICEMB MiB (default 8) is not read, its size written to the log: what it would
   cost.  The files of a set, sorted by offset, are read as ranges (gaps under a block merged),
   in pieces of 1 MiB: the block cache keeps them. */
typedef struct { const char *prefix, *suffix; } pfset_t;
static const pfset_t g_set_first[] = { { "sound/fvox/", NULL }, { "sprites/640", NULL }, { "sprites/", ".txt" }, { "decals.wad", NULL } };
static const struct { const char *model, *prefix; } g_voice[] = {
	{ "models/scientist.mdl", "sound/scientist/" }, { "models/barney.mdl", "sound/barney/" },
	{ "models/hgrunt.mdl", "sound/hgrunt/" }, { "models/gman.mdl", "sound/gman/" } };
#define N_VOICE ( sizeof( g_voice ) / sizeof( g_voice[0] ))
static unsigned char g_voice_done[N_VOICE], g_first_done;
static unsigned g_vf_sets, g_vf_files, g_vf_bytes, g_vf_us, g_vf_skipped;
void zzhl_fs_voice_stats( unsigned *sets, unsigned *files, unsigned *kib, unsigned *ms, unsigned *skipped )
{ *sets = g_vf_sets; *files = g_vf_files; *kib = g_vf_bytes / 1024u; *ms = g_vf_us / 1000u; *skipped = g_vf_skipped; }
static int pf_match( const unsigned char *ent, const pfset_t *set, unsigned nset )
{
	char nm[57];
	unsigned i, k, l;
	for( i = 0; i < 56u; i++ ) { char c = (char)ent[i]; if( c == '\\' ) c = '/'; if( c >= 'A' && c <= 'Z' ) c = (char)( c + 32 ); nm[i] = c; if( !c ) break; }
	nm[56] = 0;
	l = (unsigned)strlen( nm );
	for( k = 0; k < nset; k++ )
	{
		unsigned pl = (unsigned)strlen( set[k].prefix );
		if( l < pl || memcmp( nm, set[k].prefix, pl )) continue;
		if( set[k].suffix ) { unsigned sl = (unsigned)strlen( set[k].suffix ); if( l < sl || strcmp( nm + l - sl, set[k].suffix )) continue; }
		return 1;
	}
	return 0;
}
typedef struct { unsigned pos, len; } pfent_t;
static int pfent_cmp( const void *a, const void *b ) { unsigned x = ((const pfent_t *)a)->pos, y = ((const pfent_t *)b)->pos; return x < y ? -1 : x > y; }
/* 1 when a pak holds the set (read, or skipped as too large), 0 when none does: asked again later */
static int prefetch_set( const pfset_t *set, unsigned nset, const char *why )
{
	static pfent_t e[1024];
	unsigned n = 0, k, total = 0, cap_mb, files = 0;
	int i, si = -1;
	svcfile_t *s = NULL;
	char line[200];
	if( g_prefetch < 0 ) { const char *v = zzhl_option( "PREFETCH" ); g_prefetch = ( v && v[0] == '0' ) ? 0 : 1; }
	if( !g_prefetch || !cache_alloc() || g_ncb < 256u ) return 1;
	{ const char *v = zzhl_option( "VOICEMB" ); cap_mb = ( v && v[0] ) ? (unsigned)atoi( v ) : 8u; }
	for( i = FS_MAX_SVC; i-- > 0 && si < 0; )
	{   /* the pak holding the set: the last opened that has one of its files */
		if( !g_sv[i].used || !pak_dir( &g_sv[i] )) continue;
		for( k = 0; k < g_pd[i].n; k++ ) if( pf_match( g_pd[i].dir + k * 64u, set, nset )) { si = i; break; }
	}
	if( si < 0 ) return 0;
	s = &g_sv[si];
	for( k = 0; k < g_pd[si].n && n < 1024u; k++ )
	{
		const unsigned char *d = g_pd[si].dir + k * 64u;
		unsigned p = rd_le32( d + 56u ), l = rd_le32( d + 60u );
		if( !l || p > s->size || l > s->size - p || !pf_match( d, set, nset )) continue;
		e[n].pos = p; e[n].len = l; n++; total += l;
	}
	g_vf_sets++;
	if( total > cap_mb * 1048576u )
	{
		g_vf_skipped++;
		snprintf( line, sizeof( line ), "xacp_fs: read ahead (%s): %u files, %u KiB - more than VOICEMB=%u MiB, not read", why, n, total / 1024u, cap_mb );
		zzhl_log( line );
		return 1;
	}
	qsort( e, n, sizeof( e[0] ), pfent_cmp );
	{
		unsigned long long t0 = zzhl_us64();
		unsigned char *tmp = (unsigned char *)malloc( 1048576u );
		unsigned a, b, bytes = 0;
		if( !tmp ) return 1;
		for( k = 0; k < n; )
		{   /* a range: the next files while the gap is under a block */
			a = e[k].pos; b = e[k].pos + e[k].len; k++;
			while( k < n && e[k].pos <= b + XFS_BLOCK ) { if( e[k].pos + e[k].len > b ) b = e[k].pos + e[k].len; k++; }
			while( a < b )
			{
				unsigned piece = b - a > 1048576u ? 1048576u : b - a;
				g_want_sv = s; g_want_pos = a;
				if( sv_read( s, a, tmp, piece ) != (int)piece ) { g_want_sv = NULL; break; }
				g_want_sv = NULL;
				a += piece; bytes += piece;
			}
		}
		free( tmp );
		files = n;
		g_vf_files += files; g_vf_bytes += bytes; g_vf_us += (unsigned)( zzhl_us64() - t0 );
		snprintf( line, sizeof( line ), "xacp_fs: read ahead (%s): %u files, %u KiB (%u KiB read with the gaps), %u ms", why, files, total / 1024u, bytes / 1024u, (unsigned)(( zzhl_us64() - t0 ) / 1000u ));
		zzhl_log( line );
	}
	return 1;
}
/* a model read whole (the level's load): the first set once, and the voice that goes with it */
static void voice_ahead( svcfile_t *s, unsigned pos, unsigned n )
{
	pakdir_t *d = &g_pd[sv_index( s )];
	unsigned k, v;
	if( !g_first_done ) { g_first_done = (unsigned char)prefetch_set( g_set_first, sizeof( g_set_first ) / sizeof( g_set_first[0] ), "HEV voice, HUD, decals" ); }
	if( d->state != 1 ) return;
	for( k = 0; k < d->n; k++ )
	{
		const unsigned char *e = d->dir + k * 64u;
		if( rd_le32( e + 56u ) != pos || rd_le32( e + 60u ) != n ) continue;
		for( v = 0; v < N_VOICE; v++ )
			if( !g_voice_done[v] && pak_name_eq( e, g_voice[v].model ))
			{
				pfset_t one;
				one.prefix = g_voice[v].prefix; one.suffix = NULL;
				g_voice_done[v] = (unsigned char)prefetch_set( &one, 1, g_voice[v].prefix );
			}
		return;
	}
}

/* Chapter preloading avoids unnecessary disk access during play. */
#define SV_CH 22                                    /* 21 chapters (Uplink included) and the maps of none */
typedef struct { unsigned pos, len; char name[17]; } wlump_t;
typedef struct { int si; unsigned entry, epos, elen, dirlen, n; wlump_t *l; unsigned char *map, *ch[SV_CH]; } swad_t;
static swad_t g_swad[8];
static int g_nswad;
static unsigned *g_ord[FS_MAX_SVC];                 /* a pak's entries by offset */
static unsigned char *g_smap[FS_MAX_SVC], *g_sch[SV_CH][FS_MAX_SVC];
static int g_survey = -1;
static const unsigned char *g_sort_dir;
static void bset( unsigned char *b, unsigned i ) { b[i >> 3] = (unsigned char)( b[i >> 3] | ( 1u << ( i & 7u ))); }
static int bget( const unsigned char *b, unsigned i ) { return ( b[i >> 3] >> ( i & 7u )) & 1; }
static int survey_on( void )
{
	if( g_survey < 0 ) { const char *v = zzhl_option( "SURVEY" ); g_survey = ( v && v[0] && v[0] != '0' ) ? 1 : 0; }
	return g_survey;
}
static int ord_cmp( const void *a, const void *b )
{
	unsigned x = rd_le32( g_sort_dir + *(const unsigned *)a * 64u + 56u ), y = rd_le32( g_sort_dir + *(const unsigned *)b * 64u + 56u );
	return x < y ? -1 : x > y;
}
static int wl_cmp( const void *a, const void *b ) { unsigned x = ((const wlump_t *)a)->pos, y = ((const wlump_t *)b)->pos; return x < y ? -1 : x > y; }
static int ends_wad( const unsigned char *e )
{
	unsigned l = 0;
	while( l < 56u && e[l] ) l++;
	return l > 4 && ( e[l - 4] == '.' ) && ( e[l - 3] | 32 ) == 'w' && ( e[l - 2] | 32 ) == 'a' && ( e[l - 1] | 32 ) == 'd';
}
/* the textures of a .wad of the pak, sorted by offset (read once, through the cache) */
static swad_t *survey_wad( int si, unsigned entry )
{
	const unsigned char *e = g_pd[si].dir + entry * 64u;
	unsigned char h[12], *t;
	unsigned i, n, io;
	swad_t *w;
	int k;
	for( k = 0; k < g_nswad; k++ ) if( g_swad[k].si == si && g_swad[k].entry == entry ) return g_swad[k].l ? &g_swad[k] : NULL;
	if( g_nswad >= 8 ) return NULL;
	w = &g_swad[g_nswad++];
	memset( w, 0, sizeof( *w ));
	w->si = si; w->entry = entry; w->epos = rd_le32( e + 56u ); w->elen = rd_le32( e + 60u );
	if( w->elen < 12u || sv_read( &g_sv[si], w->epos, h, 12 ) != 12 || ( memcmp( h, "WAD3", 4 ) && memcmp( h, "WAD2", 4 ))) return NULL;
	n = rd_le32( h + 4 ); io = rd_le32( h + 8 );
	if( !n || n > 16384u || io > w->elen || n * 32u > w->elen - io ) return NULL;
	t = (unsigned char *)malloc( n * 32u );
	w->l = (wlump_t *)calloc( n, sizeof( wlump_t ));
	w->map = (unsigned char *)calloc(( n + 7u ) / 8u, 1 );
	if( !t || !w->l || !w->map || sv_read( &g_sv[si], w->epos + io, t, n * 32u ) != (int)( n * 32u )) { free( t ); free( w->l ); free( w->map ); w->l = NULL; return NULL; }
	for( i = 0; i < n; i++ )
	{
		w->l[i].pos = rd_le32( t + i * 32u ); w->l[i].len = rd_le32( t + i * 32u + 4u );
		memcpy( w->l[i].name, t + i * 32u + 16u, 16 ); w->l[i].name[16] = 0;
	}
	free( t );
	qsort( w->l, n, sizeof( wlump_t ), wl_cmp );
	w->n = n; w->dirlen = 12u + n * 32u;
	return w;
}
/* _read: the engine read [pos, pos+n) of a pak */
static void survey_note( svcfile_t *s, unsigned pos, unsigned n )
{
	int si = sv_index( s );
	pakdir_t *d = &g_pd[si];
	unsigned lo, hi, k, end = pos + n;
	if( !survey_on() || d->state != 1 || !n ) return;
	if( !g_ord[si] )
	{
		g_ord[si] = (unsigned *)malloc( d->n * sizeof( unsigned ));
		if( !g_ord[si] ) return;
		for( k = 0; k < d->n; k++ ) g_ord[si][k] = k;
		g_sort_dir = d->dir;
		qsort( g_ord[si], d->n, sizeof( unsigned ), ord_cmp );
	}
	if( !g_smap[si] && !( g_smap[si] = (unsigned char *)calloc(( d->n + 7u ) / 8u, 1 ))) return;
	lo = 0; hi = d->n;
	while( lo < hi ) { unsigned m = ( lo + hi ) / 2u; if( rd_le32( d->dir + g_ord[si][m] * 64u + 56u ) <= pos ) lo = m + 1u; else hi = m; }
	for( k = lo ? lo - 1u : 0u; k < d->n; k++ )
	{
		unsigned en = g_ord[si][k];
		const unsigned char *e = d->dir + en * 64u;
		unsigned ep = rd_le32( e + 56u ), el = rd_le32( e + 60u );
		swad_t *w;
		if( ep >= end ) break;
		if( ep + el <= pos ) continue;
		if( ends_wad( e ) && ( w = survey_wad( si, en )) != NULL )
		{   /* the textures under the read */
			unsigned r0 = ( pos > ep ? pos : ep ) - ep, r1 = ( end < ep + el ? end : ep + el ) - ep, a = 0, b = w->n, j;
			while( a < b ) { unsigned m = ( a + b ) / 2u; if( w->l[m].pos <= r0 ) a = m + 1u; else b = m; }
			for( j = a ? a - 1u : 0u; j < w->n && w->l[j].pos < r1; j++ ) if( w->l[j].pos + w->l[j].len > r0 ) bset( w->map, j );
		}
		else bset( g_smap[si], en );
	}
}

/* what the map needs that the engine did not open again.  Survey of 11/11 (build 43):
   Xash3D keeps the models, sounds and textures a map shares with the one before (Mod_FreeUnused,
   S_EndRegistration, the GL texture list), so a map's list held only what was new to it - the
   part common to every chapter came out at 0.1 MiB, the player and the weapons only in the first
   chapter's.  At the end of each map xacp_soak.c hands the server's precache lists here (models,
   sounds, generic files, events): each name's file of the pak, for a model its texture model
   (xT.mdl) and animation files (x01.mdl ...); and the textures the map's .bsp takes from the
   .wad files, read from its texture lump. */
static int pak_find_index( const char *want, int *psi, unsigned *pidx )
{
	int i;
	unsigned k;
	for( i = FS_MAX_SVC; i-- > 0; )
	{
		if( !g_sv[i].used || !pak_dir( &g_sv[i] )) continue;
		for( k = 0; k < g_pd[i].n; k++ ) if( pak_name_eq( g_pd[i].dir + k * 64u, want )) { *psi = i; *pidx = k; return 1; }
	}
	return 0;
}
static int survey_mark( const char *want )
{
	int si;
	unsigned idx;
	if( !pak_find_index( want, &si, &idx ) || ends_wad( g_pd[si].dir + idx * 64u )) return 0;
	if( !g_smap[si] && !( g_smap[si] = (unsigned char *)calloc(( g_pd[si].n + 7u ) / 8u, 1 ))) return 0;
	bset( g_smap[si], idx );
	return 1;
}
void xacp_fs_survey_add( const char *path )
{
	char n[80];
	unsigned l, i;
	if( !survey_on() || !path || !path[0] || path[0] == '*' ) return;
	if( !survey_mark( path )) return;
	l = (unsigned)strlen( path );
	if( l > 4u && l < 70u && !strcasecmp( path + l - 4u, ".mdl" ))
	{
		memcpy( n, path, l - 4u ); strcpy( n + l - 4u, "t.mdl" );
		(void)survey_mark( n );
		for( i = 1; i < 32u; i++ ) { snprintf( n, sizeof( n ), "%.*s%02u.mdl", (int)( l - 4u ), path, i ); if( !survey_mark( n )) break; }
	}
}
void xacp_fs_survey_add_bsp_textures( const char *bsp )
{
	int si, i;
	unsigned idx, ep, el, lo, ll, nt, t, k;
	unsigned char h[124], m[40], c[4];
	if( !survey_on() || !pak_find_index( bsp, &si, &idx )) return;
	ep = rd_le32( g_pd[si].dir + idx * 64u + 56u ); el = rd_le32( g_pd[si].dir + idx * 64u + 60u );
	if( el < 124u || sv_read( &g_sv[si], ep, h, 124 ) != 124 ) return;
	lo = rd_le32( h + 4u + 2u * 8u ); ll = rd_le32( h + 8u + 2u * 8u );       /* lump 2: the textures */
	if( ll < 4u || lo > el || ll > el - lo || sv_read( &g_sv[si], ep + lo, c, 4 ) != 4 ) return;
	nt = rd_le32( c );
	if( nt > 4096u || 4u + nt * 4u > ll ) return;
	for( t = 0; t < nt; t++ )
	{
		unsigned char o4[4];
		unsigned off;
		if( sv_read( &g_sv[si], ep + lo + 4u + t * 4u, o4, 4 ) != 4 ) return;
		off = rd_le32( o4 );
		if( off == 0xFFFFFFFFu || off > ll - 40u || sv_read( &g_sv[si], ep + lo + off, m, 40 ) != 40 ) continue;
		if( rd_le32( m + 24u )) continue;                  /* in the .bsp itself */
		m[16] = 0;
		for( i = 0; i < FS_MAX_SVC; i++ )
		{   /* the first .wad of the paks that has it */
			int found = 0;
			if( !g_sv[i].used || g_pd[i].state != 1 ) continue;
			for( k = 0; k < g_pd[i].n && !found; k++ )
			{
				swad_t *w;
				unsigned j;
				if( !ends_wad( g_pd[i].dir + k * 64u ) || !( w = survey_wad( i, k ))) continue;
				for( j = 0; j < w->n; j++ ) if( !strncasecmp( w->l[j].name, (const char *)m, 16 )) { bset( w->map, j ); found = 1; break; }
			}
			if( found ) break;
		}
	}
}

/* ---- a chapter read whole when it opens ----
 * tools/hl_pak.py --chapters lays pak0.pak out by chapter and writes pak0.chp: for each chapter
 * the ranges of the pak its maps load, and what they read while played (animations, sentences'
 * words, decals, HUD; tools/hl_chlayout.py).  When the engine starts reading a map of another
 * chapter (xacp_chapters.c), those ranges are read here first, in pieces of 1 MiB, into the
 * block cache: the rest of the chapter - its other maps, and the game - comes from memory.
 * CHAPTERS=0: off.  Without pak0.chp (a pak made without --chapters): nothing changes. */
extern int xacp_chapter_of( const char *map );
extern const char *xacp_chapter_title( int c );
static unsigned char *g_chp;
static unsigned g_chp_len;
static int g_chp_state, g_cur_chapter = -1;            /* state 0 not looked for, 1 loaded, -1 none */
static const svcfile_t *g_chp_pak;                      /* the pak it is for: <name>.pak -> <name>.chp */
static unsigned g_ch_opened, g_ch_bytes, g_ch_us;
void zzhl_fs_chapter_stats( unsigned *opened, unsigned *kib, unsigned *ms, int *on ) { *opened = g_ch_opened; *kib = g_ch_bytes / 1024u; *ms = g_ch_us / 1000u; *on = g_chp_state == 1; }
static void chp_load( const svcfile_t *s )
{
	long n = -1;
	char nm[FS_NAME_MAX];
	const char *v = zzhl_option( "CHAPTERS" ), *b = basename_of( s->name );
	size_t l = strlen( b );
	g_chp_state = -1;
	if( l < 5 || l >= sizeof( nm )) return;
	memcpy( nm, b, l - 4 ); strcpy( nm + l - 4, ".chp" );
	if(( v && v[0] == '0' ) || !zzhl_rt->fopen ) return;
	g_chp = svc_read_whole( nm, &n );             /* two answers that agree (16/11: one READ of it came back as another file) */
	if( !g_chp ) return;                          /* no pak0.chp: a pak made without --chapters */
	if( n >= 16 && n <= (long)FS_SERVICE_MAX && !memcmp( g_chp, "ZZCHP1\0\0", 8 ) && rd_le32( g_chp + 8 ) == s->size )
	{ g_chp_len = (unsigned)n; g_chp_state = 1; g_chp_pak = s; }
	else
	{
		slog( "pak0.chp not for this pak0.pak, chapters not read whole: ", nm, (unsigned)n, " bytes read, the pak is ", s->size );
		free( g_chp ); g_chp = NULL;
	}
}
/* the entry of a pak holding <pos> (sorted index of build 43) */
static int entry_at( int si, unsigned pos, unsigned *idx )
{
	pakdir_t *d = &g_pd[si];
	unsigned lo = 0, hi, k;
	if( d->state != 1 ) return 0;
	if( !g_ord[si] )
	{
		g_ord[si] = (unsigned *)malloc( d->n * sizeof( unsigned ));
		if( !g_ord[si] ) return 0;
		for( k = 0; k < d->n; k++ ) g_ord[si][k] = k;
		g_sort_dir = d->dir;
		qsort( g_ord[si], d->n, sizeof( unsigned ), ord_cmp );
	}
	hi = d->n;
	while( lo < hi ) { unsigned m = ( lo + hi ) / 2u; if( rd_le32( d->dir + g_ord[si][m] * 64u + 56u ) <= pos ) lo = m + 1u; else hi = m; }
	if( !lo ) return 0;
	k = g_ord[si][lo - 1u];
	if( pos - rd_le32( d->dir + k * 64u + 56u ) >= rd_le32( d->dir + k * 64u + 60u )) return 0;
	*idx = k;
	return 1;
}
/* the ranges of entry <c> of the .chp into the block cache (255: the common part) */
static int chp_read_entry( svcfile_t *s, int c, const char *title, const char *map )
{
	unsigned p, k, nch, nr = 0, tot = 0;
	const unsigned char *r = NULL;
	char line[200];
	nch = rd_le32( g_chp + 12 );
	for( p = 16, k = 0; k < nch && p + 12u <= g_chp_len; k++ )
	{
		unsigned cc = rd_le32( g_chp + p ), n = rd_le32( g_chp + p + 4 );
		if( n > ( g_chp_len - p - 12u ) / 8u ) return 0;
		if( (int)cc == c ) { nr = n; tot = rd_le32( g_chp + p + 8 ); r = g_chp + p + 12; break; }
		p += 12u + n * 8u;
	}
	if( !r || !cache_alloc()) return 0;
	{
		unsigned long long t0 = zzhl_us64();
		unsigned char *tmp = (unsigned char *)malloc( 1048576u );
		unsigned bytes = 0, i, disk0 = g_st_bytes;
		if( !tmp ) return 0;
		if( c == 255 ) snprintf( line, sizeof( line ), "xacp_fs: the common part of the chapters (with %s): reading %u KiB in %u ranges", map, tot / 1024u, nr );
		else snprintf( line, sizeof( line ), "xacp_fs: chapter %02d %s opens with %s: reading %u KiB in %u ranges", c, title, map, tot / 1024u, nr );
		zzhl_log( line );
		for( i = 0; i < nr; i++ )
		{
			unsigned a = rd_le32( r + i * 8u ), l = rd_le32( r + i * 8u + 4u ), b;
			if( a > s->size || l > s->size - a ) continue;
			for( b = a + l; a < b; )
			{
				unsigned piece = b - a > 1048576u ? 1048576u : b - a;
				g_want_sv = s; g_want_pos = a;
				if( sv_read( s, a, tmp, piece ) != (int)piece ) { g_want_sv = NULL; break; }
				g_want_sv = NULL;
				a += piece; bytes += piece;
			}
		}
		free( tmp );
		/* what came from the disk (the rest was still in the cache) */
		g_ch_opened++; g_ch_bytes += g_st_bytes - disk0; g_ch_us += (unsigned)( zzhl_us64() - t0 );
		snprintf( line, sizeof( line ), "xacp_fs: %s read: %u KiB, %u KiB of them from the disk, in %u ms", c == 255 ? "the common part" : title, bytes / 1024u, ( g_st_bytes - disk0 ) / 1024u, (unsigned)(( zzhl_us64() - t0 ) / 1000u ));
		zzhl_log( line );
	}
	return 1;
}
static void chapter_open( svcfile_t *s, unsigned pos )
{
	int si = sv_index( s ), c;
	unsigned idx, k;
	const unsigned char *e;
	char map[64];
	if( g_chp_state == 0 && g_pd[si].state == 1 && entry_at( si, pos, &idx ) && !strncasecmp( (const char *)g_pd[si].dir + idx * 64u, "maps/", 5 )) chp_load( s );
	if( g_chp_state != 1 || s != g_chp_pak || !entry_at( si, pos, &idx )) return;
	e = g_pd[si].dir + idx * 64u;
	if( strncasecmp( (const char *)e, "maps/", 5 )) return;
	for( k = 0; k < 56u && e[5 + k] && e[5 + k] != '.' && k < sizeof( map ) - 1; k++ ) map[k] = (char)e[5 + k];
	map[k] = 0;
	c = xacp_chapter_of( map );
	if( c < 0 || c == g_cur_chapter ) return;
	g_cur_chapter = c;
	/* the common part (entry 255) once; at each chapter, FIRST.  The cache is LRU
	   and the common part was read before everything else: at the change between two big chapters
	   (Questionable Ethics 23.7 MiB -> Surface Tension 41.3, with the 20 MiB common part: 85 > 80) its
	   blocks not used since the start were the oldest, so the first thrown away, and never read again.
	   Read again here, what the cache still holds costs no disk and becomes recent, what it lost comes
	   back; the new chapter then takes the place of the previous one, now the oldest. */
	(void)chp_read_entry( s, 255, "the common part", map );
	(void)chp_read_entry( s, c, xacp_chapter_title( c ), map );
}
/* xacp_soak.c: the map just surveyed joins its chapter; its own files and bytes */
void xacp_fs_survey_map_end( int ch, unsigned *items, unsigned *bytes )
{
	int si, k;
	unsigned i, it = 0, by = 0;
	if( ch < 0 || ch >= SV_CH - 1 ) ch = SV_CH - 1;
	for( si = 0; si < FS_MAX_SVC; si++ )
	{
		if( !g_smap[si] ) continue;
		if( !g_sch[ch][si] && !( g_sch[ch][si] = (unsigned char *)calloc(( g_pd[si].n + 7u ) / 8u, 1 ))) continue;
		for( i = 0; i < g_pd[si].n; i++ ) if( bget( g_smap[si], i ))
		{
			it++; by += rd_le32( g_pd[si].dir + i * 64u + 60u );
			bset( g_sch[ch][si], i );
		}
		memset( g_smap[si], 0, ( g_pd[si].n + 7u ) / 8u );
	}
	for( k = 0; k < g_nswad; k++ )
	{
		swad_t *w = &g_swad[k];
		if( !w->l ) continue;
		if( !w->ch[ch] && !( w->ch[ch] = (unsigned char *)calloc(( w->n + 7u ) / 8u, 1 ))) continue;
		for( i = 0; i < w->n; i++ ) if( bget( w->map, i )) { it++; by += w->l[i].len; bset( w->ch[ch], i ); }
		memset( w->map, 0, ( w->n + 7u ) / 8u );
	}
	*items = it; *bytes = by;
}
/* xacp_soak.c: a chapter's list, data/zzhl_chNN.lst; 1 written */
int xacp_fs_survey_write( int ch, const char *title, const char *maps, unsigned *items, unsigned *bytes )
{
	int si, k, ok = 0;
	unsigned i, cap = 4096u, len = 0, it = 0, by = 0;
	char *buf, name[24];
	FILE *f;
	if( ch < 0 || ch >= SV_CH - 1 ) ch = SV_CH - 1;
	for( si = 0; si < FS_MAX_SVC; si++ ) if( g_sch[ch][si] ) cap += g_pd[si].n * 4u;
	for( k = 0; k < g_nswad; k++ ) if( g_swad[k].ch[ch] ) cap += g_swad[k].n * 4u;
	cap *= 24u;                                         /* lines of up to ~96 bytes for a quarter of the names, at most */
	buf = (char *)malloc( cap );
	if( !buf ) return 0;
#define PUT( ... ) do { int w_ = snprintf( buf + len, cap - len, __VA_ARGS__ ); if( w_ > 0 && len + (unsigned)w_ < cap ) len += (unsigned)w_; } while( 0 )
	PUT( "# ZZHalfLife SURVEY=1 (build 43): chapter %02d %s - maps %s\n", ch, title, maps );
	PUT( "# f <file of the pak> <bytes>; d <wad> <bytes of its header and directory>; w <wad> <texture> <bytes>\n" );
	for( si = 0; si < FS_MAX_SVC; si++ )
	{
		if( !g_sch[ch][si] ) continue;
		for( i = 0; i < g_pd[si].n; i++ ) if( bget( g_sch[ch][si], i ))
		{
			const unsigned char *e = g_pd[si].dir + i * 64u;
			char nm[57];
			memcpy( nm, e, 56 ); nm[56] = 0;
			if( ends_wad( e )) continue;                   /* a .wad: its textures below */
			PUT( "f %s %u\n", nm, rd_le32( e + 60u ));
			it++; by += rd_le32( e + 60u );
		}
	}
	for( k = 0; k < g_nswad; k++ )
	{
		swad_t *w = &g_swad[k];
		char wn[57];
		if( !w->l || !w->ch[ch] ) continue;
		memcpy( wn, g_pd[w->si].dir + w->entry * 64u, 56 ); wn[56] = 0;
		PUT( "d %s %u\n", wn, w->dirlen );
		it++; by += w->dirlen;
		for( i = 0; i < w->n; i++ ) if( bget( w->ch[ch], i )) { PUT( "w %s %s %u\n", wn, w->l[i].name, w->l[i].len ); it++; by += w->l[i].len; }
	}
	PUT( "# total %u lines, %u bytes\n", it, by );
#undef PUT
	snprintf( name, sizeof( name ), "zzhl_ch%02d.lst", ch );
	if( len <= FS_SERVICE_MAX && zzhl_rt->fopen && ( f = zzhl_rt->fopen( name, "wb" )) != NULL )
	{
		ok = zzhl_rt->fwrite( buf, 1, len, f ) == len;
		if( zzhl_rt->fclose( f ) != 0 ) ok = 0;
	}
	free( buf );
	*items = it; *bytes = by;
	return ok;
}
/* the files and textures every chapter surveyed shares, and their bytes */
void xacp_fs_survey_common( unsigned *items, unsigned *bytes )
{
	int si, k, c;
	unsigned i, it = 0, by = 0;
	for( si = 0; si < FS_MAX_SVC; si++ )
		for( i = 0; g_pd[si].state == 1 && i < g_pd[si].n; i++ )
		{
			int all = 1, any = 0;
			for( c = 0; c < SV_CH - 1; c++ ) { if( !g_sch[c][si] ) continue; any = 1; if( !bget( g_sch[c][si], i )) { all = 0; break; } }
			if( any && all && !ends_wad( g_pd[si].dir + i * 64u )) { it++; by += rd_le32( g_pd[si].dir + i * 64u + 60u ); }
		}
	for( k = 0; k < g_nswad; k++ )
		for( i = 0; g_swad[k].l && i < g_swad[k].n; i++ )
		{
			int all = 1, any = 0;
			for( c = 0; c < SV_CH - 1; c++ ) { if( !g_swad[k].ch[c] ) continue; any = 1; if( !bget( g_swad[k].ch[c], i )) { all = 0; break; } }
			if( any && all ) { it++; by += g_swad[k].l[i].len; }
		}
	*items = it; *bytes = by;
}
/* xacp_soak.c: the survey writes nothing else to the disk (saves stay in memory) */
int xacp_fs_survey_active( void ) { return survey_on(); }
static void bsp_check( svcfile_t *s, unsigned pos, unsigned char *buf, unsigned n )
{
	whole_check( s, pos, buf, n, bsp_bad_planes, 8, "map", "planes", &g_bsp_checks, &g_bsp_bad, &g_bsp_fixed );
	whole_check( s, pos, buf, n, mdl_bad_tables, 0, "model", "tables", &g_mdl_checks, &g_mdl_bad, &g_mdl_fixed );
}

int _read( int fd, void *buf, size_t n )
{
	fd_t *d = fd_get( fd );
	unsigned left;
	if( !d ) return -1;
	if( d->kind == FD_STD ) return 0;
	if( d->kind == FD_SVC )
	{
		int got, header;
		/* not while the menu is only looking at the saves.  SV_GetSaveComment calls
		   SV_MapIsValid, which opens maps/<map>.bsp of each save, and a map of another chapter made
		   the whole chapter be read (20 to 33 MiB, 16 to 29 s each): the Load list took about a
		   minute to appear on the A4000 (13/11).  The chapter is read when the map really opens. */
		if( g_chp_state >= 0 && !survey_on() && !g_save_peek_on ) chapter_open( d->sv, d->pos );    /* a map of another chapter */
		g_want_sv = d->sv; g_want_pos = d->pos;                        /* the disk report names this file */
		got = sv_read( d->sv, d->pos, (unsigned char *)buf, (unsigned)n );
		g_want_sv = NULL;
		header = got >= 12 && d->pos == 0 && !memcmp( buf, "PACK", 4 );
		if( got > 0 && (unsigned)got == n ) bsp_check( d->sv, d->pos, (unsigned char *)buf, (unsigned)n );   /* build 34 */
		if( got > 0 && (unsigned)got == n ) mdl_groups_ahead( (unsigned char *)buf, (unsigned)n );          /* build 41 */
		if( got > 0 && (unsigned)got == n && n >= 8u && !memcmp( buf, "IDST", 4 )) voice_ahead( d->sv, d->pos, (unsigned)n );   /* build 42 */
		if( got > 0 ) d->pos += (unsigned)got;
		if( header && !g_pd[sv_index( d->sv )].state ) (void)pak_dir( d->sv );    /* the pak's names, once (the engine reads them next) */
		if( got > 0 ) survey_note( d->sv, d->pos - (unsigned)got, (unsigned)got );     /* SURVEY=1 */
		return got;
	}
	if( d->kind == FD_PEEK )
	{   /* save_peek: the first file by READAT, beyond it the whole save as before */
		/* up to praw the disk file IS the save; past it, the whole save is loaded and
		   inflated by save_load_disk() - the fallback this path already had. */
		unsigned lim = d->praw < d->psize ? d->praw : d->psize;
		scratch_t *w;
		if( d->pos >= d->psize ) return 0;
		if( n > d->psize - d->pos ) n = d->psize - d->pos;
		if( d->pos + (unsigned)n <= lim )
		{
			char base[64];
			save_diskname( base, d->pstem, 0 );
			if( read_full( base, SAVE_HDR + d->pos, (unsigned char *)buf, (unsigned)n )) { errno = EIO; return -1; }
			g_peek_reads++;
			d->pos += (unsigned)n;
			return (int)n;
		}
		w = sc_find( d->pname );
		if( !w ) w = save_load_disk( d->pstem, d->pname );
		if( !w ) { errno = EIO; return -1; }
		g_peek_whole++;
		w->refs++;
		d->kind = FD_SCRATCH; d->sc = w;
	}
	if( d->pos >= d->sc->size ) return 0;
	left = d->sc->size - d->pos;
	if( n > left ) n = left;
	memcpy( buf, d->sc->data + d->pos, n );
	d->pos += (unsigned)n;
	return (int)n;
}

int _write( int fd, const void *buf, size_t n )
{
	fd_t *d = fd_get( fd );
	if( !d ) return -1;
	if( d->kind == FD_STD )
	{
		extern void zzhl_console_write( const char *p, size_t n );
		zzhl_console_write( (const char *)buf, n );
		return (int)n;
	}
	if( d->kind != FD_SCRATCH ) { errno = EBADF; return -1; }
	if( !sc_reserve( d->sc, d->pos + (unsigned)n + 1 )) { errno = ENOSPC; return -1; }
	memcpy( d->sc->data + d->pos, buf, n );
	d->pos += (unsigned)n;
	if( d->pos > d->sc->size ) d->sc->size = d->pos;
	d->sc->dirty = 1;
	return (int)n;
}

off_t _lseek( int fd, off_t off, int whence )
{
	fd_t *d = fd_get( fd );
	long base, size;
	if( !d ) return -1;
	if( d->kind == FD_STD ) return 0;
	size = ( d->kind == FD_SVC ) ? (long)d->sv->size : ( d->kind == FD_PEEK ) ? (long)d->psize : (long)d->sc->size;
	base = ( whence == SEEK_SET ) ? 0 : ( whence == SEEK_CUR ) ? (long)d->pos : size;
	base += (long)off;
	if( base < 0 ) { errno = EINVAL; return -1; }
	d->pos = (unsigned)base;
	return (off_t)base;
}

int _fstat( int fd, struct stat *st )
{
	fd_t *d = fd_get( fd );
	if( !d ) return -1;
	memset( st, 0, sizeof( *st ));
	if( d->kind == FD_STD ) { st->st_mode = S_IFCHR; return 0; }
	st->st_mode = S_IFREG | 0666;
	st->st_size = ( d->kind == FD_SVC ) ? (off_t)d->sv->size : ( d->kind == FD_PEEK ) ? (off_t)d->psize : (off_t)d->sc->size;
	st->st_mtime = ( d->kind == FD_SCRATCH && d->sc->mtime ) ? (time_t)d->sc->mtime : 1;
	return 0;
}

int _stat( const char *path, struct stat *st )
{
	char n[FS_NAME_MAX];
	scratch_t *s;
	svcfile_t *v;
	norm( n, path );
	memset( st, 0, sizeof( *st ));
	st->st_mtime = 1;
	if( ieq( n, "valve/save" )) idx_load();
	if( is_dir_name( n )) { st->st_mode = S_IFDIR | 0777; return 0; }
	s = sc_find( n );
	if( s ) { st->st_mode = S_IFREG | 0666; st->st_size = (off_t)s->size; if( s->mtime ) st->st_mtime = (time_t)s->mtime; return 0; }
	{   /* a save on the disk by its header only (save_peek), not read into memory */
		char stem[SAVE_STEM_MAX + 1];
		peek_t *pk;
		if( save_on_disk( n, stem ) && ( pk = save_peek( stem )) != NULL )
		{ st->st_mode = S_IFREG | 0666; st->st_size = (off_t)pk->size; st->st_mtime = (time_t)pk->mtime; return 0; }
	}
	{   /* the screenshot of a save on the disk, by its size alone.  Without this the
	       menu never even tries to open it: is_servable() refuses valve/save/ names (no second
	       slash allowed), so this function answered ENOENT and the thumbnail was skipped. */
		char stem[SAVE_STEM_MAX + 1], base[64];
		unsigned total = 0;
		unsigned char probe[4];
		if( g_disk_saves && zzhl_rt->read_at && !gone_has( n ) && shot_stem( n, stem )
		 && ( !g_disk_only[0] || !strncmp( stem, g_disk_only, strlen( g_disk_only ))))
		{
			idx_load();
			if( idx_find( stem ) >= 0 )
			{
				int ok;
				shot_diskname( base, stem );
				ok = ( zzhl_rt->read_at( base, 0, probe, 1, &total ) >= 0 && total && total <= FS_SERVICE_MAX );
				hold_pak0();
				if( ok ) { st->st_mode = S_IFREG | 0666; st->st_size = (off_t)total; return 0; }
			}
		}
	}
	v = sv_find( n );
	if( v ) { st->st_mode = S_IFREG | 0444; st->st_size = (off_t)v->size; return 0; }
	if( !is_servable( n ) || neg_has( n ) || !zzhl_rt->file_time ) { errno = ENOENT; return -1; }
	if( pos_has( n )) { st->st_mode = S_IFREG | 0444; return 0; }    /* build 42 */
	g_st_svc++;
	if( zzhl_rt->file_time( basename_of( n )) > 0 ) { st->st_mode = S_IFREG | 0444; pos_add( n ); return 0; }
	neg_add( n );
	errno = ENOENT;
	return -1;
}
int stat( const char *path, struct stat *st ) { return _stat( path, st ); }

int _isatty( int fd ) { return fd < 3; }

int _unlink( const char *path )
{
	char n[FS_NAME_MAX];
	scratch_t *s;
	norm( n, path );
	s = sc_find( n );
	{ char st[SAVE_STEM_MAX + 1]; if( save_stem( n, st )) { gone_add( n ); peek_forget( st ); } }   /* build 41; 50 */
	if( s && !s->refs ) { free( s->data ); memset( s, 0, sizeof( *s )); return 0; }
	errno = ENOENT;
	return -1;
}
int _link( const char *o, const char *nw )
{
	char a[FS_NAME_MAX], b[FS_NAME_MAX];
	scratch_t *s, *t;
	norm( a, o ); norm( b, nw );
	if( is_pak_name( b )) { errno = EACCES; return -1; }      /* a memory file never becomes a pak */
	s = sc_find( a );
	if( !s ) s = save_get( a );        /* stat no longer reads a save in, the rename does */
	if( !s ) { errno = ENOENT; return -1; }
	t = sc_find( b );
	if( t && !t->refs ) { free( t->data ); memset( t, 0, sizeof( *t )); }
	strncpy( s->name, b, FS_NAME_MAX - 1 );
	s->dirty = 1;
	neg_del( b );
	gone_del( b );                                             /* build 41 */
	{ char st[SAVE_STEM_MAX + 1]; if( save_stem( a, st )) { gone_add( a ); peek_forget( st ); } }   /* build 50 */
	/* a config (.cfg) reaches the disk under its final name now (keep_in_memory).
	   Saves stay as they were: the rotation quick.sav -> quick01.sav lives in memory. */
	if( !s->refs && has_suffix( b, ".cfg" )) sc_flush( s );
	return 0;
}
int rename( const char *o, const char *nw ) { return _link( o, nw ); }
int remove( const char *p ) { return _unlink( p ); }
int dup( int fd )
{
	fd_t *d = fd_get( fd );
	int nf;
	if( !d ) return -1;
	nf = fd_alloc();
	if( nf < 0 ) return -1;
	g_fd[nf] = *d;
	if( d->kind == FD_SCRATCH && d->sc ) d->sc->refs++;
	if( d->kind == FD_SVC && d->sv ) d->sv->refs++;
	return nf;
}
int mkdir( const char *path, mode_t mode )
{
	char n[FS_NAME_MAX];
	(void)mode;
	norm( n, path );
	if( is_dir_name( n )) return 0;
	if( g_dirs_n < 32 ) { strncpy( g_dirs[g_dirs_n++], n, FS_NAME_MAX - 1 ); return 0; }
	errno = ENOSPC;
	return -1;
}
char *getcwd( char *buf, size_t size )
{
	if( size < 2 ) { errno = ERANGE; return NULL; }
	buf[0] = '.'; buf[1] = 0;
	return buf;
}

/* ---- directory listing ---- */
static const char *g_pak_names[] = { "pak0.pak", "pak1.pak", "pak2.pak", "pak3.pak" };
#define N_PAK_NAMES 4
/* the player's loose files the engine looks for by name in valve/ (xacp_loading.c).
   Xash3D finds a loose file through the listing of its directory (filesystem/dir.c,
   FS_FixFileCase, case-sensitive platform): a file of PROGDIR:data/ that this listing does not
   name does not exist for the engine.  Builds 24-27 never saw zzhl_loading.* nor
   zzhl_loadscreen.tga for that reason (07/11). */
/* the configs the engine writes (config.cfg, video.cfg, opengl.cfg; read before
   pak0.pak's copy, a directory has the priority, searchpath.c) and the player's own
   (userconfig.cfg, autoexec.cfg). */
static const char *g_loose_names[] = { "zzhl_loadscreen.tga", "zzhl_loading.png", "zzhl_loading.tga", "zzhl_loading.bmp",
	"config.cfg", "video.cfg", "opengl.cfg", "userconfig.cfg", "autoexec.cfg" };
#define N_LOOSE_NAMES 9
typedef struct { char dir[FS_NAME_MAX]; int idx; struct dirent ent; int open; char names[N_PAK_NAMES + N_LOOSE_NAMES + FS_MAX_SCRATCH + 33][64]; int count; } xdir_t;
static xdir_t g_dir[2];
static void dir_add( xdir_t *d, const char *name, int isdir )
{
	int i;
	if( d->count >= (int)( sizeof( d->names ) / sizeof( d->names[0] ))) return;
	for( i = 0; i < d->count; i++ ) if( ieq( d->names[i], name )) return;
	strncpy( d->names[d->count], name, 62 );
	d->names[d->count][62] = isdir ? 'D' : 'F';   /* type tag in the spare byte */
	d->names[d->count][63] = 0;
	d->count++;
}
DIR *opendir( const char *name )
{
	int i, k;
	char n[FS_NAME_MAX];
	xdir_t *d = NULL;
	norm( n, name );
	if( ieq( n, "valve" ) || ieq( n, "valve/save" )) idx_load();
	if( !is_dir_name( n )) return NULL;
	for( i = 0; i < 2; i++ ) if( !g_dir[i].open ) { d = &g_dir[i]; break; }
	if( !d ) return NULL;
	memset( d, 0, sizeof( *d ));
	d->open = 1;
	strncpy( d->dir, n, FS_NAME_MAX - 1 );
	if( ieq( n, "." ))
	{
		dir_add( d, "valve", 1 );
		for( i = 0; i < g_dirs_n; i++ ) if( !strchr( g_dirs[i], '/' )) dir_add( d, g_dirs[i], 1 );
	}
	else
	{
		size_t dl = strlen( n );
		if( ieq( n, "valve" ))
		{
			struct stat st;
			char p[FS_NAME_MAX];
			for( k = 0; k < N_PAK_NAMES; k++ )
			{
				strcpy( p, "valve/" ); strcat( p, g_pak_names[k] );
				if( _stat( p, &st ) == 0 ) dir_add( d, g_pak_names[k], 0 );
			}
			for( k = 0; k < N_LOOSE_NAMES; k++ )
			{
				strcpy( p, "valve/" ); strcat( p, g_loose_names[k] );
				if( _stat( p, &st ) == 0 ) dir_add( d, g_loose_names[k], 0 );
			}
		}
		for( i = 0; i < FS_MAX_SCRATCH; i++ )
		{
			if( !g_sc[i].name[0] ) continue;
			if( strncasecmp( g_sc[i].name, n, dl ) || g_sc[i].name[dl] != '/' || strchr( g_sc[i].name + dl + 1, '/' )) continue;
			dir_add( d, g_sc[i].name + dl + 1, 0 );
		}
		for( i = 0; i < g_dirs_n; i++ )
			if( !strncasecmp( g_dirs[i], n, dl ) && g_dirs[i][dl] == '/' && !strchr( g_dirs[i] + dl + 1, '/' )) dir_add( d, g_dirs[i] + dl + 1, 1 );
		if( ieq( n, "valve/save" ))
			for( i = 0; i < g_idx_n; i++ )
			{
				char e[SAVE_STEM_MAX + 8];
				strcpy( e, g_idx[i] ); strcat( e, ".sav" ); dir_add( d, e, 0 );
				/* The load menu checks for each save screenshot before requesting its image. */
				strcpy( e, g_idx[i] ); strcat( e, ".bmp" ); dir_add( d, e, 0 );
			}
	}
	return (DIR *)d;
}
struct dirent *readdir( DIR *dp )
{
	xdir_t *d = (xdir_t *)dp;
	if( !d || !d->open || d->idx >= d->count ) return NULL;
	strncpy( d->ent.d_name, d->names[d->idx], 62 );
	d->ent.d_name[62] = 0;
	d->ent.d_type = ( d->names[d->idx][62] == 'D' ) ? DT_DIR : DT_REG;
	d->idx++;
	return &d->ent;
}
int closedir( DIR *dp ) { xdir_t *d = (xdir_t *)dp; if( d ) d->open = 0; return 0; }

void zzhl_fs_stats( unsigned *req, unsigned *bytes, unsigned *hit, unsigned *miss, unsigned *direct, unsigned *svc, unsigned *neg, unsigned *writes )
{
	*req = g_st_req; *bytes = g_st_bytes; *hit = g_st_hit; *miss = g_st_miss; *direct = g_st_direct; *svc = g_st_svc; *neg = g_st_neg; *writes = g_st_writes;
}
#ifdef ZZHL_HOST_TEST
/* the test's "new session": everything in memory forgotten, the disk kept */
void xacp_fs_test_new_session( void )
{
	int i;
	for( i = 0; i < FS_MAX_SCRATCH; i++ ) if( g_sc[i].name[0] && !g_sc[i].refs ) { free( g_sc[i].data ); memset( &g_sc[i], 0, sizeof( g_sc[i] )); }
	g_idx_loaded = 0; g_idx_n = 0; g_neg_n = 0; g_dirs_n = 0;
	g_cfg_keep_n = 0;                             /* build 99 */
	memset( g_gone, 0, sizeof( g_gone ));         /* build 41 */
	g_pos_n = 0;                                  /* build 42 */
	memset( g_peek, 0, sizeof( g_peek ));         /* build 50 */
	g_first_done = 0; memset( g_voice_done, 0, sizeof( g_voice_done ));
	g_survey = -1;                                /* SURVEY= read again */
	free( g_chp ); g_chp = NULL; g_chp_state = 0; g_cur_chapter = -1; g_chp_pak = NULL;   /* 46 */
}
#endif
#ifdef ZZHL_HOST_TEST
void zzhl_fs_cache_reset( void );
/* tests only (build 43): the paks no longer open forgotten - the tests open more than FS_MAX_SVC */
void xacp_fs_test_drop_paks( void )
{
	int i, c, k;
	for( i = 0; i < FS_MAX_SVC; i++ )
	{
		if( g_sv[i].refs ) continue;
		free( g_sv[i].crc ); memset( &g_sv[i], 0, sizeof( g_sv[i] ));
		free( g_pd[i].dir ); memset( &g_pd[i], 0, sizeof( g_pd[i] ));
		free( g_ord[i] ); g_ord[i] = NULL; free( g_smap[i] ); g_smap[i] = NULL;
		for( c = 0; c < SV_CH; c++ ) { free( g_sch[c][i] ); g_sch[c][i] = NULL; }
	}
	for( k = 0; k < g_nswad; k++ ) { free( g_swad[k].l ); free( g_swad[k].map ); for( c = 0; c < SV_CH; c++ ) free( g_swad[k].ch[c] ); }
	memset( g_swad, 0, sizeof( g_swad )); g_nswad = 0;
	zzhl_fs_cache_reset();
}
void zzhl_fs_cache_reset( void ) { g_cbuf_base = NULL; memset( g_cb, 0, sizeof( g_cb )); g_ncb = XFS_CACHE_BLOCKS; }   /* tests only: the next read allocates again */
#endif
void zzhl_fs_cache_stats( unsigned *mib, unsigned *direct_hits, unsigned *kept ) { *mib = g_cbuf_base ? g_ncb / 16u : 0u; *direct_hits = g_st_dhit; *kept = g_st_kept; }
void zzhl_fs_stats2( unsigned *short_reads, unsigned *verify_mismatch, int *verify_on )
{
	*short_reads = g_short_reads; *verify_mismatch = g_verify_mismatch; *verify_on = g_verify;
}
/* service writes refused by the launcher (each tried once more), and given up */
void zzhl_fs_write_stats( unsigned *refused, unsigned *given_up ) { *refused = g_write_refused; *given_up = g_write_given_up; }
