/* xacp_libc.c - ZZHalfLife: what newlib (arm-none-eabi) and the engine expect from an OS that
 * is not there: the process-level syscalls, the heap (_sbrk in the Core1 arena window stage 1
 * hands over), time, the console log, single-thread pthread shims and the C++ runtime bits.
 * File descriptors are in xacp_fs.c.
 * SPDX-License-Identifier: GPL-3.0-or-later
 * ASCII only. */
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <pthread.h>
#include "xacp_rt.h"
#include "zzhl_conlog.h"
#include "zzhl_core.h"                     /* ZZHL_STACK_LO / HI */

const zzhl_rt_t *zzhl_rt;

/* ---- heap: newlib malloc grows into [heap_lo, heap_hi) of the Core1 arena ---- */
static unsigned g_heap_cur, g_heap_peak;
void *_sbrk( ptrdiff_t incr )
{
	unsigned old;
	if( !g_heap_cur ) g_heap_cur = zzhl_rt->heap_lo;
	old = g_heap_cur;
	if( incr < 0 && (unsigned)( -incr ) > ( old - zzhl_rt->heap_lo )) { errno = ENOMEM; return (void *)-1; }
	if( incr > 0 && old + (unsigned)incr > zzhl_rt->heap_hi )
	{
		zzhl_rt->shared[6] = 0x83;   /* SH_ERROR = ZZQ_FATAL_OUT_OF_MEM, for the launcher's eyes */
		errno = ENOMEM;
		return (void *)-1;
	}
	g_heap_cur = old + (unsigned)incr;
	if( g_heap_cur > g_heap_peak ) g_heap_peak = g_heap_cur;
	return (void *)old;
}
unsigned zzhl_heap_used( void ) { return g_heap_cur ? g_heap_cur - zzhl_rt->heap_lo : 0; }
unsigned zzhl_heap_peak( void ) { return g_heap_peak ? g_heap_peak - zzhl_rt->heap_lo : 0; }

/* ---- how deep the engine's stack went ----
 * 8 MiB from ZZHL_STACK_HI down to ZZHL_STACK_LO (zzhl_core.h), nothing below it but the top of the
 * heap, no guard: never measured until now.  At the start (zzhl_core_entry, already on that stack)
 * every word below the caller's frame is painted; the deepest word no longer painted tells the
 * deepest use.  Without the paint (host tests) the answer is 0. */
#define STACK_PAINT 0x5AA55AA5u
static int g_stack_painted;
void zzhl_stack_paint( void )
{
	volatile unsigned here = 0;
	unsigned top = ( (unsigned)(size_t)&here - 4096u ) & ~3u, a;
	if( top <= ZZHL_STACK_LO || top > ZZHL_STACK_HI ) return;     /* not on the engine's stack */
	for( a = ZZHL_STACK_LO; a < top; a += 4u ) *(volatile unsigned *)(size_t)a = STACK_PAINT;
	g_stack_painted = 1;
	(void)here;
}
unsigned zzhl_stack_used( void )
{
	unsigned a;
	if( !g_stack_painted ) return 0;
	for( a = ZZHL_STACK_LO; a < ZZHL_STACK_HI; a += 4u ) if( *(volatile unsigned *)(size_t)a != STACK_PAINT ) break;
	return ZZHL_STACK_HI - a;
}

/* ---- time ---- */
static unsigned g_us_last, g_us_wraps;
unsigned long long zzhl_us64( void )
{
	unsigned now = zzhl_rt->us_now();
	if( now < g_us_last ) g_us_wraps++;
	g_us_last = now;
	return ((unsigned long long)g_us_wraps << 32 ) | now;
}
/* the date.  Core1 has no clock: the 68k wrapper passes the Amiga's (DATE=<seconds since
   1970>, its local time, read as UTC by newlib's localtime so the menu shows the Amiga's hour);
   without it, a fixed day as before.  For the saves' times (the menu's list, the reload after a
   death takes the newest) and time(). */
static long long g_epoch = 1761696000;
void zzhl_set_date( unsigned long t ) { if( t > 1000000000ul ) g_epoch = (long long)t - (long long)( zzhl_us64() / 1000000ull ); }
unsigned zzhl_wall_time( void ) { return (unsigned)( g_epoch + (long long)( zzhl_us64() / 1000000ull )); }
int _gettimeofday( struct timeval *tv, void *tz )
{
	unsigned long long us = zzhl_us64();
	(void)tz;
	if( tv ) { tv->tv_sec = (time_t)( g_epoch + (long long)( us / 1000000ull )); tv->tv_usec = (suseconds_t)( us % 1000000ull ); }
	return 0;
}

/* ---- console log: the engine's stdout. Kept in a ring (zzhl_console_dump) and, line by
   line, pushed through the runtime's printf (SH_LAST_PRINTF) so the launcher shows the
   latest line. ---- */
#define CON_RING 65536u
static char g_con[CON_RING];
static unsigned g_con_wr;
static char g_line[128];
static unsigned g_line_n;
/* The mirror collapses consecutive lines that differ only by their digits ("bad normal for
   plane #6242", "#6243", ...: a level load of build 10 printed 4265 of them and the 256 KiB
   ring kept nothing else).  The first line is written, the following ones are counted and the
   count goes out with the next different line. */
#define MIR_LINE 240u
static char g_mir_cur[MIR_LINE], g_mir_prev[MIR_LINE];
static unsigned g_mir_n, g_mir_rep;
static int mir_same_shape( const char *a, const char *b )
{
	for( ;; )
	{
		while( *a >= '0' && *a <= '9' ) a++;
		while( *b >= '0' && *b <= '9' ) b++;
		if( *a != *b ) return 0;
		if( !*a ) return 1;
		a++; b++;
	}
}
extern void xacp_loading_line( const char *p, unsigned n );   /* the loading screen's console line */
static void mir_line_done( void )
{
	g_mir_cur[g_mir_n] = 0;
	xacp_loading_line( g_mir_cur, (unsigned)g_mir_n );
	if( g_mir_n && g_mir_prev[0] && mir_same_shape( g_mir_cur, g_mir_prev )) { g_mir_rep++; g_mir_n = 0; return; }
	if( g_mir_rep )
	{
		char m[64], *q = m, d[12]; int k = 0; unsigned x = g_mir_rep;
		const char *t = "  (+";
		while( *t ) *q++ = *t++;
		do { d[k++] = (char)( '0' + x % 10u ); x /= 10u; } while( x );
		while( k ) *q++ = d[--k];
		t = " lines like the previous one)\n";
		while( *t ) *q++ = *t++;
		zzhl_conlog_write( m, (unsigned)( q - m ));
		g_mir_rep = 0;
	}
	zzhl_conlog_write( g_mir_cur, g_mir_n );
	zzhl_conlog_write( "\n", 1 );
	memcpy( g_mir_prev, g_mir_cur, g_mir_n + 1 );
	g_mir_n = 0;
}
static void mir_write( const char *p, size_t n )
{
	size_t i;
	for( i = 0; i < n; i++ )
	{
		char c = p[i];
		if( c == '\n' ) { mir_line_done(); continue; }
		if( g_mir_n < MIR_LINE - 1 ) g_mir_cur[g_mir_n++] = c;
	}
}

void zzhl_console_write( const char *p, size_t n )
{
	size_t i;
	mir_write( p, n );                       /* 68k-readable mirror (zzhl_conlog.h, ZZSlots) */
	for( i = 0; i < n; i++ )
	{
		char c = p[i];
		g_con[g_con_wr++ % CON_RING] = c;
		if( c == '\n' || g_line_n >= sizeof( g_line ) - 1 )
		{
			g_line[g_line_n] = 0;
			if( g_line_n && zzhl_rt->printf ) zzhl_rt->printf( "%s", g_line );
			g_line_n = 0;
		}
		else if( c >= 32 ) g_line[g_line_n++] = c;
	}
}
void zzhl_log( const char *s ) { zzhl_console_write( s, strlen( s )); zzhl_console_write( "\n", 1 ); }
const char *zzhl_console_ring( unsigned *len, unsigned *wr ) { *len = CON_RING; *wr = g_con_wr; return g_con; }

/* ---- process ---- */
#include <setjmp.h>
jmp_buf zzhl_exit_jmp;
int zzhl_exit_jmp_set;
void _exit( int code )
{
	zzhl_rt->shared[230] = 4;    /* SH_EXIT_REASON = ZZQ_EXIT_FATAL: exit() outside Host_ExitInMain */
	zzhl_rt->shared[6] = 0x84;   /* SH_ERROR = ZZQ_FATAL_SYS_ERROR */
	if( zzhl_exit_jmp_set ) longjmp( zzhl_exit_jmp, code ? code : 1 );   /* back to zzhl_core_entry */
	for( ;; ) { zzhl_rt->pump(); }
}
int _kill( int pid, int sig ) { (void)pid; (void)sig; errno = EINVAL; return -1; }
int _getpid( void ) { return 1; }
int execv( const char *path, char *const argv[] ) { (void)path; (void)argv; errno = ENOSYS; return -1; }
int _commit( int fd ) { (void)fd; return 0; }
void _fini( void ) { }
void _init( void ) { }
void *__dso_handle;

/* ---- pthread: the engine is single-threaded on Core1 (the DNS resolver thread of
   net_ws.c never starts: no network). ---- */
int pthread_mutex_init( pthread_mutex_t *m, const pthread_mutexattr_t *a ) { (void)m; (void)a; return 0; }
int pthread_mutex_destroy( pthread_mutex_t *m ) { (void)m; return 0; }
int pthread_mutex_lock( pthread_mutex_t *m ) { (void)m; return 0; }
int pthread_mutex_unlock( pthread_mutex_t *m ) { (void)m; return 0; }
int pthread_create( pthread_t *t, const pthread_attr_t *a, void *(*fn)( void * ), void *arg ) { (void)t; (void)a; (void)fn; (void)arg; return EAGAIN; }
int pthread_detach( pthread_t t ) { (void)t; return 0; }

/* ---- hlsdk vcs_info ---- */
const char *g_VCSInfo_Branch = "master";
const char *g_VCSInfo_Commit = "8a09758";

/* ---- voice (engine/client/sound/voice.c not built) ---- */
struct sizebuf_s;
void CL_AddVoiceToDatagram( void ) { }

/* ---- what librixgpu / the MMU helper call by name (release runtime functions, reached through
   the stage-1 API in the engine image) ---- */
void dcache_clean_range( void *addr, unsigned len ) { zzhl_rt->dcache_clean( (unsigned)addr, len ); }
void dcache_invalidate_range( void *addr, unsigned len ) { zzhl_rt->dcache_invalidate( (unsigned)addr, len ); }
unsigned zzq_us_now( void ) { return zzhl_rt->us_now(); }

/* ---- printf: the C99 'z' / 't' / 'j' length modifiers ----
 * The arm-none-eabi newlib of the toolchain is built without C99 printf formats: "%zu" prints
 * the two letters "zu".  Harmless in messages, FATAL in one place: the save/restore of entity
 * function pointers (XASH_ALLOW_SAVERESTORE_OFFSETS, engine/common/lib_common.c) writes every
 * think/touch/use function as "ofs:%zu" and reads it back with Q_atoi.  Every level transition
 * (changelevel = save + restore) therefore restored every carried-over entity with ALL its
 * function pointers set to pfnGameInit + 0 ("COM_OffsetNameForFunction: ofs:zu" in the A0
 * logs): the intro guard transferred to c0a0e froze in place and never opened the tram door,
 * while a map started directly (c1a0, no restore) behaves normally.  Saved games are affected
 * the same way.
 * Fix without touching newlib or the engine: the stage-2 link wraps newlib's two formatting
 * cores (-Wl,--wrap=_svfprintf_r,--wrap=_vfprintf_r: every printf-family entry point of libc.a
 * goes through one of them) and the format is rewritten first.  On this ABI size_t and
 * ptrdiff_t are 32-bit (= int: the modifier is dropped), intmax_t is 64-bit ("ll"). */
#include <stdarg.h>
#include <stdio.h>
struct _reent;
extern int __real__svfprintf_r( struct _reent *, FILE *, const char *, va_list );
extern int __real__vfprintf_r( struct _reent *, FILE *, const char *, va_list );
static const char *c99_fmt( const char *fmt, char *buf, unsigned cap )
{
	const char *p;
	unsigned o = 0;
	int need = 0, in = 0;
	for( p = fmt; *p; p++ )
	{
		if( !in ) { if( *p == '%' ) in = 1; continue; }
		if( *p == '%' ) { in = 0; continue; }
		if( *p == 'z' || *p == 't' || *p == 'j' ) { need = 1; break; }
		if(( *p >= 'a' && *p <= 'z' ) || ( *p >= 'A' && *p <= 'Z' )) { if( *p != 'l' && *p != 'h' && *p != 'L' && *p != 'q' ) in = 0; }
	}
	if( !need ) return fmt;
	in = 0;
	for( p = fmt; *p; p++ )
	{
		if( o + 3 >= cap ) return fmt;                 /* too long: printed as before */
		if( !in ) { if( *p == '%' ) in = 1; buf[o++] = *p; continue; }
		if( *p == '%' ) { in = 0; buf[o++] = *p; continue; }
		if( *p == 'z' || *p == 't' ) continue;          /* 32-bit: like int */
		if( *p == 'j' ) { buf[o++] = 'l'; buf[o++] = 'l'; continue; }
		if(( *p >= 'a' && *p <= 'z' ) || ( *p >= 'A' && *p <= 'Z' )) { if( *p != 'l' && *p != 'h' && *p != 'L' && *p != 'q' ) in = 0; }
		buf[o++] = *p;
	}
	buf[o] = 0;
	return buf;
}
int __wrap__svfprintf_r( struct _reent *r, FILE *f, const char *fmt, va_list ap )
{
	char buf[1024];
	return __real__svfprintf_r( r, f, c99_fmt( fmt, buf, sizeof( buf )), ap );
}
int __wrap__vfprintf_r( struct _reent *r, FILE *f, const char *fmt, va_list ap )
{
	char buf[1024];
	return __real__vfprintf_r( r, f, c99_fmt( fmt, buf, sizeof( buf )), ap );
}
