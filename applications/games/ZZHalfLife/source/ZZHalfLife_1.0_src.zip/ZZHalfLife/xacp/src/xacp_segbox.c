/* Conservative segment-to-bounding-box test for glow traces.
 * Reject only when a trace cannot intersect the entity's expanded bounds.
 * Ambiguous cases use the engine's full trace.
 */

#define ZZHL_SEGBOX_EPS 1.0f

int zzhl_seg_box( const float *p0, const float *p1, const float *bmin, const float *bmax )
{
	float t0 = 0.0f, t1 = 1.0f;
	int i;

	for( i = 0; i < 3; i++ )
	{
		const float lo = bmin[i] - ZZHL_SEGBOX_EPS;
		const float hi = bmax[i] + ZZHL_SEGBOX_EPS;
		const float d  = p1[i] - p0[i];

		if( d > -1e-6f && d < 1e-6f )
		{
			/* the segment does not move along this axis: it must already be inside the slab */
			if( p0[i] < lo || p0[i] > hi ) return 0;
		}
		else
		{
			const float inv = 1.0f / d;
			float ta = ( lo - p0[i] ) * inv;
			float tb = ( hi - p0[i] ) * inv;
			if( ta > tb ) { const float s = ta; ta = tb; tb = s; }
			if( ta > t0 ) t0 = ta;
			if( tb < t1 ) t1 = tb;
			if( t0 > t1 ) return 0;        /* the slabs do not overlap: no intersection */
		}
	}
	return 1;
}
