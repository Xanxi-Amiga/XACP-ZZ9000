/* zzhl_game_rt.c - the runtime of the game image (zzhl_game.bin).
 * The game image holds the HLSDK server and client (and FreeVGUI), linked with its own newlib
 * and libstdc++.  This file is everything else it needs: its header, its entry, and the newlib
 * system calls and heap, which go to the engine through zzhl_game_imports_t (zzhl_game.h).
 * It contains no engine code; the engine is reached only through the table it hands over.
 * SPDX-License-Identifier: 0BSD
 * ASCII only. */
#include <stddef.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include "zzhl_game.h"

static const zzhl_game_imports_t *g_imp;

/* the header the engine checks; tools/mkcore.py fills the sizes and the CRC */
int zzhl_game_entry( const zzhl_game_imports_t *imp, zzhl_game_exports_t *exp );
__attribute__((section(".zzhlhdr"), used))
const zzhl_game_hdr_t zzhl_game_hdr = {
	ZZHL_GAME_MAGIC0, ZZHL_GAME_MAGIC1, ZZHL_GAME_VERSION, sizeof( zzhl_game_hdr_t ),
	ZZHL_GAME_LOAD, 0, 0, 0, 0, 0, ZZHL_GAME_ABI, { 0, 0, 0, 0, 0 }
};

/* the version strings the HLSDK registers as cvars (hlsdk-portable 8a09758d) */
const char *g_VCSInfo_Branch = "master";
const char *g_VCSInfo_Commit = "8a09758";
void *__dso_handle = 0;
void _init( void ) { }
void _fini( void ) { }

/* ---- newlib system calls ---- */
int _open( const char *path, int flags, int mode ) { return g_imp->open_( path, flags, mode ); }
int _close( int fd ) { return g_imp->close_( fd ); }
int _read( int fd, void *buf, size_t n ) { return g_imp->read_( fd, buf, n ); }
int _write( int fd, const void *buf, size_t n ) { return g_imp->write_( fd, buf, n ); }
off_t _lseek( int fd, off_t off, int whence ) { return (off_t)g_imp->lseek_( fd, (long)off, whence ); }
int _fstat( int fd, struct stat *st ) { return g_imp->fstat_( fd, st ); }
int _stat( const char *path, struct stat *st ) { return g_imp->stat_( path, st ); }
int _isatty( int fd ) { return g_imp->isatty_( fd ); }
int _unlink( const char *path ) { return g_imp->unlink_( path ); }
int _link( const char *o, const char *n ) { return g_imp->link_( o, n ); }
int mkdir( const char *path, mode_t mode ) { return g_imp->mkdir_( path, (unsigned)mode ); }
int _gettimeofday( struct timeval *tv, void *tz ) { return g_imp->gettimeofday_( tv, tz ); }
int _getpid( void ) { return g_imp->getpid_(); }
int _kill( int pid, int sig ) { return g_imp->kill_( pid, sig ); }
void _exit( int code ) { g_imp->exit_( code ); for( ;; ) { } }
void *_sbrk( ptrdiff_t incr ) { return g_imp->sbrk_( incr ); }

/* ---- the heap: the link wraps every allocator entry of newlib and libstdc++
   (-Wl,--wrap=malloc,... in build_arm.sh), so that one heap, the engine's, serves both images
   and a block may be freed by either side ---- */
struct _reent;
void *__wrap_malloc( size_t n ) { return g_imp->malloc_( n ); }
void  __wrap_free( void *p ) { g_imp->free_( p ); }
void *__wrap_calloc( size_t n, size_t s ) { return g_imp->calloc_( n, s ); }
void *__wrap_realloc( void *p, size_t n ) { return g_imp->realloc_( p, n ); }
void *__wrap_memalign( size_t a, size_t n ) { return g_imp->memalign_( a, n ); }
void *__wrap__malloc_r( struct _reent *r, size_t n ) { (void)r; return g_imp->malloc_( n ); }
void  __wrap__free_r( struct _reent *r, void *p ) { (void)r; g_imp->free_( p ); }
void *__wrap__calloc_r( struct _reent *r, size_t n, size_t s ) { (void)r; return g_imp->calloc_( n, s ); }
void *__wrap__realloc_r( struct _reent *r, void *p, size_t n ) { (void)r; return g_imp->realloc_( p, n ); }
void *__wrap__memalign_r( struct _reent *r, size_t a, size_t n ) { (void)r; return g_imp->memalign_( a, n ); }

/* ---- the port ---- */
void zzhl_pump_soon( void ) { g_imp->pump_soon(); }
unsigned long long zzhl_us64( void ) { return g_imp->us64(); }

/* ---- printf: the C99 'z' / 't' / 'j' length modifiers ----
 * The toolchain's newlib is built without them ("%zu" prints "zu").  The engine rewrites the
 * format before newlib sees it (xacp_libc.c, the same fix); the game image has its own newlib,
 * so the same few lines are here: size_t and ptrdiff_t are 32-bit (the modifier is dropped),
 * intmax_t is 64-bit ("ll"). */
extern int __real__svfprintf_r( struct _reent *, FILE *, const char *, va_list );
extern int __real__vfprintf_r( struct _reent *, FILE *, const char *, va_list );
static const char *c99_fmt( const char *fmt, char *buf, unsigned cap )
{
	const char *p;
	unsigned o = 0;
	int need = 0, in = 0;
	for( p = fmt; *p; p++ )
	{
		if( !in ) { if( *p == '%' ) in = 1; continue; }
		if( *p == '%' ) { in = 0; continue; }
		if( *p == 'z' || *p == 't' || *p == 'j' ) { need = 1; break; }
		if(( *p >= 'a' && *p <= 'z' ) || ( *p >= 'A' && *p <= 'Z' )) { if( *p != 'l' && *p != 'h' && *p != 'L' && *p != 'q' ) in = 0; }
	}
	if( !need ) return fmt;
	in = 0;
	for( p = fmt; *p; p++ )
	{
		if( o + 3 >= cap ) return fmt;
		if( !in ) { if( *p == '%' ) in = 1; buf[o++] = *p; continue; }
		if( *p == '%' ) { in = 0; buf[o++] = *p; continue; }
		if( *p == 'z' || *p == 't' ) continue;
		if( *p == 'j' ) { buf[o++] = 'l'; buf[o++] = 'l'; continue; }
		if(( *p >= 'a' && *p <= 'z' ) || ( *p >= 'A' && *p <= 'Z' )) { if( *p != 'l' && *p != 'h' && *p != 'L' && *p != 'q' ) in = 0; }
		buf[o++] = *p;
	}
	buf[o] = 0;
	return buf;
}
int __wrap__svfprintf_r( struct _reent *r, FILE *f, const char *fmt, va_list ap )
{
	char buf[1024];
	return __real__svfprintf_r( r, f, c99_fmt( fmt, buf, sizeof( buf )), ap );
}
int __wrap__vfprintf_r( struct _reent *r, FILE *f, const char *fmt, va_list ap )
{
	char buf[1024];
	return __real__vfprintf_r( r, f, c99_fmt( fmt, buf, sizeof( buf )), ap );
}

/* ---- the entry: the engine calls it once, after loading the image ---- */
extern zzhl_game_table_t lib_client_exports[];
extern zzhl_game_table_t lib_server_exports[];
extern void __libc_init_array( void );
int zzhl_game_entry( const zzhl_game_imports_t *imp, zzhl_game_exports_t *exp )
{
	if( !imp || imp->abi != ZZHL_GAME_ABI || imp->size < sizeof( *imp ) || !exp || exp->size < sizeof( *exp ))
		return -1;
	g_imp = imp;
	__libc_init_array();     /* the C++ constructors of the HLSDK and FreeVGUI globals, newlib init */
	exp->abi = ZZHL_GAME_ABI;
	exp->client = lib_client_exports;
	exp->server = lib_server_exports;
	return 0;
}
