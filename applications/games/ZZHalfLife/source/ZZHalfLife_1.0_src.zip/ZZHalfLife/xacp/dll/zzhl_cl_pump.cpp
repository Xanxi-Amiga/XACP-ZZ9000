/* SPDX-License-Identifier: 0BSD */
/*
 * zzhl_cl_pump.cpp - the GPU fed during the client's frame (see zzhl_sv_pump.cpp).
 *
 * The client library's export table (build_arm.sh, mklib overrides) gives the engine these entry points
 * in place of the hlsdk ones; each pumps (zzhl_pump_soon, rate-limited, Core1/zzhl_gpu.c) and calls the
 * hlsdk function unchanged.  Initialize also wraps the engine's random-number calls the client effects
 * use, and HUD_TempEntUpdate the callback it calls for every temporary entity (shells, debris, gibs).
 * 0BSD (Xanxi, 2026), like zzhl_sv_pump.cpp: no HLSDK code here, only its headers.
 */
#include "hud.h"
#include "cl_util.h"

extern "C" {
int Initialize( cl_enginefunc_t *pEnginefuncs, int iVersion );
int HUD_AddEntity( int type, struct cl_entity_s *ent, const char *modelname );
void HUD_StudioEvent( const struct mstudioevent_s *event, const struct cl_entity_s *entity );
void HUD_TxferLocalOverrides( struct entity_state_s *state, const struct clientdata_s *client );
void HUD_ProcessPlayerState( struct entity_state_s *dst, const struct entity_state_s *src );
void HUD_PlayerMove( struct playermove_s *ppmove, int server );
void HUD_PostRunCmd( struct local_state_s *from, struct local_state_s *to, struct usercmd_s *cmd, int runfuncs, double time, unsigned int random_seed );
void HUD_TempEntUpdate( double frametime, double client_time, double cl_gravity, struct tempent_s **ppTempEntFree, struct tempent_s **ppTempEntActive, int ( *Callback_AddVisibleEntity )( struct cl_entity_s *pEntity ), void ( *Callback_TempEntPlaySound )( struct tempent_s *pTemp, float damp ) );
void zzhl_pump_soon( void );
}

static cl_enginefunc_t s_cl;
static float ( *r_RandomFloat )( float, float );
static int ( *r_RandomLong )( int, int );
static float w_RandomFloat( float lo, float hi ) { zzhl_pump_soon(); return r_RandomFloat( lo, hi ); }
static int w_RandomLong( int lo, int hi ) { zzhl_pump_soon(); return r_RandomLong( lo, hi ); }

extern "C" int zzhl_cl_Initialize( cl_enginefunc_t *pEnginefuncs, int iVersion )
{
	s_cl = *pEnginefuncs;
	r_RandomFloat = s_cl.pfnRandomFloat; if( r_RandomFloat ) s_cl.pfnRandomFloat = w_RandomFloat;
	r_RandomLong = s_cl.pfnRandomLong; if( r_RandomLong ) s_cl.pfnRandomLong = w_RandomLong;
	return Initialize( &s_cl, iVersion );
}
extern "C" int zzhl_cl_HUD_AddEntity( int type, struct cl_entity_s *ent, const char *modelname ) { zzhl_pump_soon(); return HUD_AddEntity( type, ent, modelname ); }
extern "C" void zzhl_cl_HUD_StudioEvent( const struct mstudioevent_s *event, const struct cl_entity_s *entity ) { zzhl_pump_soon(); HUD_StudioEvent( event, entity ); }
extern "C" void zzhl_cl_HUD_TxferLocalOverrides( struct entity_state_s *state, const struct clientdata_s *client ) { zzhl_pump_soon(); HUD_TxferLocalOverrides( state, client ); }
extern "C" void zzhl_cl_HUD_ProcessPlayerState( struct entity_state_s *dst, const struct entity_state_s *src ) { zzhl_pump_soon(); HUD_ProcessPlayerState( dst, src ); }
extern "C" void zzhl_cl_HUD_PlayerMove( struct playermove_s *ppmove, int server ) { zzhl_pump_soon(); HUD_PlayerMove( ppmove, server ); }
extern "C" void zzhl_cl_HUD_PostRunCmd( struct local_state_s *from, struct local_state_s *to, struct usercmd_s *cmd, int runfuncs, double time, unsigned int random_seed ) { zzhl_pump_soon(); HUD_PostRunCmd( from, to, cmd, runfuncs, time, random_seed ); }

static int ( *r_AddVisible )( struct cl_entity_s *pEntity );
static int w_AddVisible( struct cl_entity_s *pEntity ) { zzhl_pump_soon(); return r_AddVisible( pEntity ); }
extern "C" void zzhl_cl_HUD_TempEntUpdate( double frametime, double client_time, double cl_gravity, struct tempent_s **ppTempEntFree, struct tempent_s **ppTempEntActive, int ( *Callback_AddVisibleEntity )( struct cl_entity_s *pEntity ), void ( *Callback_TempEntPlaySound )( struct tempent_s *pTemp, float damp ) )
{
	zzhl_pump_soon();
	if( Callback_AddVisibleEntity && Callback_AddVisibleEntity != w_AddVisible ) { r_AddVisible = Callback_AddVisibleEntity; Callback_AddVisibleEntity = w_AddVisible; }
	HUD_TempEntUpdate( frametime, client_time, cl_gravity, ppTempEntFree, ppTempEntActive, Callback_AddVisibleEntity, Callback_TempEntPlaySound );
}
