/* zzhl_menu_wrap.cpp - the menu's (FWGS mainui) export GetMenuAPI goes through
 * here (xacp/dll/menu_overrides.txt, build_arm.sh mklib), which hands mainui a copy of the
 * engine's function table where pfnGetSaveComment tells the file layer that the save opened next
 * is only looked at: xacp_fs.c then serves its first bytes from the disk by READAT instead of
 * reading the whole save into memory (each save of the menu's list, up to ~2.8 MiB, for one line).
 * Loading a save does not pass here: read whole and checked (CRC) as before.  Both game-info
 * calls (GetMenuAPI's and GetExtAPI's) say "single player only": no network in this build, the
 * Multiplayer button is greyed out as for such a game.  Without a liblist.gam in PROGDIR:data/ the
 * engine's defaults name the game "valve" with no training map: for valve/, "Half-Life" and t0a0
 * (Steam's liblist.gam), so the main menu has its title and its Hazard Course.  Build 52, for the
 * RasterIX texture memory (16 MiB, the menu's textures stay loaded while the game runs; 13.7 MiB of
 * them on the A4000 on 12/11, the map's sky and HUD refused): no HD background (the dozens of 21:9
 * tiles of the 25th anniversary update; resource/BackgroundLayout.txt instead, the 512 x 384 one
 * that tools/hl_menubg.py makes in pak1.pak) and the buttons written with the menu's font
 * (GFL_RENDER_PICBUTTON_TEXT) instead of the btns_main.bmp pictures.
 * SPDX-License-Identifier: GPL-2.0-or-later (as mainui)
 * ASCII only. */
#include "extdll_menu.h"
#include "menu_int.h"
#include <string.h>

extern "C" int GetMenuAPI( UI_FUNCTIONS *pFunctionTable, ui_enginefuncs_t *pEngfuncsFromEngine, ui_globalvars_t *pGlobals );
extern "C" int GetExtAPI( int version, UI_EXTENDED_FUNCTIONS *pFunctionTable, ui_extendedfuncs_t *pEngfuncsFromEngine );
extern "C" void xacp_fs_save_peek( int on );

static int ( *g_real_comment )( const char *savename, char *comment );
static int ( *g_real_gameinfo )( GAMEINFO *pgameinfo );
static gameinfo2_t *( *g_real_gameinfo2 )( int gi_version );
static ui_enginefuncs_t g_ef;
static ui_extendedfuncs_t g_xf;
static gameinfo2_t g_gi2;

/* the flags of the menu's look, see the head of this file */
static unsigned zzhl_flags( unsigned flags )
{
	return ( flags & ~(unsigned)GFL_HD_BACKGROUND ) | GFL_RENDER_PICBUTTON_TEXT;
}
static void valve_defaults( const char *folder, char *title, char *trainmap )
{
	if( strcmp( folder, "valve" )) return;
	if( !title[0] || !strcmp( title, "valve" )) strcpy( title, "Half-Life" );
	if( !trainmap[0] ) strcpy( trainmap, "t0a0" );
}
static int zzhl_game_info( GAMEINFO *pgameinfo )
{
	int r = g_real_gameinfo ? g_real_gameinfo( pgameinfo ) : 0;
	if( r && pgameinfo )
	{
		pgameinfo->gamemode = GAME_SINGLEPLAYER_ONLY;
		pgameinfo->flags = (short)zzhl_flags( (unsigned short)pgameinfo->flags );
		valve_defaults( pgameinfo->gamefolder, pgameinfo->title, pgameinfo->trainmap );
	}
	return r;
}
static gameinfo2_t *zzhl_game_info2( int gi_version )
{
	gameinfo2_t *g = g_real_gameinfo2 ? g_real_gameinfo2( gi_version ) : NULL;
	if( !g ) return NULL;
	g_gi2 = *g;
	g_gi2.gamemode = GAME_SINGLEPLAYER_ONLY;
	g_gi2.flags = zzhl_flags( g_gi2.flags );
	valve_defaults( g_gi2.gamefolder, g_gi2.title, g_gi2.trainmap );
	return &g_gi2;
}

static int zzhl_save_comment( const char *savename, char *comment )
{
	int r;
	xacp_fs_save_peek( 1 );
	r = g_real_comment ? g_real_comment( savename, comment ) : 0;
	xacp_fs_save_peek( 0 );
	return r;
}

extern "C" int zzhl_GetMenuAPI( UI_FUNCTIONS *pFunctionTable, ui_enginefuncs_t *pEngfuncsFromEngine, ui_globalvars_t *pGlobals )
{
	if( pEngfuncsFromEngine )
	{
		g_ef = *pEngfuncsFromEngine;
		g_real_comment = g_ef.pfnGetSaveComment;
		g_ef.pfnGetSaveComment = zzhl_save_comment;
		g_real_gameinfo = g_ef.pfnGetGameInfo;
		g_ef.pfnGetGameInfo = zzhl_game_info;
		pEngfuncsFromEngine = &g_ef;
	}
	return GetMenuAPI( pFunctionTable, pEngfuncsFromEngine, pGlobals );
}

extern "C" int zzhl_GetExtAPI( int version, UI_EXTENDED_FUNCTIONS *pFunctionTable, ui_extendedfuncs_t *pEngfuncsFromEngine )
{
	if( pEngfuncsFromEngine )
	{
		g_xf = *pEngfuncsFromEngine;
		g_real_gameinfo2 = g_xf.pfnGetGameInfo;
		g_xf.pfnGetGameInfo = zzhl_game_info2;
		pEngfuncsFromEngine = &g_xf;
	}
	return GetExtAPI( version, pFunctionTable, pEngfuncsFromEngine );
}
