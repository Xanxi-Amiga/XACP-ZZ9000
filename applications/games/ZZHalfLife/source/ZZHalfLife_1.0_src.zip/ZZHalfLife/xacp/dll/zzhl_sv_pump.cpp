/* SPDX-License-Identifier: 0BSD */
/*
 * zzhl_sv_pump.cpp - the GPU fed during the server's frame.
 *
 * With pipelined frames (build 32) the GPU still draws frame N while Core1 runs the engine's logic for
 * N+1.  Every texture bind in the GPU stops it until Core1 pumps the deferred queue (librixgpu rule 11),
 * and up to build 34 nothing pumped between the end of a frame and the first GL call of the next: the
 * engine's server, client and sound ran with the GPU waiting at its next bind.  The engine sources stay
 * upstream; instead the export table of the server library (build_arm.sh, mklib overrides) gives the
 * engine these two entry points in place of the hlsdk ones.  They call the hlsdk functions unchanged,
 * after wrapping a few of the calls the game logic makes all the time (traces, entity searches,
 * random numbers, think and touch) with zzhl_pump_soon (Core1/zzhl_gpu.c: a pump when events are
 * queued and 25 us have passed since the last one; nothing otherwise).  ENGPUMP=0 turns it off.
 *
 * Built into the server library with the hlsdk's own flags; zzhl_* symbols are not exports.
 * 0BSD (Xanxi, 2026): no code of the HLSDK here, only its headers, so that this file adds no licence
 * terms of its own to the game library it is linked into (see docs/AUDIT.md for the HLSDK licence).
 */
#include "extdll.h"

extern "C" void GiveFnptrsToDll( enginefuncs_t *pengfuncsFromEngine, globalvars_t *pGlobals );
extern "C" int GetEntityAPI2( DLL_FUNCTIONS *pFunctionTable, int *interfaceVersion );
extern "C" void zzhl_pump_soon( void );

static enginefuncs_t s_eng;
static void ( *r_TraceLine )( const float *, const float *, int, edict_t *, TraceResult * );
static void ( *r_TraceToss )( edict_t *, edict_t *, TraceResult * );
static int ( *r_TraceMonsterHull )( edict_t *, const float *, const float *, int, edict_t *, TraceResult * );
static void ( *r_TraceHull )( const float *, const float *, int, int, edict_t *, TraceResult * );
static void ( *r_TraceModel )( const float *, const float *, int, edict_t *, TraceResult * );
static edict_t *( *r_FindEntityInSphere )( edict_t *, const float *, float );
static void ( *r_MakeVectors )( const float * );
static int ( *r_PointContents )( const float * );
static int ( *r_RandomLong )( int, int );
static float ( *r_RandomFloat )( float, float );

static void w_TraceLine( const float *v1, const float *v2, int nm, edict_t *skip, TraceResult *tr ) { zzhl_pump_soon(); r_TraceLine( v1, v2, nm, skip, tr ); }
static void w_TraceToss( edict_t *e, edict_t *ign, TraceResult *tr ) { zzhl_pump_soon(); r_TraceToss( e, ign, tr ); }
static int w_TraceMonsterHull( edict_t *e, const float *v1, const float *v2, int nm, edict_t *skip, TraceResult *tr ) { zzhl_pump_soon(); return r_TraceMonsterHull( e, v1, v2, nm, skip, tr ); }
static void w_TraceHull( const float *v1, const float *v2, int nm, int hull, edict_t *skip, TraceResult *tr ) { zzhl_pump_soon(); r_TraceHull( v1, v2, nm, hull, skip, tr ); }
static void w_TraceModel( const float *v1, const float *v2, int hull, edict_t *e, TraceResult *tr ) { zzhl_pump_soon(); r_TraceModel( v1, v2, hull, e, tr ); }
static edict_t *w_FindEntityInSphere( edict_t *after, const float *org, float rad ) { zzhl_pump_soon(); return r_FindEntityInSphere( after, org, rad ); }
static void w_MakeVectors( const float *v ) { zzhl_pump_soon(); r_MakeVectors( v ); }
static int w_PointContents( const float *v ) { zzhl_pump_soon(); return r_PointContents( v ); }
static int w_RandomLong( int lo, int hi ) { zzhl_pump_soon(); return r_RandomLong( lo, hi ); }
static float w_RandomFloat( float lo, float hi ) { zzhl_pump_soon(); return r_RandomFloat( lo, hi ); }

#define WRAP( f ) do { r_##f = s_eng.pfn##f; if( r_##f ) s_eng.pfn##f = w_##f; } while( 0 )
extern "C" void zzhl_sv_GiveFnptrsToDll( enginefuncs_t *pengfuncsFromEngine, globalvars_t *pGlobals )
{
	s_eng = *pengfuncsFromEngine;
	WRAP( TraceLine ); WRAP( TraceToss ); WRAP( TraceMonsterHull ); WRAP( TraceHull ); WRAP( TraceModel );
	WRAP( FindEntityInSphere ); WRAP( MakeVectors ); WRAP( PointContents ); WRAP( RandomLong ); WRAP( RandomFloat );
	GiveFnptrsToDll( &s_eng, pGlobals );
}
#undef WRAP

/* the engine's calls into the game: think and touch, the two it makes per entity */
static void ( *r_Think )( edict_t * );
static void ( *r_Touch )( edict_t *, edict_t * );
static void w_Think( edict_t *e ) { zzhl_pump_soon(); r_Think( e ); }
static void w_Touch( edict_t *a, edict_t *b ) { zzhl_pump_soon(); r_Touch( a, b ); }
extern "C" int zzhl_sv_GetEntityAPI2( DLL_FUNCTIONS *pFunctionTable, int *interfaceVersion )
{
	int rc = GetEntityAPI2( pFunctionTable, interfaceVersion );
	if( rc && pFunctionTable )
	{
		if( pFunctionTable->pfnThink && pFunctionTable->pfnThink != w_Think ) { r_Think = pFunctionTable->pfnThink; pFunctionTable->pfnThink = w_Think; }
		if( pFunctionTable->pfnTouch && pFunctionTable->pfnTouch != w_Touch ) { r_Touch = pFunctionTable->pfnTouch; pFunctionTable->pfnTouch = w_Touch; }
	}
	return rc;
}
